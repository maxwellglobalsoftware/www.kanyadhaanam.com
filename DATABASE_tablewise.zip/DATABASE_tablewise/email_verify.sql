-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 16, 2019 at 12:49 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kanya3w90_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `email_verify`
--

CREATE TABLE `email_verify` (
  `id` int(11) NOT NULL,
  `pl_userId` varchar(100) DEFAULT NULL,
  `pl_primary_email` varchar(100) DEFAULT NULL,
  `pl_primary_code` varchar(200) DEFAULT NULL,
  `pl_primary_status` varchar(200) DEFAULT NULL,
  `reg_date` varchar(200) DEFAULT NULL,
  `reg_time` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `email_verify`
--

INSERT INTO `email_verify` (`id`, `pl_userId`, `pl_primary_email`, `pl_primary_code`, `pl_primary_status`, `reg_date`, `reg_time`) VALUES
(1, '190313', 'nivetha@maxwellglobalsoftware.com', '', 'yes', '09-03-2019', '03:20 PM'),
(2, '19031', 'gnaritustechchennai@gmail.com', '97609', 'no', '26-03-2019', '04:30 AM'),
(3, '190365', 'sai.24@gmail.com', '62225', 'no', '28-03-2019', '03:53 AM'),
(4, '190354', 'kalaivani@maxwellglobalsoftware.com', '71333', 'yes', '28-03-2019', '05:08 AM'),
(5, '190352', 'pradmanabhan@yahoo.com', '', 'yes', '30-03-2019', '05:11 PM'),
(6, '19043', 'rameshnr54@gmail.com', '96282', 'no', '11-04-2019', '11:27 AM'),
(7, '19045', 'kumar.aircel@rediffmail.com', '', 'yes', '12-04-2019', '01:55 PM'),
(8, '19048', 'rangarajan_50@yahoo.com', '', 'yes', '18-04-2019', '08:17 PM'),
(9, '190415', 'sureshchu777@gmail.com', '', 'yes', '24-04-2019', '07:19 AM'),
(10, '190417', 'vasudevanbnr@yahoo.com', '', 'yes', '25-04-2019', '05:15 PM'),
(11, '190418', 'subirajan1970@yahoo.co.in', '', 'yes', '25-04-2019', '06:21 PM'),
(12, '190421', 'Seechu@yahoo.com', '', 'yes', '27-04-2019', '07:35 PM'),
(13, '190430', 'sudhasimmhatp@yahoo.co.in', '', 'yes', '30-04-2019', '11:02 AM'),
(14, '19054', 'nrkrishnan.iyengar@yahoo.com', '', 'yes', '02-05-2019', '10:07 PM'),
(15, '19057', 'krishsrinivasan07@yahoo.com', '', 'yes', '05-05-2019', '07:22 PM'),
(16, '19058', 'thirumalaib@yahoo.com', '', 'yes', '05-05-2019', '11:12 PM'),
(17, '19059', 'SANTHANAM_DGVC@YAHOO.COM', '', 'yes', '06-05-2019', '01:18 PM'),
(18, '190350', 'kiruthiga@maxwellglobalsoftware.com', '62282', 'no', '09-05-2019', '12:56 PM'),
(19, '190513', 'SNRAMCHANDRAN@REDIFFMAIL.COM', '', 'yes', '12-05-2019', '11:20 AM'),
(20, '190510', 'arunganesh92@gmail.com', '43967', 'no', '14-05-2019', '06:45 PM');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `email_verify`
--
ALTER TABLE `email_verify`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `email_verify`
--
ALTER TABLE `email_verify`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
