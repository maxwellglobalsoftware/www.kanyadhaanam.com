-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 16, 2019 at 12:49 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kanya3w90_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `horoscope_details`
--

CREATE TABLE `horoscope_details` (
  `id` int(11) NOT NULL,
  `hs_userId` int(11) NOT NULL,
  `hs_imgPath` varchar(256) NOT NULL,
  `reg_date` date NOT NULL,
  `reg_time` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `horoscope_details`
--

INSERT INTO `horoscope_details` (`id`, `hs_userId`, `hs_imgPath`, `reg_date`, `reg_time`) VALUES
(2, 190312, 'Kanya@Prof/jathagam/190312_190222_horo.png', '2019-03-26', '01:07:54'),
(3, 19031, 'Kanya@Prof/jathagam/19031_IMG-20190319-WA0002.jpg', '2019-03-26', '01:12:30'),
(5, 1903109, 'Kanya@Prof/jathagam/1903109_19041_horo.jpg', '2019-04-05', '06:45:12'),
(6, 19043, 'Kanya@Prof/jathagam/19043_19043-horos.jpg', '2019-04-11', '07:17:10'),
(7, 190253, 'Kanya@Prof/jathagam/190253_190253_horos.jpg', '2019-04-23', '23:59:33'),
(8, 190415, 'Kanya@Prof/jathagam/190415_190415_horo.jpg', '2019-04-24', '00:10:29'),
(9, 190416, 'Kanya@Prof/jathagam/190416_190416-hgor.jpg', '2019-04-24', '00:44:24'),
(10, 190429, 'Kanya@Prof/jathagam/190429_190429_horo.jpg', '2019-04-30', '00:44:58'),
(11, 19054, 'Kanya@Prof/jathagam/19054_19054_horo.jpg', '2019-05-04', '08:06:50'),
(12, 19042, 'Kanya@Prof/jathagam/19042_19042_horo.jpg', '2019-05-04', '08:13:17'),
(13, 19053, 'Kanya@Prof/jathagam/19053_19053_horo.jpg', '2019-05-04', '08:18:43'),
(14, 19057, 'Kanya@Prof/jathagam/19057_19057_hor.jpg', '2019-05-06', '01:43:44'),
(15, 190350, 'Kanya@Prof/jathagam/190350_190350_horo.jpg', '2019-05-06', '09:29:43'),
(16, 190426, 'Kanya@Prof/jathagam/190426_190426_hrs.jpg', '2019-05-09', '09:11:48'),
(17, 19051, 'Kanya@Prof/jathagam/19051_19051_hrs.jpg', '2019-05-09', '09:23:23'),
(18, 190514, 'Kanya@Prof/jathagam/190514_190514_hrs.jpg', '2019-05-13', '03:52:54'),
(19, 190513, 'Kanya@Prof/jathagam/190513_190513_hrs.jpg', '2019-05-13', '06:36:08'),
(20, 190516, 'Kanya@Prof/jathagam/190516_190516_hrs.jpg', '2019-05-15', '05:56:12'),
(21, 190223, 'Kanya@Prof/jathagam/190223_190223_Hrs.jpg', '2019-05-15', '08:36:13'),
(22, 190421, 'Kanya@Prof/jathagam/190421_190421_horo.jpg', '2019-05-15', '09:06:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `horoscope_details`
--
ALTER TABLE `horoscope_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `horoscope_details`
--
ALTER TABLE `horoscope_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
