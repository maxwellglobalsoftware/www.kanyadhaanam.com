-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 16, 2019 at 12:49 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kanya3w90_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `interest_profiles`
--

CREATE TABLE `interest_profiles` (
  `id` int(11) NOT NULL,
  `pl_userId` varchar(200) NOT NULL,
  `pv_viewedId` varchar(200) NOT NULL,
  `interest` varchar(200) DEFAULT NULL,
  `pl_viewedDate` varchar(200) NOT NULL,
  `reg_date` date NOT NULL,
  `reg_time` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `interest_profiles`
--

INSERT INTO `interest_profiles` (`id`, `pl_userId`, `pv_viewedId`, `interest`, `pl_viewedDate`, `reg_date`, `reg_time`) VALUES
(1, '190313', '190312', 'I am interested in your profile. Please Accept if you are interested.', '2019-03-21', '2019-03-21', '03:28:46'),
(2, '19031', '19037', ' We liked your profile and interested to take it forward. Please reply at the earliest.', '2019-03-26', '2019-03-26', '00:39:02'),
(3, '19031', '190311', 'We find a good life partner in you for our friend. Please reply to proceed further.', '2019-03-26', '2019-03-26', '00:42:06'),
(4, '190312', '190313', 'I am interested in your profile. Please Accept if you are interested.', '2019-03-26', '2019-03-26', '01:10:31'),
(5, '190354', '1903110', 'I am interested in your profile. Please Accept if you are interested.', '2019-03-28', '2019-03-28', '01:22:59'),
(6, '190352', '190354', 'I am interested in your profile. Please Accept if you are interested.', '2019-03-28', '2019-03-28', '01:33:43'),
(7, '190415', '190413', 'You seem to be the kind of person who suits our family. We would like to contact your parents to proceed further.', '2019-04-24', '2019-04-23', '22:27:48'),
(8, '190415', '19021', 'I am interested in your profile. Please Accept if you are interested.', '2019-04-24', '2019-04-23', '22:28:34'),
(9, '190415', '190223', 'I am interested in your profile. Please Accept if you are interested.', '2019-04-24', '2019-04-23', '22:29:20'),
(10, '190415', '190365', 'I am interested in your profile. Please Accept if you are interested.', '2019-04-24', '2019-04-23', '22:46:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `interest_profiles`
--
ALTER TABLE `interest_profiles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `interest_profiles`
--
ALTER TABLE `interest_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
