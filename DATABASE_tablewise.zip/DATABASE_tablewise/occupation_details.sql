-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 16, 2019 at 12:50 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kanya3w90_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `occupation_details`
--

CREATE TABLE `occupation_details` (
  `id` int(11) NOT NULL,
  `occupation` varchar(600) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `occupation_details`
--

INSERT INTO `occupation_details` (`id`, `occupation`) VALUES
(1, 'Accountant'),
(2, 'Acting Prof'),
(3, 'Actor'),
(4, 'Administration Prof'),
(5, 'Advertising Visualiser'),
(6, 'Advocate'),
(7, 'Air Hostess'),
(8, 'Airlines'),
(9, 'Architect'),
(10, 'Archakar'),
(11, 'Artisan'),
(12, 'Audiologist'),
(13, 'Banker'),
(14, 'Beautician'),
(15, 'Biologist Botanist'),
(16, 'Business Person'),
(17, 'Chartered Accountant'),
(18, 'Chef'),
(19, 'Chemist'),
(20, 'Central Government'),
(21, 'Civil Engineer'),
(22, 'Clerical Official'),
(23, 'Commercial Pilot'),
(24, 'Company Secretary'),
(25, 'Computer Prof'),
(26, 'Consultant'),
(27, 'Contractor'),
(28, 'Cost Accountant'),
(29, 'Creative Person'),
(30, 'Customer Support Prof'),
(31, 'Defence Employee'),
(32, 'Dentist'),
(33, 'Designer'),
(34, 'Doctor'),
(35, 'Economist'),
(36, 'Educationist'),
(37, 'Engineer'),
(38, 'Engineer Mechanical'),
(39, 'Engineer Project'),
(40, 'Entertainment Prof'),
(41, 'Event Manager'),
(42, 'Executive'),
(43, 'Factory worker'),
(44, 'Farmer'),
(45, 'Fashion Designer'),
(46, 'Finance Prof'),
(47, 'Flight Attendant'),
(48, 'Freelancer'),
(49, 'Government Employee'),
(50, 'Health Care Prof'),
(51, 'Home Maker'),
(52, 'Hotel Prof'),
(53, 'IAS Allied Services'),
(54, 'IT Telecom Prof'),
(55, 'Industrialist'),
(56, 'Interior Designer'),
(57, 'Investment Prof'),
(58, 'Jeweler'),
(59, 'Jewelry Designer'),
(60, 'Journalist'),
(61, 'Law Enforcement'),
(62, 'Lawyer'),
(63, 'Lecturer'),
(64, 'Legal Prof'),
(65, 'Management'),
(66, 'Manager'),
(67, 'Marketing'),
(68, 'Media Prof'),
(69, 'Medical Prof'),
(70, 'Medical Transcriptionist'),
(71, 'Merchant Naval Officer'),
(72, 'Modeling'),
(73, 'Non Mainstream Prof'),
(74, 'Not Working'),
(75, 'Nurse'),
(76, 'Occupational Therapist'),
(77, 'Officer'),
(78, 'Optician'),
(79, 'Pharmacist'),
(80, 'Physician Assistant'),
(81, 'Physicist'),
(82, 'Physiotherapist'),
(83, 'Pilot'),
(84, 'Politician'),
(85, 'Production Prof'),
(86, 'Professor'),
(87, 'Psychologist'),
(88, 'Public Relations Prof'),
(89, 'Real Estate Prof'),
(90, 'Receptionist'),
(91, 'Research Scholar'),
(92, 'Retail Prof'),
(93, 'Retired Person'),
(94, 'Sales Prof'),
(95, 'Scientist'),
(96, 'Secretary'),
(97, 'Self Employed Person'),
(98, 'Shipping'),
(99, 'Social Worker'),
(100, 'Software Engineer'),
(101, 'Sportsman'),
(102, 'State Government'),
(103, 'Student'),
(104, 'Teacher'),
(105, 'Technician'),
(106, 'Training Prof'),
(107, 'Transportation Prof'),
(108, 'Tutor'),
(109, 'Veterinary Doctor'),
(110, 'Volunteer'),
(111, 'Web Designer'),
(112, 'Writer'),
(113, 'Others'),
(114, 'Zoologist'),
(115, 'Unemployed');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `occupation_details`
--
ALTER TABLE `occupation_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `occupation_details`
--
ALTER TABLE `occupation_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
