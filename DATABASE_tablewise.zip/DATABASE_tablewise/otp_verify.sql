-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 16, 2019 at 12:50 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kanya3w90_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `otp_verify`
--

CREATE TABLE `otp_verify` (
  `id` int(11) NOT NULL,
  `pl_userId` varchar(100) DEFAULT NULL,
  `pl_primary_mobile` varchar(300) DEFAULT NULL,
  `pl_primary_code` varchar(300) DEFAULT NULL,
  `pl_primary_status` varchar(300) DEFAULT NULL,
  `pl_secondary_mobile` varchar(300) DEFAULT NULL,
  `pl_secondary_code` varchar(300) DEFAULT NULL,
  `pl_secondary_status` varchar(300) DEFAULT NULL,
  `reg_date` varchar(300) DEFAULT NULL,
  `reg_time` varchar(300) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `otp_verify`
--

INSERT INTO `otp_verify` (`id`, `pl_userId`, `pl_primary_mobile`, `pl_primary_code`, `pl_primary_status`, `pl_secondary_mobile`, `pl_secondary_code`, `pl_secondary_status`, `reg_date`, `reg_time`) VALUES
(1, '19031', '', '', '', '1234567890', '90076', 'no', '08-03-2019', '01:21 AM'),
(2, '19031', '9500090825', '79445', 'no', '', '', '', '26-03-2019', '04:30 AM'),
(3, '19031', '', '', '', '9159730194', '90353', 'no', '26-03-2019', '04:31 AM'),
(4, '190354', '9597062642', '66856', 'no', '', '', '', '28-03-2019', '05:09 AM'),
(5, '1903109', '', '', '', '9486390726', '50299', 'no', '05-04-2019', '12:55 PM'),
(6, '19043', '8762998675', '92025', 'no', '', '', '', '11-04-2019', '11:37 AM'),
(7, '19043', '', '', '', '9972128247', '73668', 'no', '11-04-2019', '11:38 AM'),
(8, '190415', '8886114281', '52443', 'no', '', '', '', '24-04-2019', '02:18 AM'),
(9, '19054', '9900113913', '67991', 'no', '', '', '', '05-05-2019', '06:20 PM'),
(10, '190350', '9500090825', '46034', 'no', '', '', '', '09-05-2019', '12:54 PM'),
(11, '190350', '', '', '', '9080737072', '76834', 'no', '09-05-2019', '12:55 PM');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `otp_verify`
--
ALTER TABLE `otp_verify`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `otp_verify`
--
ALTER TABLE `otp_verify`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
