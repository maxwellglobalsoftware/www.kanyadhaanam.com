-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 16, 2019 at 12:50 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kanya3w90_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `partner_preferences`
--

CREATE TABLE `partner_preferences` (
  `id` int(11) NOT NULL,
  `pl_userId` varchar(200) NOT NULL,
  `age_from` varchar(200) NOT NULL,
  `age_to` varchar(200) NOT NULL,
  `education` varchar(200) DEFAULT NULL,
  `star` varchar(200) DEFAULT NULL,
  `reg_date` varchar(200) NOT NULL,
  `reg_time` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `partner_preferences`
--

INSERT INTO `partner_preferences` (`id`, `pl_userId`, `age_from`, `age_to`, `education`, `star`, `reg_date`, `reg_time`) VALUES
(1, '190313', '21', '27', '55,23,1,57,39,29,71', 'Anuradha / Anusham / Anizham,Jyesta / Kettai,Krithika / Karthika,Pushya / Poosam / Pooyam,Shatataraka / Sadayam / Satabishek,Uttarabadrapada / Uthratadhi', '12-03-2019', '03:04 AM'),
(2, '19031', '21', '40', '16,17', 'Ardra / Thiruvathira,Ashlesha / Ayilyam,Ashwini / Ashwathi,Chitra / Chitha,Moolam / Moola', '26-03-2019', '04:48 AM'),
(3, '190312', '21', '30', '4,28', 'Ashwini / Ashwathi,Bharani,Chitra / Chitha', '26-03-2019', '05:19 AM'),
(4, '1903109', '27', '32', '50', 'Anuradha / Anusham / Anizham,Ardra / Thiruvathira,Bharani,Jyesta / Kettai,Poorvapalguni / Puram / Pubbhe,Pushya / Poosam / Pooyam,Shatataraka / Sadayam / Satabishek,Shravan / Thiruvona,Swati / Chothi', '15-04-2019', '01:24 PM'),
(5, '1903110', '28', '30', '13,56,71,72,74', 'Anuradha / Anusham / Anizham,Ardra / Thiruvathira,Chitra / Chitha,Dhanista / Avittam,Hastha / Atham,Krithika / Karthika,Makha / Magam,Mrigasira / Makayiram,Poorvabadrapada / Puratathi,Poorvapalguni / ', '07-04-2019', '03:59 PM'),
(6, '19053', '25', '30', '21,39,42,71,72,74,79', 'Anuradha / Anusham / Anizham,Ashlesha / Ayilyam,Bharani,Chitra / Chitha,Dhanista / Avittam,Hastha / Atham,Jyesta / Kettai,Krithika / Karthika,Mrigasira / Makayiram,Poorvapalguni / Puram / Pubbhe,Poorv', '08-05-2019', '02:59 PM'),
(7, '190350', '21', '30', '74,77', 'Anuradha / Anusham / Anizham,Jyesta / Kettai', '09-05-2019', '12:47 PM'),
(8, '190513', '24', '29', '13,21,51,25,39,42,33,56,59,71,74', 'Ardra / Thiruvathira,Mrigasira / Makayiram', '13-05-2019', '03:00 PM'),
(9, '190513', '24', '29', '13,21,51,25,39,42,33,56,59,71,74', 'Ardra / Thiruvathira,Mrigasira / Makayiram', '13-05-2019', '03:00 PM'),
(10, '190513', '24', '29', '13,21,51,25,39,42,33,56,59,71,74', 'Ardra / Thiruvathira,Mrigasira / Makayiram', '14-05-2019', '01:56 AM'),
(11, '190516', '21', '26', '', 'Anuradha / Anusham / Anizham,Ashwini / Ashwathi,Dhanista / Avittam,Krithika / Karthika,Makha / Magam,Moolam / Moola,Mrigasira / Makayiram,Poorvabadrapada / Puratathi,Punarvasu / Punarpusam,Pushya / Po', '15-05-2019', '09:58 AM'),
(12, '190515', '26', '30', '13,51,45,53,56,74,79', 'Anuradha / Anusham / Anizham,Ashlesha / Ayilyam,Bharani,Makha / Magam,Punarvasu / Punarpusam,Shatataraka / Sadayam / Satabishek,Swati / Chothi', '15-05-2019', '11:35 AM');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `partner_preferences`
--
ALTER TABLE `partner_preferences`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `partner_preferences`
--
ALTER TABLE `partner_preferences`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
