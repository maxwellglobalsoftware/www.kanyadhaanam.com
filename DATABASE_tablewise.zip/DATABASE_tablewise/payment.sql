-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 16, 2019 at 12:50 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kanya3w90_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `pl_userId` int(11) NOT NULL,
  `pl_name` varchar(10) NOT NULL,
  `pl_amount` int(11) NOT NULL,
  `pl_startDate` date NOT NULL,
  `pl_paidDate` date NOT NULL,
  `pl_status` enum('activate','deactivate') NOT NULL,
  `pl_remarks` text NOT NULL,
  `pl_expireDate` date NOT NULL,
  `pl_enteredBy` int(11) NOT NULL,
  `reg_date` date NOT NULL,
  `reg_time` time NOT NULL,
  `txn_id` varchar(200) DEFAULT NULL,
  `payment_mode` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `pl_userId`, `pl_name`, `pl_amount`, `pl_startDate`, `pl_paidDate`, `pl_status`, `pl_remarks`, `pl_expireDate`, `pl_enteredBy`, `reg_date`, `reg_time`, `txn_id`, `payment_mode`) VALUES
(1, 190313, 'Starter', 1000, '2019-03-12', '2019-03-12', 'activate', 'online', '2019-06-10', 1, '2019-03-12', '12:06:53', '', 'online'),
(2, 190313, 'Starter', 1000, '2019-03-21', '2019-03-21', 'activate', 'testing', '2019-04-20', 1, '2019-03-21', '10:25:05', '', 'online'),
(3, 19031, 'Starter', 1000, '2019-03-26', '2019-03-26', 'activate', 'v', '2019-04-25', 1, '2019-03-26', '10:06:14', '', 'chennai office'),
(4, 190312, 'Starter', 1000, '2019-03-26', '2019-03-26', 'activate', 'v', '2019-04-25', 1, '2019-03-26', '10:38:57', '', 'chennai office'),
(5, 190365, 'Starter', 1000, '2019-03-27', '2019-03-27', 'activate', 'testing', '2019-04-26', 1, '2019-03-27', '18:56:12', '', 'online'),
(6, 190354, 'Starter', 1000, '2019-03-28', '2019-03-28', 'activate', 'testing', '2019-04-27', 1, '2019-03-28', '10:51:18', '', 'online'),
(7, 190352, 'Starter', 1000, '2019-03-28', '2019-03-28', 'activate', 'testing', '2019-04-27', 1, '2019-03-28', '11:03:32', '', 'online'),
(8, 1903109, 'Starter', 1000, '2019-04-05', '2019-04-05', 'activate', 'paid', '2019-05-05', 1, '2019-04-05', '18:45:07', '745c845c4f248f2b498e', 'online'),
(9, 190415, 'Starter', 1000, '2019-04-24', '2019-04-24', 'activate', 'paid', '2019-05-24', 1, '2019-04-24', '07:53:23', '84f928868390304326bd', 'online'),
(10, 190429, 'Starter', 1000, '2019-04-30', '2019-04-30', 'activate', 'paid', '2019-05-30', 1, '2019-04-30', '10:19:35', 'c9e92296623bf9d2e06d', 'online'),
(11, 19053, 'Starter', 1000, '2019-05-05', '2019-05-05', 'activate', 'paid', '2019-06-04', 1, '2019-05-05', '17:29:18', '1f3a7ba0089093e11bad', 'online'),
(12, 190350, 'Starter', 1000, '2019-05-06', '2019-05-06', 'activate', 'v', '2019-06-05', 1, '2019-05-06', '19:07:59', '', 'paid at bank'),
(13, 190515, 'Starter', 1000, '2019-05-15', '2019-05-15', 'activate', 'paid', '2019-06-14', 1, '2019-05-15', '16:56:34', '4ea619e030cf1b990d3b', 'online');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
