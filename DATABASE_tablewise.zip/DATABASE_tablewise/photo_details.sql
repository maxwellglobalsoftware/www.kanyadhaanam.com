-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 16, 2019 at 12:50 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kanya3w90_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `photo_details`
--

CREATE TABLE `photo_details` (
  `id` int(11) NOT NULL,
  `pho_userId` int(11) NOT NULL,
  `pho_imgPath` varchar(256) NOT NULL,
  `reg_date` date NOT NULL,
  `reg_time` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `photo_details`
--

INSERT INTO `photo_details` (`id`, `pho_userId`, `pho_imgPath`, `reg_date`, `reg_time`) VALUES
(1, 19031, 'Kanya@Prof/padangal/19031_profile_female.jpg', '2019-03-08', '01:51:13'),
(2, 19032, 'Kanya@Prof/padangal/19032_profile_female.jpg', '2019-03-08', '02:04:02'),
(3, 19033, 'Kanya@Prof/padangal/19033_profile_female.jpg', '2019-03-08', '02:12:28'),
(4, 19034, 'Kanya@Prof/padangal/19034_profile_female.jpg', '2019-03-08', '02:18:38'),
(5, 19035, 'Kanya@Prof/padangal/19035_profile_female.jpg', '2019-03-08', '02:38:32'),
(6, 19036, 'Kanya@Prof/padangal/19036_profile_female.jpg', '2019-03-08', '02:48:13'),
(7, 19037, 'Kanya@Prof/padangal/19037_profile_male.jpg', '2019-03-08', '02:52:46'),
(8, 19038, 'Kanya@Prof/padangal/19038_profile_male.jpg', '2019-03-08', '03:08:55'),
(9, 19039, 'Kanya@Prof/padangal/19039_profile_male.jpg', '2019-03-08', '03:50:33'),
(10, 190310, 'Kanya@Prof/padangal/190310_profile_male.jpg', '2019-03-08', '04:10:58'),
(11, 190311, 'Kanya@Prof/padangal/190311_profile_male.jpg', '2019-03-08', '04:13:53'),
(12, 190312, 'Kanya@Prof/padangal/190312_profile_male.jpg', '2019-03-08', '04:16:45'),
(13, 19031, 'Kanya@Prof/padangal/19031_profile_1_1_Selva_Magal_selvamagal1.jpg', '2019-03-26', '00:23:29'),
(25, 190253, 'Kanya@Prof/padangal/190253_profile_190253_phm.jpg', '2019-04-23', '23:55:18'),
(22, 1903109, 'Kanya@Prof/padangal/1903109_profile_19041_phm.jpg', '2019-04-05', '06:44:11'),
(23, 1903109, 'Kanya@Prof/padangal/1903109-0_19041_ph2.jpg', '2019-04-05', '06:44:30'),
(24, 19043, 'Kanya@Prof/padangal/19043_profile_19043_phm.jpg', '2019-04-11', '07:13:43'),
(26, 190253, 'Kanya@Prof/padangal/190253-0_190253_ph.jpg', '2019-04-23', '23:55:31'),
(27, 190415, 'Kanya@Prof/padangal/190415_profile_190415_phm.jpg', '2019-04-24', '00:08:32'),
(28, 190415, 'Kanya@Prof/padangal/190415-0_190415_ph.jpg', '2019-04-24', '00:08:50'),
(29, 190416, 'Kanya@Prof/padangal/190416_profile_190416-phm.jpg', '2019-04-24', '00:43:54'),
(30, 190416, 'Kanya@Prof/padangal/190416-0_190416-ph.jpg', '2019-04-24', '00:44:10'),
(31, 190429, 'Kanya@Prof/padangal/190429_profile_190429_phm.jpg', '2019-04-30', '00:43:02'),
(32, 190429, 'Kanya@Prof/padangal/190429-0_190429_ph.jpg', '2019-04-30', '00:43:12'),
(33, 190428, 'Kanya@Prof/padangal/190428_profile_PHOTO-2019-04-30-11-44-28.jpg', '2019-04-30', '03:30:48'),
(34, 190428, 'Kanya@Prof/padangal/190428-0_waj.jpg', '2019-04-30', '03:31:45'),
(35, 19054, 'Kanya@Prof/padangal/19054_profile_19054_phm.jpg', '2019-05-04', '08:06:25'),
(36, 19042, 'Kanya@Prof/padangal/19042_profile_19042_phm.jpg', '2019-05-04', '08:12:01'),
(37, 19042, 'Kanya@Prof/padangal/19042-0_19042_ph.jpg', '2019-05-04', '08:12:30'),
(38, 19042, 'Kanya@Prof/padangal/19042-1_19042_ph1.jpg', '2019-05-04', '08:12:30'),
(39, 19042, 'Kanya@Prof/padangal/19042-2_19042_ph2.jpg', '2019-05-04', '08:12:30'),
(40, 19042, 'Kanya@Prof/padangal/19042-3_19042_ph3.jpg', '2019-05-04', '08:12:30'),
(41, 19053, 'Kanya@Prof/padangal/19053_profile_19053_phm.jpg', '2019-05-04', '08:17:55'),
(42, 19053, 'Kanya@Prof/padangal/19053-0_19053_ph.jpg', '2019-05-04', '08:18:15'),
(43, 19057, 'Kanya@Prof/padangal/19057_profile_19057_phm.jpg', '2019-05-06', '01:42:22'),
(44, 19057, 'Kanya@Prof/padangal/19057-0_19057_ph.jpg', '2019-05-06', '01:42:43'),
(45, 19057, 'Kanya@Prof/padangal/19057-1_19057_ph1.jpg', '2019-05-06', '01:42:43'),
(46, 190350, 'Kanya@Prof/padangal/190350_profile_190350_phm.jpg', '2019-05-06', '09:26:35'),
(47, 190350, 'Kanya@Prof/padangal/190350-0_190350_ph.jpg', '2019-05-06', '09:28:28'),
(48, 190350, 'Kanya@Prof/padangal/190350-1_190350_phm.jpg', '2019-05-06', '09:28:28'),
(49, 190350, 'Kanya@Prof/padangal/190350-2_467809-==.jpg', '2019-05-06', '09:28:28'),
(50, 190350, 'Kanya@Prof/padangal/190350-3_bracelet 2.jpg', '2019-05-06', '09:28:28'),
(53, 190426, 'Kanya@Prof/padangal/190426-0_190426_Ph1_Ab.jpg', '2019-05-09', '09:10:38'),
(54, 190426, 'Kanya@Prof/padangal/190426_profile_190426_phm.jpg', '2019-05-09', '09:10:56'),
(55, 19051, 'Kanya@Prof/padangal/19051_profile_19051_Phm.jpg', '2019-05-09', '09:22:18'),
(56, 19051, 'Kanya@Prof/padangal/19051-0_19051_Ph1.jpg', '2019-05-09', '09:23:00'),
(57, 190514, 'Kanya@Prof/padangal/190514_profile_190514_Phm.jpg', '2019-05-13', '03:51:46'),
(58, 190514, 'Kanya@Prof/padangal/190514-0_190514_ph1.jpg', '2019-05-13', '03:52:18'),
(59, 190513, 'Kanya@Prof/padangal/190513_profile_190513_Phm.jpg', '2019-05-13', '06:34:55'),
(60, 190513, 'Kanya@Prof/padangal/190513-0_IMG-20190513-WA0001.jpg', '2019-05-13', '06:35:30'),
(61, 190513, 'Kanya@Prof/padangal/190513-1_IMG-20190513-WA0008.jpg', '2019-05-13', '06:35:30'),
(62, 190513, 'Kanya@Prof/padangal/190513_profile_190513_hrs.jpg', '2019-05-13', '06:38:28'),
(63, 190223, 'Kanya@Prof/padangal/190223_profile_190223_Phm.jpg', '2019-05-15', '08:35:21'),
(64, 190223, 'Kanya@Prof/padangal/190223-0_IMG-20190515-WA0001.jpg', '2019-05-15', '08:35:52'),
(65, 190421, 'Kanya@Prof/padangal/190421_profile_190421_Phm.jpg', '2019-05-15', '09:06:05'),
(66, 190421, 'Kanya@Prof/padangal/190421-0_190421_alb1.jpg', '2019-05-15', '09:06:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `photo_details`
--
ALTER TABLE `photo_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `photo_details`
--
ALTER TABLE `photo_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
