-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 16, 2019 at 12:50 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kanya3w90_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `photo_details(bk)`
--

CREATE TABLE `photo_details(bk)` (
  `id` int(11) NOT NULL,
  `pho_userId` int(11) NOT NULL,
  `pho_imgPath` varchar(256) NOT NULL,
  `reg_date` date NOT NULL,
  `reg_time` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `photo_details(bk)`
--

INSERT INTO `photo_details(bk)` (`id`, `pho_userId`, `pho_imgPath`, `reg_date`, `reg_time`) VALUES
(1, 19031, 'Kanya@Prof/padangal/19031_profile_female.jpg', '2019-03-08', '01:51:13'),
(2, 19032, 'Kanya@Prof/padangal/19032_profile_female.jpg', '2019-03-08', '02:04:02'),
(3, 19033, 'Kanya@Prof/padangal/19033_profile_female.jpg', '2019-03-08', '02:12:28'),
(4, 19034, 'Kanya@Prof/padangal/19034_profile_female.jpg', '2019-03-08', '02:18:38'),
(5, 19035, 'Kanya@Prof/padangal/19035_profile_female.jpg', '2019-03-08', '02:38:32'),
(6, 19036, 'Kanya@Prof/padangal/19036_profile_female.jpg', '2019-03-08', '02:48:13'),
(7, 19037, 'Kanya@Prof/padangal/19037_profile_male.jpg', '2019-03-08', '02:52:46'),
(8, 19038, 'Kanya@Prof/padangal/19038_profile_male.jpg', '2019-03-08', '03:08:55'),
(9, 19039, 'Kanya@Prof/padangal/19039_profile_male.jpg', '2019-03-08', '03:50:33'),
(10, 190310, 'Kanya@Prof/padangal/190310_profile_male.jpg', '2019-03-08', '04:10:58'),
(11, 190311, 'Kanya@Prof/padangal/190311_profile_male.jpg', '2019-03-08', '04:13:53'),
(12, 190312, 'Kanya@Prof/padangal/190312_profile_male.jpg', '2019-03-08', '04:16:45'),
(13, 19031, 'Kanya@Prof/padangal/19031_profile_1_1_Selva_Magal_selvamagal1.jpg', '2019-03-26', '00:23:29'),
(14, 19031, 'Kanya@Prof/padangal/19031-0_1_1_Pournami_Pournami1.jpg', '2019-03-26', '00:26:19'),
(15, 19031, 'Kanya@Prof/padangal/19031-1_1_1_Selva_Magal_selvamagal1.jpg', '2019-03-26', '00:26:19'),
(18, 19041, 'Kanya@Prof/padangal/19041_profile_19041_phm.jpg', '2019-04-05', '01:39:47'),
(19, 19041, 'Kanya@Prof/padangal/19041-0_19041_ph.jpg', '2019-04-05', '01:40:28'),
(20, 19041, 'Kanya@Prof/padangal/19041-1_19041_ph1.jpg', '2019-04-05', '01:40:28'),
(21, 19041, 'Kanya@Prof/padangal/19041-2_19041_ph2.jpg', '2019-04-05', '01:40:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `photo_details(bk)`
--
ALTER TABLE `photo_details(bk)`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `photo_details(bk)`
--
ALTER TABLE `photo_details(bk)`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
