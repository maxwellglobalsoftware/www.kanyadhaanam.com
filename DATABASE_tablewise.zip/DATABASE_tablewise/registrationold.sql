-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 16, 2019 at 12:50 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kanya3w90_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `registrationold`
--

CREATE TABLE `registrationold` (
  `id` int(11) NOT NULL,
  `km_regcode` varchar(16) NOT NULL,
  `km_name` varchar(128) NOT NULL,
  `km_password` varchar(32) NOT NULL,
  `km_gender` enum('male','female') NOT NULL,
  `km_dateofbirth` date NOT NULL,
  `km_dayofbirth` varchar(16) NOT NULL,
  `km_birthtime` varchar(16) NOT NULL,
  `km_age` varchar(8) DEFAULT NULL,
  `km_housename` varchar(128) NOT NULL,
  `km_email` varchar(256) DEFAULT NULL,
  `km_mobile` varchar(16) NOT NULL,
  `km_second_mobile` varchar(16) NOT NULL,
  `km_landline` varchar(32) DEFAULT NULL,
  `km_registered_date` date NOT NULL,
  `km_order_of_birth` varchar(32) NOT NULL,
  `km_place_of_birth` varchar(32) NOT NULL,
  `km_status` enum('pending','block','deleted','postpone','live','suspend') NOT NULL,
  `km_registered_by` enum('byself','byadmin') NOT NULL DEFAULT 'byself',
  `km_marital_status` enum('unmarried','widower','divorced','awaiting divorce') NOT NULL,
  `km_caste` varchar(128) NOT NULL,
  `km_subcaste` varchar(128) NOT NULL,
  `km_gothram` varchar(64) NOT NULL,
  `km_state` int(11) DEFAULT NULL,
  `km_district` varchar(120) NOT NULL,
  `km_city` varchar(120) NOT NULL,
  `km_street` varchar(120) NOT NULL,
  `km_doorno` varchar(150) NOT NULL,
  `km_pincode` varchar(16) DEFAULT NULL,
  `km_native_place` varchar(100) NOT NULL,
  `km_native_district` varchar(100) NOT NULL,
  `km_family_status` varchar(500) DEFAULT NULL,
  `km_family_type` varchar(500) DEFAULT NULL,
  `km_family_value` varchar(500) DEFAULT NULL,
  `bcount` varchar(300) DEFAULT NULL,
  `bmcount` varchar(400) DEFAULT NULL,
  `scount` varchar(400) DEFAULT NULL,
  `smcount` varchar(300) DEFAULT NULL,
  `km_weight` varchar(16) NOT NULL,
  `km_height` varchar(16) NOT NULL,
  `km_physical_status` enum('normal','challenged') NOT NULL,
  `km_education` varchar(128) NOT NULL,
  `km_education_details` varchar(600) DEFAULT NULL,
  `km_occupation` varchar(128) DEFAULT NULL,
  `km_employee_in` enum('government','private','business','notworking') NOT NULL,
  `km_annual_income` varchar(128) DEFAULT NULL,
  `km_blood_group` varchar(20) NOT NULL,
  `km_company_name` varchar(128) DEFAULT NULL,
  `km_dosham` enum('yes','no','dontknow') NOT NULL,
  `km_dosham_details` varchar(500) DEFAULT NULL,
  `km_star` varchar(64) NOT NULL,
  `km_rasi` varchar(32) NOT NULL,
  `km_lagnam` varchar(65) NOT NULL,
  `km_thisai_irrupu` varchar(65) NOT NULL,
  `km_father_name` varchar(120) NOT NULL,
  `km_mother_name` varchar(120) NOT NULL,
  `km_father_occupation` varchar(160) NOT NULL,
  `km_mother_ocupation` varchar(160) NOT NULL,
  `km_languages` text NOT NULL,
  `reg_date` date NOT NULL,
  `reg_time` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registrationold`
--

INSERT INTO `registrationold` (`id`, `km_regcode`, `km_name`, `km_password`, `km_gender`, `km_dateofbirth`, `km_dayofbirth`, `km_birthtime`, `km_age`, `km_housename`, `km_email`, `km_mobile`, `km_second_mobile`, `km_landline`, `km_registered_date`, `km_order_of_birth`, `km_place_of_birth`, `km_status`, `km_registered_by`, `km_marital_status`, `km_caste`, `km_subcaste`, `km_gothram`, `km_state`, `km_district`, `km_city`, `km_street`, `km_doorno`, `km_pincode`, `km_native_place`, `km_native_district`, `km_family_status`, `km_family_type`, `km_family_value`, `bcount`, `bmcount`, `scount`, `smcount`, `km_weight`, `km_height`, `km_physical_status`, `km_education`, `km_education_details`, `km_occupation`, `km_employee_in`, `km_annual_income`, `km_blood_group`, `km_company_name`, `km_dosham`, `km_dosham_details`, `km_star`, `km_rasi`, `km_lagnam`, `km_thisai_irrupu`, `km_father_name`, `km_mother_name`, `km_father_occupation`, `km_mother_ocupation`, `km_languages`, `reg_date`, `reg_time`) VALUES
(1, '19031', 'kalai', '12345', 'female', '1991-08-11', 'Wednesday', '1:7 AM', NULL, 'NA', 'gnaritustechchennai@gmail.com', '9500090825', '9159730194', '-', '2019-03-08', '4', 'Chennai', 'live', 'byself', 'unmarried', '', '', 'NA', 31, '518', 'Chennai', 'Chennai', '1', '655422', 'chennai', 'chennai', 'middle', 'nuclear', 'traditional', '2', '0', '3', '0', '45 Kgs', '5ft 6in', 'normal', '15', 'BE', '5', 'private', '300000', '14', 'Advertising', 'no', '', 'Bharani', 'Meena', 'Katagam', 'Na', 'Durai', 'Mathi', 'Teacher', 'House Wife', 'Tamil, English', '2019-03-08', '00:21:14'),
(2, '19032', 'Divya', '123457', 'female', '1984-08-16', 'Wednesday', '4:2 PM', NULL, 'na', 'maxwellchennai30@gmail.com', '9999999906', '2345678980', '-', '2019-03-08', '5', 'Trichy', 'live', 'byself', 'unmarried', '', '', 'na', 31, '522', 'Trichy', 'Trichy', '1', '235475', 'Trichy', 'Trichy', 'middle', 'joint', 'orthodox', '4', '2', '4', '2', '42 Kgs', '4ft 10in', 'normal', '6', '', '7', 'government', '1234567', '6', 'Hosters', 'no', '', 'Bharani', 'Kumbha', 'Kumbha', 'na', 'Test', 'Test', 'Test', 'TEst', 'tamil', '2019-03-08', '02:03:07'),
(3, '19033', 'Sindhu', '123', 'female', '1993-03-02', 'Wednesday', '5:2 AM', NULL, 'test', 'na@gmail.com', '1234567890', '5465789456', '-', '2019-03-08', '3', 'test', 'live', 'byself', 'unmarried', '', '', 'test', 14, '195', 'test', 'test', '234', '334556', 'na', 'na', 'middle', 'joint', 'orthodox', '5', '2', '3', '2', '41 Kgs', '4ft 8in', 'normal', '8', '', '10', 'government', '32355686', '3', 'test', 'no', '', 'Bharani', 'Kumbha', 'Katagam', 'na', 'test', 'sdxfgc', 'test', 'cvb', 'tamil', '2019-03-08', '02:11:56'),
(4, '19034', 'Kavitha', '123', 'female', '1992-10-17', 'Wednesday', '9:10 PM', NULL, 'na', 'na1@gmail.com', '2134567774', '2133456789', '-', '2019-03-08', '5', 'Test', 'live', 'byself', 'unmarried', '', '', 'na', 31, '517', 'Test', 'Test', '2', '312456', 'na', 'na', 'middle', 'joint', 'orthodox', '4', '2', '2', '2', '43 Kgs', '4ft 9in', 'normal', '16', '', '8', 'government', '23456', '1', 'Test', 'no', '', 'Ashwini / Ashwathi', 'Kumbha', 'Kumbha', 'na', 'Test', 'Test', 'Test', 'Test', 'tamil', '2019-03-08', '02:18:15'),
(5, '19035', 'Priya', '098', 'female', '1986-08-15', 'Monday', '4:2 PM', NULL, 'Test', 'na2@gmail.com', '3245678799', '2345678909', '-', '2019-03-08', '3', 'Test', 'live', 'byself', 'unmarried', '', '', 'Test', 31, '517', 'Test', 'Test', '33', '224567', 'Test', 'Test', 'middle', 'joint', 'orthodox', '3', '1', '2', '3', '44 Kgs', '4ft 9in', 'normal', '28', '', '15', 'government', '4567', '12', 'Test', 'no', '', 'Bharani', 'Simham', 'Katagam', 'Test', 'Test', 'Test', 'Test', 'Test', 'tamil', '2019-03-08', '02:21:13'),
(6, '19036', 'Devi', '567', 'female', '1997-05-05', 'Wednesday', '5:3 PM', NULL, 'test1', 'na3@gmail.com', '6789065444', '2344567687', '-', '2019-03-08', '4', 'test', 'live', 'byself', 'unmarried', '', '', 'test1', 31, '509', 'test1', 'test1', '2', '134456', 'test1', 'test1', 'middle', 'joint', 'orthodox', '2', '2', '2', '1', '50 Kgs', '5ft 5in', 'normal', '28', '', '13', 'government', '2345', '2', 'test', 'no', '', 'Mrigasira / Makayiram', 'Rishabam', 'Rishabam', 'na', 'test1', 'test1', 'test1', 'test1', 'tamil', '2019-03-08', '02:47:38'),
(7, '19037', 'Ravi', '123', 'male', '1986-10-15', 'Tuesday', '3:1 PM', NULL, 'Test', 'na5@gmail.com', '4567890324', '3456789076', '-', '2019-03-08', '4', 'Test', 'live', 'byself', 'unmarried', '', '', 'Test', 31, '512', 'Test', 'Test', '1', '324546', 'Test', 'Test', 'middle', 'joint', 'orthodox', '2', '0', '2', '0', '43 Kgs', '4ft 8in', 'normal', '6', '', '3', 'government', '435678', '4', 'Test', 'no', '', 'Moolam / Moola', 'Rishabam', 'Mesham', 'Test', 'Test', 'Test', 'Test', 'Test', 'wertfg', '2019-03-08', '02:52:07'),
(8, '19038', 'Sathish', '123', 'male', '1987-09-18', 'Monday', '3:2 PM', NULL, 'Test', 'na6@gmail.com', '3234547689', '3445676890', '-', '2019-03-08', '8', 'Test', 'live', 'byself', 'unmarried', '', '', 'Test', 31, '519', 'Test', 'Test', '111', '123455', 'Test', 'Test', 'middle', 'joint', 'orthodox', '4', '2', '2', '2', '41 Kgs', '5ft 5in', 'normal', '16', '', '3', 'government', '123', '14', 'Test', 'no', '', 'Ashlesha / Ayilyam', 'Katagam', 'Katagam', 'Test', 'Test', 'Test', 'Test', 'Test', 'tamil', '2019-03-08', '03:08:21'),
(9, '19039', 'Raja', '123', 'male', '1983-11-18', 'Tuesday', '3:2 AM', NULL, 'Test', 'na7@gmail.com', '1237832215', '1246789999', '-', '2019-03-08', '4', 'Test', 'live', 'byself', 'unmarried', '', '', 'Test', 31, '514', 'Test', '123', '123', '123456', 'Test', 'Test', 'middle', 'joint', 'orthodox', '2', '1', '4', '2', '43 Kgs', '4ft 9in', 'normal', '16', '', '2', 'government', '1234', '4', 'Test', 'no', '', 'Ashwini / Ashwathi', 'Katagam', 'Katagam', 'Test', 'Test', 'Test', 'Test', 'Test', 'tamil', '2019-03-08', '03:50:02'),
(10, '190310', 'Raj Kumar', '123', 'male', '1984-08-16', 'Friday', '4:3 AM', NULL, 'Test', 'na9@gmail.com', '5876987090', '3245678907', '-', '2019-03-08', '5', 'Test', 'live', 'byself', 'unmarried', '', '', 'Test', 31, '515', 'Test', 'Test', '22', '243546', 'Test', 'Test', 'middle', 'joint', 'orthodox', '3', '0', '3', '0', '50 Kgs', '4ft 9in', 'normal', '17', '', '6', 'government', '2345', '13', 'Test', 'yes', 'Test', 'Chitra / Chitha', 'Rishabam', 'Simham', 'Test', 'Test', 'Test', 'Test', 'Test', 'tamil', '2019-03-08', '04:10:25'),
(11, '190311', 'Surendren', '123', 'male', '1985-10-16', 'Tuesday', '10:11 AM', NULL, 'Test', 'na11@gmail.com', '1243567890', '3456789055', '-', '2019-03-08', '3', 'Test', 'live', 'byself', 'unmarried', '', '', 'Test', 31, '509', 'Test', 'Test', '134', '232456', 'Test', 'Test', 'middle', 'joint', 'orthodox', '8', '0', '7', '0', '43 Kgs', '4ft 10in', 'normal', '28', '', '26', 'government', '23345', '6', 'Test', 'no', '', 'Ardra / Thiruvathira', 'Simham', 'Mithunam', 'Test', 'Test', 'Test', 'Test', 'Test', 'tamil', '2019-03-08', '04:13:27'),
(12, '190312', 'Harish', '678', 'male', '1990-03-03', 'Tuesday', '1:0 PM', NULL, 'Test', 'na12@gmail.com', '1234567989', '4981344509', '-', '2019-03-08', '7', 'Test', 'live', 'byself', 'unmarried', '', '', 'Test', 31, '518', 'Test', 'Test', '33', '345678', 'Test', 'Test', 'middle', 'joint', 'orthodox', '4', '0', '4', '0', '49 Kgs', '5ft 1in', 'normal', '17', '', '4', 'government', '345', '2', 'Test', 'no', '', 'Ardra / Thiruvathira', 'Kumbha', 'Makara', 'Test', 'Test', 'Test', 'Test', 'Test', 'tamil', '2019-03-08', '04:16:14'),
(13, '190313', 'Nivetha', 'testing', 'female', '1997-02-02', 'Tuesday', '3:14 PM', NULL, 'testing', 'nivetha@maxwellglobalsoftware.com', '8765678945', '8765678945', '2345-12345678', '2019-03-09', '3', 'testing', 'live', 'byself', 'unmarried', '3', '12', 'testing', 5, '75', 'testing', 'testing', 'testing', '987667', 'testing', 'v', 'middle', 'joint', 'orthodox', '2', '4', '3', '2', '43 Kgs', '4ft 9in', 'normal', '28', 'testing', '2', 'government', 'testing', '2', 'testing', 'no', '', 'Ashlesha / Ayilyam', 'Kumbha', 'Katagam', 'testing', 'testing', 'testing', 'testing', 'testing', 'testing', '2019-03-09', '04:49:48'),
(14, '190314', 'Mavi', 'Radheykrishna', 'female', '1995-12-27', 'Wednesday', '7:26 AM', NULL, 'cvdfvdfxvd', 'mavitha@maxwellglobalsoftware.com', '8778015428', '8778015428', '-', '2019-03-12', '3', 'ubjskdhjfc', 'block', 'byself', 'unmarried', '1', '14', 'dvzxv', 31, '511', 'KK', 'East Street', '7/75', '262662', 'xvdfv', 'vdfvdf', 'middle', 'nuclear', 'traditional', '0', '0', '0', '0', '40 Kgs', '5ft 2in', 'normal', '13', 'BE', '37', 'private', '1000000', '9', 'Engineer', 'no', '', 'Makha / Magam', 'Kumbha', 'Makara', 'fvdfsvfdb', 'Krishna', 'Radha', '-', '-', 'Tamil,English', '2019-03-12', '02:51:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registrationold`
--
ALTER TABLE `registrationold`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `registrationold`
--
ALTER TABLE `registrationold`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
