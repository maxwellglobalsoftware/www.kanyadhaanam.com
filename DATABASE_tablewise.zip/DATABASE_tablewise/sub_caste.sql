-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 16, 2019 at 12:51 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kanya3w90_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `sub_caste`
--

CREATE TABLE `sub_caste` (
  `id` int(11) NOT NULL,
  `caste` varchar(128) NOT NULL,
  `subcaste` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_caste`
--

INSERT INTO `sub_caste` (`id`, `caste`, `subcaste`) VALUES
(1, '3', 'Koteshwara'),
(2, '3', 'Sri Raghavendra'),
(3, '3', 'Swami Shivalli'),
(4, '3', 'Sri Kanva'),
(5, '3', 'Sri Vysaraja'),
(6, '3', 'Shukla Yajurvedi'),
(7, '3', 'Sri Pejawara'),
(8, '3', 'Sri Padarajaru'),
(9, '3', 'Sri Uttradi'),
(10, '3', 'Sri Rayaru'),
(11, '3', 'Others'),
(12, '3', 'Dont like to specify'),
(13, '3', 'Dont Know'),
(14, '1', 'Ashtasahasram'),
(15, '1', 'Brahacharnam'),
(16, '1', 'Vadama'),
(17, '1', 'Vathima'),
(18, '1', 'Others'),
(19, '1', 'Dont wish to specify'),
(20, '1', 'Dont know my sub-caste'),
(21, '2', 'Thenkalai'),
(22, '2', 'Vadakalai'),
(23, '2', 'Others'),
(24, '2', 'Dont wish to specify'),
(25, '2', 'Dont know my sub-caste');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sub_caste`
--
ALTER TABLE `sub_caste`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sub_caste`
--
ALTER TABLE `sub_caste`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
