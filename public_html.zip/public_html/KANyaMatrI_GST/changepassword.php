<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
ob_start();
session_start();
require_once 'includes/configure.php';
require_once 'includes/session_handler.php';
require_once '../init.php';

$profileId = $_SESSION['Kamma_Matri']['id'];
//*********************** Horoscope Details *******************************
$users = new User();
$users = $users->getUsers("WHERE id = '{$profileId}'")->resultSet();    
$user = $users[0];
//print_r($user);

if(isset($_SESSION['pwdUpdate'])) {
    if($_SESSION['pwdUpdate']) {
        $result = "Password updated successfully";
    } else {
        $result = "Failed to update Password";
    }
    unset($_SESSION['pwdUpdate']);
}
if(isset($_SESSION['msg'])){
    $result = $_SESSION['msg']; 
    unset($_SESSION['msg']);
}

if(isset($_POST['btn_chgpwd'])) {      
    $data = array();   
    
    $oldpwd = $_POST['oldpwd'];
    $newpwd = $_POST['newpwd'];
    $confirmpwd = $_POST['confirmpwd'];
//    echo $user['password'];
//    exit();

    $cryptKey  = 'MaTriKamMa$123&brides$1*10#^&matriMonY@Grooms';
    $confm_oldpswd      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $oldpwd, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
    
    if($confm_oldpswd == $user['password']){        
        if($newpwd == $confirmpwd){
            
            $cryptKey  = 'MaTriKamMa$123&brides$1*10#^&matriMonY@Grooms';
    		$new_pswd      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $newpwd, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
    		
    		
            $data[] = $new_pswd;
            $data[] = $profileId;
            $registration = new User();
            $registration = $registration->updatePassword($data);
            $payment_id = $registration->rowCount();
            if($payment_id){   
                $_SESSION['flag'] = 'success';
                $_SESSION['pwdUpdate'] = true;
            } else {
                $_SESSION['flag'] = 'fail';
                $_SESSION['pwdUpdate'] = false;
            }
        }else{
            $_SESSION['flag'] = 'newpwd';
            $_SESSION['msg'] = 'New and Confirm password doesnot match';
        }
        $_SESSION['oldpwd'] = $oldpwd;
    }else{
        $_SESSION['oldpwd'] = '';
        $_SESSION['flag'] = 'oldpwd';
        $_SESSION['msg'] = 'Please enter valid Old Password';
    }
    
    
    header("Location: changepassword.php");
}
?>
<!DOCTYPE html>
<html>

<link rel="stylesheet" href="../css/jquery-ui.css">
  
  <script src="../js/jquery-1.12.4.js"></script>
  <script src="../js/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>


   <?php include("includes/headertop.php");?>
   <body class="home color-green boxed shadow">
      <div class="root">
         <?php include("includes/header.php");?>
         <section class="content reverse" style=" width: 90%;">
            <section>
                
               <section class="columns" style="margin-top:10px !important;  width: 90%;">
                  <h2><span>Change Password</span></h2>
                 
                  <div id="result-content" style=" width: 90%;">
                       <div  id="message_container" style="text-align: center; display: none; color: red;font-size: 15px; font-weight: bold">
                    <span id="message"></span>
                </div>
                                <form action="" method="post" enctype="multipart/form-data">
                                <table width="100%"  border="0">
                                       <tbody>

                                          <tr>
                                             <th>Old Password :</th>
                                             <td>
                                                 <input type="text" id="oldpwd" name="oldpwd" placeholder="Old Password" class="text" value="<?php echo $_POST['oldpwd']; ?>" required="">
                                             </td>
                                          </tr>
                                          <tr>
                                             <th>New Password :</th>
                                             <td>
                                                 <input type="password" id="newpwd" name="newpwd" placeholder="New Password" class="text" required="">
                                             </td>
                                          </tr>
                                          <tr>
                                             <th>Confirm Password :</th>
                                             <td>
                                                 <input type="password" id="confirmpwd" name="confirmpwd" placeholder="Confirm Password" class="text" required="">
                                             </td>
                                          </tr> 
                                          <tr>
                                              <td colspan="2">
                                                <input type="submit" name="btn_chgpwd" value="Submit" style="background:#93bf1b;color:#ffffff;margin-top:10px;margin-left: 50%;" onclick="return validateUserInfo();">
                                             </td>
                                          </tr>

                                       </tbody>
                                    </table>
                                  </form>
                            </div>
               </section>
            </section>
         </section>
         <div style=" clear: both;"></div>
         <?php include("includes/footer.php");?>
         <?php
        if(isset($result)) {
	?>
        <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(2000, function() {
                            $('#message').text("");
                            <?php 
                            if($_SESSION['flag'] == 'newpwd'){
                                ?>
                                $('#oldpwd').val('<?php echo $_SESSION['oldpwd']; ?>');
                                
                                $('#newpwd').focus();
                           <?php }else if($_SESSION['flag'] == 'oldpwd'){
                                ?>
                                            $('#oldpwd').focus();
                                            <?php
                            }else if($_SESSION['flag'] == 'fail'){
                             ?>
                                 $('#oldpwd').focus();
                                 <?php   
                            }else{?>
                                
                          <?php  }
                            ?>
                    });
            }, 2000);
        </script>
	<?php
            }
	?>
      </div>
   </body>
</html>