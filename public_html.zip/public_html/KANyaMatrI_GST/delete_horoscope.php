<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
ini_set('memory_limit','128M');
ob_start();
session_start();
require_once 'includes/configure.php';
require_once 'includes/session_handler.php';
require_once '../init.php';
date_default_timezone_set('Asia/Kolkata');

if(empty($_SESSION['Kamma_Matri'])){
    header("Location: index.php");
}

if($_SESSION['Kamma_Matri']){
    $enteredBy = $_SESSION['Kamma_Matri']['id'];    
}


if(isset($_SESSION['horoscope_deleted'])) {
    if($_SESSION['horoscope_deleted']) {
        $result = "Horoscope Deleted";
    } else {
        $result = "Failed to delete";
    }
    unset($_SESSION['horoscope_deleted']);
}
$users = new Registration();
$users = $users->fetch()->resultSet(); 

$available_userId = array();
foreach($users as $user) { 
    array_push($available_userId, $user['km_regcode']);
}
if(isset($_POST['profile_id'])){
    $profile_id = $_POST['profile_id'];
    $horoscopes = new Profile();
    $horoscopes = $horoscopes->fetchHoroscope("WHERE hs_userId = '{$profile_id}' ORDER BY id DESC")->resultSet();
    $horoscope = $horoscopes[0];
}
if($_POST['flag'] == 'Yes') {      
    $data = array();   
    echo 'selected_photos = '.$_POST['selected_photos'];
    $selected_photos = explode(',', $_POST['selected_photos']);
    foreach($selected_photos as $photo){
        $horoscopes = new Profile();
        $horoscopes = $horoscopes->fetchHoroscope("WHERE id = '{$photo}' ORDER BY id DESC")->resultSet();
        $horoscope = $horoscopes[0];
        $photo_imgPath = $horoscope['hs_imgPath'];
        
        $data = array(); 
        $data[] = $photo;
        $photos = new Profile();
        $photos = $photos->removeIDHoroscope($data);  
        $photos_id = $photos->rowCount();
        if($photos_id){
            unlink('../'.$photo_imgPath);
        }
    }
    $_SESSION['horoscope_deleted'] = true;
    header("Location: delete_horoscope.php");
}


?>
<!DOCTYPE html>
<html>

    <link rel="stylesheet" href="../css/jquery-ui.css">
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
    <link rel="stylesheet" href="../css/bootstrap-datetimepicker.min.css" />
  
    <script src="../js/jquery-1.12.4.js"></script>
    <script src="../js/jquery-ui.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/moment.js"></script>
    <script src="../js/bootstrap-datetimepicker.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>


   <?php include("includes/headertop.php");?>
   <body class="home color-green boxed shadow">
      <div class="root">
         <?php include("includes/header.php");?>
         <section class="content reverse" style=" width: 70%;">
            <section>
                <div  id="message_container" style="text-align: center; display: none; color: red;font-size: 18px; font-weight: bold">
                    <span id="message"></span>
                </div>
               <section class="columns" style="margin-top:10px !important;  width: 90%;">
                  <h2><span>Delete Horoscope</span></h2>
                  <form action="" id="photo_form" method="post" enctype="multipart/form-data">
                      <input type="hidden" name="selected_photos" id="selected_photos" />
                      <input type="hidden" name="profile_id" value="<?php echo $profile_id;?>" id ="profile_id" />
                      <input type="hidden" name="flag" id ="flag" />
                    <table width="50%"  border="0">
                           <tbody>
                              
                              <tr>
                                 <!--<th></th>-->
                                 <td>
                                     <div class="row">
                                         <input class="col-md-9" type="text" id="user_id" value="<?php echo $profile_id;?>" name="user_id" placeholder="User ID" class="text" required="">
                                     </div>
                                     
                                 </td>

                              </tr>
                              
                              
                              <tr>
                                 <td>
                                 <?php 
                                 if($horoscope){ ?>
                              
                                     <div class="col-md-4" style="padding:5px;">
                                 
                                     
                                     <label class="checkbox-inline " style="margin-left: 0px;padding-left: 20px;">
                                         <input type="checkbox" class="delete_photo" name="photos"  id="<?php echo $horoscope['id']; ?>" value="<?php echo $horoscope['id']; ?>">
                                     </label>
                                 
                                     <img style="width:102px;height: 120px;" src="../<?php echo $horoscope['hs_imgPath']; ?>" />
                                     </div>
                                 
                                 <?php } else { ?>
                                     <div id="result-content">
                                <h4 style="margin: 1.5em 1em;text-align: center;color: #17800a;"> Horoscope not available. </h4>
                            </div>
                                 <?php } ?>
                                 </td>
                              </tr>
                              <tr>
                                  <td colspan="2">
                                    
                                      <input type="button" class="delete" name="btn_delete" value="Delete" style="background:#93bf1b;color:#ffffff;margin-top:10px;margin-left: 50%;">
                                    
                                 </td>
                              </tr>
                              
                           </tbody>
                        </table>
                      </form>
               </section>
            </section>
         </section>
         <div style=" clear: both;"></div>
         <?php include("includes/footer.php");?>
          <?php
        if(isset($result)) {
	?>
        <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(1000, function() {
                            $('#message').text("");
                            $('#username').focus();
                    });
            }, 1000);
        </script>
	<?php
            }
	?>
      </div>
        <script type="text/javascript">
            var availableUserId = "";
            $(document).ready(function() {
                $('#start_from').datetimepicker({
                    format: 'DD-MM-YYYY',
                    pickTime:false,
                    sideBySide:true
                });
                $('#paid_date').datetimepicker({
                    format: 'DD-MM-YYYY',
                    pickTime:false,
                    sideBySide:true
                });
                
                availableUserId = <?php echo json_encode($available_userId); ?>;
               $("#user_id").autocomplete({
                    source: availableUserId,
                    autoFocus:true,
                    select: function( event , ui ) {
                        $('#profile_id').val(ui.item.label);            
                        $('#photo_form').attr('method', 'post');
                        $('#photo_form').attr('action', 'delete_horoscope.php');
                        $('#photo_form').submit();
                    }
                });                
            });
         
      
        $( document ).on('change','#plan_name ', function () {
            var plan_name = $(this).val();
            if(plan_name == 'Starter'){
                $('#plan_amount').val(200);
            }
            
        });
        $(document).on('click','.delete_photo ', function () {    
            var selected_days = $('input[name="photos"]:checked').map(function () {  
                return this.value;
            }).get().join(",");    
            $('#selected_photos').val(selected_days);
        });
        </script>
        <script>            
            $(document).on('click', '.delete', function() { 
                var Select_Horos = $('#selected_photos').val();
                if(Select_Horos){
                var confirm_msg = confirm("Are you sure to delete?");
                if (confirm_msg == true) {
                    $('#flag').val('Yes');
                    $('#photo_form').attr('method', 'post');
                    $('#photo_form').attr('action', 'delete_horoscope.php');
                    $('#photo_form').submit();
                }else{

                }
                } else {
                    alert("Please select Horoscope");
                    return false;
                }                          
            });
        </script>
   </body>
</html>