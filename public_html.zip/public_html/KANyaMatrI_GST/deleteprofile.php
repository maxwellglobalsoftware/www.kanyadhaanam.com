<!DOCTYPE html>
<html>

<link rel="stylesheet" href="../css/jquery-ui.css">
  
  <script src="../js/jquery-1.12.4.js"></script>
  <script src="../js/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>


   <?php include("includes/headertop.php");?>
   <body class="home color-green boxed shadow">
      <div class="root">
         <?php include("includes/header.php");?>
         <section class="content reverse" style=" width: 90%;">
            <section>
               <section class="columns" style="margin-top:10px !important;  width: 90%; bo ">
                  <h2><span>Delete Profile</span></h2>


                  <br><br><br><br><br><br><br><br><br><br><br>



               </section>
            </section>
         </section>
         <div style=" clear: both;"></div>
         <?php include("includes/footer.php");?>
      </div>
   </body>
</html>