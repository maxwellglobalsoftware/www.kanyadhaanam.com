<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../init.php';
header("Content-Type: application/vnd.ms-excel");
header("Content-disposition: attachment; filename=payment_report.xls");

if($_POST['report'] == "payment_report") {
    
    $payments = new Payment();
    $payments = $payments->fetch("GROUP BY pl_userId ORDER BY id DESC")->resultSet();  
    

    echo"<table border='1'>"
    . "<tr>"
            . "<th>S.No</th>"
            . "<th>Reg ID</th>"
            . "<th>Name</th>"
            . "<th>Mobile No</th>"
            . "<th>Count</th>"
            . "</tr>";
    $sno = 1;
    foreach($payments as $payment){ 


        $profiles = new Registration();
        $profiles = $profiles->fetch("WHERE km_regcode = '{$payment['pl_userId']}'")->resultSet();
        $profile = $profiles[0];

        $getpayments = new Payment();
        $getpayments = $getpayments->fetch("WHERE pl_userId = '{$payment['pl_userId']}' AND pl_status = 'activate' ORDER BY id DESC")->resultSet();

        $payment_count = count($getpayments);


        echo"<tr>"
            . "<td>".$sno."</td>"
            . "<td>".$payment['pl_userId']."</td>"
            . "<td>".$profile['km_name']."</td>"
            . "<td>".$profile['km_mobile']."</td>"
            . "<td>".$payment_count."</td>"
        . "</tr>";
        $sno++;
    }
}

?>