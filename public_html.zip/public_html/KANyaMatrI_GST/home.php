<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
   ini_set('memory_limit','128M');
   ob_start();
   session_start();
   require_once 'includes/configure.php';
   require_once 'includes/session_handler.php';
   require_once '../init.php';
   date_default_timezone_set('Asia/Kolkata');
   if(empty($_SESSION['Kamma_Matri'])){
       header("Location: index.php");
   }
   
   
   $cur_date = date("d-m-Y");
   
   $profiles = new Registration();
   $profiles = $profiles->fetch("WHERE km_gender = 'male' AND km_status = 'live' ORDER BY id DESC")->resultSet();
   $Total_male = count($profiles);
   
   $profiles = new Registration();
   $profiles = $profiles->fetch("WHERE km_gender = 'female' AND km_status = 'live' ORDER BY id DESC")->resultSet();
   $Total_female = count($profiles);
   
   $profiles = new Registration();
   $profiles = $profiles->fetch("WHERE km_gender = 'male' AND km_marital_status = 'divorced' AND km_status = 'live' ORDER BY id DESC")->resultSet();
   $totalmale_divorced = count($profiles);
   
   $profiles = new Registration();
   $profiles = $profiles->fetch("WHERE km_gender = 'female' AND km_marital_status = 'divorced' AND km_status = 'live' ORDER BY id DESC")->resultSet();
   $Totalfemale_divorced = count($profiles);
   
   $profiles = new Registration();
   $profiles = $profiles->fetch("WHERE km_status = 'live'")->resultSet();
   $live_profiles = count($profiles);
   
   $profiles = new Registration();
   $profiles = $profiles->fetch("WHERE km_status = 'pending'")->resultSet();
   $pending_profiles = count($profiles);
   
   $profiles = new Registration();
   $profiles = $profiles->fetch("WHERE km_status = 'block'")->resultSet();
   $block_profiles = count($profiles);
   
   $today = date('Y-m-d');
   $profiles = new Registration();
   $profiles = $profiles->fetch("WHERE km_registered_date = '{$today}' AND km_status = 'live'")->resultSet();
   $today_profiles = count($profiles);
   
   $profiles = new Registration();
   $profiles = $profiles->fetch("WHERE km_registered_date = '{$today}' AND km_gender = 'male' AND km_status = 'live'")->resultSet();
   $male_profiles = count($profiles);
   
   $profiles = new Registration();
   $profiles = $profiles->fetch("WHERE km_registered_date = '{$today}' AND km_gender = 'female' AND km_status = 'live'")->resultSet();
   $female_profiles = count($profiles);
   
   $totalprofiles = new Registration();
   $totalprofiles = $totalprofiles->fetch("WHERE km_status = 'live' OR km_status = 'pending' OR km_status = 'block'")->resultSet();
   $Total_count = count($totalprofiles);
   
   
   $loginusers = new Login();
   $loginusers = $loginusers->fetchLogin("WHERE logged_in_date = '{$cur_date}' GROUP BY user_id")->resultSet();
   $loginuser_total_count = count($loginusers);
   
   $totalloginusers = new Login();
   $totalloginusers = $totalloginusers->fetchLogin("WHERE logged_in_date = '{$cur_date}'")->resultSet();
   $user_total_count = count($totalloginusers);
   
   $visitorcounts = new Login();
   $visitorcounts = $visitorcounts->fetchVisitor("WHERE visitin_date = '{$cur_date}'")->resultSet();
   $visitor_total_count = count($visitorcounts);
   
   
   ?>
<!DOCTYPE html>
<html>
   <?php include("includes/headertop.php");?>
   <body class="home color-green boxed shadow">
      <div class="root">
         <?php include("includes/header.php");?>
         <section class="content reverse" style=" width: 100%;">
            <section>
               <section class="columns" style="margin-top:10px !important;  width: 100%; ">
                  <h2><span>Profile Status</span></h2>
                  <div class="col_3" style=" display: block; margin-left: 20px;">
                     <div class="col-md-3 widget widget1">
                        <div class="r3_counter_box">
                           <i class="fa fa-eye"></i>
                           <div class="stats">
                              <h5><?php echo $live_profiles; ?></h5>
                              <div class="grow">
                                 <p>LIVE</p>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-3 widget widget1">
                        <div class="r3_counter_box">
                           <i class="fa fa-users"></i>
                           <div class="stats">
                              <h5><?php echo $pending_profiles;?></h5>
                              <div class="grow grow1">
                                 <p>PENDING</p>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-3 widget widget1">
                        <div class="r3_counter_box">
                           <i class="fa fa-ban"></i>
                           <div class="stats">
                              <h5><?php echo $block_profiles;?></h5>
                              <div class="grow grow3">
                                 <p>BLOCK</p>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-3 widget widget1">
                        <div class="r3_counter_box">
                           <i class="fa fa-bar-chart"></i>
                           <div class="stats">
                              <h5><?php echo $Total_count; ?></h5>
                              <div class="grow grow2">
                                 <p>TOTAL</p>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-3 widget widget1" style="margin-top:2%;     margin-bottom: 20px;">
                        <div class="r3_counter_box">
                           <i class="fa fa-female"></i>
                           <div class="stats">
                              <h5><?php echo $Total_female;?></h5>
                              <div class="grow grow3">
                                 <p>BRIDES</p>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-3 widget widget1" style="margin-top:2%">
                        <div class="r3_counter_box">
                           <i class="fa fa-male"></i>
                           <div class="stats">
                              <h5><?php echo $Total_male;?></h5>
                              <div class="grow grow3">
                                 <p>GROOMS</p>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-3 widget widget1" style="margin-top:2%">
                        <div class="r3_counter_box">
                           <i class="fa fa-female"></i>
                           <div class="stats">
                              <h5><?php echo $Totalfemale_divorced;?></h5>
                              <div class="grow grow3" >
                                 <p>BRIDES DIVORCED</p>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-3 widget widget1" style="margin-top:2%">
                        <div class="r3_counter_box">
                           <i class="fa fa-male"></i>
                           <div class="stats">
                              <h5><?php echo $totalmale_divorced; ?></h5>
                              <div class="grow grow2" >
                                 <p>GROOMS DIVORCED</p>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="clearfix"> </div>
                  </div>
               </section>
               <section class="columns">
                  <h2><span>New Registration</span></h2>
                  <div style=" width: 100%;">
                     <div class="col_3" style=" display: block; margin: 20px;">
                        <div class="col-md-3 widget widget1">
                           <div class="r3_counter_box">
                              <i class="fa fa-female"></i>
                              <div class="stats">
                                 <h5><?php echo $female_profiles; ?></h5>
                                 <div class="grow">
                                    <p>BRIDE</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-3 widget widget1">
                           <div class="r3_counter_box">
                              <i class="fa fa-male"></i>
                              <div class="stats">
                                 <h5><?php echo $male_profiles; ?></h5>
                                 <div class="grow grow1">
                                    <p>GROOM</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-3 widget widget1">
                           <div class="r3_counter_box">
                              <i class="fa fa-bar-chart"></i>
                              <div class="stats">
                                 <h5><?php echo $today_profiles;?></h5>
                                 <div class="grow grow2">
                                    <p>TOTAL</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="clearfix"> </div>
                     </div>
                  </div>
               </section>
               <section class="columns">
                  <h2><span>Users & Visitors Count</span></h2>
                  <div style=" width: 100%;">
                     <div class="col_3" style=" display: block; margin: 20px;">
                        <div class="col-md-3 widget widget1">
                           <div class="r3_counter_box">
                              <i class="fa fa-users"></i>
                              <div class="stats">
                                 <h5><?php echo $loginuser_total_count; ?></h5>
                                 <div class="grow">
                                    <p>Users</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-3 widget widget1">
                           <div class="r3_counter_box">
                              <i class="fa fa-eye"></i>
                              <div class="stats">
                                 <h5><?php echo $visitor_total_count; ?></h5>
                                 <div class="grow grow1">
                                    <p>Visitors</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="clearfix"> </div>
                     </div>
                  </div>
               </section>
            </section>
         </section>
         <div style=" clear: both;"></div>
         <?php include("includes/footer.php");?>
      </div>
   </body>
</html>