<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
ini_set('memory_limit','128M');
ob_start();
session_start();
require_once 'includes/session_handler.php';
require_once 'includes/configure.php';
require_once '../init.php';
date_default_timezone_set('Asia/Kolkata');

if(empty($_SESSION['Kamma_Matri'])){
    header("Location: index.php");
}

if($_SESSION['Kamma_Matri']){
    $enteredBy = $_SESSION['Kamma_Matri']['id'];    
}

if(isset($_SESSION['horosAdded'])) {
    if($_SESSION['horosAdded']) {
        $result = "Horoscope Added";
    } else {
        $result = "Failed to add Horoscope";
    }
    unset($_SESSION['horosAdded']);
}
if(isset($_POST['selected_user'])){
    $users = new Registration();
    $users = $users->fetch("WHERE km_regcode = '{$_POST['selected_user']}'")->resultSet();
    $user = $users[0];
    $horos = new Profile();
    $horos = $horos->fetchHoroscope("WHERE hs_userId = '{$_POST['selected_user']}'")->resultSet();
    $horos = $horos[0];
    unset($_SESSION['hs_imgPath']);
    $_SESSION['hs_imgPath'] = $horos['hs_imgPath'];
    $data = array(); 
    $data['user_name'] = $user['km_name'];
    if($horos){
        $data['hs_imgPath'] = '../'.$horos['hs_imgPath'];
    }    
    echo json_encode($data);
    exit();
}
$users = new Registration();
$users = $users->fetch()->resultSet(); 

$available_userId = array();
foreach($users as $user) { 
    array_push($available_userId, $user['km_regcode']);
}

if(isset($_POST['btn_horos'])) {      
      
    // if (!file_exists('uploads/horoscope')) {
    //     mkdir('uploads/horoscope', 0777, true);
    // }
    $horos = new Profile();
    $horos = $horos->fetchHoroscope("WHERE hs_userId = '{$_POST['user_id']}'")->resultSet();
    if($horos){        
        $data = array(); 
        $data[] = $_POST['user_id'];
        unlink($horos[0]['hs_imgPath']);
        $horos = new Profile();
        $horos = $horos->removeHoroscope($data);
    }
    if($_FILES['horos_image']['name']){
        $ImagePath = 'Kanya@Prof/jathagam/'.$_POST['user_id'].'_'.str_replace(" ", "_", $_FILES['horos_image']['name']);
        move_uploaded_file($_FILES['horos_image']['tmp_name'], '../'.$ImagePath);
        $data = array(); 
        $data[] = $_POST['user_id'];        
        $data[] = $ImagePath;
        $horos = new Profile();
        $horos = $horos->addHoroscope($data);
        $horos_id = $horos->lastInsertID();
        if($horos_id){   
            $_SESSION['horosAdded'] = true;
        } else {
            $_SESSION['horosAdded'] = false;
        }
    }  
    header("Location: horoupload.php");
}
?>
<!DOCTYPE html>
<html>

<link rel="stylesheet" href="../css/jquery-ui.css">
  
  <script src="../js/jquery-1.12.4.js"></script>
  <script src="../js/jquery-ui.js"></script>
  <script>
    var availableUserId = "";
    $(document).ready(function() {       
        availableUserId = <?php echo json_encode($available_userId); ?>;
        $("#user_id").autocomplete({
            source: availableUserId,
            autoFocus:true,
            select: function( event , ui ) {

            }
        });                
    });
  </script>

  <style type="text/css">
    
    input[type=text], input[type=password] {
    width: 55% !important;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}
  </style>


   <?php include("includes/headertop.php");?>
   <body class="home color-green boxed shadow">
      <div class="root">
         <?php include("includes/header.php");?>
         <section class="content reverse" style=" width: 90%;">
            <section>
                <div  id="message_container" style="text-align: center; display: none; color: red;font-size: 18px; font-weight: bold">
                    <span id="message"></span>
                </div>
               <section class="columns" style="margin-top:10px !important;  width: 90%;">
                  <h2><span>Horoscope Upload</span></h2>
                  <form action="" id="UploadHoros" method="post" enctype="multipart/form-data">
                    <table width="50%"  border="0">
                           <tbody>
                              
                              <tr>
                                 <th>User ID :</th>
                                 <td>
                                     <input type="text" id="user_id" name="user_id" placeholder="User ID" class="text" required="">
                                 </td>
                              </tr>
                              <tr>
                                 <th>User Name :</th>
                                 <td>
                                     <input type="text" id="user_name"  name="user_name" placeholder="User Name" readonly class="text">
                                 </td>
                              </tr>
                              
                              <tr id="horoscope">
                                 <th>Horoscope :</th>
                                 <td>
                                     <img id="horosImg" style="width:550px;height: 320px;"/>
                                 </td>
                              </tr>
                             
                              <tr>
                                 <th>Upload Horoscope:</th>                                 
                                    <td style="padding-top: 30px; padding-left: 15px">
                                        <!--<input type="file" name="horos_image[]" multiple="multiple" class="horos_image" style="float: left;">-->
                                        <input type="file" required accept=".jpg, .jpeg, .png, .gif" id="horos_image" name="horos_image" class="horos_image" style="float: left;">
                                    </td>                                 
                              </tr>    
                              
                              <tr>
                                  <td colspan="2">
                                    <input type="submit" name="btn_horos" value="Submit" style="background:#93bf1b;color:#ffffff;margin-top:10px;margin-left: 50%;" onclick="return validateUserInfo();">
                                 </td>
                              </tr>
                              
                           </tbody>
                        </table>
                      </form>
               </section>
            </section>
         </section>
         <div style=" clear: both;"></div>
         <?php include("includes/footer.php");?>
         <script>
            $(document).ready(function() {
               $('#UploadHoros').submit(function() {

                var ext = $('#horos_image').val().split('.').pop().toLowerCase();
                if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
                    alert('Please enter jpg/jpeg/png/gif file exactly');
                    return false;
                }

               });
            });
          </script>
         <?php
        if(isset($result)) {
	?>
        <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(1000, function() {
                            $('#message').text("");
                            $('#username').focus();
                    });
            }, 1000);
        </script>
	<?php
            }
	?>
        <script type="text/javascript">
            var availableUserId = "";
            var user = "";
            $(document).ready(function() {
                availableUserId = <?php echo json_encode($available_userId); ?>;
                $("#user_id").autocomplete({
                    source: availableUserId,
                    autoFocus:true,
                    select: function( event , ui ) {
                        $.ajax({
                            url: 'horoupload.php',
                            method: 'POST',
                            data: {
                              'selected_user':ui.item.label
                            },
                            success: function(response) {   
                                var user = JSON.parse(response);
                                $('#user_name').val(user.user_name);
                                if(user.hs_imgPath){
//                                    $('#horoscope').css('display','block');
                                    $('#horosImg').attr('src',user.hs_imgPath);
                                    $('#horos_image').val(user.hs_imgPath);
                                    $('#horos_image').prop('required',false);
                                }else{
                                    $('#horosImg').attr('src','');
                                    $('#horos_image').prop('required',true);
                                }
                            }
                        });
                    }
                });
            });
         
      
        $( document ).on('change','#plan_name ', function () {
            var plan_name = $(this).val();
            if(plan_name == 'Starter'){
                $('#plan_amount').val(200);
            }
            
        });
        </script>
      </div>
   </body>
</html>