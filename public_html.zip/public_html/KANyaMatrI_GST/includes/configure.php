<?php

//for subcaste
$countryArr=array('Afghanistan','Albania','Algeria','Angola','Argentina','Armenia','Australia','Austria','Bahamas','Bahrain','Bangladesh','Belgium','Bosnia and Herzegovina','Botswana','Brazil','Brunei','Bulgaria','Burundi','Cambodia','Cameroon','Canada','Chile','China','Colombia','Congo','Costa Rica','Croatia','Cuba','Cyprus','Czech Republic','Denmark','East Timor','Egypt','Estonia','Ethiopia','Fiji Islands','Finland','France','French Guiana','Germany','Greece','Greenland','Guatemala','Guyana','Honduras','Hong Kong','Hungary','Iceland','India','Indonesia','Iran','Iraq','Ireland','Israel','Italy','Jamaica','Japan','Jordan','Kazakhstan','Kenya','Korea','Korea North','Kuwait','Lebanon','Liberia','Libya','Luxembourg','Macedonia','Madagascar','Malaysia','Maldives','Mauritius','Mexico','Mongolia','Myanmar','Namibia','Nepal','Netherlands','New Zealand','Nigeria','Norway','Oman','Pakistan','Panama','Papua New Guinea','Paraguay','Peru','Philippines','Poland','Portugal','Qatar','Romania','Russia','Saudi Arabia','Seychelles','Singapore','Slovakia','Somalia','South Africa','Spain','Sri Lanka','Sudan','Suriname','Sweden','Switzerland','Syria','Taiwan','Thailand','Trinidad & Tobago','Turkey','Uganda','Ukraine','United Arab Emirates','United Kingdom','United States of America','Uruguay','Vatican City','Venezuela','Vietnam','Yugoslavia','Zambia','Zimbabwe');


//for stars
$stars_array = array('Anuradha / Anusham / Anizham','Ardra / Thiruvathira','Ashlesha / Ayilyam','Ashwini / Ashwathi','Bharani','Chitra / Chitha','Dhanista / Avittam','Hastha / Atham','Jyesta / Kettai','Krithika / Karthika','Makha / Magam','Moolam / Moola','Mrigasira / Makayiram','Poorvabadrapada / Puratathi','Poorvapalguni / Puram / Pubbhe','Poorvashada / Pooradam','Punarvasu / Punarpusam','Pushya / Poosam / Pooyam','Revathi','Rohini','Shatataraka / Sadayam / Satabishek','Shravan / Thiruvona','Swati / Chothi','Uttarabadrapada / Uthratadhi','Uttarapalguni / Uthram','Uttarashada / Uthradam','Vishaka / Vishakam');

//for Rasimoolam
//$rasi_array = array('Dhanus (Sagittarius)','Kanni (Virgo)','Katagam (Cancer)','Kumbha (Aquarius)','Makara (Capricorn)','Meena (Pisces)','Mesham (Aries)','Mithunam (Gemini)','Rishabam (Taurus)','Simham (Leo)','Tula (Libra)','Virichigam (Scorpio)');

$rasi_array = array('Dhanus','Kanni','Katagam','Kumbha','Makara','Meena','Mesham','Mithunam','Rishabam','Simham','Tula','Virichigam');

//for education
$edu_array = array( 4 => 'B.A',15 => 'B.Arch',5 => 'B.Com',28 => 'B.E.S',16 => 'B.Ed',17 => 'B.Pharm', 6 => 'B.Sc',14 => 'B.Tech',8 => 'BBA',9 => 'BBM',
    11 => 'BCA', 12 => 'BCS', 55 => 'BDS', 13 => 'BE', 27 => 'BFA', 10 => 'BHMS', 20 => 'BL', 26 => 'BMM', 19 => 'BPT', 7 => 'BS', 18 => 'BVSC',
    23 => 'C.Tech', 21 => 'CA', 60 => 'CPL', 22 => 'CS', 24 => 'Diploma' , 51 => 'Engineering', 1 => 'High School' ,2 => 'Hr.Sec. School', 3 => 'I.T.I.',
    61 => 'IAS', 25 => 'ICWA', 58 => 'LLB', 57 => 'LLM', 44 => 'M.Arch', 32 => 'M.Com', 31 => 'M.Ed', 46 => 'M.Pharm', 45 => 'M.Phil', 53=> 'M.Tech', 30 => 'MA',
    35 => 'MBA', 39 => 'MBBS', 36 => 'MBM', 37 => 'MCA', 42 => 'MD', 40 => 'MDS', 33 => 'ME', 29 => 'MHM', 43 => 'ML', 56 => 'MS', 59 => 'MS (Engg)', 34 => 'MSc',
    41 => 'MVSC' ,49 => 'P.G', 38 => 'PG.Diploma', 54 => 'PGDM', 47 => 'Ph.D', 50 => 'U.G',70 => 'D T. Ed', 71=>'B.E., MBA', 72=>'B.Tech., MBA',73=>'Hotel Management',
    74=>'B.E., MS', 75=>'M.Sc., B.Ed., MBA', 76=>'M.Sc., B.Ed', 77=>'B.Sc., B.Ed', 78=>'B.Com(CA)', 79=>'B.Tech., MS',
);

$height_array = array('4.6' =>'4ft 6in','4.7'=>'4ft 7in','4.8'=>'4ft 8in','4.9'=>'4ft 9in','4.10' => '4ft 10in','4.11' => '4ft 11in',
    '5'=>'5ft','5.1'=>'5ft 1in','5.2'=>'5ft 2in','5.3'=>'5ft 3in','5.4'=>'5ft 4in','5.5'=>'5ft 5in','5.6'=>'5ft 6in','5.7'=>'5ft 7in','5.8'=>'5ft 8in','5.9'=>'5ft 9in','5.10'=>'5ft 10in','5.11'=>'5ft 11in',
    '6'=>'6ft','6.1'=>'6ft 1in','6.2'=>'6ft 2in','6.3'=>'6ft 3in','6.4'=>'6ft 4in','6.5'=>'6ft 5in','6.6'=>'6ft 6in'
    );

//for OCCUPATION
$OccupationArr=array('ADMIN'=>array('1'=>'Manager','2'=>'Supervisor','3'=>'Officer','4'=>'Administrative Professional','5'=>'Executive','6'=>'Clerk'),'AGRICULTURE'=>array('7'=>'Agriculture & Farming Professional'),'AIRLINE'=>array('8'=>'Pilot','9'=>'Air Hostess','10'=>'Airline Professional'),'ARCHITECT & DESIGN'=>array('11'=>'Architect','12'=>'Interior Designer'),'BANKING & FINANCE'=>array('13'=>'Chartered Accountant','14'=>'Company Secretary','15'=>'Accounts/Finance Professional','16'=>'Banking Service Professional','17'=>'Auditor'),'BEAUTY & FASHION'=>array('18'=>'Fashion Designer','19'=>'Beautician'),'CIVIL SERVICES'=>array('20'=>'Civil Services (IAS/IPS/IRS/IES/IFS)'),'DEFENCE'=>array('21'=>'Army','22'=>'Navy','23'=>'Airforce'),'EDUCATION'=>array('24'=>'Professor / Lecturer','25'=>'Teaching / Academician','26'=>'Education Professional'),'HOSPITALITY'=>array('27'=>'Hotel / Hospitality Professional'),'IT & ENGINEERING'=>array('28'=>'Software Professional','29'=>'Hardware Professional','30'=>'Engineer - Non IT'),'LEGAL'=>array('31'=>'Lawyer & Legal Professional'),'LAW ENFORCEMENT'=>array('32'=>'Law Enforcement Officer'),'MEDICAL'=>array('33'=>'Doctor','34'=>'Health Care Professional','35'=>'Paramedical Professional','36'=>'Nurse'),'MARKETING & SALES'=>array('37'=>'Marketing Professional','38'=>'Sales Professional'),'MEDIA & ENTERTAINMENT'=>array('39'=>'Journalist','40'=>'Media Professional','41'=>'Entertainment Professional','42'=>'Event Management Professional','43'=>'Advertising / PR Professional'),'MERCHANT NAVY'=>array('44'=>'Mariner / Merchant Navy'),'SCIENTIST'=>array('45'=>'Scientist / Researcher'),'TOP MANAGEMENT'=>array('46'=>'CXO / President, Director, Chairman'),'OTHERS'=>array('47'=>'Consultant','48'=>'Customer Care Professional','49'=>'Social Worker','50'=>'Sportsman','51'=>'Technician','52'=>'Arts & Craftsman','53'=>'Business','54'=>'Others','55'=>'Not Working'));

$paymenttype=array('1'=>'paypal','2'=>'netbanking','3'=>'nescoOffices','4'=>'payatbanks');

$date_array = array('01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31');

//$profileCreatedFor=array('self'=>'By Self','son'=>'Son','daughter'=>'Daughter','brother'=>'Brother','sister'=>'Sister','relative'=>'Relative','friend'=>'Friend');

$month_array = array('01'=>'Jan','02'=>'Feb','03'=>'Mar','04'=>'Apr','05'=>'May','06'=>'Jun','07'=>'Jul','08'=>'Aug','09'=>'Sep','10'=>'Oct','11'=>'Nov','12'=>'Dec');

$day_array = array('Sunday', 'Monday', 'Tuesday', 'Wednesday','Thursday', 'Friday', 'Saturday');

$registeredBy_array = array('byself', 'byadmin');

$profileStatus_array = array('deleted','block','pending','postpone','live', 'suspend');

$paymentStatus = array('activate', 'deactivate');

$plan_array = array('Starter' => '200');

$paymode_array = array('kovipatti office','chennai office','online','paid at bank');

$blood_array = array('A+','O+','B+','AB+','A-','O-','B-','AB-','A1+','A1B+','A2+','A2B+','A1-','A1B-','A2-','A2B-','B1+');

?>