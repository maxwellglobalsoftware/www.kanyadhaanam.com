<header class="h5">
  
   <section class="main-header">
      <p class="title">
         <a href="home.php">
         <img src="images/logo.png" alt="Matrimony" width="300">
         </a>
      </p>
      <nav class="" style="width:730px; float: left; margin-bottom: 5.9%;">
         <div style=" float: right; color: #f90808; margin-top: 25px; font-weight: bold; "> <span>
            <a href="home.php" style="color: #f90808;"><i class="fa fa-home" aria-hidden="true"></i> Home </a> &nbsp;| &nbsp;</span>
            <span><a href="changepassword.php" style="color: #f90808;"><i class="fa fa-unlock-alt" aria-hidden="true"></i> Change Password</a> &nbsp;|&nbsp;</span> 
            <span><a href="index.php" style="color: #f90808;"><i class="fa fa-power-off" aria-hidden="true"></i> Logout </a> </span>
         </div>
      </nav>
      <nav class="mainmenu">
         <ul>
            <li class="parent"><a href="home.php">Home</a></li>
            <li><a href="registration.php">New Registration</a></li>
            <li><a href="manage_profiles.php">View Registration</a></li>
            <li class="parent">
               <a href="#">Payment <i class="fa fa-caret-down" aria-hidden="true"></i> </a>
               <ul style="width: 228px;">
                  <li><a href="payment.php">Manual Payment</a></li>
                  <li><a href="manage_payments.php">View Payment</a></li>
                  <li><a href="nopayment_profiles.php">Login but not Payment Profiles</a></li>
                  <li><a href="manage_contact_profile_history.php">Contact Profile</a></li>
                  <li><a href="manage_horoscope_profile_history.php">Horoscope Profile</a></li>
                  
               </ul>
            </li>
            <li class="parent right">
               <a href="">Upload <i class="fa fa-caret-down" aria-hidden="true"></i></a>
               <ul style="width: 228px;">
                  <li><a href="photoupload.php">Profile Photo Upload</a></li>
                  <li><a href="photoalbumupload.php">Album Photos Upload</a></li>
                  <li><a href="horoupload.php">Horoscope Upload</a></li>
               </ul>
            </li>
            <li class="parent right">
               <a href="">Delete <i class="fa fa-caret-down" aria-hidden="true"></i></a>
               <ul style="width: 228px;">
                  <li><a href="manage_album.php">Profile Photo Delete</a></li>
                  <li><a href="delete_horoscope.php">Horoscope Delete</a></li>
               </ul>
            </li>
            <li class="parent right">
               <a href="">Report <i class="fa fa-caret-down" aria-hidden="true"></i></a>
               <ul style="width: 228px;">
                  <li><a href="login_user_report.php">Login User</a></li>
                  <li><a href="notlogin_user_report.php">Not Login User</a></li>
                  <li><a href="not_photoupload_profile.php">Photo Not Upload User</a></li>
                  <li><a href="not_horoscopeupload_profile.php">Horoscope Not Upload User</a></li>
                  <li><a href="district_wise_report.php">District Report</a></li>
                 
                 
                  <li><a href="partner_preferences.php">Partner Preferences</a></li>
                  <li><a href="matching_profiles.php">Matching Profiles</a></li>
               </ul>
            </li>
            
         </ul>
      </nav>
      <div class="clear"></div>
   </section>
</header>
<style>
   .landing-form p {
   margin: 1em 0;
   }
   .slider {
   height: 410px !important;
   }
   .text {
   padding: 5px;
   width: 94%;
   color: #000;
   border: 1px solid #ccc;
   border-radius: 2px;
   background: #fff;
   }
   .content>aside section table td {
   padding: 1px 0;
   color: #3f3f3f;
   font-size: 12px;
   }
   .content>aside section table th {
   padding: 1px 0;
   color: #666666;
   font-size: 11px;
   border-bottom: 0px solid #e5e5e5;
   }
</style>