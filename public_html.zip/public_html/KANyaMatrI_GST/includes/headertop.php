<head>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   <title>Kanyadhaanam Matrimony</title>
   <meta name="viewport" content="width=1000, User-scalable=yes">
   <link rel="icon" href="images/favicon.png" type="image/x-icon">
   <link href="../css/font-awesome.css" rel="stylesheet" type="text/css">
   <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
   <link href="../css/style-headers.css" rel="stylesheet" type="text/css" media="screen">
   <link href="../css/style-colors.css" rel="stylesheet" type="text/css" media="screen">
   <link href="https://fonts.googleapis.com/css?family=Josefin+Sans" rel="stylesheet">
   <link rel="stylesheet" type="text/css" href="css/admin.css">
   <link href="css/style.css" rel="stylesheet" type="text/css" media="screen">
   <style type="text/css">
      .select > span {
      display: none !important;
      }
      @font-face {
      font-family: 'Roboto';
      src: url(fonts/Roboto-Regular.ttf);
      }
      .color-green .main-header a {
      color: #fff;
      font-weight: normal;
      }
   </style>

    <style type="text/css">@font-face {
      font-family: 'blogger_sansregular';
      src: url('fonts/Blogger_Sans-webfont.eot');
      src: url('fonts/Blogger_Sans-webfont.eot?#iefix') format('embedded-opentype'),
      url('fonts/Blogger_Sans-webfont.woff2') format('woff2'),
      url('fonts/Blogger_Sans-webfont.woff') format('woff'),
      url('fonts/Blogger_Sans-webfont.ttf') format('truetype'),
      url('fonts/Blogger_Sans-webfont.svg#blogger_sansregular') format('svg');
      font-weight: normal;
      font-style: normal;
      }
   </style>

   <link href="https://fonts.googleapis.com/css?family=Rubik" rel="stylesheet">
</head>