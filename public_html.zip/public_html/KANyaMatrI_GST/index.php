<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   if($_SESSION['Kamma_Matri']){
       unset($_SESSION['Kamma_Matri']);
   }
    if($_SESSION['Kamma_Manage_Matri']){
      unset($_SESSION['otp_no']);
        unset($_SESSION['Kamma_Manage_Matri']);
    }
   date_default_timezone_set('Asia/Kolkata');
   require_once '../init.php';
   
   if(isset($_SESSION['loginerror'])) {
    $result = "Invalid login";
    unset($_SESSION['loginerror']);
   }
   
   if(isset($_POST['btn_submit'])) {
       $username = $_POST['username'];
       $password = $_POST['password'];
       
       echo '<br>';
   
       $cryptKey  = 'MaTriKamMa$123&brides$1*10#^&matriMonY@Grooms';
       $confm_pswd      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $password, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
       
       
   
       $user = new User();
       $user = $user->loginOTP($username, $confm_pswd);  
   
       if($user) {
   
            $otp_c = mt_rand(756912,985466);
   
            $to = "support@kanyadhaanam.com";
   $subject = "Code Verification - www.kanyadhaanam.com";
   
            $msg= "<table>
            <tr><td align='right'>Your OTP Code is&nbsp;:&nbsp;</td><td>$otp_c</td></tr>
            </table><br>";
   
            // Always set content-type when sending HTML email
   $headers = "MIME-Version: 1.0" . "\r\n";
   $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
   
   // More headers
   $headers .= 'From: <support@kanyadhaanam.com>' . "\r\n";
   
   $send = mail($to,$subject,$msg,$headers);
   
   
   if($send){
            $_SESSION['otp_no'] = $otp_c;
            $_SESSION['login_success'] = true;
            header('Location: otp_confirm.php');
         }
   
           //$data = array();
           //$data[] = $_SESSION['Kamma_Matri']['id'];
           //$data[] = date_format(new DateTime(), 'd-m-Y');
           //$data[] = date_format(new DateTime(), 'h:i A');
   
           //$login = new Login();
           //$login = $login->setLogin($data);
   
           //header('Location: home.php');
         
       } else {
           header('Location: index.php');
       }
   }
   
   ?>
<!DOCTYPE html>
<html>
   <style type="text/css">
      .content-slider input[type="submit"] {
      width: 100%;
      background-color: #ff500b ;
      color: white;
      padding: 12px 20px;
      border: none;
      font-size: 18px;
      letter-spacing: 1px;
      cursor: pointer;
      outline: none;
      transition: .5s ease-in;
      -webkit-transition: .5s ease-in;
      -ms-transition: .5s ease-in;
      -o-transition: .5s ease-in;
      -moz-transition: .5s ease-in;
      }
      input[type=submit]:hover {
      background-color:#ff8400;
      }
   </style>
   <script type="text/javascript">
      function logfn(form)
      
      {
      
      
      if(form.username.value=="") { alert("Please Enter Username"); form.username.focus(); return false; }
      
      if(form.password.value=="") { alert("Please Enter Password"); form.password.focus(); return false; }
      
      }
      
   </script>
   <?php include("includes/headertop.php");?>  
   <body>
      <div class="container">
         <center> <a href="index.php">
            <img src="images/logo.png" alt="Kanyadhaanam Matrimony" width="350">
            </a>
         </center>
         <section class="content reverse">
            <center>
              
                  <section class="columns content-slider" style="margin-top:20px !important;">
                     <section style=" width: 350px; padding:5px;background:#ededed; border: solid 1px #ccc;">
                        <h3 style="      background: #fd9500;
                           padding: 15px;
                           font-size: 1.4em;
                           font-weight: normal;
                           text-align: center;
                           text-transform: uppercase;
                           color: #fff; margin-top: 0px;">LOGIN</h3>
                        <form  method="post" name="LoginForm" onsubmit="return logfn(LoginForm);">
                           <div  id="message_container" style="text-align: center; display: none; color: red; font-weight: bold">
                              <span id="message"></span>
                           </div>
                           <div class="container">
                              <label style=" text-align: left;"><b>Username</b></label>
                              <input id="username" type="text" placeholder="Enter Username" name="username" >
                              <br>
                              <label style=" text-align: left;"><b>Password</b></label>
                              <input type="password" placeholder="Enter Password" name="password" >
                              <br><br>
                              <input type="submit" name="btn_submit" value="Login">
                              
                           </div>
                        </form>
                     </section>
                  </section>
               
            </center>
         </section>
      </div>
      <script src="../js/jquery-1.12.4.js"></script>
      <?php
         if(isset($result)) {
         ?>
      <script>
         $('#message_container').fadeIn(10);
         $('#message').text("<?php echo $result; ?>");
         setTimeout(function() {
                 $('#message_container').fadeOut(1000, function() {
                         $('#message').text("");
                         $('#username').focus();
                 });
         }, 1000);
      </script>
      <?php
         }
         ?>
   </body>
</html>