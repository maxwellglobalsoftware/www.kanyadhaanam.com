<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
ini_set('memory_limit','128M');
ob_start();
session_start();
require_once 'includes/configure.php';
require_once 'includes/session_handler.php';
require_once '../init.php';
date_default_timezone_set('Asia/Kolkata');

if(empty($_SESSION['Kamma_Matri'])){
    header("Location: index.php");
}

if($_SESSION['Kamma_Matri']){
    $enteredBy = $_SESSION['Kamma_Matri']['id'];    
}


if(isset($_SESSION['paymentAdded'])) {
    if($_SESSION['paymentAdded']) {
        $result = "Payment Added";
    } else {
        $result = "Failed to add Payment";
    }
    unset($_SESSION['paymentAdded']);
}
$users = new Registration();
$users = $users->fetch()->resultSet(); 

$available_userId = array();
foreach($users as $user) { 
    array_push($available_userId, $user['km_regcode']);
}
if(isset($_POST['profile_id'])){
    $profile_id = $_POST['profile_id'];
    $photos = new Profile();
    $photos = $photos->fetchPhotos("WHERE pho_userId = '{$profile_id}' ORDER BY id DESC")->resultSet();
}
if($_POST['flag'] == 'Yes') {      
    $data = array();   
    echo 'selected_photos = '.$_POST['selected_photos'];
    $selected_photos = explode(',', $_POST['selected_photos']);
    foreach($selected_photos as $photo){
        $photos = new Profile();
        $photos = $photos->fetchPhotos("WHERE id = '{$photo}' ORDER BY id DESC")->resultSet();
        $photos = $photos[0];
        $photo_imgPath = $photos['pho_imgPath'];
        
        $data = array(); 
        $data[] = $photo;
        $photos = new Profile();
        $photos = $photos->removePhotos($data);  
        if($photos->rowCount()){
            unlink('../'.$photo_imgPath);
        }
    }
    header("Location: manage_album.php");
}
//print_r(count($photos));


//header("Location: manage_payments.php");

?>
<!DOCTYPE html>
<html>

    <link rel="stylesheet" href="../css/jquery-ui.css">
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
    <link rel="stylesheet" href="../css/bootstrap-datetimepicker.min.css" />
  
    <script src="../js/jquery-1.12.4.js"></script>
    <script src="../js/jquery-ui.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/moment.js"></script>
    <script src="../js/bootstrap-datetimepicker.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>


<style type="text/css">
    
    input[type=text], input[type=password], select {
    width: 40% !important;
    padding: 12px 20px !important;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

th {
    text-align: left;
    font-size: 16px;
}
  </style>

   <?php include("includes/headertop.php");?>
   <body class="home color-green boxed shadow">
      <div class="root">
         <?php include("includes/header.php");?>
         <section class="content reverse" style=" width: 70%;">
            <section>
                <div  id="message_container" style="text-align: center; display: none; color: red;font-size: 18px; font-weight: bold">
                    <span id="message"></span>
                </div>
               <section class="columns" style="margin-top:10px !important;  width: 90%;">
                  <h2><span>Delete Photo</span></h2>
                  <form action="" id="photo_form" method="post" enctype="multipart/form-data">
                      <input type="hidden" name="selected_photos" id="selected_photos" />
                      <input type="hidden" name="profile_id" value="<?php echo $profile_id;?>" id ="profile_id" />
                      <input type="hidden" name="flag" id ="flag" />
                    <table width="50%"  border="0">
                           <tbody>
                              
                              <tr>
                                 <!--<th></th>-->
                                 <td>
                                     <div class="row">
                                         <input class="col-md-9" type="text" id="user_id" value="<?php echo $profile_id;?>" name="user_id" placeholder="User ID" class="text" required="">
                                     </div>
                                     
                                 </td>
<!--                                 <td>
                                     <input type="button" class="view_photo" style="cursor: pointer;padding: 0px;color: blue;border: none;font-weight: bold;" value="View">
                                 </td>-->
                              </tr>
                              
                              
                              <tr>
                                 <td style=" padding-left: 0px;">
                                 <?php 
                                 if($photos){
                                 foreach($photos as $photo){ ?>
                              
                                     <div class="col-md-4" style="padding:5px;">
                                 
                                     
                                     <label class="checkbox-inline " style="margin-left: 0px;padding-left: 20px;">
                                         <input type="checkbox" class="delete_photo" name="photos"  id="<?php echo $photo['id']; ?>" value="<?php echo $photo['id']; ?>">
                                     </label>
                                 
                                     <img style="width:102px;height: 120px;" src="../<?php echo $photo['pho_imgPath']; ?>" />
                                     </div>
                                 
                                 <?php }
                                 }else{?>
                                     <div id="result-content">
                                <h4 style="margin: 1.5em 1em;text-align: center;color: #17800a;"> Photos not available. </h4>
                            </div>
                                 <?php } ?>
                                 </td>
                              </tr>
                              <tr>
                                  <td colspan="2">
                                    
                                      <input type="button" class="delete" name="btn_delete" value="Delete" style="background:#93bf1b;color:#ffffff;margin-top:10px;margin-left: 50%;">
                                    
                                 </td>
                              </tr>
                              
                           </tbody>
                        </table>
                      </form>
               </section>
            </section>
         </section>
         <div style=" clear: both;"></div>
         <?php include("includes/footer.php");?>
          <?php
        if(isset($result)) {
	?>
        <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(1000, function() {
                            $('#message').text("");
                            $('#username').focus();
                    });
            }, 1000);
        </script>
	<?php
            }
	?>
      </div>
        <script type="text/javascript">
            var availableUserId = "";
            $(document).ready(function() {
                $('#start_from').datetimepicker({
                    format: 'DD-MM-YYYY',
                    pickTime:false,
                    sideBySide:true
                });
                $('#paid_date').datetimepicker({
                    format: 'DD-MM-YYYY',
                    pickTime:false,
                    sideBySide:true
                });
                
                availableUserId = <?php echo json_encode($available_userId); ?>;
               $("#user_id").autocomplete({
                    source: availableUserId,
                    autoFocus:true,
                    select: function( event , ui ) {
                        $('#profile_id').val(ui.item.label);            
                        $('#photo_form').attr('method', 'post');
                        $('#photo_form').attr('action', 'manage_album.php');
                        $('#photo_form').submit();
                    }
                });                
            });
         
      
        $( document ).on('change','#plan_name ', function () {
            var plan_name = $(this).val();
            if(plan_name == 'Starter'){
                $('#plan_amount').val(200);
            }
            
        });
        $(document).on('click','.delete_photo ', function () {    
            var selected_days = $('input[name="photos"]:checked').map(function () {  
                return this.value;
            }).get().join(",");    
            $('#selected_photos').val(selected_days);
        });
        </script>
        <script>            
            $(document).on('click', '.delete', function() { 
                var confirm_msg = confirm("Are you sure to delete?");
                if (confirm_msg == true) {
                    $('#flag').val('Yes');
                    $('#photo_form').attr('method', 'post');
                    $('#photo_form').attr('action', 'manage_album.php');
                    $('#photo_form').submit();
                }else{

                }                
            });
        </script>
   </body>
</html>