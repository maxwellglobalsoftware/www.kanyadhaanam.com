<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
ini_set('memory_limit','128M');
ob_start();
session_start();
require_once 'includes/session_handler.php';
require_once 'includes/configure.php';
require_once '../init.php';
date_default_timezone_set('Asia/Kolkata');

$current_year = date("Y-m-d");

if(empty($_SESSION['Kamma_Matri'])){
    header("Location: index.php");
}


if($_SESSION['Kamma_Matri']){
    $enteredBy = $_SESSION['Kamma_Matri']['id'];    
}

if(isset($_SESSION['profile_deleted'])) {
    if($_SESSION['profile_deleted']) {
        $result = "Successfully Deleted";
    } else {
        $result = "Failed to delete";
    }
    unset($_SESSION['profile_deleted']);
}


if(isset($_POST['search_btn'])){


    $user_id = $_POST['user_id'];

    $today = date('Y-m-d');

    $paymentIDs = new Payment();
    $paymentIDs = $paymentIDs->fetch("WHERE pl_userId = '{$user_id}'  ORDER BY id DESC LIMIT 1")->resultSet(); 
    $paymentID = $paymentIDs[0];  
    
    $payments = new Payment();
    $payments = $payments->fetch("WHERE pl_userId = '{$user_id}' AND id = '{$paymentID['id']}' AND pl_status = 'activate' AND '{$today}' BETWEEN pl_startDate AND pl_expireDate ORDER BY id DESC")->resultSet(); 
    $payment = $payments[0]; 

    if($payment){
    $profiles = new Profile();
    $profiles = $profiles->fetch("WHERE pv_userId = '{$user_id}' AND pv_paymentId = '{$payment['id']}' AND contact = '1' GROUP BY pv_viewedId")->resultSet();
    // $profiles = $profiles->fetch("WHERE pv_userId = '{$user_id}' AND pv_paymentId = '{$payment['id']}' AND contact = '1'")->resultSet();
    }  else {

    }
    
} 


if(isset($_SESSION['profile_search'])){


    $user_id = $_SESSION['profile_search'];
    unset($_SESSION['profile_search']);

    $today = date('Y-m-d');

    $paymentIDs = new Payment();
    $paymentIDs = $paymentIDs->fetch("WHERE pl_userId = '{$user_id}'  ORDER BY id DESC LIMIT 1")->resultSet(); 
    $paymentID = $paymentIDs[0];  
    
    $payments = new Payment();
    $payments = $payments->fetch("WHERE pl_userId = '{$user_id}' AND id = '{$paymentID['id']}' AND pl_status = 'activate' AND '{$today}' BETWEEN pl_startDate AND pl_expireDate ORDER BY id DESC")->resultSet(); 
    $payment = $payments[0]; 

    if($payment){

    $profiles = new Profile();
    $profiles = $profiles->fetch("WHERE pv_userId = '{$user_id}' AND pv_paymentId = '{$payment['id']}' AND contact = '1' GROUP BY pv_viewedId")->resultSet();
    //$profiles = $profiles->fetch("WHERE pv_userId = '{$user_id}' AND pv_paymentId = '{$payment['id']}' AND contact = '1'")->resultSet();
    }  else {

    }
    
} 


$users = new Registration();
$users = $users->fetch("WHERE km_status = 'live'")->resultSet(); 

$available_userId = array();
foreach($users as $user) { 
    array_push($available_userId, $user['km_regcode']);
}


if(isset($_POST['delete_id'])){
    $data = array();
    $data[] = $_POST['delete_id'];

    $deletepayprofile = new Profile();
    $deletepayprofile = $deletepayprofile->removeContactProfile($data);
    $deletepayprofile_id = $deletepayprofile->rowCount();

    if($deletepayprofile_id){ 
        $_SESSION['profile_deleted'] = true;
    }else{
        $_SESSION['profile_deleted'] = false;
    }
    $_SESSION['profile_search'] = $_POST['profile_id'];
    header('Location: manage_contact_profile_history.php');
}
?>
<!DOCTYPE html>
<html>

    <link rel="stylesheet" href="../css/jquery-ui.css">
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
    <link rel="stylesheet" href="../css/bootstrap-datetimepicker.min.css" />
    <!-- DataTables CSS -->
    <link href="../css/plugins/dataTables.bootstrap.css" rel="stylesheet">
  
    <script src="../js/jquery-1.12.4.js"></script>
    <script src="../js/jquery-ui.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/moment.js"></script>
    <script src="../js/bootstrap-datetimepicker.js"></script>
    <!-- DataTables JavaScript -->
    <script src="../js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="../js/plugins/dataTables/dataTables.bootstrap.js"></script>
    <script type="text/javascript">
    function searchfn(form){

    if(form.user_id.value==""){ alert("Please enter user id"); form.user_id.focus(); return false;  }


    }
</script>   
    
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
  <style>
    .table>tbody>tr>td {
        padding: 2px;
    }
    .pagination>.active>a{    
        background-color: #077907;
        border-color: #077907;
    }
    .pagination>.active>a:hover{
        color: #077907;
        background-color: yellowgreen;
        border-color: yellowgreen;
    }
    .pagination>li>a, .pagination>li>span {       
        color: whitesmoke;
        text-decoration: none;
        background-color: limegreen;
    }
  </style>

   <?php include("includes/headertop.php");?>
   <body class="home color-green boxed shadow">
      <div class="root">
         <?php include("includes/header.php");?>
         <section class="content reverse" style="width: 100%;">
            <section>
                <div  id="message_container" style="text-align: center; display: none; color: red;font-size: 18px; font-weight: bold">
                    <span id="message"></span>
                </div>
               <section class="columns" style="  width: 100%;">
                <h2><span style="padding: 0px;">Contact Profile History</span></h2>
                <!--<div class="panel panel-primary">-->

                <form method="post"  action="" name="SearchForm" onsubmit="return searchfn(SearchForm);">                 
                <div class="col-md-12">
                
                <div class="col-md-3" style="margin-left: 30%;">
                <input type="text" name="user_id" id="user_id" class="text" style=""  placeholder="User ID" <?php if($user_id){ ?> value="<?php echo $user_id; ?>" <?php } ?> autocomplete="off">
                </div>
                <div class="col-md-3" style="margin-top: 0.2%;">
                <input type="submit" name="search_btn" value="Search" style="background:#93bf1b;color:#ffffff;width: 50%;height: 40px;" >
                </div>
                </div>
                 </form>


                
                <!-- /.panel-heading -->
                <div class="panel-body response_panel"  style="width:100%;margin: 0px;padding: 2px;">
                    <div class="table-responsive" id="customer_table" style="overflow-x:hidden">
                       <form method="post" id='search_result' action="">
                            <input type="hidden" id="submit_id" name="submit_id" value="<?php echo $_POST['submit_id'];?>" />
                            <input type="hidden" id="delete_id" name="delete_id" value="<?php echo $_POST['delete_id'];?>" />
                            <input type="hidden" id="profile_id" name="profile_id" value="<?php echo $user_id;?>" />
                            <table class="table table-striped table-bordered table-hover" id="dataTables_customer">
                                <thead>
                                    <tr class="center heading" style="background-color:#077907;border-color: #077907;color: white">
                                        <th style="text-align: center;">S.No</th>
                                        <th style="text-align: center;">User ID</th>
                                        <th style="text-align: center;">User Name</th>
                                        <th style="text-align: center;">Viewed ID</th>
                                        <th style="text-align: center;">Viewed User Name</th>
                                        <th style="text-align: center;">Viewed Date</th>
                                        <th style="text-align: center;">Viewed Time</th>
                                        <th style="text-align: center;">Action</th>  
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $sno = 1;
                                    if($profiles){
                                    foreach($profiles as $conprofile){ 
                                        $profiles = new Registration();
                                        $profiles = $profiles->fetch("WHERE km_regcode = '{$conprofile['pv_userId']}'")->resultSet();
                                        $profile = $profiles[0];

                                        $viewedprofiles = new Registration();
                                        $viewedprofiles = $viewedprofiles->fetch("WHERE km_regcode = '{$conprofile['pv_viewedId']}'")->resultSet();
                                        $viewedprofile = $viewedprofiles[0];
                                        ?>
                                    <tr>                                    
                                        <td style="text-align: center;"><?php echo $sno;?></td>
                                        <td style="text-align: left;"><?php echo ucwords($conprofile['pv_userId']);?></td>
                                        <td style="text-align: left;"><?php echo ucwords($profile['km_name']);?></td>
                                        <td style="text-align: left;"><?php echo ucwords($conprofile['pv_viewedId']);?></td>
                                        <td style="text-align: left;"><?php echo ucwords($viewedprofile['km_name']);?></td>
                                        <td style="text-align: center;"><?php echo ucwords($conprofile['pl_viewedDate']);?></td>
                                        <td style="text-align: center;"><?php echo $conprofile['pl_viewedTime'];?></td>
                                        <td style="text-align: center;"><input type="button" class="delete_profile" id="<?php echo $conprofile['pv_viewedId'];?>" style="cursor: pointer;padding: 0px;color: blue;border: none;font-weight: bold;" value="Delete"></td>  
                                    </tr>
                                    <?php 
                                    $sno++;
                                    } } ?>
                                </tbody>

                            </table>
                        </form>

                    </div>

                </div>
                <!-- /.panel-body -->
            <!--</div>-->
               </section>
            </section>
         </section>
         <div style=" clear: both;"></div>
         <?php include("includes/footer.php");?>
         <script src="js/jquery.js"></script>
         <script src="js/jquery.min.js"></script>
          <?php
        if(isset($result)) {
	?>
        <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(1000, function() {
                            $('#message').text("");
                            $('#username').focus();
                    });
            }, 1000);
        </script>
	<?php
            }
	?>
      </div>
         <script type="text/javascript">
            var availableUserId = "";
            var table = "";
            $(document).ready(function() {
                 table = $("#dataTables_customer").DataTable({
                    "order": [[ 1, "desc" ]],
                    "pageLength": 25

                });
                $('#from_date').datetimepicker({
                    format: 'DD-MM-YYYY',
                    pickTime:false,
                    sideBySide:true
                });
                $('#to_date').datetimepicker({
                    format: 'DD-MM-YYYY',
                    pickTime:false,
                    sideBySide:true
                });
                
                availableUserId = <?php echo json_encode($available_userId); ?>;
               $("#user_id").autocomplete({
                    source: availableUserId,
                    autoFocus:true,
                });                
            });

        $(document).on('click', '.delete_profile', function() {   
          var confirm_msg = confirm("Are you sure to delete?");
          if (confirm_msg == true) {
              var profile_id =  $(this).attr('id');
              //alert(profile_id);
              $('#delete_id').val(profile_id);             
              $('#search_result').attr('method', 'post');
              $('#search_result').attr('action', 'manage_contact_profile_history.php');
              $('#search_result').submit();
          }            
      });
        

        </script>
   </body>
</html>