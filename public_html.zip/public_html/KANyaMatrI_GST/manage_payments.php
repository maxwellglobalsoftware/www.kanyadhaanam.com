<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
ini_set('memory_limit','128M');
ob_start();
session_start();
require_once 'includes/session_handler.php';
require_once 'includes/configure.php';
require_once '../init.php';
date_default_timezone_set('Asia/Kolkata');

$current_year = date("Y-m-d");

if(empty($_SESSION['Kamma_Matri'])){
    header("Location: index.php");
}

if($_SESSION['Kamma_Matri']){
    $enteredBy = $_SESSION['Kamma_Matri']['id'];    
}

if(isset($_SESSION['paymentUpdate'])) {
    if($_SESSION['paymentUpdate']) {
        $result = "Payment Updated";
    } else {
        $result = "Failed to update Payment";
    }
    unset($_SESSION['paymentUpdate']);
}

if(isset($_POST['search_btn'])){

    $from_date = date_format(new DateTime($_POST['from_date']), 'Y-m-d');
    $to_date = date_format(new DateTime($_POST['to_date']), 'Y-m-d');
    $status = $_POST['status'];

    if($status == 'activate'){

        // echo 1;
        // exit();
        $condition = "WHERE pl_startDate BETWEEN '{$from_date}' AND '{$to_date}' ORDER BY id DESC";
        $payments = new Payment();
        $payments = $payments->fetch("WHERE pl_startDate BETWEEN '{$from_date}' AND '{$to_date}' ORDER BY id DESC")->resultSet(); 

    } else if($status == 'nopayment'){
        
        $condition = "";
        $export_status = "not_paid";
    } else {

        $condition = "WHERE pl_expireDate BETWEEN '{$from_date}' AND '{$to_date}' ORDER BY id DESC";
        $payments = new Payment();
        $payments = $payments->fetch("WHERE pl_expireDate BETWEEN '{$from_date}' AND '{$to_date}' ORDER BY id DESC")->resultSet();
    }

} else {
$year = date('Y');
$condition = "WHERE year(reg_date) = '{$year}' ORDER BY id DESC";
$payments = new Payment();
$payments = $payments->fetch("WHERE year(reg_date) = '{$year}' ORDER BY id DESC")->resultSet(); 

}


if(isset($_POST['submit_id'])){
    unset($_SESSION['payment_id']);
    $_SESSION['payment_id'] = $_POST['submit_id'];
    header("Location: payment.php");
}
?>
<!DOCTYPE html>
<html>

    <link rel="stylesheet" href="../css/jquery-ui.css">
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
    <link rel="stylesheet" href="../css/bootstrap-datetimepicker.min.css" />
    <!-- DataTables CSS -->
    <link href="../css/plugins/dataTables.bootstrap.css" rel="stylesheet">
  
    <script src="../js/jquery-1.12.4.js"></script>
    <script src="../js/jquery-ui.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/moment.js"></script>
    <script src="../js/bootstrap-datetimepicker.js"></script>
    <!-- DataTables JavaScript -->
    <script src="../js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="../js/plugins/dataTables/dataTables.bootstrap.js"></script>
<script type="text/javascript">
    function searchfn(form){

    if(form.from_date.value==""){ alert("Please select from date"); form.from_date.focus(); return false;  }

    if(form.to_date.value==""){ alert("Please select to date"); form.to_date.focus(); return false;  }

    if(form.status.value==""){ alert("Please select status"); form.status.focus(); return false;  }

    }
</script>   
    
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
  <style>
    .table>tbody>tr>td {
        padding: 2px;
    }
    .pagination>.active>a{    
        background-color: #077907;
        border-color: #077907;
    }
    .pagination>.active>a:hover{
        color: #077907;
        background-color: yellowgreen;
        border-color: yellowgreen;
    }
    .pagination>li>a, .pagination>li>span {       
        color: whitesmoke;
        text-decoration: none;
        background-color: limegreen;
    }

    th {
    
    font-weight: normal;
}


  </style>

   <?php include("includes/headertop.php");?>
   <body class="home color-green boxed shadow">
      <div class="root">
         <?php include("includes/header.php");?>
         <section class="content reverse" style="width: 100%;">
            <section>
                <div  id="message_container" style="text-align: center; display: none; color: red;font-size: 18px; font-weight: bold">
                    <span id="message"></span>
                </div>
               <section class="columns" style="margin-top:0px !important;  width: 100%;">
                <h2><span style="padding: 0px;">Payment Details </span></h2>
                
            <form method="post"  action="" name="SearchForm" onsubmit="return searchfn(SearchForm);">                 
            <div class="col-md-12">
            <div class="col-md-3">
            <label>From Date &nbsp;&nbsp;
            <input type="text" name="from_date" id="from_date" class="text"  style="" placeholder="-- Date --" <?php if($_POST['from_date']){ ?> value="<?php echo $_POST['from_date']; ?>" <?php } else { ?> value="<?php echo date("d-m-Y"); ?>" <?php } ?> autocomplete="off" >
            </label>
            </div>
            <div class="col-md-3">
            <label>To Date &nbsp;&nbsp;
            <input type="text" name="to_date" id="to_date" class="text" style=""  placeholder="-- Date --" <?php if($_POST['to_date']){ ?> value="<?php echo $_POST['to_date']; ?>" <?php } else { ?> value="<?php echo date("d-m-Y"); ?>" <?php } ?> autocomplete="off">
            </label>
            </div>
            <div class="col-md-3" style="margin-top: 1%;">
            <label>Status &nbsp;&nbsp;
            <select name="status" class="text" style="">
            <option value="" Selected Disabled>-- Select --</option>
            <option value="activate" <?php if($_POST['status'] == 'activate'){ echo 'selected'; } ?>>Activate</option>
            <option value="expired" <?php if($_POST['status'] == 'expired'){ echo 'selected'; } ?> >Expired</option>
            <!--<option value="nopayment" <?php if($_POST['status'] == 'nopayment'){ echo 'selected'; } ?> >No Payment</option>-->
            </select>
            </label>
            </div>
            <div class="col-md-3" style="margin-top: 3%;">
            <input type="submit" name="search_btn" value="Search" style="background:#93bf1b;color:#ffffff;width: 50%;height: 40px;" >
            </div>
            </div>
             </form>
                
                <!-- /.panel-heading -->
                <div class="panel-body response_panel"  style="width:100%;margin: 0px;padding: 2px;">
                    <div class="table-responsive" id="customer_table" style="overflow-x:hidden">
                        <form method="post" id='search_result' action="">
                            <input type="hidden" id="submit_id" name="submit_id" value="<?php echo $_POST['submit_id'];?>" />

                            <input type="hidden" name="report" id="report" />
                            <input type="hidden" name="observations" id="observations" value="<?php echo $condition;?>"/>
                            <input type="hidden" name="export_status" id="export_status" value="<?php echo $export_status; ?>">

                            <div class="col-md-3 pull-right" style="padding:0px;margin: 0px;text-align: left;"> 
                           <a href="javascript:void(0)" id="exportcsv">
                           <img src="../images/export.png" style="float: right;width: 95px;height: 75px;margin-right: 40px;margin-top: -25px;">
                          </a>
                            </div>
                            <br><br>

                            <table class="table table-striped table-bordered table-hover" id="dataTables_customer">
                                <thead>
                                    <tr class="center heading" style="background-color:#077907;border-color: #077907;color: white">
                                        <th style="text-align: center;">S.No</th>
                                        <th style="text-align: center;">Reg ID</th>
                                        <th style="text-align: center;">Name</th>
                                        <!--<th style="text-align: center;">Plan</th>-->
                                        <th style="text-align: center;">Status</th>
                                        <th style="text-align: center;">Amount</th>
                                        <th style="text-align: center;">Paid Date</th>
                                        <th style="text-align: center;">Start Date</th>
                                        <th style="text-align: center;">Expire Date</th> 
                                        <th style="text-align: center;">Txn ID</th>  
                                        <th style="text-align: center;">Payment Mode</th>  
                                        <!--<th style="text-align: center;">Action</th>-->
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $sno = 1;
                                    foreach($payments as $payment){ 
                                        $profiles = new Registration();
                                        $profiles = $profiles->fetch("WHERE km_regcode = '{$payment['pl_userId']}'")->resultSet();
                                        $profile = $profiles[0];
                                        ?>
                                    <tr>                                    
                                        <td style="text-align: center;"><?php echo $sno;?></td>
                                        <td style="text-align: center;"><input type="button" class="view_profile" id="<?php echo $payment['id'];?>" style="cursor: pointer;padding: 0px;color: blue;border: none;font-weight: bold;" value="<?php echo $payment['pl_userId'];?>"></td>
                                        <td style="text-align: left;"><?php echo ucwords($profile['km_name']);?></td>
                                        <!--<td style="text-align: left;"><?php echo ucwords($payment['pl_name']);?></td>-->
                                        <td style="text-align: center;"><?php echo ucwords($payment['pl_status']);?></td>
                                        <td style="text-align: center;"><?php echo $payment['pl_amount'];?></td>
                                        <td style="text-align: center;"><?php echo date_format(new DateTime($payment['pl_paidDate']), 'd-m-Y');?></td>
                                        <td style="text-align: center;"><?php echo date_format(new DateTime($payment['pl_startDate']), 'd-m-Y');?></td>
                                        <td style="text-align: left;"><?php echo date_format(new DateTime($payment['pl_expireDate']), 'd-m-Y');?></td>                                <td style="text-align: center;"><?php echo $payment['txn_id'];?></td>   
                                         <td style="text-align: center;"><?php echo $payment['payment_mode'];?></td>
                                        <!--<td style="text-align: center;"><input type="button" class="view_profile" id="<?php echo $payment['pl_userId'];?>" style="cursor: pointer;padding: 0px;color: blue;border: none;font-weight: bold;" value="View"></td>-->
                                    </tr>
                                    <?php 
                                    $sno++;
                                    } ?>
                                </tbody>

                            </table>
                        </form>

                    </div>

                </div>
                <!-- /.panel-body -->
            <!--</div>-->
               </section>
            </section>
         </section>
         <div style=" clear: both;"></div>
         <?php include("includes/footer.php");?>
          <?php
        if(isset($result)) {
	?>
        <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(1000, function() {
                            $('#message').text("");
                            $('#username').focus();
                    });
            }, 1000);
        </script>
	<?php
            }
	?>
      </div>
        <script type="text/javascript">
            var availableUserId = "";
            var table = "";
            $(document).ready(function() {
                 table = $("#dataTables_customer").DataTable({
                    "columns": [
                        { "width": "5%"},
                        { "width": "10%"},
                        { "width": "15%"},
                        { "width": "10%"},
                        { "width": "7%"},
                        { "width": "3%"},
                        { "width": "10%"},
                        { "width": "10%"},
                        { "width": "10%"},
                        { "width": "3%"},
                        
                    ],
                    "order": [[ 1, "desc" ]],
                    "pageLength": 25

                });
                $('#from_date').datetimepicker({
                    format: 'DD-MM-YYYY',
                    pickTime:false,
                    sideBySide:true
                });
                $('#to_date').datetimepicker({
                    format: 'DD-MM-YYYY',
                    pickTime:false,
                    sideBySide:true
                });
                
                availableUserId = <?php echo json_encode($available_userId); ?>;
               $("#user_id").autocomplete({
                    source: availableUserId,
                    autoFocus:true,
                    select: function( event , ui ) {

                    }
                });                
            });
         
      
        $( document ).on('change','#plan_name ', function () {
            var plan_name = $(this).val();
            if(plan_name == 'Starter'){
                $('#plan_amount').val(200);
            }
            
        });
        
        
        $(document).on('click', '.view_profile', function() {                  
            var profile_id =  $(this).attr('id');
//            alert(profile_id);
            $('#submit_id').val(profile_id);
            $('#submit_flag').val('profile');                
            $('#search_result').attr('method', 'post');
            $('#search_result').attr('action', 'manage_payments.php');
            $('#search_result').attr('target', 'blank');
            $('#search_result').submit();
        });
        $(document).on('click', '#exportcsv', function() { 
            $('#report').val('payment_report');
            var Export = $('#export_status').val();
            $('#export_status').val(Export);
            $('#search_result').attr('method', 'post');
            $('#search_result').attr('action', '../lib/paymentexcel.php');
            $('#search_result').submit();            
        });
        </script>
   </body>
</html>