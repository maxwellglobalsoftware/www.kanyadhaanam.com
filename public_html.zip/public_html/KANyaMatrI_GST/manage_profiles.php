<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
ini_set('memory_limit','128M');
ob_start();
session_start();
require_once 'includes/configure.php';
require_once 'includes/session_handler.php';
require_once '../init.php';
date_default_timezone_set('Asia/Kolkata');
if(empty($_SESSION['Kamma_Matri'])){
    header("Location: index.php");
}

if($_SESSION['Kamma_Matri']){
    $enteredBy = $_SESSION['Kamma_Matri']['id'];    
}

if(isset($_SESSION['paymentAdded'])) {
    if($_SESSION['paymentAdded']) {
        $result = "Payment Added";
    } else {
        $result = "Failed to add Payment";
    }
    unset($_SESSION['paymentAdded']);
}
// $users = new Registration();
// $users = $users->fetch()->resultSet(); 

// $available_userId = array();
// foreach($users as $user) { 
//     array_push($available_userId, $user['km_regcode']);
// }


if(isset($_POST['search_btn'])){

	$RegBy = $_POST['registeredBy'];

	$status = $_POST['status'];


 if($RegBy != '' && $status != ''){

 	$condition = "WHERE km_status = '{$status}' AND km_registered_by = '{$RegBy}' ORDER BY id DESC";

	$profil = new Registration();
	$profil = $profil->fetch("WHERE km_status = '{$status}' AND km_registered_by = '{$RegBy}' ORDER BY id DESC")->resultSet();

 } else if($RegBy != '' && $status == ''){

 	$condition = "WHERE km_registered_by = '{$RegBy}' ORDER BY id DESC";

	$profil = new Registration();
	$profil = $profil->fetch("WHERE km_registered_by = '{$RegBy}' ORDER BY id DESC")->resultSet();

 } else if($RegBy == '' && $status != ''){

 	$condition = "WHERE km_status = '{$status}' ORDER BY id DESC";

	$profil = new Registration();
	$profil = $profil->fetch("WHERE km_status = '{$status}' ORDER BY id DESC")->resultSet();

 }

} else {

$profil = new Registration();
$profil = $profil->fetch("ORDER BY id DESC")->resultSet();
$condition = "ORDER BY id DESC";

}


$profil= new Registration();
$profil = $profil->fetch("ORDER BY id DESC")->resultSet();



if(isset($_POST['submit_id'])){
    unset($_SESSION['profile_id']);
    $_SESSION['profile_id'] = $_POST['submit_id'];
    header("Location: viewregistration.php");
}
?>
<!DOCTYPE html>
<html>

    <link rel="stylesheet" href="../css/jquery-ui.css">
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
    <link rel="stylesheet" href="../css/bootstrap-datetimepicker.min.css" />
    <!-- DataTables CSS -->
    <link href="../css/plugins/dataTables.bootstrap.css" rel="stylesheet">
  
    <script src="../js/jquery-1.12.4.js"></script>
    <script src="../js/jquery-ui.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/moment.js"></script>
    <script src="../js/bootstrap-datetimepicker.js"></script>
    <!-- DataTables JavaScript -->
    <script src="../js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="../js/plugins/dataTables/dataTables.bootstrap.js"></script>
    
    
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
  <style>
     .table>tbody>tr>td {
        vertical-align: middle !important;
    }
    .pagination>.active>a{    
        background-color: #077907;
        border-color: #077907;
    }
    .pagination>.active>a:hover{
        color: #077907;
        background-color: yellowgreen;
        border-color: yellowgreen;
    }
    .pagination>li>a, .pagination>li>span {       
        color: whitesmoke;
        text-decoration: none;
        background-color: limegreen;
    }
    
    th, td {
    text-align: center;
    
    font-weight: normal;
    padding-left: 5px;
}
    
    
  </style>
  <script type="text/javascript">
    function searchfn(form){

    if(form.registeredBy.value=="" && form.status.value==""){ alert("Please select any one"); form.registeredBy.focus(); return false;  }

    }
</script> 
   <?php include("includes/headertop.php");?>
   <body class="home color-green boxed shadow">
       
       
      <div class="root">
         <?php include("includes/header.php");?>
        
         
         
         <section class="content reverse" style="width: 100%;">
            <section>
                <div  id="message_container" style="text-align: center; display: none; color: red;font-size: 18px; ">
                    <span id="message"></span>
                </div>
               <section class="columns" style="margin-top:0px !important;  width: 100%;">
                   
                   <br>
                <h2><span style="padding: 0px;">Registration Details </span></h2>
                <!--<div class="panel panel-primary">-->

                <form method="post"  action="" name="SearchForm" onsubmit="return searchfn(SearchForm);">                 
	            <div class="col-md-12" style="margin-left: 15%;">
	            <div class="col-md-3" style="margin-top: 1%;">
	            <label>Register By &nbsp;&nbsp;<br>
	            <select name="registeredBy" class="text" style="font-weight: normal;">
	              <option value="" Selected disabled>- Registered By -</option>
	              <?php foreach($registeredBy_array as $registeredBy){?>
	              <option <?php if($registeredBy == $_POST['registeredBy'] ){ echo 'selected'; }?> value="<?php echo $registeredBy; ?>"><?php echo $registeredBy; ?></option>
	              <?php } ?>
	            </select>
	            </label>
	            </div>
	            <div class="col-md-3" style="margin-top: 1%;">
	            <label>Status &nbsp;&nbsp;
	            <select name="status" class="text" style=" font-weight: normal;">
	            <option value="" Selected disabled>- Status -</option>
                <?php foreach($profileStatus_array as $profileStatus){?>
                <option <?php if($profileStatus == $_POST['status'] ){ echo 'selected'; }?> value="<?php echo $profileStatus; ?>"><?php echo ucwords($profileStatus); ?></option>
                <?php } ?>
	            </select>
	            </label>
	            </div>
	            <div class="col-md-3" style="margin-top: 3%;">
	            <input type="submit" name="search_btn" value="Search" style="background:#93bf1b;color:#ffffff;width: 50%;height: 40px;" >
	            </div>
	            </div>
	            </form>
                
                <form method="post" id='export_result' action="">
                <input type="hidden" name="report" id="report" />
                <input type="hidden" name="observations" id="observations" value="<?php echo $condition;?>"/>
                <div class="col-md-3 pull-right" style="padding:0px;margin: 0px;text-align: left;"> 
	              <a href="javascript:void(0)" id="exportcsv">
	                <img src="../images/export.png" style="float: right;width: 95px;height: 75px;margin-right: 40px;margin-top: -25px;">
	            </a>
	             </div>
	             </form>
                
                <!-- /.panel-heading -->
                <div class="panel-body response_panel"  style="width:100%;margin: 0px;padding: 2px;">
                    <div class="table-responsive" id="customer_table" style="overflow-x:hidden">
                        <form method="post" id='search_result' action="">
                            <input type="hidden" id="submit_id" name="submit_id" value="<?php echo $_POST['submit_id'];?>" />
                            <table class="table table-striped table-bordered table-hover" id="dataTables_customer">
                                <thead>
                                    <tr class="center heading" style="background-color:#077907;border-color: #077907;color: white">
                                        <th style="text-align: center;">S.No</th>
                                        <th style="text-align: center;">Reg ID</th>
                                        <th style="text-align: center;width: 200px;">Name</th>
                                        <th style="text-align: center;">Gender</th>
                                        <th style="text-align: center;">Mobile</th>
                                        <th style="text-align: center;">Second Mobile</th>
                                        <th style="text-align: center;">Email </th>
                                        <th style="text-align: center;">Preferences </th>
                                        <!--<th style="text-align: center;">Edu</th>-->
                                        <!--<th style="text-align: center;">City</th>-->
                                        <!--<th style="text-align: center;">DOB</th>-->
                                        <th style="text-align: center;">Marital</th>
                                        <th style="text-align: center;width: 100px;">Reg Date</th>
                                        <!--<th style="text-align: center;">Raasi</th>-->
                                        <th style="text-align: center;">Status</th>
                                        <!--<th style="text-align: center;">Action</th>-->
                                    </tr>
                                </thead>
                                <tbody>
                                    
                         
                                    <?php 
                                    $sno = 1;
                                    foreach($profil as $profile){ 
                                        ($profile['km_gender'] == 'male')? $gender = 'M':$gender='F';
                                        
                                        
                $primary_otp_success = new OTP();
           $primary_otp_success = $primary_otp_success->fetch("WHERE pl_userId = '{$profile['km_regcode']}' AND  pl_primary_status = 'yes' ORDER BY id DESC")->resultSet(); 
           $primary_otp_success = $primary_otp_success[0];

           $secondary_otp_success = new OTP();
           $secondary_otp_success = $secondary_otp_success->fetch("WHERE pl_userId = '{$profile['km_regcode']}' AND  pl_secondary_status = 'yes' ORDER BY id DESC")->resultSet(); 
           $secondary_otp_success = $secondary_otp_success[0];
           
           $primary_email_success = new OTP();
           $primary_email_success = $primary_email_success->fetchEmail("WHERE pl_userId = '{$profile['km_regcode']}' AND  pl_primary_status = 'yes' ORDER BY id DESC")->resultSet(); 
           $primary_email_success = $primary_email_success[0];
           
           $get_partners = new Partner();
           $get_partners = $get_partners->fetch("WHERE pl_userId = '{$profile['km_regcode']}' ORDER BY id DESC")->resultSet();
           $get_partner = $get_partners[0];
           
           
                                        ?>
                                    <tr>                                    
                                        <td style="text-align: center;"><?php echo $sno;?></td>
                                        <td style="text-align: center;"><input type="button" class="view_profile" id="<?php echo $profile['id'];?>" style="cursor: pointer;     padding: 5px;     color: #ff0a1f;     border: none;     font-size: 14px;" value="<?php echo $profile['km_regcode'];?>"></td>
                                        <td style="text-align: left;"><?php echo ucwords($profile['km_name']);?></td>
                                        <td style="text-align: center;"><?php echo $gender;?></td>
                                        
                                         <td style="text-align: center;"><?php echo $profile['km_mobile'];?>   &nbsp;<?php if($primary_otp_success){ ?>  <small><i style="font-size:19px;color:green" class="fa fa-check"></i></small> <?php } else { ?> <i class="fa fa-times" style="font-size:19px;color:red"></i> <?php } ?></td>
                                        
                                        <td style="text-align: center;"><?php echo $profile['km_second_mobile'];?>   &nbsp;<?php if($secondary_otp_success){ ?>  <small><i style="font-size:19px;color:green" class="fa fa-check"></i></small> <?php } else { ?> <i class="fa fa-times" style="font-size:19px;color:red"></i> <?php } ?></td>

                                       <td style="text-align: center;"><?php echo $profile['km_email'];?>   &nbsp;<?php if($primary_email_success){ ?>  <small><i style="font-size:19px;color:green" class="fa fa-check"></i></small> <?php } else { ?> <i class="fa fa-times" style="font-size:19px;color:red"></i> <?php } ?></td>
                                       
                                       <td style="text-align: center;"><?php if($get_partner){ ?>  <small><i style="font-size:19px;color:green" class="fa fa-check"></i></small> <?php } else { ?> <i class="fa fa-times" style="font-size:19px;color:red"></i> <?php } ?></td>
                                        
                                        <!--<td style="text-align: center;"><?php echo $profile['km_mobile'];?></td>-->
                                        <!--<td style="text-align: center;"><?php echo $edu_array[$profile['km_education']];?></td>-->
                                        <!--<td style="text-align: left;"><?php echo ucwords($profile['km_city']);?></td>-->
                                        <!--<td style="text-align: center;"><?php echo date_format(new DateTime($profile['km_dateofbirth']), 'd-m-Y');?></td>-->
                                        <td style="text-align: center;"><?php echo ucwords($profile['km_marital_status']);?></td>
                                        <td style="text-align: center;"><?php echo date_format(new DateTime($profile['km_registered_date']), 'd-m-Y');?></td>
                                        <!--<td style="text-align: center;"><?php echo $profile['km_rasi'];?></td>-->
                                        <td style="text-align: center;"><?php echo $profile['km_status'];?></td>
                                        <!--<td style="text-align: center;"><input type="button" class="view_profile" id="<?php echo $profile['id'];?>" style="cursor: pointer;     padding: 5px;     color: #ff0a1f;     border: none;     font-size: 14px;" value="View"></td>-->
                                    </tr>
                                    <?php 
                                    $sno++;
                                    } ?>
                                </tbody>

                            </table>
                        </form>

                    </div>

                </div>
                <!-- /.panel-body -->
            <!--</div>-->
               </section>
            </section>
         </section>
         <div style=" clear: both;"></div>
         <?php include("includes/footer.php");?>
          <?php
        if(isset($result)) {
	?>
        <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(1000, function() {
                            $('#message').text("");
                            $('#username').focus();
                    });
            }, 1000);
        </script>
	<?php
            }
	?>
      </div>
        <script type="text/javascript">
            var availableUserId = "";
            var table = "";
            $(document).ready(function() {
                 table = $("#dataTables_customer").DataTable({
                    
                    "order": [[ 1, "desc" ]],
                    "pageLength": 50

                });
                $('#start_from').datetimepicker({
                    format: 'DD-MM-YYYY',
                    pickTime:false,
                    sideBySide:true
                });
                $('#paid_date').datetimepicker({
                    format: 'DD-MM-YYYY',
                    pickTime:false,
                    sideBySide:true
                });
                
                availableUserId = <?php echo json_encode($available_userId); ?>;
               $("#user_id").autocomplete({
                    source: availableUserId,
                    autoFocus:true,
                    select: function( event , ui ) {

                    }
                });                
            });
         
      
        $( document ).on('change','#plan_name ', function () {
            var plan_name = $(this).val();
            if(plan_name == 'Starter'){
                $('#plan_amount').val(200);
            }
            
        });
        $(document).on('click', '.view_profile', function() {                  
            var profile_id =  $(this).attr('id');
//            alert(profile_id);
            $('#submit_id').val(profile_id);
            $('#submit_flag').val('profile');                
            $('#search_result').attr('method', 'post');
            $('#search_result').attr('action', 'viewregistration.php');
            $("#search_result").prop("target", 'blank');
            $('#search_result').submit();
        });
        $(document).on('click', '#exportcsv', function() { 
            $('#report').val('profile_report');
            $('#export_result').attr('method', 'post');
            $('#export_result').attr('action', '../lib/exporttoexcel.php');
            $('#export_result').submit();            
        });
        </script>
   </body>
</html>