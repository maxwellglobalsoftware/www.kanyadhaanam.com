<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT)); ?>
<?php
ini_set('memory_limit','128M');
ob_start();
session_start();
require_once 'includes/configure.php';
require_once 'includes/session_handler.php';
require_once '../init.php';
date_default_timezone_set('Asia/Kolkata');

if(empty($_SESSION['Kamma_Matri'])){
    header("Location: index.php");
}


if($_SESSION['Kamma_Matri']){
    $enteredBy = $_SESSION['Kamma_Matri']['id'];    
}

if(isset($_SESSION['message'])){
    $result = $_SESSION['message'];
    unset($_SESSION['message']);
}

if(isset($_SESSION['book_added'])) {
    if($_SESSION['book_added']) {
        $result = "Successfully Added";
    } else {
        $result = "Failed to add";
    }
    unset($_SESSION['book_added']);
}

if(isset($_POST['selected_user'])){
    $users = new Registration();
    $users = $users->fetch("WHERE km_regcode = '{$_POST['selected_user']}'")->resultSet();
    $user = $users[0];    
    $data = array(); 
    $data['user_name'] = $user['km_name']; 
    $data['user_gender'] = ucwords($user['km_gender']); 
    $data['user_mobile'] = $user['km_mobile'];
    echo json_encode($data);
    exit();
}

if(isset($_POST['profile_id'])){
    $profile_id = $_POST['profile_id'];

    $getusers = new Registration();
    $getusers = $getusers->fetch("WHERE km_regcode = '{$_POST['profile_id']}'")->resultSet();
    $getuser = $getusers[0];

    $get_partners = new Partner();
    $get_partners = $get_partners->fetch("WHERE pl_userId = '{$_POST['profile_id']}'")->resultSet();
    $get_partner = $get_partners[0];


}



$users = new Registration();
$users = $users->fetch()->resultSet(); 

$available_userId = array();
foreach($users as $user) { 
    array_push($available_userId, $user['km_regcode']);
}


$male_profiles = new Registration();
   $male_profiles = $male_profiles->fetch("WHERE km_gender = 'male' AND km_status = 'live' ORDER BY id DESC")->resultSet();    

?>
<!DOCTYPE html>
<html>

<link rel="stylesheet" href="../css/jquery-ui.css">
  
  <script src="../js/jquery-1.12.4.js"></script>
  <script src="../js/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
   <?php include("includes/headertop.php");?>
    <body class="home color-green boxed shadow">
        <div class="root">
            <?php include("includes/header.php");?>
            <section class="content reverse" style=" width: 90%;min-height: 400px;">
                <section>
                    <div  id="message_container" style="text-align: center; display: none; color: red;font-size: 18px; font-weight: bold">
                        <span id="message"></span>
                    </div>
                    <section class="columns" style="margin-top:10px !important;  width: 90%;">
                        <h2><span>Matching Profiles</span></h2>
                        
                        <?php if($get_partner){ ?>
                        <form method="post" id="search_result" class="print_frm"  action="print.php" target="_blank">
                        <input type="hidden" name="profile_id" value="<?php echo $profile_id;?>" id ="profile_id" />
                         <input type="submit" id="<?php echo $profile_id;?>" class="print" name="btn_add" value="Print" style="background:#93bf1b;color:#ffffff;margin-top:10px;margin-left: 50%;float: right;">
                        </form>
                        <?php } ?>
                        
                        
                        <form id="UploadForm" method="post" enctype="multipart/form-data" name="UploadForm" >
                        <input type="hidden" name="profile_id" value="<?php echo $profile_id;?>" id ="profile_id" />
                        
                       
                        
                        <table width="50%"  border="0">
                               <tbody>

                                  <tr id="reg_id" >
                                     <th>User ID :</th>
                                     <td>
                                         <input type="text" id="user_id" name="user_id" placeholder="User ID" class="text" value="<?php echo $profile_id;?>" >
                                     </td>
                                  </tr>
                                  </tbody>
                                  </table>

                                  <?php if($getuser){ ?>
                                  <table width="50%"  border="0">
                               <tbody>
                                  <tr >
                                     <th>Name :</th>
                                     <td>
                                         <input type="text" id="user_name"  name="user_name" placeholder="Name"  readonly class="text" value="<?php echo $getuser['km_name'];?>">
                                     </td>
                                  </tr>
                                  <tr>
                                     <th>Gender :</th>
                                     <td>
                                         <input type="text" id="user_gender"  name="user_gender" placeholder="Gender" readonly class="text" value="<?php echo ucwords($getuser['km_gender']); ?>" >
                                     </td>
                                  </tr>
                                  <tr>
                                     <th>Mobile No :</th>
                                     <td>
                                         <input type="text" id="user_mobile"  name="user_mobile" placeholder="Mobile No" readonly class="text" value="<?php echo $getuser['km_mobile'];?>">
                                     </td>
                                  </tr>
                                  </tbody>
                                  </table>

                                  

                          <h4 style="margin-top: 3%;margin-left: 9%;">Profile Expectation :</h4>


                          

                             <table width="50%" style="font-size: 18px;">
                             <tbody>

                              <tr>
                                <th style="text-align: right;">Age :</th>
                                <td>
                                     <?php if($get_partner){ ?>
                                     <?php echo $get_partner['age_from'].' to '.$get_partner['age_to']; ?>
                                     <?php } else { ?>
                                     N / A
                                     <?php } ?>
                                </td>
                              </tr>

                              <tr>
                                <th style="text-align: right;">Star :</th>
                                <td>
                                     <?php if($get_partner['star']){ ?>
                                     <?php echo $get_partner['star']; ?>
                                     <?php } else { ?>
                                     N / A
                                     <?php } ?>
                                </td>
                              </tr>

                              <tr>
                                <th style="text-align: right;">Education :</th>
                                <td>
                                     <?php if($get_partner['education']){ ?>
                                     <?php
                                      $index = 1;

                                      foreach($edu_array as $key => $value) {
                                        
                                        $categoryIds = explode(',', $get_partner['education']);

                                        foreach($categoryIds as $categoryId) {
                                          if($categoryId == $key) {
                                            if($index == 1) {
                                              echo $value;
                                            } else {
                                              echo ", " . $value;
                                            }

                                            $index++;
                                          }
                                        }
                                      }
                                    ?>
                                     <?php } else { ?>
                                     N / A
                                     <?php } ?>
                                </td>
                              </tr>


                             
                             </tbody>
                             </table>

                             <?php

                             $cur_year = date('Y');

                             $prefer_age_to = $get_partner['age_to'];;
                             
                             $to_year = ($cur_year - ($get_partner['age_from'] - 1));
                             
                             $from_year = ($cur_year - $prefer_age_to);
                             
                             $prefer_education = explode(",", $get_partner['education']);
                             
                             $prefer_star = explode(",", $get_partner['star']);
                             
                             $statement = "";
                             
                             $pre_edu = $get_partner['education'];
                                 
                             $pre_star = $get_partner['star'];

                             if($getuser['km_gender'] == 'male'){
                                     $km_gender = 'female';
                                 }else{
                                     $km_gender = 'male';
                                 }

                             if($get_partner['star']){
       
                          $matchprofiles = new Registration();
                          $matchprofiles = $matchprofiles->fetch("WHERE km_gender = '{$km_gender}' AND   YEAR(km_dateofbirth) BETWEEN '{$from_year}' AND '{$to_year}' AND (km_star = '{$prefer_star[0]}' OR km_star = '{$prefer_star[1]}' OR km_star = '{$prefer_star[2]}' OR km_star = '{$prefer_star[3]}' OR km_star = '{$prefer_star[4]}' OR km_star = '{$prefer_star[5]}' OR km_star = '{$prefer_star[6]}' OR km_star = '{$prefer_star[7]}' OR km_star = '{$prefer_star[8]}' OR km_star = '{$prefer_star[9]}' OR km_star = '{$prefer_star[10]}' OR km_star = '{$prefer_star[11]}' OR km_star = '{$prefer_star[12]}' OR km_star = '{$prefer_star[13]}' OR km_star = '{$prefer_star[14]}' OR km_star = '{$prefer_star[15]}' OR km_star = '{$prefer_star[16]}' OR km_star = '{$prefer_star[17]}' OR km_star = '{$prefer_star[18]}' OR km_star = '{$prefer_star[19]}' OR km_star = '{$prefer_star[20]}') AND km_status = 'live' ORDER BY id DESC")->resultSet();
                            $match_profiles_list = count($matchprofiles);
                        
                           }

                             ?>

                        
                        <?php 
                        if($matchprofiles){ ?>
                        <p style="margin-bottom: 0px;font-size: 20px;font-weight: bold;    color: green;">Total : <?php echo $match_profiles_list; ?> Profiles</p>

                        <?php
                        foreach($matchprofiles as $profile){
                            
                            $users = new Registration();
                            $users = $users->fetch("WHERE km_regcode = '{$profile['km_regcode']}'")->resultSet();
                            $user = $users[0];
                            $photos = new Profile();
                            $photos = $photos->fetchPhotos("WHERE pho_userId = '{$user['km_regcode']}' AND pho_imgPath LIKE '%_profile_%' ORDER BY id DESC LIMIT 1")->resultSet();
                            $photo = $photos[0];
                            if($photo['pho_imgPath']){
                                $imgPath =  '../'.$photo['pho_imgPath'];
                        
                                $image_file = fopen($imgPath, 'r');
                                $imgPath = fread($image_file, filesize($imgPath));
                            }else{
                                $imgPath = '../images/'.$user['km_gender'].'.png';
                        
                                $image_file = fopen($imgPath, 'r');
                                $imgPath = fread($image_file, filesize($imgPath));                                
                            } 

                            //// Occupation /////
                            $occupations = new Registration();
                            $occupations = $occupations->fetchOccupation("WHERE id = '{$user['km_occupation']}' ORDER BY occupation ASC")->resultSet();
                            $occupation = $occupations[0];
                            
                            //// Districts /////
                            $districts = new Registration();
                            $districts = $districts->fetchDistricts("WHERE id = '{$user['km_district']}' ORDER BY name ASC")->resultSet();
                            $district = $districts[0];
                            
                            
                            $from = new DateTime($user['km_dateofbirth']);
                            $to   = new DateTime('today');
                            $age = $from->diff($to)->y; 
                            $cur_Year = date("Y");

                            $view_only_horos = new Profile();
                            $view_only_horos = $view_only_horos->fetchHoroscope("WHERE hs_userId = '{$user['km_regcode']}'")->resultSet();
                            $view_only_horos = $view_only_horos[0];
                        
                            ?>
                        <div id="r-content" class="style50" style="min-height: 0px;">
                        <div class="r-content-left" style="border-right: none;">
                           <span class="profile"> Profile ID : <?php echo $user['km_regcode'];?> </span>
                           <div class="r-content-photo">
                              <!--<a href="viewalbum.php">--> 
                              <img width="150" height="170" border="0" src="data:image/jpeg;base64,<?php echo base64_encode($imgPath); ?>">
                              <!--</a>-->
                           </div>
                           
                        </div>

                          <div class="r-content-right-top">
                           <div class="r-content-top-1" style="border-left: 1px dotted #CCCCCC;margin-top: 4%;">
                              <table width="526" cellspacing="0" cellpadding="0" border="0">
                                 <tbody>
                                      <tr>
                                       <td height="20" style="color:#000" valign="top">
                                          Name
                                       </td>
                                       <td valign="top">
                                          :
                                       </td>
                                       <td style="color:#333">
                                          <?php if($user['km_name']){ echo $user['km_name']; } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td width="124" height="20" style="color:#000">Age / Height</td>
                                       <td width="20">:</td>
                                       <td width="182" style="color:#333"> 
                                          <?php if($age && $user['km_height']){ ?>
                                          <?php echo $age; ?> / <?php echo $user['km_height']; ?>   
                                          <?php } else if($age){ ?>
                                          <?php if($age == $cur_Year){ echo 'N / A'; } else { echo $age; } ?>
                                          <?php } else if($user['km_height']){?>
                                          <?php echo $user['km_height']; ?> 
                                          <?php } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td height="20" style="color:#000" valign="top">
                                          Star
                                       </td>
                                       <td valign="top">
                                          :
                                       </td>
                                       <td style="color:#333">
                                          <?php if($user['km_star']){ echo $user['km_star']; } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td height="20" style="color:#000" valign="top">
                                          District
                                       </td>
                                       <td valign="top">
                                          :
                                       </td>
                                       <td style="color:#333">
                                      <?php 
                                          if($user['km_district']){ 
                                          if($district){ 
                                            echo $district['name']; } 
                                            else { echo $user['km_district']; }
                                            } else { echo 'N / A'; } 
                                          ?>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td height="19" style="color:#000">Qualification</td>
                                       <td height="19">:</td>
                                       <td height="19" style="color:#333">
                                          <?php  if($user['km_education']){ echo $edu_array[$user['km_education']]; } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td height="20" style="color:#000">Profession</td>
                                       <td>:</td>
                                       <td style="color:#333">
                                          <?php 
                                          if($user['km_occupation']){ 
                                          if($occupation){ 
                                            echo $occupation['occupation']; } 
                                            else { echo $user['km_occupation']; }
                                            } else { echo 'N / A'; } 
                                          ?>
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                              </div>
                              </div>


                        </div>
                        <?php } 
                        } else{
                             ?>
                     <div id="result-content">
                        <h4 style="margin: 1.5em 1em;text-align: center;color: #17800a;"> Profile not available. </h4>
                     </div>
                     <?php
                        }                                
                        ?>

                           <?php } ?>

                      </form>

                      <div style=" clear: both;"></div>

                    </section>
                </section>
            </section>
            <div style=" clear: both;"></div>
            <?php include("includes/footer.php");?>
             <script src="js/jquery.js"></script>
             <script src="../js/jquery-1.12.4.js"></script>
    <script src="../js/jquery-ui.js"></script>
                <script>
    $(document).ready(function() {
      $('.print_frm').submit(function() {
        if(!confirm("Do you want to print?")) {
          return false;
        }
      });
    });
</script>
            <?php
            if(isset($result)) {
            ?>
            <script>
                $('#message_container').fadeIn(10);
                $('#message').text("<?php echo $result; ?>");
                setTimeout(function() {
                        $('#message_container').fadeOut(2000, function() {
                                $('#message').text("");
                                $('#username').focus();
                        });
                }, 5000);
            </script>
            <?php
                }
            ?>
            
            <script type="text/javascript">
            var availableUserId = "";
            var user = "";
            $(document).ready(function() {
                availableUserId = <?php echo json_encode($available_userId); ?>;
                $("#user_id").autocomplete({
                    source: availableUserId,
                    autoFocus:true,
                    select: function( event , ui ) {
                        $('#profile_id').val(ui.item.label);            
                        $('#UploadForm').attr('method', 'post');
                        $('#UploadForm').attr('action', 'matching_profiles.php');
                        $('#UploadForm').submit();
                    }
                });
            });
         
      
        $( document ).on('change','#plan_name ', function () {
            var plan_name = $(this).val();
            if(plan_name == 'Starter'){
                $('#plan_amount').val(200);
            }
            
        });
        
     
        
        </script>
      
        <script language="Javascript" type="text/javascript">
            function Number(e, t) {
                try {
                    if (window.event) {
                        var charCode = window.event.keyCode;
                    }
                    else if (e) {
                        var charCode = e.which;
                    }
                    else { return true; }
                    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                        return false;
                    }
                    return true;
                }
                catch (err) {
                    alert(err.Description);
                }
            }
            
         </script>

 <script>
    
    $(document).ready(function() {
      var Stats = JSON.parse('<?php echo $statesEncoded; ?>');
      var Cits = JSON.parse('<?php echo $districtsEncoded; ?>');

      $('#states').change(function() {
        var categoryId = $(this).val();

        $('#citys').empty();
        $('#citys').append('<option value="" Selected disabled>- Select -</option>');

        $.each(Cits, function(index, element) {
          if(element.state_id == categoryId) {
            $('#citys').append('<option value="' + element.id + '">' + element.name + '</option>');
          }
        });
      });
    });
  
</script>
        </div>
    </body>
</html>