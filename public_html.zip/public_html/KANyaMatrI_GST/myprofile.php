<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
ob_start();
session_start();
require_once 'includes/configure.php';
require_once 'includes/session_handler.php';
require_once 'init.php';
require_once 'includes/pagination.php';
require_once 'includes/db.php';

$profileId = $_SESSION['User_Kamma_Matri']['km_regcode'];
//*********************** Profile Details *******************************
$profiles = new Registration();
$profiles = $profiles->fetch("WHERE km_regcode = '{$profileId}'")->resultSet();    
$profile = $profiles[0];
//*********************** Horoscope Details *******************************
//$horos = new Profile();
//$horos = $horos->fetchHoroscope("WHERE hs_userId = '{$profile['km_regcode']}'")->resultSet();
//$horos = $horos[0];
//*********************** Photo Details *******************************
$photos = new Profile();
$photos = $photos->fetchPhotos("WHERE pho_userId = '{$profile['km_regcode']}' AND pho_imgPath LIKE '%_profile_%'")->resultSet();
$photo = $photos[0];
if($photo['pho_imgPath']){
    $imgPath =  'admin/'.$photo['pho_imgPath'];
}else{
    if($profile['km_gender'] == 'male'){
        $imgPath = 'images/male.png';
    }else{
        $imgPath = 'images/female.png';
    }
     
}
?>
<!DOCTYPE html>
<html>
<?php include("includes/headertop.php");?>

    <body class="home color-green boxed shadow">
        <div class="root">
            <?php include("includes/headerin.php");?>
                <section class="slider11 p05" style="  float: left; width: 65%">

                    <img src="images/kammavar.jpg">

                    <?php //include("includes/banner.php");?>
                </section>
                <?php //include("includes/quicksearch.php");?>
                    <section class="content reverse">
                        <section class="main" style=" margin-top: 1%;">

                            <table>
                                <tr class="tabletitle" >
                                    <td colspan="2" style="  border-top-left-radius: 0.5em; border-top-right-radius: 0.5em;">Full Profile </td>
                                </tr>
                            </table>

                            <div id="result-content">
                                <div id="result-box">
                                    <div id="result-box-top-left"></div>
                                    <div id="result-box-top-middle">
                                        <div class="profile-id-text"><b>Profile ID :</b></div>
                                        <div class="profile-id-text-results"><?php echo $profile['km_regcode'];?></div>
                                        <div class="profile-id-text-results" style="width:100px;"> </div>
                                    </div>
                                    <div id="result-box-top-right"></div>
                                    <div class="spacer"></div>
                                    <div id="result-box-content2">
                                        <div id="photo-area">
                                            <div class="photo-album">
                                                <div class="photo-content">
                                                    <img src="../<?php echo $imgPath; ?>" width="130" height="130" alt="" style="border:0px;">
                                                </div>
                                            </div>

                                            <div class="photo-text"  style="cursor:pointer;"></div>
                                        </div>
                                        <div id="right-information">
                                            <div id="information-area-1q">
                                                <div class="information-text-title"> <b>Name :</b> </div>
                                                <div class="information-text-title"> <b>Created By :</b> </div>
                                                <div class="information-text-title"> <b>Age :</b> </div>
                                                <div class="information-text-title"> <b>D.O.B :</b> </div>
                                                <!--<div class="information-text-title"> <b>Gothram :</b> </div>-->
                                                <div class="information-text-title"> <b>Star : </b> </div>
                                                <div class="information-text-title"> <b>Raasi :</b> </div>
                                                
                                            </div>
                                            <div id="information-area-1a" style=" width:200px;">
                                                <div class="information-text" style="width:210px;">
                                                    <?php echo ucwords($profile['km_name']); ?></div>
                                                <?php 
                                                    $from = new DateTime($profile['km_dateofbirth']);
                                                    $to   = new DateTime('today');
                                                    $age = $from->diff($to)->y;
                                                ?>
                                                <div class="information-text"><?php echo ucwords($profile['km_registered_by']); ?></div>
                                                <div class="information-text"><?php echo $age.' Yrs'; ?></div>
                                                <div class="information-text"><?php echo date_format(new DateTime($profile['km_dateofbirth']), 'd-m-Y'); ?></div>                                                
<!--                                                <div class="information-text">
                                                    <?php echo $profile['km_gothram']; ?> </div>-->
                                                <div class="information-text"><?php echo $profile['km_star']; ?> </div>
                                                <div class="information-text"><?php echo $profile['km_rasi']; ?> </div>
                                            </div>
                                            <div id="information-area-2anew">
                                                <div style="padding-left:0px;">
                                                    <div style="padding-top:10px; width:280px; cursor:pointer; float: left;  color:#b10000; font-weight: bold;">


                                                   <img src="images/man-user.png" width="32"> Contact Details<br><br>
                                                   <div style=" margin-left: 12%; line-height: 36px;">


                                                   <span><img src="images/mobile.png" width="25">  <?php echo $profile['km_mobile']; ?></span><br>

                                                   <span ><img src="images/call.png" width="25">  <?php echo $profile['km_landline']; ?></span>

                                                   </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="spacer"></div>
                                        </div>
                                        <div class="spacer"></div>
                                    </div>
                                    <div id="result-box-bottom-left"></div>
                                    <div id="result-box-bottom-middle"></div>
                                    <div id="result-box-bottom-right"></div>
                                    <div class="spacer"></div>
                                </div>
                                <br>



<!--                                <div class="basic-info-title-box">
                                    <div class="basic-info-title-left"></div>
                                    <div id="info-3-title-middle">
                                        <div class="full-profile-title-text-1"><b>Horoscope</b></div>
                                    </div>
                                    <div class="basic-info-title-right"></div>
                                    <div class="spacer"></div>
                                    <div style=" margin-left: 8px;  border-style: solid;border-width: 1px;border-color: #99f381;">                                        
                                    <div>
                                        <?php if($horos['hs_imgPath']){?>
                                        <img style='max-width:642px;' src="<?php echo 'admin/'.$horos['hs_imgPath'];?>"></div>
                                        <?php }else{ ?>
                                        <p style="text-align: center;color:red;">Horoscope not available</p>
                                        <?php } ?>
                                    </div>
                                </div>-->
                                <div class="basic-info-title-box">
                                    <div class="basic-info-title-left"></div>
                                    <div id="info-3-title-middle">
                                        <div class="full-profile-title-text-1"><b>Basic Information</b></div>
                                    </div>
                                    <div class="basic-info-title-right"></div>
                                    <div class="spacer"></div>
                                    <div class="basic-information-box" style=" height:auto;">
                                        <BR />
                                        <div class="profile-q"><b>Gender : </b></div>
                                        <div class="profile-a"><span class="information-text">
<?php echo ucwords($profile['km_gender']); ?> </span></div>
                                        <div class="spacer"></div>
                                        <div class="profile-q"><b>Place of Birth : </b></div>
                                        <div class="profile-a"><span class="information-text">
<?php echo ucwords($profile['km_place_of_birth']); ?> </span></div>
                                        <div class="spacer"></div>
                                        <div class="profile-q">
                                            <b>Marital Status :</b></div>
                                        <div class="profile-a"><span class="information-text">
<?php echo ucwords($profile['km_marital_status']); ?> </span></div>
                                        <div class="spacer"></div>
                                        <div class="profile-q">
                                            <b>Height :</b></div>
                                        <div class="profile-a"><span class="information-text">
<?php echo $profile['km_height']; ?> </span></div>
                                        <div class="spacer"></div>
                                        <div class="profile-q">
                                            <b>Weight :</b></div>
                                        <div class="profile-a"><span class="information-text">
<?php echo $profile['km_weight']; ?> </span></div>
                                        <div class="spacer"></div>
                                        <div class="profile-q">
                                            <b>Email :</b></div>
                                        <div class="profile-a"><span class="information-text">
<?php 
if($profile['km_email']){
    $km_email = $profile['km_email'];
}else{
    $km_email = 'NA';
}
echo $km_email;
?> </span></div>
                                        <div class="spacer"></div>
                                        <div class="profile-q">
                                            <b>Order of Birth :</b></div>
                                        <div class="profile-a"><span class="information-text">
<?php echo $profile['km_order_of_birth']; ?> </span></div>
                                        <div class="spacer"></div>
                                        <div class="profile-q">
                                            <b>Physical Status :</b></div>
                                        <div class="profile-a"><span class="information-text">
<?php echo ucwords($profile['km_physical_status']); ?> </span></div>
                                        <div class="spacer"></div>
                                        <div class="profile-q">
                                            <b>Languages Known :</b></div>
                                        <div class="profile-a"><span class="information-text">
<?php echo ucwords($profile['km_languages']); ?> </span></div>
                                        <div class="spacer"></div>
                                       
                                    </div>
                                    
                                </div>

                                <div class="basic-info-title-box">
                                    <div class="basic-info-title-left"></div>
                                    <div id="info-4-title-middle">
                                        <div class="full-profile-title-text">
                                            <b>Education &amp; Career</b></div>
                                    </div>
                                    <div class="basic-info-title-right"></div>
                                    <div class="spacer"></div>

                                    <div class="basic-information-box" style=" height:120px;">
                                        <BR />
                                        <div class="profile-q"><b>Education : </b></div>
                                        <div class="profile-a"><span class="information-text">
<?php echo $edu_array[$profile['km_education']]; ?> </span></div>
                                        <div class="spacer"></div>
                                        <div class="profile-q"><b>Occupation : </b></div>
                                        <div class="profile-a"><span class="information-text">
<?php echo $profile['km_occupation']; ?> </span></div>
                                        <div class="spacer"></div>
                                        <div class="profile-q">
                                            <b>Annual Income :</b></div>
                                        <div class="profile-a"><span class="information-text">
<?php echo $profile['km_annual_income']; ?> </span></div>
                                       
                                    </div>

                                    <div class="basic-info-title-box">
                                        <div class="basic-info-title-left"></div>
                                        <div id="info-3-title-middle">
                                            <div class="full-profile-title-text-1"><b>Horoscope Details</b></div>
                                        </div>
                                        <div class="basic-info-title-right"></div>
                                        <div class="spacer"></div>
                                        <div class="basic-information-box" style="height:auto;">
                                            <div class="profile-q-long"><b>Chevvai Dosham :</b></div>
                                            <div class="profile-a-small"><span class="information-text">
<?php echo ucwords($profile['km_dosham']); ?> </span></div>
                                            <div class="spacer"></div>
                                            <div class="profile-q-long"><b>Lagnam :</b></div>
                                            <div class="profile-a-small"><span class="information-text">
<?php echo ucwords($profile['km_lagnam']); ?> </span></div>
                                            <div class="spacer"></div>
                                            <div class="profile-q-long"><b>House Name :</b></div>
                                            <div class="profile-a-small"><span class="information-text">
<?php echo ucwords($profile['km_housename']); ?>  </span></div>
                                            <div class="spacer"></div>
                                            <div class="profile-q-long"><b>Gothram :</b></div>
                                            <div class="profile-a-small"><span class="information-text">
<?php echo ucwords($profile['km_gothram']); ?>  </span></div>
                                            
                                                                                        <div class="spacer"></div>

                                            <div class="profile-q-long"><b>Thisai irrupu</b></div>
                                            <div class="profile-a-small"><span class="information-text">
<?php echo ucwords($profile['km_thisai_irrupu']); ?> </span></div>
                                            <div class="spacer"></div>
                                        </div>
                                    </div>

                                </div>
                                <br>
                                <div class="basic-info-title-box">
                                    <div class="basic-info-title-left"></div>
                                    <div id="info-3-title-middle">
                                        <div class="full-profile-title-text-1"><b>Family Information</b></div>
                                    </div>
                                    <div class="basic-info-title-right"></div>
                                    <div class="spacer"></div>
                                    <div class="basic-information-box" style="height:auto;">
                                        <div class="profile-q-long"><b>Father's Name :</b></div>
                                        <div class="profile-a-small" style="width:320px;"><span class="information-text">
<?php echo ucwords($profile['km_father_name']); ?></span></div>
                                        
                                        <div class="spacer"></div>
                                        <div class="profile-q-long"><b>Father's Professional :</b></div>
                                        <div class="profile-a-small" style="width:320px;"><span class="information-text">
<?php echo ucwords($profile['km_father_occupation']); ?></span></div>                                        
                                        <div class="spacer"></div>
                                        <div class="profile-q-long"><b>Mother's Name :</b></div>
                                        <div class="profile-a-small" style="width:320px;"><span class="information-text">
<?php echo ucwords($profile['km_mother_name']); ?></span></div>
                                        
                                        <div class="spacer"></div>
                                        <div class="profile-q-long"><b>Mother's Professional :</b></div>
                                        <div class="profile-a-small" style="width:320px;"><span class="information-text">
<?php echo ucwords($profile['km_mother_ocupation']); ?> </span></div>
                                        <div class="spacer"></div>
                                        <div class="profile-q-long"><b>Address :</b></div>
                                        
                                        
                                         <div class="spacer"></div>
                                        
                                        <!--<div class="profile-a-small" style="margin-left: 25%;width:320px;">-->
                                            <div class="profile-a-small" style="margin-left: 25%;width:320px;"><span class="information-text"><?php echo '# '.ucwords($profile['km_doorno'].','); ?> </span></div>
                                            <div class="profile-a-small" style="margin-left: 25%;width:320px;"><span class="information-text"><?php echo ucwords($profile['km_street'].','); ?> </span></div>
                                            <div class="profile-a-small" style="margin-left: 25%;width:320px;"><span class="information-text"><?php echo ucwords($profile['km_city'].','); ?> </span></div>
                                            <div class="profile-a-small" style="margin-left: 25%;width:320px;"><span class="information-text"><?php echo ucwords($profile['km_district'].'(Dist),'); ?> </span></div>
                                            <div class="profile-a-small" style="margin-left: 25%;width:320px;"><span class="information-text"><?php echo ucwords($profile['km_pincode']).'.'; ?> </span></div>
<!--                                        </div>-->
                                        
                                        <div class="spacer"></div>

                                        <div class="spacer"></div>
                                    </div>
                                </div>

                               

                                
                                <p>&nbsp;</p>
                            </div>

                        </section>

                        <?php include("includes/right.php");?>

                    </section>
                    <div style=" clear: both;"></div>

                    <?php include("includes/footertop.php");?>



                    <?php include("includes/footer.php");?>
        </div>
    </body>

</html>