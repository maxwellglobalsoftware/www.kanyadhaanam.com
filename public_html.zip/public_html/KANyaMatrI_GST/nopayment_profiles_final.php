<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
ini_set('memory_limit','128M');
ob_start();
session_start();
require_once 'includes/session_handler.php';
require_once 'includes/configure.php';
require_once '../init.php';
date_default_timezone_set('Asia/Kolkata');

$current_year = date("Y-m-d");

if(empty($_SESSION['Kamma_Matri'])){
    header("Location: index.php");
}

if($_SESSION['Kamma_Matri']){
    $enteredBy = $_SESSION['Kamma_Matri']['id'];    
}


$getprofiles= new Registration();
$getprofiles = $getprofiles->fetch("WHERE km_status = 'live' ORDER BY id DESC")->resultSet();

?>
<!DOCTYPE html>
<html>

    <link rel="stylesheet" href="../css/jquery-ui.css">
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
    <link rel="stylesheet" href="../css/bootstrap-datetimepicker.min.css" />
    <!-- DataTables CSS -->
    <link href="../css/plugins/dataTables.bootstrap.css" rel="stylesheet">
  
    <script src="../js/jquery-1.12.4.js"></script>
    <script src="../js/jquery-ui.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/moment.js"></script>
    <script src="../js/bootstrap-datetimepicker.js"></script>
    <!-- DataTables JavaScript -->
    <script src="../js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="../js/plugins/dataTables/dataTables.bootstrap.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
  <style>
    .table>tbody>tr>td {
        padding: 2px;
    }
    .pagination>.active>a{    
        background-color: #077907;
        border-color: #077907;
    }
    .pagination>.active>a:hover{
        color: #077907;
        background-color: yellowgreen;
        border-color: yellowgreen;
    }
    .pagination>li>a, .pagination>li>span {       
        color: whitesmoke;
        text-decoration: none;
        background-color: limegreen;
    }
  </style>

   <?php include("includes/headertop.php");?>
   <body class="home color-green boxed shadow">
      <div class="root">
         <?php include("includes/header.php");?>
         <section class="content reverse" style="width: 100%;">
            <section>
                <div  id="message_container" style="text-align: center; display: none; color: red;font-size: 18px; font-weight: bold">
                    <span id="message"></span>
                </div>
               <section class="columns" style="margin-top:0px !important;  width: 100%;">
                <h2 style="margin-top: 2%;"><span style="padding: 0px;">No Payment Profiles Details </span></h2>
                
                <!-- /.panel-heading -->
                <div class="panel-body response_panel"  style="width:100%;margin: 0px;padding: 2px;">
                    <div class="table-responsive" id="customer_table" style="overflow-x:hidden">
                        <form method="post" id='search_result' action="">
                        <input type="hidden" id="submit_id" name="submit_id" value="<?php echo $_POST['submit_id'];?>" />

                            <input type="hidden" name="report" id="report" />
                            <input type="hidden" name="observations" id="observations" value="<?php echo $condition;?>"/>
                            
                            <div class="col-md-3 pull-right" style="padding:0px;margin: 0px;text-align: left;"> 
                           <a href="javascript:void(0)" id="exportcsv">
                           <img src="../images/export.png" style="float: right;width: 95px;height: 75px;margin-right: 40px;margin-top: -25px;">
                          </a>
                            </div>
                            <br><br>

                            <table class="table table-striped table-bordered table-hover" id="dataTables_customer">
                                <thead>
                                    <tr class="center heading" style="background-color:#077907;border-color: #077907;color: white">
                                        <th style="text-align: center;">S.No</th>
                                        <th style="text-align: center;">Reg ID</th>
                                        <th style="text-align: center;">Name</th>
                                        <th style="text-align: center;">Mobile</th>
                                        <th style="text-align: center;">Second Mobile</th>
                                        <th style="text-align: center;">Email ID</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    if($getprofiles){
                                    $sno = 1;
                                    foreach($getprofiles as $getprofile){ 
                                        
                                        

                                    	$payments = new Payment();
									    $payments = $payments->fetch("WHERE pl_userId = '{$getprofile['km_regcode']}'")->resultSet();
									    $payment = $payments[0];

									    if($payment){

										} else {

                                        ?>
                                    <tr>                                    
                                        <td style="text-align: center;"><?php echo $sno;?></td>
                                        <td style="text-align: center;"><input type="button" class="view_profile" id="<?php echo $getprofile['id'];?>" style="cursor: pointer;padding: 0px;color: blue;border: none;font-weight: bold;" value="<?php echo $getprofile['km_regcode'];?>"></td>
                                        <td style="text-align: left;"><?php echo ucwords($getprofile['km_name']);?></td>
                                        <td style="text-align: center;"><?php echo $getprofile['km_mobile'];?></td>
                                        <td style="text-align: center;"><?php echo $getprofile['km_second_mobile'];?></td>
                                        <td style="text-align: center;"><?php echo $getprofile['km_email'];?></td>
                                    </tr>
                                    <?php 
                                    $sno++; } } } ?>
                                </tbody>

                            </table>
                        </form>

                    </div>

                </div>
                <!-- /.panel-body -->
            <!--</div>-->
               </section>
            </section>
         </section>
         <div style=" clear: both;"></div>
         <?php include("includes/footer.php");?>
          <?php
        if(isset($result)) {
	?>
        <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(1000, function() {
                            $('#message').text("");
                            $('#username').focus();
                    });
            }, 1000);
        </script>
	<?php
            }
	?>
      </div>
        <script type="text/javascript">
            var availableUserId = "";
            var table = "";
            $(document).ready(function() {
                 table = $("#dataTables_customer").DataTable({
                    "order": [[ 1, "desc" ]],
                    "pageLength": 25

                });
                $('#from_date').datetimepicker({
                    format: 'DD-MM-YYYY',
                    pickTime:false,
                    sideBySide:true
                });
                $('#to_date').datetimepicker({
                    format: 'DD-MM-YYYY',
                    pickTime:false,
                    sideBySide:true
                });
                
                availableUserId = <?php echo json_encode($available_userId); ?>;
               $("#user_id").autocomplete({
                    source: availableUserId,
                    autoFocus:true,
                    select: function( event , ui ) {

                    }
                });                
            });
         
      
        $(document).on('click', '.view_profile', function() {                  
            var profile_id =  $(this).attr('id');
//            alert(profile_id);
            $('#submit_id').val(profile_id);
            $('#submit_flag').val('profile');                
            $('#search_result').attr('method', 'post');
            $('#search_result').attr('action', 'viewregistration.php');
            $('#search_result').submit();
        });
        $(document).on('click', '#exportcsv', function() { 
            $('#report').val('no_payment_report');
            $('#search_result').attr('method', 'post');
            $('#search_result').attr('action', '../lib/nopaymentexcel.php');
            $('#search_result').submit();            
        });
        </script>
   </body>
</html>