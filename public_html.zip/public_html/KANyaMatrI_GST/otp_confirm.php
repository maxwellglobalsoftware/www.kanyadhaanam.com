<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   date_default_timezone_set('Asia/Kolkata');
   require_once '../init.php';

   
 if(isset($_SESSION['otperror'])) {
    $result = "Invalid OTP";
    unset($_SESSION['otperror']);
  }

  if(isset($_SESSION['login_success'])) {
      if($_SESSION['login_success'] == "true") {
         $result = "Check your admin Email ID & enter the OTP code";
      } 
      unset($_SESSION['login_success']);
  }

  $send_no = $_SESSION['otp_no'];

  if(!isset($send_no)){
    header('Location: index.php');
  }

        if(isset($_POST['btn_submit'])) {

        $otp_number = $_POST['otp_number'];

        if($send_no == $otp_number) {

          $username = $_SESSION['Kamma_Manage_Matri']['user_name'];
          $password = $_SESSION['Kamma_Manage_Matri']['password'];
          unset($_SESSION['Kamma_Manage_Matri']);

          $user = new User();
          $user = $user->login($username, $password);

          if($user){

           	$data = array();
            $data[] = $_SESSION['Kamma_Matri']['id'];
            $data[] = date_format(new DateTime(), 'd-m-Y');
            $data[] = date_format(new DateTime(), 'h:i A');

            $login = new Login();
            $login = $login->setLogin($data);

            header('Location: home.php');
          
          }
        } else {
        $_SESSION['otperror'] = false;
        header('Location: otp_confirm.php');
        }
    }


   ?>
<!DOCTYPE html>
<html>
   <style type="text/css">
      .content-slider input[type="submit"] {
      width: 100%;
      background-color: #ff500b ;
      color: white;
      padding: 12px 20px;
      border: none;
      font-size: 18px;
      letter-spacing: 1px;
      cursor: pointer;
      outline: none;
      transition: .5s ease-in;
      -webkit-transition: .5s ease-in;
      -ms-transition: .5s ease-in;
      -o-transition: .5s ease-in;
      -moz-transition: .5s ease-in;
      }
      input[type=submit]:hover {
      background-color:#ff8400;
      }
   </style>
<script type="text/javascript">
   function logfn(form)
 
 {

if(form.otp_number.value=="") { alert("Please Enter OTP"); form.otp_number.focus(); return false; }

 }

</script>
   <?php include("includes/headertop.php");?>   
   <body>
      <div class="root">

      <br><br>
         
               <center> <a href="index.php">
                  <img src="images/logo.png" alt="Matrimony" width="350">
                  </a>
               </center>
              
         <section class="content reverse">

         <center>
            
               <section class="columns content-slider" style="margin-top:20px !important;">
                  <section style=" width: 350px; padding:5px;background:#ededed; border: solid 1px #ccc;">

                     <form  method="post" name="LoginForm" onsubmit="return logfn(LoginForm);">

                     <div  id="message_container" style="text-align: center; display: none; color: red; font-weight: bold">
                        <span id="message"></span>
                     </div>
                     
                        <div class="container">
                           <label style=" text-align: left;"><b>Enter OTP</b></label>
                           <input id="otp_number" type="text" placeholder="Enter OTP" name="otp_number" onkeypress="return Number(event,this);" Maxlength="6" autocomplete="off">

                           <br><br>
                           <input type="submit" name="btn_submit" value="Confirm">
                        </div>
                     </form>
                  </section>
               </section>
            
            </center>
         </section>
        
      </div>
      <script src="../js/jquery-1.12.4.js"></script>
      <script language="Javascript" type="text/javascript">
 
   function Number(e, t) {
       try {
           if (window.event) {
               var charCode = window.event.keyCode;
           }
           else if (e) {
               var charCode = e.which;
           }
           else { return true; }
           if (charCode > 31 && (charCode < 48 || charCode > 57)) {
               return false;
           }
           return true;
       }
       catch (err) {
           alert(err.Description);
       }
   }

</script>
      <?php
         if(isset($result)) {
         ?>
      <script>
         $('#message_container').fadeIn(10);
         $('#message').text("<?php echo $result; ?>");
         setTimeout(function() {
                 $('#message_container').fadeOut(2000, function() {
                         $('#message').text("");
                         $('#username').focus();
                 });
         }, 5000);
      </script>
      <?php
         }
         ?>
   </body>
</html>