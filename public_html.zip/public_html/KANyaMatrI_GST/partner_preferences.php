<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
ini_set('memory_limit','128M');
ob_start();
session_start();
require_once 'includes/configure.php';
require_once 'includes/session_handler.php';
require_once '../init.php';
date_default_timezone_set('Asia/Kolkata');

if(empty($_SESSION['Kamma_Matri'])){
    header("Location: index.php");
}

if($_SESSION['Kamma_Matri']){
    $enteredBy = $_SESSION['Kamma_Matri']['id'];    
}


if(isset($_SESSION['prefer_updated'])) {
    if($_SESSION['prefer_updated']) {
        $result = "Successfully Updated";
    } else {
        $result = "You have made no changes to save";
    }
    unset($_SESSION['prefer_updated']);
}

if(isset($_SESSION['prefer_added'])) {
    if($_SESSION['prefer_added']) {
        $result = "Successfully Added";
    } else {
        $result = "Failed to add";
    }
    unset($_SESSION['prefer_added']);
}

$users = new Registration();
$users = $users->fetch()->resultSet(); 

$available_userId = array();
foreach($users as $user) { 
    array_push($available_userId, $user['km_regcode']);
}

  if(isset($_POST['btn_update'])){

  $data = array();

  $data[] = $_POST['profile_id'];
  $data[] = $_POST['age_from'];
  $data[] = $_POST['age_to'];
  if($_POST['education']){
  $data[] = implode(",", $_POST['education']);
  } else {
  $data[] = "";
  }
  if($_POST['star']){
  $data[] = implode(",", $_POST['star']); 
  } else {
  $data[] = ""; 
  }
  $data[] = date("d-m-Y");
  $data[] = date("h:i A");
  $data[] = $_POST['partner_id'];

  $updatepartner = new Partner();
  $updatepartner = $updatepartner->update($data);
  $updatepartner_id = $updatepartner->rowCount();

  if($updatepartner_id){
    $_SESSION['prefer_updated'] = true;
  } else {
    $_SESSION['prefer_updated'] = false;
  }
  header("Location: partner_preferences.php");
  }


  if(isset($_POST['btn_add'])){
   
    $data = array();
   
    $data[] = $_POST['profile_id'];
    $data[] = $_POST['age_from'];
    $data[] = $_POST['age_to'];
    if($_POST['education']){
    $data[] = implode(",", $_POST['education']);
    } else {
    $data[] = "";
    }
    if($_POST['star']){
    $data[] = implode(",", $_POST['star']); 
    } else {
    $data[] = ""; 
    }
    $data[] = date("d-m-Y");
    $data[] = date("h:i A");
   
    $partner = new Partner();
    $partner = $partner->add($data);
    $partner_id = $partner->lastInsertID();
   
    if($partner_id){
      $_SESSION['prefer_added'] = true;
    } else {
      $_SESSION['prefer_added'] = false;
    }
    header("Location: partner_preferences.php");
   }



if(isset($_POST['profile_id'])){

    $profile_id = $_POST['profile_id'];

    $value = 1;

    $profiles = new Registration();
    $profiles = $profiles->fetch("WHERE km_regcode = '{$profile_id}'")->resultSet();    
    $profile = $profiles[0];

    $get_partners = new Partner();
    $get_partners = $get_partners->fetch("WHERE pl_userId = '{$profile_id}' ORDER BY id DESC LIMIT 1")->resultSet(); 
    $get_partner = $get_partners[0];

}


?>
<!DOCTYPE html>
<html>

    <link rel="stylesheet" href="../css/jquery-ui.css">
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
    <link rel="stylesheet" href="../css/bootstrap-datetimepicker.min.css" />
  
    <script src="../js/jquery-1.12.4.js"></script>
    <script src="../js/jquery-ui.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/moment.js"></script>
    <script src="../js/bootstrap-datetimepicker.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
<script type="text/javascript">
   function formfn(form)
   
   {

  if(form.value.value!="") {

  var educheckboxSelectedCount = 0;

  $.each($('[name="education[]"]:checked'), function(index, element) {
            educheckboxSelectedCount++;
          });

   if(educheckboxSelectedCount == 0) {
    alert("Please select education");
    return false;
   }


   var checkboxSelectedCount = 0;

  $.each($('[name="star[]"]:checked'), function(index, element) {
            checkboxSelectedCount++;
          });

   if(checkboxSelectedCount == 0) {
    alert("Please select star");
    return false;
   }

 }

   }
   
  </script>

   <?php include("includes/headertop.php");?>
   <body class="home color-green boxed shadow">
      <div class="root">
         <?php include("includes/header.php");?>
         <section class="content reverse" style=" width: 70%;min-height: 400px;">
            <section>
                <div  id="message_container" style="text-align: center; display: none; color: red;font-size: 18px; font-weight: bold">
                    <span id="message"></span>
                </div>
               <section class="columns" style="margin-top:10px !important;  width: 90%;">
                  <h2><span>Partner Preferences</span></h2>
                  <form action="" id="photo_form" method="post" enctype="multipart/form-data" name="PreferForm" onsubmit="return formfn(PreferForm);">
                  <input type="hidden" name="profile_id" value="<?php echo $profile_id;?>" id ="profile_id" />
                  <input type="hidden" name="value" value="<?php echo $value;?>" id ="value" />
                  <input type="hidden" id="partner_id" name="partner_id" value="<?php echo $get_partner['id']; ?>">
                    <table width="50%"  border="0">
                           <tbody>

                              <tr>
                                 <th style="text-align: center;">User ID : <span style="color:#c03131;font-size: 20px;"> * </span></th>
                                 <td>
                                     <input type="text" id="user_id" value="<?php echo $profile_id;?>" name="user_id" placeholder="User ID" class="text">
                                 </td>
                              </tr>

                              <?php if($profile){  ?>

                              <tr>
                                 <th style="text-align: center;width: 20%;">Name : <span style="color:#c03131;font-size: 20px;"> * </span></th>
                                 <td>
                                     <input type="text" id="user_name" value="<?php echo $profile['km_name'];?>" name="user_name" placeholder="Name" class="text" readonly>
                                 </td>
                              </tr>

                              <tr>
                                 <th style="text-align: center;">Mobile No : <span style="color:#c03131;font-size: 20px;"> * </span></th>
                                 <td>
                                     <input type="text" id="mobile" value="<?php echo $profile['km_mobile'];?>" name="mobile" placeholder="Mobile No" class="text" readonly>
                                 </td>
                              </tr>

                               <tr>
                                 <th style="text-align: center;">Preferred Age :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <table width="100%">
                                       <tbody>
                                          <tr>
                                          <th style="text-align: center;">From :</th>
                                             <td >
                                             <select id="age_from" name="age_from" style="opacity: 1;">
                                                <option value="21" >21</option>
                                                <?php for($age = 22; $age <= 50; $age++ ){?>
                                                <option value="<?php echo $age;?>" <?php if($get_partner['age_from'] == $age){ echo 'selected'; }  ?> ><?php echo $age;?></option>
                                                <?php } ?>
                                             </select>
                                             </td>
                                             <th style="text-align: center;">To :</th>
                                             <td >
                                                <select id="age_to" name="age_to" style="opacity: 1;">
                                                <option value="21" >21</option>
                                                <?php for($age = 22; $age <= 50; $age++ ){?>
                                                <option value="<?php echo $age;?>" <?php if($get_partner['age_to'] == $age){ echo 'selected'; }  ?> ><?php echo $age;?></option>
                                                <?php } ?>
                                             </select>
                                                
                                             </td>
                                             
                                             
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>

                               <tr>
                               <th style="text-align: center;vertical-align: top;">Education :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                  <?php
                                foreach($edu_array as $key => $value) {
                                  $educationIds = explode(',', $get_partner['education']);
                                ?>
                             <?php
                                $educationChecked = false;
                                foreach($educationIds as $educationId) {
                                  if($educationId == $key) {
                                   
                                 ?>    

                                 <div class="col-md-4">
                                  <label style="min-height: 35px;" class="checkbox-inline">
                                  <input type="checkbox" value="<?php echo $key;?>" name="education[]" checked><?php echo $value;?>
                                  </label>
                               </div>
                               <?php 
                                  $educationChecked = true; 
                                  } 
                                  }  
                                  ?>
                               <?php if($educationChecked == false) {  ?>
                               <div class="col-md-4">
                                  <label style="min-height: 35px;" class="checkbox-inline">
                                  <input type="checkbox" value="<?php echo $key;?>" name="education[]"><?php echo $value;?>
                                  </label>
                               </div>
                               <?php 
                                  } 
                                    }  
                                    ?>

                                 </td>
                              </tr>


                              <tr>
                               <th style="text-align: center;vertical-align: top;">Star :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                 <?php
                                  foreach($stars_array as $star) {
                                    $starIds = explode(',', $get_partner['star']);
                                  ?>
                               <?php
                                  $starChecked = false;
                                  foreach($starIds as $starIds) {
                                    if($starIds == $star) {
                                   ?>
                               <div class="col-md-6">
                                  <label style="min-height: 35px;" class="checkbox-inline">
                                  <input type="checkbox" name="star[]" value="<?php echo $star; ?>" checked><?php echo $star; ?>
                                  </label>
                               </div>
                               <?php $starChecked = true; } }  ?>
                               <?php if($starChecked == false) {  ?>
                               <div class="col-md-6">
                                  <label style="min-height: 35px;" class="checkbox-inline">
                                  <input type="checkbox" name="star[]" value="<?php echo $star; ?>"><?php echo $star; ?>
                                  </label>
                               </div>
                               <?php } }  ?>

                                 </td>
                              </tr>

                              <?php if($get_partner){ ?>
                              <tr>
                                  <td colspan="2">
                                    
                                      <input type="submit" class="delete" name="btn_update" value="Update" style="background:#93bf1b;color:#ffffff;margin-top:10px;margin-left: 50%;">
                                    
                                 </td>
                              </tr>
                              <?php } else { ?>
                              <tr>
                                  <td colspan="2">
                                    
                                      <input type="submit" class="delete" name="btn_add" value="Add" style="background:#93bf1b;color:#ffffff;margin-top:10px;margin-left: 50%;">
                                    
                                 </td>
                              </tr>
                              <?php } ?>



                              <?php } ?>
                            
                              
                           </tbody>
                        </table>
                      </form>
               </section>
            </section>
         </section>
         <div style=" clear: both;"></div>
         <?php include("includes/footer.php");?>
          <?php
        if(isset($result)) {
	?>
        <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(1000, function() {
                            $('#message').text("");
                            $('#username').focus();
                    });
            }, 1000);
        </script>
	<?php
            }
	?>
      </div>
        <script type="text/javascript">
            var availableUserId = "";
            $(document).ready(function() {
                $('#start_from').datetimepicker({
                    format: 'DD-MM-YYYY',
                    pickTime:false,
                    sideBySide:true
                });
                $('#paid_date').datetimepicker({
                    format: 'DD-MM-YYYY',
                    pickTime:false,
                    sideBySide:true
                });
                
                availableUserId = <?php echo json_encode($available_userId); ?>;
               $("#user_id").autocomplete({
                    source: availableUserId,
                    autoFocus:true,
                    select: function( event , ui ) {
                        $('#profile_id').val(ui.item.label);            
                        $('#photo_form').attr('method', 'post');
                        $('#photo_form').attr('action', 'partner_preferences.php');
                        $('#photo_form').submit();
                    }
                });                
            });
         
      
        </script>
        
   </body>
</html>