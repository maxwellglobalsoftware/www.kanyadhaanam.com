<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
ini_set('memory_limit','128M');
ob_start();
session_start();
require_once 'includes/configure.php';
require_once 'includes/session_handler.php';
require_once '../init.php';
date_default_timezone_set('Asia/Kolkata');

if(empty($_SESSION['Kamma_Matri'])){
    header("Location: index.php");
}

if($_SESSION['Kamma_Matri']){
    $enteredBy = $_SESSION['Kamma_Matri']['id'];    
}


if(isset($_SESSION['paymentAdded'])) {
    if($_SESSION['paymentAdded']) {
        $result = "Payment Added";
    } else {
        $result = "Failed to add Payment";
    }
    unset($_SESSION['paymentAdded']);
}
$users = new Registration();
$users = $users->fetch()->resultSet(); 

$available_userId = array();
foreach($users as $user) { 
    array_push($available_userId, $user['km_regcode']);
}
if(isset($_SESSION['payment_id'])){
    $profile_id = $_SESSION['payment_id'];
    unset($_SESSION['payment_id']);
    $payments = new Payment();
    $payments = $payments->fetch("WHERE id = '{$profile_id}' ORDER BY id DESC LIMIT 1")->resultSet(); 
    $mg_payment = $payments[0];
    $payment_id = $payment['id'];
    
}
//print_r($payment);

if(isset($_POST['btn_update'])) {      
    $data = array();   
    $start_date = date_format(new DateTime($_POST['start_from']), 'Y-m-d');
    $start_date = new DateTime($start_date);
    $start_date->modify("+30 day");
    $expire_date = $start_date->format("Y-m-d");       
    $data[] = $_POST['user_id'];
    $data[] = $_POST['plan_name'];
    $data[] = $_POST['plan_amount'];
    $data[] = date_format(new DateTime($_POST['start_from']), 'Y-m-d');
    $data[] = date_format(new DateTime($_POST['paid_date']), 'Y-m-d');
    $data[] = $expire_date;
    $data[] = $enteredBy;
    $data[] = $_POST['status']; 
    $data[] = $_POST['remarks'];
    $data[] = $_POST['payment_mode'];
    $data[] = $_POST['payment_id'];
    
//    print_r($data);
//    exit();
    

    $payment = new Payment();
    $payment = $payment->update($data);
    $updatepayment_id = $payment->rowCount();

    if($updatepayment_id){   
        $_SESSION['paymentUpdate'] = true;
    } else {
        $_SESSION['paymentUpdate'] = false;
    }
    header("Location: manage_payments.php");
}

if(isset($_POST['btn_payment'])) {      
    $data = array();   
    $start_date = date_format(new DateTime($_POST['start_from']), 'Y-m-d');
    $start_date = new DateTime($start_date);
    $start_date->modify("+30 day");
    $expire_date = $start_date->format("Y-m-d");       
    $data[] = $_POST['user_id'];
    $data[] = $_POST['plan_name'];
    $data[] = $_POST['plan_amount'];
    $data[] = date_format(new DateTime($_POST['start_from']), 'Y-m-d');
    $data[] = date_format(new DateTime($_POST['paid_date']), 'Y-m-d');
    $data[] = $expire_date;
    $data[] = $enteredBy;
    $data[] = 'activate'; 
    $data[] = $_POST['remarks'];
    $data[] = date("Y-m-d");
    $data[] = date("H:i:s");
    $data[] = "";
    $data[] = $_POST['payment_mode'];
//    print_r($data);
//    exit();
    $payment = new Payment();
    $payment = $payment->add($data);
    $addpayment_id = $payment->lastInsertID();
    
     $profiles = new Registration();
     $profiles = $profiles->fetch("WHERE km_regcode = '{$_POST['user_id']}'")->resultSet();    
     $profile = $profiles[0];

     $phone_no = $profile['km_mobile'];
     $profile_name = $profile['km_name'];
     $profile_email = $profile['km_email'];
     
     $msgdata = "Dear {$profile_name}, We have received your payment and activated your account in KANYADHAANAM MATRIMONY. Login and Find your Life partner. Call 95000 90825.";
     $url_data="http://alerts.maxwellsms.com/api/v3/index.php";
     $parameters_data = "method=sms&api_key=Afebb28266bdbd1300d76c268f10f65b8&to=$phone_no&sender=KDMMAT&message=$msgdata&format=xml&flash=0";
     
     $ch_data = curl_init($url_data);
     curl_setopt($ch_data, CURLOPT_POST, 1);
     curl_setopt($ch_data, CURLOPT_POSTFIELDS, $parameters_data);
     curl_setopt($ch_data, CURLOPT_FOLLOWLOCATION, 1);
     curl_setopt($ch_data, CURLOPT_HEADER, 0);
     curl_setopt($ch_data, CURLOPT_RETURNTRANSFER, 1);
     $response_data = curl_exec($ch_data);

         if($profile_email){
   
      $msg= "<table>
        
        <p style='font-size: 18px;'>Dear {$profile_name},</p>
        
        <tr><td align='left' style='font-size: 17px;line-height: 1.5em;'>Thank You very much for making payment in KANYADHAANAM MATRIMONY</td></tr>
        <tr><td align='left' style='font-size: 17px;line-height: 1.5em;'>We have received your payment and activated your account in KANYADHAANAM MATRIMONY. Login and Find your Life partner. </td></tr>
        <tr><td align='left' style='font-size: 17px;line-height: 1.5em;'>Call:95000 90825 for any clarifications.</td></tr>
        </table>
        <br>
        <table>
        <tr style='font-size: 15px;line-height: 1.5em;'><td>Regards, </tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;'><td>KANYADHAANAM MATRIMONY - TEAM</tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;'><td><a href='www.kanyadhaanam.com' target='_blank'>www.kanyadhaanam.com</a></tr></td>
        </table>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/call_icon.png' style=''> &nbsp;95000 90825</p>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/whatsapp_icon.png' style=''> &nbsp;95000 90825</p>
        
        
        <div id='accordion-container' style='font-size: 11px;background: #ffffff;padding: 5px 10px 10px 10px;border: 1px solid #cccccc;;border-radius: 5px;box-shadow: 0 5px 15px #cccccc; width:70%;'>
        
        <h2 class='accordion-header active-header' style=' margin-top: 0px;border-radius: 5px 5px 0 0;background: url(http://www.kanyadhaanam.com/images/active-header.gif) #cef98d;background-repeat: no-repeat;margin: 5px 0 0 0;padding: 5px 20px;cursor: pointer;color: #e23f0c;'><img src='http://www.kanyadhaanam.com/images/lightbulb.png' width='40' style='vertical-align: middle;'>  Qns : How soon will my membership be processed when I make payment?
        </h2>

        <div class='accordion-content open-content' style='width: 766px; display: block;padding: 10px;background: #ffffff;border: 1px solid #cccccc;border-top: 0;border-radius: 0 0 5px 5px;text-align: justify;width: auto;font-size: 16px;font-weight: normal;'>
         <p style='margin: 5px;'>Your subscription will be activated within 5 minutes after your successfull payment.</p>
        
        </div>
        
        ";
   
       $to = $profile_email;
       $subject = "Reg: Payment activated in KANYADHAANAM MATRIMONY";
   
     // Always set content-type when sending HTML email
      $headers = "MIME-Version: 1.0" . "\r\n";
      $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
      
      // More headers
      $headers .= 'From: <support@kanyadhaanam.com>' . "\r\n";
      
      $send_mail = mail($to,$subject,$msg,$headers);
   
   }

    if($addpayment_id){   
        $_SESSION['paymentAdded'] = true;
    } else {
        $_SESSION['paymentAdded'] = false;
    }
    header("Location: payment.php");
}
?>
<!DOCTYPE html>
<html>

    <link rel="stylesheet" href="../css/jquery-ui.css">
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
    <link rel="stylesheet" href="../css/bootstrap-datetimepicker.min.css" />
  
    <script src="../js/jquery-1.12.4.js"></script>
    <script src="../js/jquery-ui.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/moment.js"></script>
    <script src="../js/bootstrap-datetimepicker.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>


  <style type="text/css">
    
    input[type=text], input[type=password], select {
    width: 90% !important;
    padding: 12px 20px !important;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

th {
    text-align: left;
    font-size: 16px;
}
  </style>


   <?php include("includes/headertop.php");?>
   <body class="home color-green boxed shadow">
      <div class="root">
         <?php include("includes/header.php");?>
         <section class="content reverse" style=" width: 70%;">
            <section>
                <div  id="message_container" style="text-align: center; display: none; color: red;font-size: 18px; font-weight: bold">
                    <span id="message"></span>
                </div>
               <section class="columns" style="margin-top:10px !important;  width: 90%;">
                  <h2><span>Payment</span></h2>
                  <form action="" method="post" enctype="multipart/form-data">
                      <input type="hidden" name="payment_id" value="<?php echo $mg_payment['id']; ?>" />
                    <table width="50%"  border="0">
                           <tbody>
                              
                              <tr>
                                 <th>User ID :</th>
                                 <td>
                                     <input type="text" id="user_id" <?php if($mg_payment['pl_userId']){ ?> readonly value="<?php echo $mg_payment['pl_userId']; ?>"  <?php } ?> name="user_id" placeholder="User ID" class="text" required="">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Plan Name :</th>
                                 <td>
                                     <select name="plan_name" id="plan_name" required="" style="opacity: 1;">
                                       <option value="" selected disabled>-- Plan Name --</option>
                                       <?php foreach($plan_array as $key => $value){ ?>
                                       <option <?php if($mg_payment['pl_name'] == $key){echo 'selected';} ?> value="<?php echo $key;?>"><?php echo $key;?></option>
                                       <?php } ?>
                                    </select>
                                 </td>
                              </tr>
                              
                              <tr>
                                 <th>Plan Amount :</th>
                                 <td>
                                    <input type="text" readonly value="<?php echo $mg_payment['pl_amount']; ?>" id="plan_amount" name="plan_amount" placeholder="Plan Amount" class="text" required="">
                                 </td>
                              </tr>
                              
                              <tr>
                                 <th>Plan Start From :</th>
                                 <td>
                                     <input class="form-control text" type="text" name="start_from" id="start_from" data-field="datetime" data-date-format="DD-MM-YYYY" <?php ($mg_payment['pl_startDate'])?$pl_startDate = $mg_payment['pl_startDate'] : $pl_startDate = date('Y-m-d'); ?> value="<?php echo date_format(new DateTime($pl_startDate), 'd-m-Y');?>" readonly autocomplete="off" style="width: 145px;" required>
                                </td>
                              </tr>
                              
                              <tr>
                                 <th>Paid Date :</th>
                                 <td>
                                     <input class="form-control text" type="text" name="paid_date" id="paid_date" data-field="datetime" data-date-format="DD-MM-YYYY" <?php ($mg_payment['pl_paidDate'])?$pl_paidDate = $mg_payment['pl_paidDate'] : $pl_paidDate = date('Y-m-d'); ?> value="<?php echo date_format(new DateTime($pl_paidDate), 'd-m-Y');?>" readonly autocomplete="off" style="width: 145px;" required>
                                 </td>
                              </tr>
                              <?php if($mg_payment['pl_status']){?>
                              <tr>
                                 <th>Status :</th>
                                 <td>
                                    <select name="status" required="" style="opacity: 1;">
                                        <option value="" disabled>- Status -</option>
                                        <?php foreach($paymentStatus as $status){?>
                                        <option <?php if($status == $mg_payment['pl_status'] ){ echo 'selected'; }?> value="<?php echo $status; ?>"><?php echo ucwords($status); ?></option>
                                        <?php } ?>
                                      </select>
                                 </td>
                              </tr>
                              <?php } ?>
                              
                              <tr>
                                 <th>Remarks :</th>
                                 <td>
                                     <textarea name="remarks" rows="3" cols="40"><?php echo $mg_payment['pl_remarks'];?></textarea>
                                         
<!--                                     <input class="form-control text" type="text" name="paid_date" id="paid_date" data-field="datetime" data-date-format="DD-MM-YYYY"  value="<?php echo date_format(new DateTime($profile['pl_paidDate']), 'd-m-Y');?>" readonly autocomplete="off" style="width: 145px;" required>-->
                                 </td>
                              </tr>
                              
                              <tr>
                                 <th>Payment Mode :</th>
                                 <td>
                                     <select name="payment_mode" id="payment_mode" required="" style="opacity: 1;">
                                       <option value="" selected disabled>-- Payment Mode --</option>
                                       <?php foreach($paymode_array as $value){ ?>
                                       <option <?php if($mg_payment['payment_mode'] == $value){ echo 'selected'; } ?> value="<?php echo $value;?>"><?php echo ucwords($value);?></option>
                                       <?php } ?>
                                    </select>
                                 </td>
                              </tr>
                              
                              <tr>
                                  <td colspan="2">
                                      <?php if($mg_payment['pl_status']){?>
                                    <input type="submit" name="btn_update" value="Update" style="background:#93bf1b;color:#ffffff;margin-top:10px;margin-left: 50%;" onclick="return validateUserInfo();">
                                    <?php }else{ ?>
                                    <input type="submit" name="btn_payment" value="Submit" style="background:#93bf1b;color:#ffffff;margin-top:10px;margin-left: 50%;" onclick="return validateUserInfo();">
                                    <?php } ?>
                                 </td>
                              </tr>
                              
                           </tbody>
                        </table>
                      </form>
               </section>
            </section>
         </section>
         <div style=" clear: both;"></div>
         <?php include("includes/footer.php");?>
          <?php
        if(isset($result)) {
	?>
        <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(1000, function() {
                            $('#message').text("");
                            $('#username').focus();
                    });
            }, 1000);
        </script>
	<?php
            }
	?>
      </div>
        <script type="text/javascript">
            var availableUserId = "";
            $(document).ready(function() {
                $('#start_from').datetimepicker({
                    format: 'DD-MM-YYYY',
                    pickTime:false,
                    sideBySide:true
                });
                $('#paid_date').datetimepicker({
                    format: 'DD-MM-YYYY',
                    pickTime:false,
                    sideBySide:true
                });
                
                availableUserId = <?php echo json_encode($available_userId); ?>;
               $("#user_id").autocomplete({
                    source: availableUserId,
                    autoFocus:true,
                    select: function( event , ui ) {

                    }
                });                
            });
         
      
        $( document ).on('change','#plan_name ', function () {
            var plan_name = $(this).val();
            if(plan_name == 'Starter'){
                $('#plan_amount').val(1000);
            }
            
        });
        </script>
   </body>
</html>