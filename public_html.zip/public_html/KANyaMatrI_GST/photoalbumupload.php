<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
ini_set('memory_limit','128M');
ob_start();
session_start();
require_once 'includes/configure.php';
require_once 'includes/session_handler.php';
require_once '../init.php';
date_default_timezone_set('Asia/Kolkata');

if(empty($_SESSION['Kamma_Matri'])){
    header("Location: index.php");
}

if($_SESSION['Kamma_Matri']){
    $enteredBy = $_SESSION['Kamma_Matri']['id'];    
}
if(isset($_SESSION['message'])){
    $result = $_SESSION['message'];
    unset($_SESSION['message']);
}

if(isset($_SESSION['photoAdded'])) {
    if($_SESSION['photoAdded']) {
        $result = "Photos Uploaded";
    } else {
        $result = "Failed to upload Photos";
    }
    unset($_SESSION['photoAdded']);
}
if(isset($_POST['selected_user'])){
    $users = new Registration();
    $users = $users->fetch("WHERE km_regcode = '{$_POST['selected_user']}'")->resultSet();
    $user = $users[0];    
    $data = array(); 
    $data['user_name'] = $user['km_name'];       
    echo json_encode($data);
    exit();
}
$users = new Registration();
$users = $users->fetch()->resultSet(); 

$available_userId = array();
foreach($users as $user) { 
    array_push($available_userId, $user['km_regcode']);
}

if(isset($_POST['btn_photos'])) {
    $photos = new Profile();
    $photos = $photos->fetchPhotos("WHERE pho_userId = '{$_POST['user_id']}'")->resultSet();
    
    if(count($photos) > 11){
        $_SESSION['message'] = "You are already upload maximum number of Photos";
        header("Location: photoalbumupload.php");
        exit();
    }else{
        if(count($_FILES['photo_image']['name']) > 10) {
            $_SESSION['message'] = "You could upload maximum 10 Photos Only";
            header("Location: photoalbumupload.php");
            exit();
        }
        if(count($_FILES['photo_image']['error']) >= 1) {
            for($i = 0; $i < count($_FILES['photo_image']['error']); $i++) {
                if($_FILES['photo_image']['error'][$i] == 0) {                
                    $imagePath = 'Kanya@Prof/padangal/' .$_POST['user_id'].'-'.$i.'_'. $_FILES['photo_image']['name'][$i];

                    move_uploaded_file($_FILES['photo_image']['tmp_name'][$i], '../'.$imagePath);
                    $data = array(); 
                    $data[] = $_POST['user_id'];        
                    $data[] = $imagePath;
                    $photos = new Profile();
                    $photos = $photos->addPhotos($data);
                } 
            }
            $photo_id = $photos->lastInsertID();
        }   
        if($photo_id){   
            $_SESSION['photoAdded'] = true;
        } else {
            $_SESSION['photoAdded'] = false;
        }
    }    
          
    header("Location: photoalbumupload.php");
}
?>
<!DOCTYPE html>
<html>

<link rel="stylesheet" href="../css/jquery-ui.css">
  
  <script src="../js/jquery-1.12.4.js"></script>
  <script src="../js/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
  <script type="text/javascript">
   function formfn(form)
 
 {

if(form.user_id.value=="") { alert("Please enter user id"); form.user_id.focus(); return false; }

var fi = document.getElementById('files');

if (fi.files.length == 0) {

if(form.files.value=="") { alert("Please uplaod album photos"); form.files.focus(); return false; }
}

 }

</script>
   <?php include("includes/headertop.php");?>
    <body class="home color-green boxed shadow">
        <div class="root">
            <?php include("includes/header.php");?>
            <section class="content reverse" style=" width: 90%;">
                <section>
                    <div  id="message_container" style="text-align: center; display: none; color: red;font-size: 18px; font-weight: bold">
                        <span id="message"></span>
                    </div>
                    <section class="columns" style="margin-top:10px !important;  width: 90%;">
                        <h2><span>Album Photos Upload</span></h2>
                        <form action="" id="UploadForm" method="post" enctype="multipart/form-data" name="UploadForm" onsubmit="return formfn(UploadForm);">
                        <table width="50%"  border="0">
                               <tbody>

                                  <tr>
                                     <th>User ID :</th>
                                     <td>
                                         <input type="text" id="user_id" name="user_id" placeholder="User ID" class="text">
                                     </td>
                                  </tr>
                                  <tr>
                                     <th>User Name :</th>
                                     <td>
                                         <input type="text" id="user_name"  name="user_name" placeholder="User Name" readonly class="text">
                                     </td>
                                  </tr>
                                  <tr>
                                     <th>Upload Album Photos:</th>                                 
                                        <td style="padding-top: 30px; padding-left: 15px">
                                            <input type="file" id="files" name="photo_image[]"  accept=".jpg, .jpeg, .png, .gif" onchange="validateImage()" multiple="multiple"  style="float: left;">
                                        </td>                                 
                                  </tr>    

                                  <tr>
                                      <td colspan="2">
                                        <input type="submit" name="btn_photos" accept="jpg,jpeg,png,gif" value="Submit" style="background:#93bf1b;color:#ffffff;margin-top:10px;margin-left: 50%;" onclick="return validateUserInfo();">
                                     </td>
                                  </tr>

                               </tbody> 
                            </table>
                      </form>

                    </section>
                </section>
            </section>
            <div style=" clear: both;"></div>
            <?php include("includes/footer.php");?>
<script type="text/javascript">
function validateImage() {
    var formData = new FormData();
    var file = document.getElementById("files").files[0];
    var file2 = document.getElementById("files").files[1];
    var file3 = document.getElementById("files").files[2];
    var file4 = document.getElementById("files").files[3];
    var file5 = document.getElementById("files").files[4];
    var file6 = document.getElementById("files").files[5];
    var file7 = document.getElementById("files").files[6];
    var file8 = document.getElementById("files").files[7];
    var file9 = document.getElementById("files").files[8];
    var file10 = document.getElementById("files").files[9];
    formData.append("Filedata", file);
    var t = file.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "gif") {
        alert('Please upload jpg,jpeg,png,gif file exactly');
        document.getElementById("files").value = '';
        return false;
    }
    formData.append("Filedata", file2);
    var t = file2.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "gif") {
        alert('Please upload jpg,jpeg,png,gif file exactly');
        document.getElementById("files").value = '';
        return false;
    }
    formData.append("Filedata", file3);
    var t = file3.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "gif") {
        alert('Please upload jpg,jpeg,png,gif file exactly');
        document.getElementById("files").value = '';
        return false;
    }
    formData.append("Filedata", file4);
    var t = file4.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "gif") {
        alert('Please upload jpg,jpeg,png,gif file exactly');
        document.getElementById("files").value = '';
        return false;
    }
    formData.append("Filedata", file5);
    var t = file5.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "gif") {
        alert('Please upload jpg,jpeg,png,gif file exactly');
        document.getElementById("files").value = '';
        return false;
    }
    formData.append("Filedata", file6);
    var t = file6.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "gif") {
        alert('Please upload jpg,jpeg,png,gif file exactly');
        document.getElementById("files").value = '';
        return false;
    }
    formData.append("Filedata", file7);
    var t = file7.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "gif") {
        alert('Please upload jpg,jpeg,png,gif file exactly');
        document.getElementById("files").value = '';
        return false;
    }
    formData.append("Filedata", file8);
    var t = file8.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "gif") {
        alert('Please upload jpg,jpeg,png,gif file exactly');
        document.getElementById("files").value = '';
        return false;
    }
    formData.append("Filedata", file9);
    var t = file9.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "gif") {
        alert('Please upload jpg,jpeg,png,gif file exactly');
        document.getElementById("files").value = '';
        return false;
    }
    formData.append("Filedata", file10);
    var t = file10.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "gif") {
        alert('Please upload jpg,jpeg,png,gif file exactly');
        document.getElementById("files").value = '';
        return false;
    }
}
</script>
            <?php
            if(isset($result)) {
            ?>
            <script>
                $('#message_container').fadeIn(10);
                $('#message').text("<?php echo $result; ?>");
                setTimeout(function() {
                        $('#message_container').fadeOut(2000, function() {
                                $('#message').text("");
                                $('#username').focus();
                        });
                }, 5000);
            </script>
            <?php
                }
            ?>
            <script type="text/javascript">
            var availableUserId = "";
            var user = "";
            $(document).ready(function() {
                availableUserId = <?php echo json_encode($available_userId); ?>;
                $("#user_id").autocomplete({
                    source: availableUserId,
                    autoFocus:true,
                    select: function( event , ui ) {
                        $.ajax({
                            url: 'photoalbumupload.php',
                            method: 'POST',
                            data: {
                              'selected_user':ui.item.label
                            },
                            success: function(response) {   
                                var user = JSON.parse(response);
                                $('#user_name').val(user.user_name);
                                if(user.hs_imgPath){
//                                    $('#horoscope').css('display','block');
                                    $('#horosImg').attr('src',user.hs_imgPath);
                                    $('#horos_image').val(user.hs_imgPath);
                                    $('#horos_image').prop('required',false);
                                }else{
                                    $('#horosImg').attr('src','');
                                    $('#horos_image').prop('required',true);
                                }
                            }
                        });
                    }
                });
            });
         
      
        $( document ).on('change','#plan_name ', function () {
            var plan_name = $(this).val();
            if(plan_name == 'Starter'){
                $('#plan_amount').val(200);
            }
            
        });
        </script>
        </div>
    </body>
</html>