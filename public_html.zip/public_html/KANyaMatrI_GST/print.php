<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT)); ?>
<?php
ini_set('memory_limit','128M');
ob_start();
session_start();
require_once 'includes/configure.php';
require_once 'includes/session_handler.php';
require_once '../init.php';
date_default_timezone_set('Asia/Kolkata');

if(empty($_SESSION['Kamma_Matri'])){
    header("Location: index.php");
}


if($_SESSION['Kamma_Matri']){
    $enteredBy = $_SESSION['Kamma_Matri']['id'];    
}

if(isset($_SESSION['message'])){
    $result = $_SESSION['message'];
    unset($_SESSION['message']);
}

if(isset($_SESSION['book_added'])) {
    if($_SESSION['book_added']) {
        $result = "Successfully Added";
    } else {
        $result = "Failed to add";
    }
    unset($_SESSION['book_added']);
}

if(isset($_POST['selected_user'])){
    $users = new Registration();
    $users = $users->fetch("WHERE km_regcode = '{$_POST['selected_user']}'")->resultSet();
    $user = $users[0];    
    $data = array(); 
    $data['user_name'] = $user['km_name']; 
    $data['user_gender'] = ucwords($user['km_gender']); 
    $data['user_mobile'] = $user['km_mobile'];
    echo json_encode($data);
    exit();
}


if(isset($_POST['profile_id'])){
    $profile_id = $_POST['profile_id'];

    $getusers = new Registration();
    $getusers = $getusers->fetch("WHERE km_regcode = '{$_POST['profile_id']}'")->resultSet();
    $getuser = $getusers[0];

    $get_partners = new Partner();
    $get_partners = $get_partners->fetch("WHERE pl_userId = '{$_POST['profile_id']}'")->resultSet();
    $get_partner = $get_partners[0];


}



$users = new Registration();
$users = $users->fetch()->resultSet(); 

$available_userId = array();
foreach($users as $user) { 
    array_push($available_userId, $user['km_regcode']);
}


$male_profiles = new Registration();
$male_profiles = $male_profiles->fetch("WHERE km_gender = 'male' AND km_status = 'live' ORDER BY id DESC")->resultSet();    

?>
<html>

<head>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">

<style>
body{
  font-family: 'Roboto', sans-serif;font-size: 14px;
}

table td{
  font-size: 14px
}

div#header {
   position:fixed; top:20px; left:0px; height:140px; right:0px;overflow:hidden;
}
div#footer {
   position:fixed; bottom:0px; height:100px; left:0px; right:0px; overflow:hidden;
}

div#content{
   position:absolute; top:160px; bottom:100px; left:0px; right:0px; /*overflow: auto;*/
}




</style>
<style type="text/css" media="print">
@page {
    size:21cm 29.7cmt;
    margin:1cm 1cm 1cm 1cm; 
    mso-title-page:yes;
    mso-page-orientation: portrait;
    mso-header: header;
    mso-footer: footer;
}
@page content {margin: 1cm 1cm 1cm 1cm;}
div.content {page: content;}

</style>
<style type="text/css" media="print">
@page {
    size: auto;   /* auto is the initial value */
    margin: 0em 2em;  /* this affects the margin in the printer settings */
}
</style>

</head>
<body onload="print()">

<div id="header">

<h4 style="color:#d40000;text-align: center;margin: 0.5%;font-size: 14px"> </h4>

<h3 style="margin: 0.5%;text-align: center;color: green;font-size: 18px"></h3>

<h2 style="margin: 0.5%;;text-align: center;color: green;font-size: 28px"></h2>

       <p style="margin:1.5% 0% 0.5% ;text-align: center;color: #111;">
</p>


</div>

<div style="clear: both;"></div>

<div id="content">
<?php if($getuser){ ?>
<?php

$cur_year = date('Y');

$prefer_age_to = $get_partner['age_to'];;

$to_year = ($cur_year - ($get_partner['age_from'] - 1));

$from_year = ($cur_year - $prefer_age_to);

$prefer_education = explode(",", $get_partner['education']);

$prefer_star = explode(",", $get_partner['star']);

$statement = "";

$pre_edu = $get_partner['education'];

$pre_star = $get_partner['star'];

if($getuser['km_gender'] == 'male'){
$km_gender = 'female';
}else{
$km_gender = 'male';
}

if($get_partner['star']){

$matchprofiles = new Registration();
$matchprofiles = $matchprofiles->fetch("WHERE km_gender = '{$km_gender}' AND   YEAR(km_dateofbirth) BETWEEN '{$from_year}' AND '{$to_year}' AND (km_star = '{$prefer_star[0]}' OR km_star = '{$prefer_star[1]}' OR km_star = '{$prefer_star[2]}' OR km_star = '{$prefer_star[3]}' OR km_star = '{$prefer_star[4]}' OR km_star = '{$prefer_star[5]}' OR km_star = '{$prefer_star[6]}' OR km_star = '{$prefer_star[7]}' OR km_star = '{$prefer_star[8]}' OR km_star = '{$prefer_star[9]}' OR km_star = '{$prefer_star[10]}' OR km_star = '{$prefer_star[11]}' OR km_star = '{$prefer_star[12]}' OR km_star = '{$prefer_star[13]}' OR km_star = '{$prefer_star[14]}' OR km_star = '{$prefer_star[15]}' OR km_star = '{$prefer_star[16]}' OR km_star = '{$prefer_star[17]}' OR km_star = '{$prefer_star[18]}' OR km_star = '{$prefer_star[19]}' OR km_star = '{$prefer_star[20]}') AND km_status = 'live' ORDER BY id DESC")->resultSet();
$match_profiles_list = count($matchprofiles);

}

?>
<?php 
if($matchprofiles){ ?>
<?php
foreach($matchprofiles as $profile){

$users = new Registration();
$users = $users->fetch("WHERE km_regcode = '{$profile['km_regcode']}'")->resultSet();
$user = $users[0];

$photos = new Profile();
$photos = $photos->fetchPhotos("WHERE pho_userId = '{$user['km_regcode']}' AND pho_imgPath LIKE '%_profile_%' ORDER BY id DESC LIMIT 1")->resultSet();
$photo = $photos[0];

if($photo['pho_imgPath']){

if($sno < 8){


if($photo['pho_imgPath']){
$imgPath =  '../'.$photo['pho_imgPath'];

$image_file = fopen($imgPath, 'r');
$imgPath = fread($image_file, filesize($imgPath));
}else{
$imgPath = '../images/'.$user['km_gender'].'.png';

$image_file = fopen($imgPath, 'r');
$imgPath = fread($image_file, filesize($imgPath));                                
} 

//// Occupation /////
$occupations = new Registration();
$occupations = $occupations->fetchOccupation("WHERE id = '{$user['km_occupation']}' ORDER BY occupation ASC")->resultSet();
$occupation = $occupations[0];

//// Districts /////
$districts = new Registration();
$districts = $districts->fetchDistricts("WHERE id = '{$user['km_district']}' ORDER BY name ASC")->resultSet();
$district = $districts[0];


$from = new DateTime($user['km_dateofbirth']);
$to   = new DateTime('today');
$age = $from->diff($to)->y; 
$cur_Year = date("Y");

$view_only_horos = new Profile();
$view_only_horos = $view_only_horos->fetchHoroscope("WHERE hs_userId = '{$user['km_regcode']}'")->resultSet();
$view_only_horos = $view_only_horos[0];

?>



                        <div id="r-content" class="style50" style="min-height: 0px;height: 180px!important;border: 2px dotted #EEEEEE;padding-left: 1%;    margin: 10px 0 0px 10px;float: left;font-weight: normal;height: auto;width:47%;">
                        <div class="r-content-left" style="border-right: none;width: 25%;float: left;font-weight: normal;height:180px;margin-top:4%">
                           

                             <span class="profile" style="margin-left: 5%;font-weight: bold;color: green;">ID : <?php echo $user['km_regcode'];?> </span>

                           <div style="border: 2px solid #CCCCCC;float: left;margin-top:2%;    width: 120px;height: 120px;">
                              <img width="150" height="170" border="0" src="data:image/jpeg;base64,<?php echo base64_encode($imgPath); ?>" style="height: 120px;width: 120px;">
                           </div>
                           
                        </div>

                          <div class="r-content-right-top" style="margin: 0px;width: 60%;float: right;height: auto;padding: 0 0 10px;">
                           <div class="r-content-top-1" style="border:0px!important;margin-top:8%;float: left;height: auto;padding: 0 10px;padding-left: 5%;">
                              <table width="526" cellspacing="0" cellpadding="0" border="0" style="width: 100%;border: none;text-transform: uppercase;">
                                 <tbody>

                                



                                 <?php if($user['km_regcode']){ ?>
                                    <tr>
                                       <td colspan="2"  style="color:green;padding: 2px 0px!important;font-weight: bold;border: none!important;text-align: left!important;">
                                       
                                     </td>
                                    </tr>
                                    <?php } ?>


                                 <?php if($user['km_name']){ ?>
                                 <tr>
                                     <td style="color:#d40000;padding: 2px 0px!important;border: none!important;text-align: left!important;">
                                        <?php if($user['km_star']){ echo $user['km_name']; } else { echo 'N / A'; } ?> , <span style="color:green;padding-left: 3%;border: none!important;text-align: left!important;"> <?php  if($user['km_education']){ echo $edu_array[$user['km_education']]; } else { echo 'N / A'; } ?>
                                          </span>
                                     </td>

                                     



                                    

                                  </tr>
                                  <?php } ?>



                                   <?php if($user['km_occupation']){ ?>
                                    <tr>
                                       <td  style="color:#000;padding: 4px 0px!important;border: none!important;text-align: left!important;">
                                          <?php 
                                          if($user['km_occupation']){ 
                                          if($occupation){ 
                                            echo $occupation['occupation']; } 
                                            else { echo $user['km_occupation']; }
                                            } else { echo 'N / A'; } 
                                          ?>
                                       </td>
                                    </tr>
                                    <?php } ?>

                                 <?php if($age || $user['km_height']){ ?>
                                    <tr>
                                       <td  width="182" style="color:#000;padding: 4px 0px!important;border: none!important;text-align: left!important;"> 
                                          <?php if($age && $user['km_height']){ ?>
                                          <?php echo $age; ?> / <?php echo $user['km_height']; ?>   
                                          <?php } else if($age){ ?>
                                          <?php if($age == $cur_Year){ echo 'N / A'; } else { echo $age; } ?>
                                          <?php } else if($user['km_height']){?>
                                          <?php echo $user['km_height']; ?> 
                                          <?php } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>
                                  <?php } ?>
                                   <?php if($user['km_star']){ ?>
                                    <tr>
                                       <td style="color:#000;padding: 4px 0px!important;border: none!important;text-align: left!important;">
                                          <?php if($user['km_star']){ echo $user['km_star']; } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>
                                    <?php } ?>
                                    <?php if($user['km_district']){ ?>
                                    <tr>
                                       <td  style="color:#000;padding: 4px 0px!important;border: none!important;text-align: left!important;">
                                      <?php 
                                          if($user['km_district']){ 
                                          if($district){ 
                                            echo $district['name']; } 
                                            else { echo $user['km_district']; }
                                            } else { echo 'N / A'; } 
                                          ?>
                                       </td>
                                    </tr>
                                    <?php } ?>
                                    
                                   
                                 </tbody>
                              </table>
                              </div>
                              </div>


                        </div>
                        <?php $sno++; } }  } 
                        } else{
                             ?>
                     <div id="result-content">
                        <h4 style="margin: 1.5em 1em;text-align: center;color: #17800a;"> Profile not available. </h4>
                     </div>
                     <?php
                        }                                
                        ?>

                           <?php } ?>

                   </div>

<div style="clear: both;"></div>
                   <div id="footer">


<h3 style="text-align: center;color:#111;font-size: 16px;    margin: 0.5%;"></h3>

<h4 style="    margin: 0.5%;text-align: center;color:#111;font-size: 14px;"> </h4>


<div style="float: left;width: 38%;margin:0% 1% ">
<h4 style="    margin: 0.5%;text-align: left;color: green;font-size: 14px;"><img src="images/phone.png" width="15px" style="padding-top: 5px"> </h4>
</div>




<div style="float: left;width: 30%;margin:0% 1% ">
<h4 style="    margin-top: 1.8%;text-align: left;color: red;font-size: 14px;"> </h4>
</div>


<div style="float: left;width: 25%;margin:0% 1% ">
<h4 style="    margin: 0.5%;text-align: right;color: green;font-size: 14px;"><img src="images/whatsapp.png" width="15px" style="padding-top: 5px">  </h4>
</div>

</div>

    </body>
</html>