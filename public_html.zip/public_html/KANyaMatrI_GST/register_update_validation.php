<?php error_reporting(E_ALL^E_NOTICE); ?>
<?php
  ob_start();
  session_start();
  require_once '../init.php';

        if($_POST['flag'] == 'MobileNo'){
            
        $phone_no = $_POST['phone'];
        
        $reg_code = $_POST['km_Code'];

        $registration = new Registration();
        $registration = $registration->fetch("WHERE km_regcode != '{$reg_code}' AND km_mobile = '{$phone_no}'")->resultSet();
        $registration = $registration[0];

        if($registration){
          $result = "exists";
        } else {
          $result = "success";  
        }

        echo $result.'-'.$phone_no;
        
        }

        if($_POST['flag'] == 'Sec_MobileNo'){
            
        $sec_phone_no = $_POST['sec_phone'];
        
        $reg_code = $_POST['km_Code'];

        $registration = new Registration();
        $registration = $registration->fetch("WHERE km_regcode != '{$reg_code}' AND km_second_mobile = '{$sec_phone_no}'")->resultSet();
        $registration = $registration[0];

        if($registration){
          $result = "exists";
        } else {
          $result = "success";  
        }

        echo $result.'-'.$sec_phone_no;
        
        }

        if($_POST['flag'] == 'EMail'){
            
        $gmail = $_POST['gmail'];
        
        $reg_code = $_POST['km_Code'];

        $registration = new Registration();
        $registration = $registration->fetch("WHERE km_regcode != '{$reg_code}' AND km_email = '{$gmail}'")->resultSet();
        $registration = $registration[0];

        if($registration){
          $result = "exists";
        } else {
          $result = "success";  
        }

        echo $result.'-'.$gmail;
        
        }


?>