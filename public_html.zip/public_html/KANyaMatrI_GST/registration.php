<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
   ini_set('memory_limit','128M');
   ob_start();
   session_start();
   require_once 'includes/configure.php';
   require_once 'includes/session_handler.php';
   require_once '../init.php';
   date_default_timezone_set('Asia/Kolkata');
   if(empty($_SESSION['Kamma_Matri'])){
       header("Location: index.php");
   }
   
   if(isset($_SESSION['registrationAdded'])) {     
       if($_SESSION['registrationAdded']) {
           $result = "Registration Completed";
       } else {
           $result = "Failed to add Registration";
       }
       unset($_SESSION['registrationAdded']);
   }
   if(isset($_SESSION['registrationAdded_user'])) {     
       if($_SESSION['registrationAdded_user']) {
           $result_user = $_SESSION['userinfo'];
       } 
       unset($_SESSION['registrationAdded_user']);
   }
   if(isset($_SESSION['registrationAdded_pass'])) {     
       if($_SESSION['registrationAdded_pass']) {
           $result_pass = $_SESSION['userpass'];
       } 
       unset($_SESSION['registrationAdded_pass']);
   }
   
   if(isset($_SESSION['register_exists'])) {     
       if($_SESSION['register_exists']) {
           $result = "Profile ID already exists";
       } 
       unset($_SESSION['register_exists']);
   }
   
          //// States /////
    $castes = new Registration();
    $castes = $castes->fetchCastes("ORDER BY caste ASC")->resultSet();

    $castesEncoded = json_encode($castes); 

    //// subcastes /////
    $subcastes = new Registration();
    $subcastes = $subcastes->fetchSubcastes("ORDER BY subcaste ASC")->resultSet();

    $subcastesEncoded = json_encode($subcastes);   
   
   if(isset($_POST['btn_register'])) {  
       $reg_year = date('y');
       $year = date('Y');
       $month = date('m');
       
       $registration = new Registration();
       $registration = $registration->fetch("WHERE YEAR(km_registered_date) = '{$year}' AND MONTH(km_registered_date) = '{$month}'")->resultSet(); 
       $count = count($registration) + 1 ;
       $km_regcode = $reg_year.$month.$count;
       
       $data = array();
       
       $data[] = $km_regcode;
       $data[] = $_POST['member_name'];
       $data[] = $_POST['password'];
       $data[] = $_POST['gender'];
       $data[] = $_POST['education'];
       $data[] = $_POST['education_details'];
       $data[] = $_POST['employedIn'];
       $data[] = $_POST['occupation'];
      ;
       $data[] = $_POST['annualIncome'];  
       $data[] = $_POST['bloodgroup'];  
       $data[] = $_POST['doorNo'];
       $data[] = $_POST['street'];
       $data[] = $_POST['city'];
       $data[] = $_POST['state'];
       $data[] = $_POST['district'];
       $data[] = $_POST['pincode'];  
       $data[] = $_POST['mobile'];
       $data[] = $_POST['second_mobile'];
       $data[] = $_POST['email'];
       $data[] = $_POST['landline_code'].'-'.$_POST['landline'];
       $data[] = $_POST['marital_status'];
       $data[] = $_POST['caste'];
       $data[] = $_POST['subcaste'];

      
       $data[] = $_POST['languagesKnown'];
       $data[] = $_POST['physical_status']; 
       
       $data[] = $_POST['father_name'];
       $data[] = $_POST['father_occupation'];
       $data[] = $_POST['mother_name'];
       $data[] = $_POST['mother_occupation']; 
       $data[] = $_POST['year'].'-'.$_POST['month'].'-'.$_POST['date'];
       $data[] = $_POST['day'];
       $data[] = $_POST['birthhour'].':'.$_POST['birthmins'].' '.$_POST['birthmeridium'];
       $data[] = $_POST['place_of_birth'];
       $data[] = $_POST['order_of_place'];    
       $data[] = $_POST['house_name'];
       $data[] = $_POST['gothram'];
       $data[] = $_POST['native'];
       $data[] = $_POST['native_district'];
       $data[] = $_POST['family_status'];
       $data[] = $_POST['family_type'];
       $data[] = $_POST['family_value'];
       $data[] = $_POST['bcount'];
       $data[] = $_POST['bmcount'];
       $data[] = $_POST['scount'];
       $data[] = $_POST['smcount'];
        if($_POST['height_ft']){
        $data[] = $_POST['height_ft'];  
        } else {
        $data[] = $_POST['height_cms']; 
        }     
       $data[] = $_POST['weight'];
       $data[] = $_POST['star'];
       $data[] = $_POST['rasi'];
       $data[] = $_POST['lagnam'];
       $data[] = $_POST['thisai_irrupu']; 
       $data[] = $_POST['dosham'];
       if($_POST['dosham'] == 'yes'){
       $data[] = $_POST['dosham_details'];  
       } else {
       $data[] = "";
       }
       $data[] = date_format(new DateTime($_POST['registered_date']), 'Y-m-d');
       $data[] = $_POST['registeredBy'];
       $data[] = 'pending';
       $data[] = date('Y-m-d');
       $date[] = date('h-i');
     
       
       $gtregistration = new Registration();
       $gtregistration = $gtregistration->fetch("WHERE km_regcode = '{$km_regcode}' ORDER BY id DESC")->resultSet();
       $regis = $gtregistration[0];
   
      if($regis){ 
       $_SESSION['register_exists'] = true;
       header("Location: registration.php");
      } else {
       
       $registration = new Registration();
       $registration = $registration->add($data);
       $registration_id = $registration->lastInsertID();
   
       $sms_phone = $_POST['mobile'];
       
       $email_send = $_POST['email'];
       
       $profile_name = $_POST['member_name'];
   
        $msgsend = "Your Profile is successfully registered in Kanyadhaanam Matrimony, Wish u all success in future! Thank you, if u have any questions please contact us 95000 90825";
                 $url="http://alerts.maxwellsms.com/api/v3/index.php";
                 $parameters = "method=sms&api_key=Afebb28266bdbd1300d76c268f10f65b8&to=$sms_phone&sender=KDMMAT&message=$msgsend&format=xml&flash=0";
   
                 $ch = curl_init($url);
                 curl_setopt($ch, CURLOPT_POST, 1);
                 curl_setopt($ch, CURLOPT_POSTFIELDS, $parameters);
                 curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                 curl_setopt($ch, CURLOPT_HEADER, 0);
                 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                 $response = curl_exec($ch);
                 
                 
       if($email_send){
           
       $msg= "<table>
      
      <p>Dear {$profile_name},</p>
      
      <tr><td align='left' style='font-size: 18px;line-height: 1.5em;'>Thank You very much for your interest with Kanyadhaanam Matrimony</td></tr>
   
      <tr><td align='left' style='font-size: 18px;line-height: 1.5em;'>Your Profile is successfully registered in Kanyadhaanam Matrimony, Wish u all success in future! Thank you, if u have any questions please contact us 95000 90825</td></tr>
   
      <tr style='font-size: 18px;line-height: 1.5em;'><td>Regards</tr></td>
      <tr style='font-size: 18px;line-height: 1.5em;'><td>Kanyadhaanam Matrimony - TEAM</tr></td>
      </table><br>";
      
      $to = $email_send;
      $subject = "Registration successful from Kanyadhaanam Matrimony";
   
      // Always set content-type when sending HTML email
       $headers = "MIME-Version: 1.0" . "\r\n";
       $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
       
       // More headers
       $headers .= 'From: <support@kanyadhaanam.com>' . "\r\n";
       
       $send_mail = mail($to,$subject,$msg,$headers);
           
       }
       
       $users = new Registration();
       $users = $users->fetch("WHERE id = '{$registration_id}'")->resultSet();
       $users = $users[0];
       $_SESSION['userinfo'] = 'REG NO : '.$users['km_regcode'];
       $_SESSION['userpass'] = 'PASSWORD : '.$users['km_password'];
     
   
       if($registration_id){   
           $_SESSION['registrationAdded'] = true;
           $_SESSION['registrationAdded_user'] = true;
           $_SESSION['registrationAdded_pass'] = true;
       } else {
           $_SESSION['registrationAdded'] = false;
       }
       header("Location: registration.php");
      }
   }
   
   
     //// Occupation /////
       $occupations = new Registration();
       $occupations = $occupations->fetchOccupation("ORDER BY occupation ASC")->resultSet();
   
       //// Districts /////
       $districts = new Registration();
       $districts = $districts->fetchDistricts("ORDER BY name ASC")->resultSet();
   
       $districtsEncoded = json_encode($districts);
   
       //// States /////
       $states = new Registration();
       $states = $states->fetchStates("ORDER BY name ASC")->resultSet();
   
       $statesEncoded = json_encode($states);   
   
   
   ?>
<!DOCTYPE html>
<html>
   <style>
      th {
      text-align: left;
      color: #000;
      font-weight: normal;
      font-size: 16px;
      }
      input[type=text], input[type=password], select {
      width: 95% !important;
      }
      span.select{
      width: 100% !important; 
      border:none !important;
      }
      .radio-inline input[type=radio] {
      margin-top: 3px !important;
      }
   </style>
   <link rel="stylesheet" href="../css/jquery-ui.css">
   <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
   <link rel="stylesheet" href="../css/bootstrap-datetimepicker.min.css" />
   <script src="../js/jquery-1.12.4.js"></script>
   <script src="../js/jquery-ui.js"></script>
   <script src="../js/bootstrap.min.js"></script>
   <script src="../js/moment.js"></script>
   <script src="../js/bootstrap-datetimepicker.js"></script>
   <script type="text/javascript">
      function regform(form)
      
      {
      
      var numbers = /^[0-9]+$/; 
      
      var passw = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{6,20}$/;
      
      var re = /^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$/;
      
      
      
      if(form.member_name.value=="") { alert("Please enter name"); form.member_name.focus(); return false; }
      
      if(form.password.value=="") { alert("Please enter password"); form.password.focus(); return false; }
      
      
      if(form.education.value=="") { alert("Please select education"); form.education.focus(); return false; }
      
      if(form.employedIn.value=="notworking") {
                                               
        } else {
      
      if(form.occupation.value=="") { alert("Please select occupation"); form.occupation.focus(); return false; }
      

      
      if(form.company_name.value=="") { alert("Please enter occupation details"); form.company_name.focus(); return false; }
      
      if(form.annualIncome.value=="") { alert("Please enter annual income"); form.annualIncome.focus(); return false; }
      
      }
      
      if(form.bloodgroup.value=="") { alert("Please select blood group"); form.bloodgroup.focus(); return false; }
      
      if(form.doorNo.value=="") { alert("Please enter door no"); form.doorNo.focus(); return false; }
      
      if(form.street.value=="") { alert("Please enter street"); form.street.focus(); return false; }
      
      if(form.city.value=="") { alert("Please enter city"); form.city.focus(); return false; }
      
      if(form.pincode.value=="") { alert("Please enter pincode"); form.pincode.focus(); return false; }
      
       if(form.pincode.value!="")
      {
      if(!form.pincode.value.match(numbers))  
      {  
      
      alert('Please enter pincode with only numbers');  
      form.pincode.focus(); return false;
      }
      if (form.pincode.value.length != 6)
      { 
      alert('Please enter your 6 digits pincode exactly');  
      form.pincode.focus(); return false; 
      } 
      }
      
      if(form.state.value=="") { alert("Please select state"); form.state.focus(); return false; }
      
      if(form.district.value=="") { alert("Please enter district"); form.district.focus(); return false; }
      
      //  if(form.email.value=="") { alert("Please enter your Email ID"); form.email.focus(); return false; }
      
      if(form.email.value!="")
      {
      if(!form.email.value.match(re))  
      {  
      
      alert('Please enter valid Email ID');  
      form.email.focus(); return false;
      }  
      }
      
      if(form.mobile.value=="") { alert("Please enter mobile number"); form.mobile.focus(); return false; }
      if(form.mobile.value!="")
      {
      if(!form.mobile.value.match(numbers))  
      {  
      
      alert('Please enter mobile number with only numbers');  
      form.mobile.focus(); return false;
      } 
      if (form.mobile.value.length != 10)
      { 
      alert('Please enter your 10 digits mobile number exactly');  
      form.mobile.focus(); return false; 
      } 
      
      }
      
      if(form.second_mobile.value=="") { alert("Please enter your secondary mobile number"); form.second_mobile.focus(); return false; }
      if(form.second_mobile.value!="")
      {
      if(!form.second_mobile.value.match(numbers))  
      {  
      
      alert('Please enter secondary mobile number with only numbers');  
      form.second_mobile.focus(); return false;
      } 
      if (form.second_mobile.value.length != 10)
      { 
      alert('Please enter your 10 digits secondary mobile number exactly');  
      form.second_mobile.focus(); return false; 
      } 
      
      }
      
      if(form.landline_code.value!="") {
                                           
       if(form.landline_code.value.length < 3 || form.landline_code.value.length > 5) {
         alert("Please enter landline code 3 to 5 digits only"); form.landline_code.focus(); return false;
       }
       
      }
      
      
       if(form.landline.value!="")
       {
       if(!form.landline.value.match(numbers))  
       {  
       
       alert('Please enter landline number with only numbers');  
       form.landline.focus(); return false;
       }
       if (form.landline.value.length != 8)
       { 
       alert('Please enter your 8 digits landline number exactly');  
       form.landline.focus(); return false; 
       } 
       }
      
      if(form.languagesKnown.value=="") { alert("Please enter language"); form.languagesKnown.focus(); return false; }
      
      if(form.father_name.value=="") { alert("Please enter father's name"); form.father_name.focus(); return false; }
      
      
      if(form.father_occupation.value=="") { alert("Please enter father's occupation"); form.father_occupation.focus(); return false; }
      
      if(form.mother_name.value=="") { alert("Please enter mother's name"); form.mother_name.focus(); return false; }
      
      
      if(form.mother_occupation.value=="") { alert("Please enter mother's occupation"); form.mother_occupation.focus(); return false; }
      
      if(form.date.value=="" && form.month.value=="" && form.year.value=="") { alert("Please select date of birth"); form.date.focus(); return false; }
      
      if(form.date.value=="") { alert("Please select date"); form.lagnam.focus(); return false; }
      
      if(form.month.value=="") { alert("Please select month"); form.month.focus(); return false; }
      
      if(form.year.value=="") { alert("Please select year"); form.year.focus(); return false; }
      
      if(form.day.value=="") { alert("Please select day of birth"); form.day.focus(); return false; }
      
      if(form.birthhour.value=="" && form.birthmins.value=="" && form.birthmeridium.value=="") { alert("Please select time of birth"); form.birthhour.focus(); return false; }
                                           
         if(form.birthhour.value=="" ) { alert("Please select hour"); form.birthhour.focus(); return false; }
      
      if(form.birthmins.value=="" ) { alert("Please select mins"); form.birthmins.focus(); return false; }
      
      if(form.birthmeridium.value=="" ) { alert("Please select meridiem"); form.birthmeridium.focus(); return false; }
      
      if(form.place_of_birth.value=="") { alert("Please enter place of birth"); form.place_of_birth.focus(); return false; }
      
      if(form.order_of_place.value=="") { alert("Please select order of birth"); form.order_of_place.focus(); return false; }
      
       
      if(form.house_name.value=="") { alert("Please enter house name"); form.house_name.focus(); return false; }
      
      if(form.gothram.value=="") { alert("Please enter gothram"); form.gothram.focus(); return false; }
      
      
      if(form.native.value=="") { alert("Please enter native place"); form.native.focus(); return false; }
      
      if(form.native_district.value=="") { alert("Please enter native district"); form.native_district.focus(); return false; }
      
      if(form.height_ft.value=="" && form.height_cms.value=="") { alert("Please select height"); form.height_ft.focus(); return false; }
      
      if(form.family_status[0].checked=="" && form.family_status[1].checked=="" && form.family_status[2].checked=="" && form.family_status[3].checked=="") { alert("Please select famil status"); form.family_status[0].focus(); return false; }
      
      if(form.family_type[0].checked=="" && form.family_type[1].checked=="") { alert("Please select famil type"); form.family_type[0].focus(); return false; }
      
      if(form.family_value[0].checked=="" && form.family_value[1].checked=="" && form.family_value[2].checked=="" && form.family_value[3].checked=="") { alert("Please select famil value"); form.family_value[0].focus(); return false; }
      
      
      if(form.weight.value=="") { alert("Please select weight"); form.weight.focus(); return false; }
      
      
      if(form.star.value=="") { alert("Please select star"); form.star.focus(); return false; }
      
      if(form.rasi.value=="") { alert("Please select rasi"); form.rasi.focus(); return false; }
      
      if(form.lagnam.value=="") { alert("Please select lagnam"); form.lagnam.focus(); return false; }
      
      if(form.thisai_irrupu.value=="") { alert("Please enter thisai irrupu"); form.thisai_irrupu.focus(); return false; }
      
      if(form.dosham.value=="yes") {
      
      if(form.dosham_details.value=="") { alert("Please enter dosham details"); form.dosham_details.focus(); return false; }
      
      }
      
      if(form.registeredBy.value=="") { alert("Please select registered by"); form.registeredBy.focus(); return false; }
      
      
      
      }
      
   </script>
   <?php include("includes/headertop.php");?>
   <body class="home color-green boxed shadow">
      <div class="root">
         <?php include("includes/header.php");?>
         <section class="content reverse" style=" width: 90%;">
            <section>
               <div  id="message_container" style="text-align: center; display: none; color: red;font-size: 18px; font-weight: bold;margin-bottom: 10px;margin-top: 10px;">
                  <span id="message"></span>
               </div>
               <div  id="message_container_user" style="text-align: center; display: none; color: red;font-size: 18px; font-weight: bold;margin-bottom: 10px;">
                  <span id="message_user"></span>
               </div>
               <div  id="message_container_pass" style="text-align: center; display: none; color: red;font-size: 18px; font-weight: bold">
                  <span id="message_pass"></span>
               </div>
               <section class="columns" style="margin-top:10px !important;  width: 90%; ">
                  <h2><span>New Registration</span></h2>
                  <form method="post" enctype="multipart/form-data" name="RegisterForm" onsubmit="return regform(RegisterForm);" autocomplete="off">
                     <div style=" border: solid  1px #ccc; border-radius: 5px; padding: 20px;">
                        <table width="50%"  border="0">
                           <tbody>
                              <span style=" font-size: 20px; color: #0e4805; font-weight: bold;"> Personal Details</span>
                              <tr>
                                 <th>Name :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" id="member_name" name="member_name" placeholder="Name" class="text" autocomplete="off" >
                                 </td>
                              </tr>
                              <tr>
                                 <th>Password :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="password" id="password" name="password" placeholder="Password" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th width="30%">Gender :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <label class="radio-inline" style="position: relative;bottom: 15px">
                                    <input name="gender" id="gender" type="radio" value="Female"  checked="">
                                    </label> Female
                                    <label class="radio-inline" style="position: relative;bottom: 12px">
                                    <input name="gender" id="gender" type="radio" value="Male" >
                                    </label> Male
                                 </td>
                              </tr>
                                <tr>
                                 <th>Caste :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                   
                                        <select style="opacity: 1;"  name="caste" id="castes">
                                                <option value="" Selected Disabled>-- Select Caste --</option>
                                                <?php foreach($castes as $caste){ ?>
                                                <option value="<?php echo $caste['id']; ?>"><?php echo $caste['caste']; ?></option>
                                                <?php } ?>
                                             </select>
                                 </td>
                              </tr>
                                <tr>
                                 <th> Sub Caste :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                   
                                               <select  style="opacity: 1;"   name="subcaste" id="subcastes">
                                                <option value="" Selected Disabled>-- Select Subcaste --</option>
                                             </select>
                                 </td>
                              </tr>
                              <tr>
                                 <th>Education :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <select name="education"   style="opacity: 1;">
                                       <option value="" selected disabled>-- Select Education --</option>
                                       <?php foreach($edu_array as $key => $value){ ?>
                                       <option value="<?php echo $key;?>"><?php echo $value;?></option>
                                       <?php } ?>
                                    </select>
                                 </td>
                              </tr>
                              <tr>
                                 <th>Education Details (Optional) :  </th>
                                 <td>
                                    <textarea rows="4" style="min-height: inherit;" id="education_details" name="education_details" placeholder="Education Details" class="text" autocomplete="off"></textarea>
                                 </td>
                              </tr>
                              <tr>
                                 <th width="30%">Employed in :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <label class="radio-inline" style="position: relative;bottom: 15px">
                                    <input name="employedIn" id="employedIn" type="radio" value="government"  checked="">
                                    </label> Government
                                    <label class="radio-inline" style="position: relative;bottom: 12px">
                                    <input name="employedIn" id="employedIn" type="radio" value="private" >
                                    </label> Private
                                    <label class="radio-inline" style="position: relative;bottom: 11px">
                                    <input name="employedIn" id="employedIn" type="radio" value="business" >
                                    </label> Business
                                    <label class="radio-inline" style="position: relative;bottom: 11px">
                                    <input name="employedIn" id="employedIn" type="radio" value="notworking" >
                                    </label> Not Working
                                 </td>
                              </tr>
                              <tr id="job1">
                                 <th>Occupation :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <select name="occupation"   style="opacity: 1;">
                                       <option value="" selected disabled>-- Select Occupation --</option>
                                       <?php foreach($occupations as $occupation){ ?>
                                       <option value="<?php echo $occupation['id'];?>"><?php echo $occupation['occupation'];?></option>
                                       <?php } ?>
                                    </select>
                                 </td>
                              </tr>
                              <tr id="job2">
                                 <th>Occupation Details  :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <textarea rows="4" style="min-height: inherit;" id="company_name" name="company_name" placeholder="Occupation Details" class="text" autocomplete="off"></textarea>
                                 </td>
                              </tr>
                              <tr id="job3">
                                 <th>Annual Income  :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" id="annualIncome" name="annualIncome" placeholder="Annual Income" class="text" onkeypress="return onlyNos(event,this);" Maxlength="10" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Blood Group :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <select name="bloodgroup"   style="opacity: 1;">
                                       <option value="" selected disabled>-- Select Blood Group --</option>
                                       <?php foreach($blood_array as $key => $value){ ?>
                                       <option value="<?php echo $key;?>"><?php echo $value;?></option>
                                       <?php } ?>
                                       <option value="donotknow">- Don't Know -</option>
                                    </select>
                                    </span>
                                 </td>
                              </tr>
                              <tr>
                                 <th>Door NO  :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" id="doorNo" name="doorNo" placeholder="Door NO" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Street Name :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" id="street" name="street" placeholder="Street Name" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>City :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" id="city" name="city" placeholder="City" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Pincode :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" id="pincode" name="pincode" placeholder="Pincode" class="text" onkeypress="return onlyNos(event,this);" autocomplete="off"  Maxlength="6">
                                 </td>
                              </tr>
                              <tr>
                                 <th>State :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <select name="state" id="states" style="opacity: 1;">
                                       <option value="" selected disabled>-- Select State --</option>
                                       <?php foreach($states as $state){ ?>
                                       <option value="<?php echo $state['id'];?>"><?php echo $state['name'];?></option>
                                       <?php } ?>
                                    </select>
                                 </td>
                              </tr>
                              <tr >
                                 <th>District :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <select name="district" id="districts" style="opacity: 1;">
                                       <option value="" selected disabled>-- Select District --</option>
                                       <?php foreach($districts as $district){ ?>
                                       <option value="<?php echo $district['id'];?>"><?php echo $district['name'];?></option>
                                       <?php } ?>
                                    </select>
                                 </td>
                              </tr>
                              <tr>
                                 <th>Email :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" name="email" id="email" class="text" placeholder="Email"  autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Mobile No :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" name="mobile" id="mobile" class="text" placeholder="Mobile No."  onkeypress="return onlyNos(event,this);" Maxlength="10" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Secondary Mobile No :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" name="second_mobile" id="second_mobile" class="text"Languages Known placeholder="Mobile No."  onkeypress="return onlyNos(event,this);" Maxlength="10" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Landline No :</th>
                                 <td>
                                    <input type="text" id="landline_code" name="landline_code" class="text" placeholder="Code."  onkeypress="return onlyNos(event,this);" autocomplete="off"  Maxlength="5" style="float:left;width: 20%!important;">
                                    <input type="text" id="landline" name="landline" class="text" placeholder="Landline No."  onkeypress="return onlyNos(event,this);" autocomplete="off"  Maxlength="8" style="width:75%!important;">
                                 </td>
                              </tr>
                              <tr>
                                 <th width="30%">Marital Status :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <label class="radio-inline" style="position: relative;bottom: 15px">
                                    <input name="marital_status" id="marital_status" type="radio" value="unMarried"  checked="">
                                    </label> Unmarried
                                    <label class="radio-inline" style="position: relative;bottom: 12px">
                                    <input name="marital_status" id="marital_status" type="radio" value="widower" >
                                    </label> Widower
                                    <label class="radio-inline" style="position: relative;bottom: 11px">
                                    <input name="marital_status" id="marital_status" type="radio" value="divorced" >
                                    </label> Divorced
                                    <label class="radio-inline" style="position: relative;bottom: 11px">
                                    <input name="marital_status" id="marital_status" type="radio" value="awaiting" >
                                    </label> Awaiting Divorce
                                 </td>
                              </tr>
                              <tr>
                                 <th>Languages Known :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" id="languagesKnown" name="languagesKnown" placeholder="Languages Known" class="text" autocomplete="off" >
                                    <br>
                                    <span>For Example (Tamil, English, .. etc)</span>
                                 </td>
                              </tr>
                              <tr>
                                 <th width="30%">Physical status :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <label class="radio-inline" style="position: relative;bottom: 15px">
                                    <input name="physical_status" id="physical_status" type="radio" value="normal"  checked="">
                                    </label> Normal 
                                    <label class="radio-inline" style="position: relative;bottom: 12px">
                                    <input name="physical_status" id="physical_status" type="radio" value="challenged" >
                                    </label> Physically challenged
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </div>
                     <br>
                     <div style=" border: solid  1px #ccc; border-radius: 5px; padding: 20px;">
                        <table>
                           <tbody>
                              <span style=" font-size: 20px; color: #0e4805; font-weight: bold;"> Family Status</span>
                              <tr>
                                 <th>Father's Name :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" id="father_name" name="father_name" placeholder="Father's Name" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Father's Occupation :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" id="father_occupation" name="father_occupation" placeholder="Father's Occupation" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Mother's Name :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" id="mother_name" name="mother_name" placeholder="Mother's Name" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Mother's Occupation :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" id="mother_occupation" name="mother_occupation" placeholder="Mother's Occupation" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>D.O.B :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <table width="100%">
                                       <tbody>
                                          <tr>
                                             <td style=" margin: 0px; padding: 0px;">
                                                <select name="date"  style="opacity: 1;">
                                                   <option value="" selected disabled>- Date -</option>
                                                   <?php foreach($date_array as $date){?>
                                                   <option value="<?php echo $date; ?>"><?php echo $date; ?></option>
                                                   <?php } ?>
                                                </select>
                                                </span>
                                             </td>
                                             <td>
                                                <select name="month"  style="opacity: 1;">
                                                   <option value="" selected disabled>- Month -</option>
                                                   <?php foreach($month_array as $key => $month){?>
                                                   <option value="<?php echo $key; ?>"><?php echo $month; ?></option>
                                                   <?php } ?>
                                                </select>
                                                </span>
                                             </td>
                                             <td>
                                                <select name="year"  style="opacity: 1;">
                                                   <option value="" selected disabled>- Year -</option>
                                                   <?php for($year = date('Y')-18;$year >= date('Y')-50;$year--){?>
                                                   <option value="<?php echo $year; ?>"><?php echo $year; ?></option>
                                                   <?php } ?>
                                                </select>
                                                </span>
                                             </td>
                                             <td>
                                                <select name="day"  style="opacity: 1;">
                                                   <option value="" selected disabled>- Day -</option>
                                                   <?php foreach($day_array as $day){?>
                                                   <option value="<?php echo $day; ?>"><?php echo $day; ?></option>
                                                   <?php } ?>
                                                   <option value="donotknow">- Don't Know -</option>
                                                </select>
                                                </span>
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>
                              <tr>
                                 <th>Time of Birth :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <table width="70%">
                                       <tbody>
                                          <tr>
                                             <td style=" margin: 0px; padding: 0px;">
                                                <select name="birthhour" class="form-control" style="opacity: 1;">
                                                   <option value="" Selected Disabled>Hours</option>
                                                   <?php for($hours = 1; $hours <= 12; $hours++ ){ ?>
                                                   <option value="<?php echo $hours; ?>"><?php echo $hours; ?></option>
                                                   <?php } ?>
                                                </select>
                                             </td>
                                             <td>
                                                <select name="birthmins" class="form-control" style="opacity: 1;">
                                                   <option value="" Selected Disabled>Mins</option>
                                                   <?php for($mins = 0; $mins <= 59; $mins++ ){ ?>
                                                   <option  value="<?php echo $mins; ?>"><?php echo $mins; ?></option>
                                                   <?php } ?>
                                                </select>
                                             </td>
                                             <td>
                                                <select name="birthmeridium" class="form-control" style="opacity: 1;">
                                                   <option value="" Selected Disabled>Meridium</option>
                                                   <option value="AM">AM</option>
                                                   <option value="PM">PM</option>
                                                </select>
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>
                              <tr>
                                 <th>Place of Birth :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" id="place_of_birth" name="place_of_birth" placeholder="Place of Birth" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Order of Birth  :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <select class="form-control" id="order_of_place" name="order_of_place" >
                                       <option value="" Selected Disabled> --- Select --- </option>
                                       <?php for($oob = 1; $oob <= 10; $oob++ ){ ?>
                                       <option value="<?php echo $oob; ?>"><?php echo $oob; ?></option>
                                       <?php } ?>
                                    </select>
                                 </td>
                              </tr>
                              <tr>
                                 <th>House Name :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" id="house_name" name="house_name" placeholder="House Name" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Gothram :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" id="gothram" name="gothram" placeholder="Gothram" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Native Place :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" id="native" name="native" placeholder="Native Place" class="text"   autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Native District :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" id="native_district" placeholder="Native District" name="native_district" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th width="30%">Family Status :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <label class="radio-inline" style="position: relative;bottom: 0px; display: inline;">
                                    <input name="family_status" id="family_status" type="radio" value="middle"  >
                                    </label> Middle class
                                    <label class="radio-inline" style="position: relative;bottom: 0px; display: inline; left: 5px;">
                                    <input name="family_status" id="family_status" type="radio" value="uppermiddle">
                                    </label> Upper middle class
                                    <label class="radio-inline" style="position: relative;bottom: 0px; display: inline; left: 5px;">
                                    <input name="family_status" id="family_status" type="radio" value="rich">
                                    </label> Rich
                                    <label class="radio-inline" style="position: relative;bottom: 0px; display: inline; left: 5px;">
                                    <input name="family_status" id="family_status" type="radio" value="affluent">
                                    </label> Affluent
                                 </td>
                              </tr>
                              <tr>
                                 <th width="30%">Family Type :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <label class="radio-inline" style="position: relative;bottom: 0px; display: inline;">
                                    <input name="family_type" id="family_type" type="radio" value="joint"  >
                                    </label> Joint
                                    <label class="radio-inline" style="position: relative;bottom: 0px; display: inline; left: 5px;">
                                    <input name="family_type" id="family_type" type="radio" value="nuclear">
                                    </label> Nuclear
                                 </td>
                              </tr>
                              <tr>
                                 <th width="30%">Family Values :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <label class="radio-inline" style="position: relative;bottom: 0px; display: inline;">
                                    <input name="family_value" id="family_value" type="radio" value="orthodox"  >
                                    </label> Orthodox
                                    <label class="radio-inline" style="position: relative;bottom: 0px; display: inline; left: 5px;">
                                    <input name="family_value" id="family_value" type="radio" value="traditional">
                                    </label> Traditional
                                    <label class="radio-inline" style="position: relative;bottom: 0px; display: inline; left: 5px;">
                                    <input name="family_value" id="family_value" type="radio" value="moderate">
                                    </label> Moderate
                                    <label class="radio-inline" style="position: relative;bottom: 0px; display: inline; left: 5px;">
                                    <input name="family_value" id="family_value" type="radio" value="liberal">
                                    </label> Liberal
                                 </td>
                              </tr>
                              <tr>
                                 <th>No. of Brother(s) Unmarried :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <table width="70%">
                                       <tbody>
                                          <tr>
                                             <td style=" margin: 0px; padding: 0px;">
                                                <select id="bthrs" name="bcount" class="form-control" style="opacity: 1;">
                                                   <?php for($bro = 0; $bro <= 10; $bro++ ){ ?>
                                                   <option  value="<?php echo $bro; ?>" style="color: rgb(0, 79, 0);"><?php echo $bro; ?></option>
                                                   <?php } ?>
                                                </select>
                                             </td>
                                             <td style="text-align: right;font-size: 16px;">No. of Brother(s) Married :  <span style="color:#c03131;font-size: 20px;"> * </span> &nbsp; &nbsp; &nbsp;</td>
                                             <td>
                                                <select id="bthrsm" name="bmcount" class="form-control" style="opacity: 1;">
                                                   <?php for($mbro = 0; $mbro <= 10; $mbro++ ){ ?>
                                                   <option value="<?php echo $mbro; ?>" style="color: rgb(0, 79, 0);"><?php echo $mbro; ?></option>
                                                   <?php } ?>
                                                </select>
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>
                              <tr>
                                 <th>No. of Sister(s) Unmarried :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <table width="70%">
                                       <tbody>
                                          <tr>
                                             <td style=" margin: 0px; padding: 0px;">
                                                <select id="sisters" name="scount" class="form-control" style="opacity: 1;">
                                                   <?php for($sis = 0; $sis <= 10; $sis++ ){ ?>
                                                   <option <?php if($edit_profile['scount'] == $sis){ echo 'selected'; } ?> value="<?php echo $sis; ?>" style="color: rgb(0, 79, 0);"><?php echo $sis; ?></option>
                                                   <?php } ?>
                                                </select>
                                             </td>
                                             <td style="text-align: right;font-size: 16px;">No. of Sister(s) Married :  <span style="color:#c03131;font-size: 20px;"> * </span> &nbsp; &nbsp; &nbsp;</td>
                                             <td>
                                                <select id="sisterscount" name="smcount" class="form-control" style="opacity: 1;">
                                                   <?php for($msis = 0; $msis <= 10; $msis++ ){ ?>
                                                   <option <?php if($edit_profile['smcount'] == $msis){ echo 'selected'; } ?> value="<?php echo $msis; ?>" style="color: rgb(0, 79, 0);"><?php echo $msis; ?></option>
                                                   <?php } ?>
                                                </select>
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>
                              <tr>
                                 <th>Height :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <table width="100%">
                                       <tbody>
                                          <tr>
                                             <td style=" margin: 0px; padding: 0px;">
                                                <select name="height_ft" id="height_ft"  style="opacity: 1;">
                                                   <option value="" selected disabled>- Feet & Inches -</option>
                                                   <?php foreach($height_array as $height => $height_str){?>
                                                   <option value="<?php echo $height_str; ?>"><?php echo $height_str; ?></option>
                                                   <?php } ?>
                                                </select>
                                             </td>
                                             <td>(Or)</td>
                                             <td>
                                                <select name="height_cms" id="height_cms"  style="opacity: 1;">
                                                   <option value="" selected disabled>- Cms -</option>
                                                   <?php for($height = 135;$height <= 210;$height++){?>
                                                   <option value="<?php echo $height.' Cms'; ?>"><?php echo $height.' Cms'; ?></option>
                                                   <?php } ?>
                                                </select>
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>
                              <tr>
                                 <th>Weight :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <span class="select">
                                       <select name="weight"  style="opacity: 1;">
                                          <option value="" selected disabled>- Weight -</option>
                                          <?php for($weight = 40;$weight <= 150;$weight++){?>
                                          <option value="<?php echo $weight.' Kgs'; ?>"><?php echo $weight.' Kgs'; ?></option>
                                          <?php } ?>
                                       </select>
                                    </span>
                                 </td>
                              </tr>
                              <tr>
                                 <th>Star :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <span class="select">
                                       <select name="star"  style="opacity: 1;">
                                          <option value="" selected disabled>- Star -</option>
                                          <?php foreach($stars_array as $star){?>
                                          <option value="<?php echo $star; ?>"><?php echo $star; ?></option>
                                          <?php } ?>
                                       </select>
                                    </span>
                                 </td>
                              </tr>
                              <tr>
                                 <th>Raasi :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <span class="select">
                                       <select name="rasi"  style="opacity: 1;">
                                          <option value="" selected disabled>- Raasi -</option>
                                          <?php foreach($rasi_array as $rasi){?>
                                          <option value="<?php echo $rasi; ?>"><?php echo $rasi; ?></option>
                                          <?php } ?>
                                       </select>
                                    </span>
                                 </td>
                              </tr>
                              <tr>
                                 <th>Lagnam :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <span class="select">
                                       <select name="lagnam"  style="opacity: 1;">
                                          <option value="" selected disabled>- Lagnam -</option>
                                          <?php foreach($rasi_array as $lagnam){?>
                                          <option value="<?php echo $lagnam; ?>"><?php echo $lagnam; ?></option>
                                          <?php } ?>
                                          <option value="donotknow">- Don't Know -</option>
                                       </select>
                                    </span>
                                 </td>
                              </tr>
                              <tr>
                                 <th>Thisai Irrupu :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" id="thisai_irrupu" name="thisai_irrupu" placeholder ='Thisai Irrupu' class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th width="30%">Dosham  :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <label class="radio-inline" style="position: relative;bottom: 15px">
                                    <input name="dosham" id="dosham" type="radio" value="yes">
                                    </label> Yes
                                    <label class="radio-inline" style="position: relative;bottom: 12px">
                                    <input name="dosham" id="dosham" type="radio" value="no" checked="">
                                    </label> No
                                    <label class="radio-inline" style="position: relative;bottom: 11px">
                                    <input name="dosham" id="dosham" type="radio" value="dontknow">
                                    </label> Don't Know
                                 </td>
                              </tr>
                              <tr id="detail_dosham" style="display:none;">
                                 <th>Dosham Details  :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" id="dosham_details" name="dosham_details" placeholder="Dosham Details" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Registered Date :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <!--<input type="text" name="registered_date"  class="text"  id="registered_date">-->
                                    <input class="form-control text" type="text" name="registered_date" id="registered_date" data-field="datetime" data-date-format="DD-MM-YYYY"  value="<?php echo date('d-m-Y');?>" readonly autocomplete="off" style="width: 145px;" >
                                 </td>
                              </tr>
                              <tr>
                                 <th>Registered By :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <span class="select">
                                       <select name="registeredBy" style="opacity: 1;">
                                          <option value="" selected disabled>- Registered By -</option>
                                          <?php foreach($registeredBy_array as $registeredBy){?>
                                          <option value="<?php echo $registeredBy; ?>"><?php echo $registeredBy; ?></option>
                                          <?php } ?>
                                       </select>
                                    </span>
                                 </td>
                              </tr>
                              <tr>
                                 <th></th>
                                 <td>
                                    <input type="submit" name="btn_register" value="Register" style="background:#ea0609;color:#ffffff;margin-top:10px;" onclick="return validateUserInfo();">
                                 </td>
                              </tr>
                     </div>
                     </tbody>
                     </table>
                  </form>
               </section>
            </section>
         </section>
         <div style=" clear: both;"></div>
         <?php include("includes/footer.php");?>
         <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
         <script language="Javascript" type="text/javascript">
            function onlyNos(e, t) {
                try {
                    if (window.event) {
                        var charCode = window.event.keyCode;
                    }
                    else if (e) {
                        var charCode = e.which;
                    }
                    else { return true; }
                    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                        return false;
                    }
                    return true;
                }
                catch (err) {
                    alert(err.Description);
                }
            }
            
         </script>
          <script>
    $(document).ready(function() {
      var Stats = JSON.parse('<?php echo $castesEncoded; ?>');
      var Dist = JSON.parse('<?php echo $subcastesEncoded; ?>');

      $('#castes').change(function() {
        var categoryId12 = $(this).val();

        $('#subcastes').empty();
        $('#subcastes').append('<option value="" selected disabled>-- Select --</option>');

        $.each(Dist, function(index, element){
          if(element.caste == categoryId12) {
            
            $('#subcastes').append('<option value="' + element.id + '">' + element.subcaste + '</option>');
          }
        });
      });
    });

</script>
         <script type="text/javascript">
            $(document).ready(function() {
            $('input[name="dosham"]').click(function() 
             {
              var value = $(this).val();
              if( value == "yes")
              {
              $("#detail_dosham").show();
              }
              else{
              $("#detail_dosham").hide();
              }
            });
            });
         </script>
         <script type="text/javascript">
            $(document).on('click', '#employedIn', function() {
                     var Gend = $(this).val();
                      if(Gend == 'notworking'){
                          $('#job1').hide();
                        $('#job2').hide();
                        $('#job3').hide();
                      } else {
                        $('#job1').show();
                        $('#job2').show();
                        $('#job3').show();
                      }
                  });
              
         </script>
         <script>
            $(document).ready(function() {
              var Stats = JSON.parse('<?php echo $statesEncoded; ?>');
              var Dist = JSON.parse('<?php echo $districtsEncoded; ?>');
            
              $('#states').change(function() {
                var categoryId = $(this).val();
            
                $('#districts').empty();
                $('#districts').append('<option value="" selected disabled>-- Select District--</option>');
            
                $.each(Dist, function(index, element) {
                  if(element.state_id == categoryId) {
                    $('#districts').append('<option value="' + element.id + '">' + element.name + '</option>');
                  }
                });
              });
            });
            
         </script>
         <script type="text/javascript">
            $(document ).on('keyup','#email', function () {
             var Email_ID = $('#email').val();
             //alert(Email_ID);
             if(Email_ID){
             $.ajax({
             type:'post',
             url:'register_validation.php',
             data:{
                 flag:'EMail',
                 gmail : Email_ID,
             },
             success:function(response) {
             var response = response.split("-");
             if(response[0] == 'exists'){
               alert('Email ID already registered..enter another email id');
               document.getElementById("email").value = '';
               document.getElementById("email").focus();
             }
             }
             }); 
             }
             });
            
            $(document ).on('keyup','#mobile', function () {
             var Mobile_No = $('#mobile').val();
             //alert(Mobile_No);
             if(Mobile_No){
             $.ajax({
             type:'post',
             url:'register_validation.php',
             data:{
                 flag:'MobileNo',
                 phone : Mobile_No,
             },
             success:function(response) {
             var response = response.split("-");
             if(response[0] == 'exists'){
               alert('Mobile No already registered..enter another mobile no');
               document.getElementById("mobile").value = '';
               document.getElementById("mobile").focus();
             }
             }
             }); 
             }
             });
            
            $(document ).on('keyup','#second_mobile', function () {
            var sec_Mobile_No = $('#second_mobile').val();
            if(sec_Mobile_No){
            $.ajax({
            type:'post',
            url:'register_validation.php',
            data:{
             flag:'Sec_MobileNo',
             sec_phone : sec_Mobile_No,
            },
            success:function(response) {
            var response = response.split("-");
            if(response[0] == 'exists'){
            alert('Secondary Mobile No already registered..enter another secondary mobile no');
            document.getElementById("second_mobile").value = '';
            }
            }
            }); 
            }
            });
            
            
            
         </script>
         <?php
            if(isset($result)) {
            ?>
         <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(50000, function() {
                            $('#message').text("");
                            $('#username').focus();
                    });
            }, 50000);
         </script>
         <?php
            }
            ?>
         <?php
            if(isset($result_user)) {
            ?>
         <script>
            $('#message_container_user').fadeIn(10);
            $('#message_user').text("<?php echo $result_user; ?>");
            setTimeout(function() {
                    $('#message_container_user').fadeOut(50000, function() {
                            $('#message_user').text("");
                            $('#username').focus();
                    });
            }, 50000);
         </script>
         <?php
            }
            ?>
         <?php
            if(isset($result_pass)) {
            ?>
         <script>
            $('#message_container_pass').fadeIn(10);
            $('#message_pass').text("<?php echo $result_pass; ?>");
            setTimeout(function() {
                    $('#message_container_pass').fadeOut(50000, function() {
                            $('#message_pass').text("");
                            $('#username').focus();
                    });
            }, 50000);
         </script>
         <?php
            }
            ?>
      </div>
   </body>
</html>