<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
ini_set('memory_limit','128M');
ob_start();
session_start();
require_once 'includes/configure.php';
require_once 'includes/session_handler.php';
require_once '../init.php';
date_default_timezone_set('Asia/Kolkata');

if(empty($_SESSION['Kamma_Matri'])){
    header("Location: index.php");
}

if($_SESSION['Kamma_Matri']){
    $enteredBy = $_SESSION['Kamma_Matri']['id'];    
}


$report_id = $_SESSION['report_id'];
$view_id = $_SESSION['view_id'];

if(empty($report_id)){
    header("Location: index.php");
}

$users = new Registration();
$users = $users->fetch()->resultSet(); 

$available_userId = array();
foreach($users as $user) { 
    array_push($available_userId, $user['km_regcode']);
}


if(isset($_POST['btn_submit'])){


  $arr = array();
  $arr[] = $_POST['user_id'];
  $arr[] = $_POST['send_date'];
  $arr[] = $_POST['send_remarks'];
  $arr[] = $_POST['enter_by'];

  $addcall = new SMS();
  $addcall = $addcall->addCall($arr);
  $addcall_id = $addcall->lastInsertID();

  $view_url = $_POST['view_url'];

  unset($_SESSION['report_id']);
  unset($_SESSION['view_id']);

  if($addcall_id){
    $_SESSION['call_added'] = true;
  } else {
    $_SESSION['call_added'] = false;
  }
  header("Location: $view_url");
}


if(isset($report_id)){

$getprofiles= new Registration();
$getprofiles = $getprofiles->fetch("WHERE id = '{$report_id}' ORDER BY id DESC")->resultSet();
$getprofile = $getprofiles[0];


$callhistorys = new SMS();
$callhistorys = $callhistorys->fetchCall("WHERE pl_userId = '{$getprofile['km_regcode']}' ORDER BY id DESC")->resultSet(); 


}


?>
<!DOCTYPE html>
<html>

    <link rel="stylesheet" href="../css/jquery-ui.css">
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
    <link rel="stylesheet" href="../css/bootstrap-datetimepicker.min.css" />
  
    <script src="../js/jquery-1.12.4.js"></script>
    <script src="../js/jquery-ui.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/moment.js"></script>
    <script src="../js/bootstrap-datetimepicker.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
<script type="text/javascript">
   function callfn(form)
 
 {

if(form.send_remarks.value=="") { alert("Please enter remarks"); form.send_remarks.focus(); return false; }

if(form.enter_by.value=="") { alert("Please enter enter by"); form.enter_by.focus(); return false; }

 }

</script>

   <?php include("includes/headertop.php");?>
   <body class="home color-green boxed shadow">
      <div class="root">
         <?php include("includes/header.php");?>
         <section class="content reverse" style=" width: 70%;">
            <section>
                <div  id="message_container" style="text-align: center; display: none; color: red;font-size: 18px; font-weight: bold">
                    <span id="message"></span>
                </div>
               <section class="columns" style="margin-top:10px !important;  width: 90%;">
                  <h2><span>New Call</span></h2>
                  <form  method="post" name="NewForm" enctype="multipart/form-data" onsubmit="return callfn(NewForm);">
                      <input type="hidden" name="view_url" value="<?php echo $view_id; ?>" />
                    <table width="50%"  border="0">
                           <tbody>

                              <tr>
                                 <th>Name :</th>
                                 <td>
                                     <input type="text" id="name" value="<?php echo $getprofile['km_name']; ?>" name="name" placeholder="Name" class="text" readonly>
                                 </td>
                              </tr>
                              
                              <tr>
                                 <th>Reg ID :</th>
                                 <td>
                                     <input type="text" id="user_id" value="<?php echo $getprofile['km_regcode']; ?>" name="user_id" placeholder="User ID" class="text" readonly>
                                 </td>
                              </tr>

                              <tr>
                                 <th>Mobile No :</th>
                                 <td>
                                     <input type="text" id="mobile" value="<?php echo $getprofile['km_mobile']; ?>" name="mobile" placeholder="Mobile No" class="text" readonly>
                                 </td>
                              </tr>

                              <tr>
                                 <th>Email ID :</th>
                                 <td>
                                     <input type="text" id="email" value="<?php echo $getprofile['km_email']; ?>" name="email" placeholder="Email ID" class="text" readonly>
                                 </td>
                              </tr>

                              <tr>
                                 <th>Date :</th>
                                 <td>
                                     <input type="text" id="send_date" value="<?php echo date("d-m-Y"); ?>" name="send_date" placeholder="Date" class="text" readonly >
                                 </td> 
                              </tr>

                              <tr>
                                 <th>Remarks :</th>
                                 <td>
                                     <textarea rows="4" id="send_remarks"  name="send_remarks" class="text" placeholder="Remarks" autofocus="autofocus"></textarea>
                                 </td>
                              </tr>


                              <tr>
                                 <th>Enter By:</th>
                                 <td>
                                 <select name="enter_by" style="opacity: 1;" > 
                                <option value="" Selected Disabled>-- Select --</option>
                                <option value="Durga">Durga</option>
                                <option value="Sulthana">Sulthana</option>
                                <option value="Divvya">Divvya</option>
                                <option value="Mavitha">Mavitha</option>
                                <option value="Vimala">Vimala</option>
                                </select> 
                                 </td>
                              </tr>
                              
                              <tr>
                                  <td colspan="2">
                                    <input type="submit" name="btn_submit" value="Submit" style="background:#93bf1b;color:#ffffff;margin-top:10px;margin-left: 50%;">
                                 </td>
                              </tr>
                              
                           </tbody>
                        </table>
                      </form>

                       <h2><span>Call History</span></h2>

                       <table class="table table-striped table-bordered table-hover" id="dataTables_customer">
                                <thead>
                                    <tr class="center heading" style="background-color:#077907;border-color: #077907;color: white">
                                        <th style="text-align: center;">S.No</th>
                                        <th style="text-align: center;">Reg ID</th>
                                        <th style="text-align: center;">Date</th>
                                        <th style="text-align: center;">Remarks</th>
                                        <th style="text-align: center;">Enter By</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    if($callhistorys){
                                    $sno = 1;
                                    foreach($callhistorys as $callhistory){ 

                              
                                        ?>
                                    <tr>                                    
                                        <td style="text-align: center;"><?php echo $sno;?></td>
                                        <td style="text-align: center;"><?php echo $callhistory['pl_userId'];?></td>
                                        <td style="text-align: left;"><?php echo date_format(new DateTime($callhistory['call_date']), 'd-m-Y');?></td>
                                        <td style="text-align: center;"><?php echo $callhistory['remarks'];?></td>
                                        <td style="text-align: center;"><?php echo $callhistory['enter_by'];?></td>
                                    </tr>
                                    <?php 
                                    $sno++;
                                    } } else {  ?>
                                    <tr>
                                    <td colspan="10">No data available</td>
                                    </tr>
                                    <?php } ?>
                                </tbody>

                            </table>



               </section>
            </section>
         </section>
         <div style=" clear: both;"></div>
         <?php include("includes/footer.php");?>
          <?php
        if(isset($result)) {
	?>
        <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(1000, function() {
                            $('#message').text("");
                            $('#username').focus();
                    });
            }, 1000);
        </script>
	<?php
            }
	?>
      </div>
        <script type="text/javascript">
            var availableUserId = "";
            $(document).ready(function() {
                $('#start_from').datetimepicker({
                    format: 'DD-MM-YYYY',
                    pickTime:false,
                    sideBySide:true
                });
                $('#paid_date').datetimepicker({
                    format: 'DD-MM-YYYY',
                    pickTime:false,
                    sideBySide:true
                });
                
                availableUserId = <?php echo json_encode($available_userId); ?>;
               $("#user_id").autocomplete({
                    source: availableUserId,
                    autoFocus:true,
                    select: function( event , ui ) {

                    }
                });                
            });
         
      
        $( document ).on('change','#plan_name ', function () {
            var plan_name = $(this).val();
            if(plan_name == 'Starter'){
                $('#plan_amount').val(500);
            }
            
        });
        </script>
   </body>
</html>