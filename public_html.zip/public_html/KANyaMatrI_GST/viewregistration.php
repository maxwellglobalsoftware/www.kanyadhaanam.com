<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
ob_start();
session_start();
require_once 'includes/configure.php';
require_once 'includes/session_handler.php';
require_once '../init.php';
date_default_timezone_set('Asia/Kolkata');
if(empty($_SESSION['Kamma_Matri'])){
    header("Location: index.php");
}

$view_id_profile=($_POST['submit_id'])?$_POST['submit_id']:$_REQUEST['submit_id'];

if(!isset($view_id_profile)){
header("Location: manage_profiles.php");
}

$editprofiles = new Registration();
$editprofiles = $editprofiles->fetch("WHERE id = '{$view_id_profile}'")->resultSet();    
$editprofile = $editprofiles[0];

$profile_id = $editprofile['km_regcode'];
//*********************** Profile Details *******************************
$profiles = new Registration();
$profiles = $profiles->fetch("WHERE km_regcode = '{$profile_id}'")->resultSet();    
$profile = $profiles[0];
//print_r($profile);
//*********************** Horoscope Details *******************************
$horos = new Profile();
$horos = $horos->fetchHoroscope("WHERE hs_userId = '{$profile['km_regcode']}'")->resultSet();
$horos = $horos[0];
//*********************** Photo Details *******************************
$photos = new Profile();
$photos = $photos->fetchPhotos("WHERE pho_userId = '{$profile['km_regcode']}' AND pho_imgPath LIKE '%_profile_%'")->resultSet();
$photo = $photos[0];
if($photo['pho_imgPath']){
    $imgPath =  '../'.$photo['pho_imgPath'];
}else{
    if($profile['km_gender'] == 'male'){
        $imgPath = '../images/male.png';
    }else{
        $imgPath = '../images/female.png';
    }
     
     
     
     
}
         //// States /////
    $castes = new Registration();
    $castes = $castes->fetchCastes("ORDER BY caste ASC")->resultSet();

    $castesEncoded = json_encode($castes); 

    //// subcastes /////
    $subcastes = new Registration();
    $subcastes = $subcastes->fetchSubcastes("ORDER BY subcaste ASC")->resultSet();

    $subcastesEncoded = json_encode($subcastes);  

$callhistorys = new SMS();
$callhistorys = $callhistorys->fetchCall("WHERE pl_userId = '{$profile_id}' ORDER BY id DESC")->resultSet(); 


$smshistorys = new SMS();
$smshistorys = $smshistorys->fetch("WHERE pl_userId = '{$profile_id}' ORDER BY id DESC")->resultSet();  

$loginhistorys = new Login();
$loginhistorys = $loginhistorys->fetchLogin("WHERE user_id = '{$profile['id']}'")->resultSet(); 
$total_logincount = count($loginhistorys);

$lastloginhistorys = new Login();
$lastloginhistorys = $lastloginhistorys->fetchLogin("WHERE user_id = '{$profile['id']}' ORDER BY id DESC LIMIT 1")->resultSet(); 
$lastloginhistory = $lastloginhistorys[0];


if(isset($_SESSION['registrationUpdate'])) {     
    if($_SESSION['registrationUpdate']) {
        $result = "Successfully Updated";
    } else {
        $result = "You have made no changes to save";
    }
    unset($_SESSION['registrationUpdate']);
}

if(isset($_SESSION['send_success'])) {     
    if($_SESSION['send_success']) {
        $result = "Successfully Sent";
    } else {
        $result = "Failed to send";
    }
    unset($_SESSION['send_success']);
}

if(isset($_SESSION['call_added'])) {     
    if($_SESSION['call_added']) {
        $result = "Successfully Added";
    } else {
        $result = "Failed to add";
    }
    unset($_SESSION['call_added']);
}


if(isset($_POST['add_call'])){


    $arr = array();
    $arr[] = $profile_id;
    $arr[] = $_POST['send_date'];
    $arr[] = $_POST['send_remarks'];
    $arr[] = $_POST['enter_by'];

    $addcall = new SMS();
    $addcall = $addcall->addCall($arr);
    $addcall_id = $addcall->lastInsertID();

    $profile_call_ID = $_POST['profile_call_id'];

    if($addcall_id){
        $_SESSION['call_added'] = true;
    } else {
        $_SESSION['call_added'] = false;
    }
    header("Location: viewregistration.php?submit_id=$profile_call_ID&&status=update");
}



if(isset($_POST['btn_update'])) {   
    
    
    
 
  
   
    $data = array();
    
    $data[] = $_POST['member_name'];
    $data[] = $_POST['password'];
    $data[] = $_POST['gender'];
    $data[] = $_POST['education'];
    $data[] = $_POST['education_details'];
    $data[] = $_POST['employedIn'];
    $data[] = $_POST['occupation'];
    $data[] = $_POST['occupation_details'];
    $data[] = $_POST['annualIncome'];  
    $data[] = $_POST['bloodgroup'];  
    $data[] = $_POST['doorNo'];
    $data[] = $_POST['street'];
    $data[] = $_POST['city'];
    $data[] = $_POST['state'];
    $data[] = $_POST['district'];
    $data[] = $_POST['pincode'];  
    $data[] = $_POST['mobile'];
    $data[] = $_POST['second_mobile'];
    $data[] = $_POST['email'];
    $data[] = $_POST['landline_code'].'-'.$_POST['landline'];
    $data[] = $_POST['marital_status'];
     $data[] = $_POST['caste'];
      $data[] = $_POST['subcaste'];
    $data[] = $_POST['languagesKnown'];
    $data[] = $_POST['physical_status']; 
    
    $data[] = $_POST['father_name'];
    $data[] = $_POST['father_occupation'];
    $data[] = $_POST['mother_name'];
    $data[] = $_POST['mother_occupation']; 
    $data[] = $_POST['year'].'-'.$_POST['month'].'-'.$_POST['date'];
    $data[] = $_POST['day'];
    $data[] = $_POST['birthhour'].':'.$_POST['birthmins'].' '.$_POST['birthmeridium'];
    $data[] = $_POST['place_of_birth'];
    $data[] = $_POST['order_of_place'];    
    $data[] = $_POST['house_name'];
    $data[] = $_POST['gothram'];
    $data[] = $_POST['native'];
    $data[] = $_POST['native_district'];
    $data[] = $_POST['family_status'];
    $data[] = $_POST['family_type'];
    $data[] = $_POST['family_value'];
    $data[] = $_POST['bcount'];
    $data[] = $_POST['bmcount'];
    $data[] = $_POST['scount'];
    $data[] = $_POST['smcount'];
    if($_POST['height_ft']){
   $data[] = $_POST['height_ft'];  
   } else {
   $data[] = $_POST['height_cms']; 
   }   
    $data[] = $_POST['weight'];
    $data[] = $_POST['star'];
    $data[] = $_POST['rasi'];
    $data[] = $_POST['lagnam'];
    $data[] = $_POST['thisai_irrupu']; 
    $data[] = $_POST['dosham'];
    if($_POST['dosham'] == 'yes'){
    $data[] = $_POST['dosham_details'];  
    } else {
    $data[] = "";
    }
    
  
    $data[] = $_POST['registeredBy'];
    $data[] = $_POST['status_val'];
    $data[] = $_POST['profile_edit_id'];
    
  

 
    $registration = new Registration();
    $registration = $registration->update($data);
    
    
    $registration_id = $registration->rowCount();

    $updateprofiles = new Registration();
    $updateprofiles = $updateprofiles->fetch("WHERE km_regcode = '{$profile_id}'")->resultSet();    
    $updateprofile = $updateprofiles[0];

     if($updateprofile['km_gender'] == 'male'){
       $km_gender = 'female';
     }else{
       $km_gender = 'male';
     }

    if($_POST['status'] == 'live'){

    $get_emails = new Registration();
    $get_emails = $get_emails->fetchMailSend("WHERE km_regcode = '{$profile_id}' ORDER BY id DESC")->resultSet();
    $get_emails = $get_emails[0];

    if($get_emails){

    } else {

    $data = array();
    $data[] = $profile_id;

    $addprrofile = new Registration();
    $addprrofile = $addprrofile->addMailSend($data);
    $addprrofile = $addprrofile->lastInsertID();


    $dob_birth = $updateprofile['km_dateofbirth'];

    $star_name = $updateprofile['km_star'];

    $profile_add_name  = $updateprofile['km_name'];

    $profile_add_district  = $updateprofile['km_district'];

    $profile_add_education  = $edu_array[$updateprofile['km_education']];

    $profile_add_occupation  = $updateprofile['km_occupation'];

    $height_ft = $updateprofile['km_height'];

    $from = new DateTime($dob_birth);
    $to   = new DateTime('today');
    $age = $from->diff($to)->y; 
    $cur_Year = date("Y");

    $get_partners = new Partner();
    $get_partners = $get_partners->fetch("WHERE '{$age}' BETWEEN age_from AND age_to AND (star REGEXP CONCAT ('(^|,)($star_name)(,|$)')) ORDER BY id DESC")->resultSet();

    if($get_partners){ 

    foreach($get_partners as $get_partner){

   $users = new Registration();
   $users = $users->fetch("WHERE km_regcode = '{$get_partner['pl_userId']}' AND km_gender = '{$km_gender}' AND km_status = 'live' ")->resultSet();
   $user = $users[0];

   // $users = new Registration();
   // $users = $users->fetch("WHERE km_regcode = '180190' AND km_gender = '{$km_gender}'")->resultSet();
   // $user = $users[0];

   if($user){

   $user_email = $user['km_email'];

   $user_name = $user['km_name'];

    $photos = new Profile();
    $photos = $photos->fetchPhotos("WHERE pho_userId = '{$profile_id}' AND pho_imgPath LIKE '%_profile_%' ORDER BY id DESC LIMIT 1")->resultSet();
    $photo = $photos[0];

    if($photo['pho_imgPath']){
        $imgPath =  $photo['pho_imgPath'];
    }else{
        $imgPath = 'images/'.$updateprofile['km_gender'].'.png';               
    } 

   $primary_emails = new OTP();
   $primary_emails = $primary_emails->fetchEmail("WHERE pl_userId = '{$user['km_regcode']}' AND pl_primary_email = '{$user_email}' AND pl_primary_status = 'yes' ORDER BY id DESC")->resultSet(); 
   $primary_email = $primary_emails[0];

   if($primary_email){


    $msg= "<p style='font-size: 18px;'>Dear {$user_name},</p>";
   
  $msg.= "<p style='font-size: 18px;'>Here, you can view matching profiles based on your partner’s preference. One might be your special someone!</p>";

  $msg.="<table><tr>";

  $msg.='<td align="left"><img src="http://www.kanyadhaanam.com/'.str_replace(" ", '%20', $imgPath).'" width="250" height="250"></td>';

  $msg.="<td align='left' style='font-weight:bold;vertical-align:top;padding-left: 3%;font-size: 18px;'>

  <span style='line-height: 2.0em;'>Name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;$profile_add_name</span><br>

  <span style='line-height: 2.0em;'>Age &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;$age</span><br>

  <span style='line-height: 2.0em;'>Height&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;$height_ft</span><br>

  <span style='line-height: 2.0em;'>Star&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;$star_name</span><br>

  <span style='line-height: 2.0em;'>District&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;$profile_add_district</span><br>


    <span style='line-height: 2.0em;'>Education&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;$profile_add_education</span><br>

    <span style='line-height: 2.0em;'>Occupation&nbsp;&nbsp;:&nbsp;$profile_add_occupation</span><br>

    </td>

    </tr><br></table><br>";


    $msg.="<table><tr style='font-size: 18px;line-height: 1.5em;'><td>Regards</tr></td>
   <tr style='font-size: 18px;line-height: 1.5em;'><td>KANYADHAANAM MATRIMONY - TEAM</tr></td>
   </table><br>";

   $prof_to = $user_email;
   $prof_subject = "New matching profile found in KANYADHAANAM MATRIMONY";

   // Always set content-type when sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    
    // More headers
    $headers .= 'From: <support@kanyadhaanam.com>' . "\r\n";
    
    $send_mail = mail($prof_to,$prof_subject,$msg,$headers);


   }

    }

    }

    }

}

    }

    $profile_update_submit = $_POST['profile_edit_id'];
   
    
      if($registration_id){   
        $_SESSION['registrationUpdate'] = true;
    } else {
        $_SESSION['registrationUpdate'] = false;
    }
    header("Location: viewregistration.php?submit_id=$profile_update_submit&&status=update");
}


    //// Occupation /////
    $occupations = new Registration();
    $occupations = $occupations->fetchOccupation("ORDER BY occupation ASC")->resultSet();


    //// Districts /////
    $districts = new Registration();
    $districts = $districts->fetchDistricts("ORDER BY name ASC")->resultSet();

    $districtsEncoded = json_encode($districts);

    //// States /////
    $states = new Registration();
    $states = $states->fetchStates("ORDER BY name ASC")->resultSet();

    $statesEncoded = json_encode($states);

    $editdistricts = new Registration();
    $editdistricts = $editdistricts->fetchDistricts("WHERE state_id = '{$profile['km_state']}' ORDER BY name ASC")->resultSet();

    $editoccupations = new Registration();
    $editoccupations = $editoccupations->fetchOccupation("WHERE id = '{$profile['km_occupation']}' ORDER BY occupation ASC")->resultSet();
    $editoccupation = $editoccupations[0];

    if($editoccupation){
        $occu_name = $editoccupation['occupation'];
    } else {
        $occu_name = $profile['km_occupation'];
    }


    if(isset($_POST['paid_member'])){

    $mobile_no = $_POST['profile_send_mobile'];
    
    $profile_name = $_POST['profile_send_name'];
    
    $profile_email = $_POST['profile_send_email'];

    $profile_send_submit = $_POST['profile_send_id'];

    if($mobile_no || $profile_email){

    $data = array();
    $data[] = $profile_id;
    $data[] = date("Y-m-d");
    $data[] = "Paid Member";

    $addsms = new SMS();
    $addsms = $addsms->add($data);
    $addsms_id = $addsms->lastInsertID();


    $msgsend = "Thank you for being a featured user of KANYADHAANAM MATRIMONY. Become a paid member to Enjoy more features. Reach Us 95000 90825 www.kanyadhaanam.com";
    $url="http://alerts.maxwellsms.com/api/v3/index.php";
    $parameters = "method=sms&api_key=Afebb28266bdbd1300d76c268f10f65b8&to=$mobile_no&sender= KDMMAT&message=$msgsend&format=xml&flash=0";

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $parameters);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $response = curl_exec($ch);
    
    
    if($profile_email){

  $msg= "<table>
        
        <p style='font-size: 18px;margin-bottom:8px;'>Dear {$profile_name},</p>
        
        <tr><td align='left' style='font-size: 17px;line-height: 1.5em;'>Thank you for being a featured user of KANYADHAANAM MATRIMONY. Become a paid member to Enjoy more features.Kindly login your profile to view membership details.</td></tr>
        </table>
        <br>
        <table>
        <tr style='font-size: 15px;line-height: 1.5em;font-weight:bold;'><td>Regards, </tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;font-weight:bold;'><td>KANYADHAANAM MATRIMONY - TEAM</tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;'><td><a href='www.kanyadhaanam.com' target='_blank'>www.kanyadhaanam.com</a></tr></td>
        </table>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/call_icon.png' style=''> &nbsp;95000 90825</p>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/whatsapp_icon.png' style=''> &nbsp;95000 90825</p>
        
        
        <div id='accordion-container' style='font-size: 11px;background: #ffffff;padding: 5px 10px 10px 10px;border: 1px solid #cccccc;;border-radius: 5px;box-shadow: 0 5px 15px #cccccc; width:70%;'>
        
        <h2 class='accordion-header active-header' style=' margin-top: 0px;border-radius: 5px 5px 0 0;background: url(http://www.kanyadhaanam.com/images/active-header.gif) #cef98d;background-repeat: no-repeat;margin: 5px 0 0 0;padding: 5px 20px;cursor: pointer;color: #e23f0c;'><img src='http://www.kanyadhaanam.com/images/lightbulb.png' width='40' style='vertical-align: middle;'>  Qns : How can I renew/upgrade memberships?
        </h2>
        
        <div class='accordion-content open-content' style='width: 766px; display: block;padding: 10px;background: #ffffff;border: 1px solid #cccccc;border-top: 0;border-radius: 0 0 5px 5px;text-align: justify;width: auto;font-size: 16px;font-weight: normal;'>
         <p style='margin: 5px;'>You can choose to upgrade membership by clicking on Membership from the Menu. You can renew your current membership only a couple of weeks from the time of expiry of the current one.</p>
        
        </div>

        <h2 class='accordion-header active-header' style=' margin-top: 0px;border-radius: 5px 5px 0 0;background: url(http://www.kanyadhaanam.com/images/active-header.gif) #cef98d;background-repeat: no-repeat;margin: 5px 0 0 0;padding: 5px 20px;cursor: pointer;color: #e23f0c;'><img src='http://www.kanyadhaanam.com/images/lightbulb.png' width='40' style='vertical-align: middle;'>  Qns : Benefits of paid member
        </h2>

        <div class='accordion-content open-content' style='width: 766px; display: block;padding: 10px;background: #ffffff;border: 1px solid #cccccc;border-top: 0;border-radius: 0 0 5px 5px;text-align: justify;width: auto;font-size: 16px;font-weight: normal;'>
         <p style='margin: 5px;'>You can send unlimited Express Interest.</p>
         <p style='margin: 5px;'>You can view the unlimited full profiles.</p>
        
        </div>
        
        ";
   
   $to = $profile_email;
   $subject = "Upgrade Now to Enjoy more features ! KANYADHAANAM MATRIMONY";

   // Always set content-type when sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    
    // More headers
    $headers .= 'From: <support@kanyadhaanam.com>' . "\r\n";
    
    $send_mail = mail($to,$subject,$msg,$headers);

    }
    
    $_SESSION['send_success'] = true;
    header("Location: viewregistration.php?submit_id=$profile_send_submit&&status=update&&type=paid");
    

  } else {
  header("Location: viewregistration.php?submit_id=$profile_send_submit&&status=update&&type=error");  
  }

   }

   if(isset($_POST['latest_profile'])){

    $mobile_no = $_POST['profile_send_mobile'];
    
    $profile_name = $_POST['profile_send_name'];
    
    $profile_email = $_POST['profile_send_email'];

    $profile_send_submit = $_POST['profile_send_id'];

    if($mobile_no || $profile_email){

    $data = array();
    $data[] = $profile_id;
    $data[] = date("Y-m-d");
    $data[] = "Latest Profiles";

    $addsms = new SMS();
    $addsms = $addsms->add($data);
    $addsms_id = $addsms->lastInsertID();

    $msgsend = "Online Portal for KANYADHAANAM MATRIMONY. visit www.kanyadhaanam.com for the latest updated profiles.. login often and get married soon.. Call 95000 90825";
    $url="http://alerts.maxwellsms.com/api/v3/index.php";
    $parameters = "method=sms&api_key=Afebb28266bdbd1300d76c268f10f65b8&to=$mobile_no&sender= KDMMAT&message=$msgsend&format=xml&flash=0";

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $parameters);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $response = curl_exec($ch);
    
    
     if($profile_email){

  $msg= "<table>
        
        <p style='font-size: 18px;margin-bottom:8px;'>Dear {$profile_name},</p>
        
        <tr><td align='left' style='font-size: 17px;line-height: 1.5em;'>Online Portal for KANYADHAANAM MATRIMONY. visit <a href='www.kanyadhaanam.com' target='_blank'>www.kanyadhaanam.com</a> for the latest updated profiles.. login often and get married soon..</td></tr>
        </table>
        <br>
        <table>
        <tr style='font-size: 15px;line-height: 1.5em;font-weight:bold;'><td>Regards, </tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;font-weight:bold;'><td>KANYADHAANAM MATRIMONY - TEAM</tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;'><td><a href='www.kanyadhaanam.com' target='_blank'>www.kanyadhaanam.com</a></tr></td>
        </table>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/call_icon.png' style=''> &nbsp;95000 90825</p>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/whatsapp_icon.png' style=''> &nbsp;95000 90825</p>
        
        
        <div id='accordion-container' style='font-size: 11px;background: #ffffff;padding: 5px 10px 10px 10px;border: 1px solid #cccccc;;border-radius: 5px;box-shadow: 0 5px 15px #cccccc; width:70%;'>
        
        <h2 class='accordion-header active-header' style=' margin-top: 0px;border-radius: 5px 5px 0 0;background: url(http://www.kanyadhaanam.com/images/active-header.gif) #cef98d;background-repeat: no-repeat;margin: 5px 0 0 0;padding: 5px 20px;cursor: pointer;color: #e23f0c;'><img src='http://www.kanyadhaanam.com/images/lightbulb.png' width='40' style='vertical-align: middle;'>  Qns : Is my credit card payment on <a href='www.kanyadhaanam.com' target='_blank'>www.kanyadhaanam.com</a> secure?
        </h2>
        
        <div class='accordion-content open-content' style='width: 766px; display: block;padding: 10px;background: #ffffff;border: 1px solid #cccccc;border-top: 0;border-radius: 0 0 5px 5px;text-align: justify;width: auto;font-size: 16px;font-weight: normal;'>

         <p style='margin: 5px;'>Yes, your credit card information on kanyadhaanam.com is perfectly secure. We have an encryption software that prevents misuse of the information. This encrypted information is passed on the payment gateway. Credit card info is entered only on the VeriSign Certified secure server. 128 bit SSL encryption deployed.</p>

         <p style='margin: 5px;'>We can process Visa and MasterCard credit cards issued around the globe. Real time authorization happens to the information. For extra level of protection, our payment gateway also supports <b>Verified by VISA</b> and <b>MasterCard Secure Code</b> services.</p>
        
        </div><br>
";
   
   $to = $profile_email;
   $subject = "Login now to view Latest Profiles in KANYADHAANAM MATRIMONY !";

   // Always set content-type when sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    
    // More headers
    $headers .= 'From: <support@kanyadhaanam.com>' . "\r\n";
    
    $send_mail = mail($to,$subject,$msg,$headers);

    }

    $_SESSION['send_success'] = true;
    header("Location: viewregistration.php?submit_id=$profile_send_submit&&status=update&&type=latest");

  } else {
  header("Location: viewregistration.php?submit_id=$profile_send_submit&&status=update&&type=error");  
  }

   }

   if(isset($_POST['user_pass'])){

    $mobile_no = $_POST['profile_send_mobile'];
    
    $profile_name = $_POST['profile_send_name'];
    
    $profile_email = $_POST['profile_send_email'];

    $profile_send_submit = $_POST['profile_send_id'];

    if($mobile_no || $profile_email){

    $data = array();
    $data[] = $profile_id;
    $data[] = date("Y-m-d");
    $data[] = "Username and Password";

    $addsms = new SMS();
    $addsms = $addsms->add($data);
    $addsms_id = $addsms->lastInsertID();

    $msgsend = "Thank you for being a featured user of www.kanyadhaanam.com. If you not received your user name and password, Please call 95000 90825";
    $url="http://alerts.maxwellsms.com/api/v3/index.php";
    $parameters = "method=sms&api_key=Afebb28266bdbd1300d76c268f10f65b8&to=$mobile_no&sender= KDMMAT&message=$msgsend&format=xml&flash=0";

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $parameters);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $response = curl_exec($ch);
    
    
    if($profile_email){

  $msg= "<table>
        
        <p style='font-size: 18px;margin-bottom:8px;'>Dear {$profile_name},</p>
        
        <tr><td align='left' style='font-size: 17px;line-height: 1.5em;'>Thank you for being a featured user of <a href='www.kanyadhaanam.com' target='_blank'>www.kanyadhaanam.com</a>. If you not received your user name and password, Please call 95000 90825</td></tr>
        </table>
        <br>
        <table>
        <tr style='font-size: 15px;line-height: 1.5em;font-weight:bold;'><td>Regards, </tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;font-weight:bold;'><td>KANYADHAANAM MATRIMONY - TEAM</tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;'><td><a href='www.kanyadhaanam.com' target='_blank'>www.kanyadhaanam.com</a></tr></td>
        </table>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/call_icon.png' style=''> &nbsp;95000 90825</p>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/whatsapp_icon.png' style=''> &nbsp;95000 90825</p>
        
        
        <div id='accordion-container' style='font-size: 11px;background: #ffffff;padding: 5px 10px 10px 10px;border: 1px solid #cccccc;;border-radius: 5px;box-shadow: 0 5px 15px #cccccc; width:70%;'>
        
        <h2 class='accordion-header active-header' style=' margin-top: 0px;border-radius: 5px 5px 0 0;background: url(http://www.kanyadhaanam.com/images/active-header.gif) #cef98d;background-repeat: no-repeat;margin: 5px 0 0 0;padding: 5px 20px;cursor: pointer;color: #e23f0c;'><img src='http://www.kanyadhaanam.com/images/lightbulb.png' width='40' style='vertical-align: middle;'>  Qns : How to Upload Photo & horoscope?
        </h2>
        
        <div class='accordion-content open-content' style='width: 766px; display: block;padding: 10px;background: #ffffff;border: 1px solid #cccccc;border-top: 0;border-radius: 0 0 5px 5px;text-align: justify;width: auto;font-size: 16px;font-weight: normal;'>

         <p style='margin: 5px;'>Send Your photos and horoscope to support@kanyadhaanam.com for instant upload.</p>

         <p style='margin: 5px;'>You can also take a selfie or send your photos via WhatsApp to 95000 90825 for instant upload.</p>
        
        </div><br>
";
   
   $to = $profile_email;
   $subject = "Get Your Username and password Now  -  KANYADHAANAM MATRIMONY";

   // Always set content-type when sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    
    // More headers
    $headers .= 'From: <support@kanyadhaanam.com>' . "\r\n";
    
    $send_mail = mail($to,$subject,$msg,$headers);

    }
    
    

    $_SESSION['send_success'] = true;
    header("Location: viewregistration.php?submit_id=$profile_send_submit&&status=update&&type=user");

    } else {
  header("Location: viewregistration.php?submit_id=$profile_send_submit&&status=update&&type=error");  
  }

   }

   if(isset($_POST['send_photo'])){

    $mobile_no = $_POST['profile_send_mobile'];
    
    $profile_name = $_POST['profile_send_name'];
    
    $profile_email = $_POST['profile_send_email'];

    $profile_send_submit = $_POST['profile_send_id'];

    if($mobile_no || $profile_email){

    $data = array();
    $data[] = $profile_id;
    $data[] = date("Y-m-d");
    $data[] = "Photo and Horoscope";

    $addsms = new SMS();
    $addsms = $addsms->add($data);
    $addsms_id = $addsms->lastInsertID();

    $msgsend = "Thank you for being a featured user of www.kanyadhaanam.com. send photo and Horoscope to support@kanyadhaanam.com to activate your account or Call 95000 90825";
    $url="http://alerts.maxwellsms.com/api/v3/index.php";
    $parameters = "method=sms&api_key=Afebb28266bdbd1300d76c268f10f65b8&to=$mobile_no&sender= KDMMAT&message=$msgsend&format=xml&flash=0";

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $parameters);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $response = curl_exec($ch);
    
     if($profile_email){

    $msg= "<table>
        
        <p style='font-size: 18px;margin-bottom:8px;'>Dear {$profile_name},</p>
        
        <tr><td align='left' style='font-size: 17px;line-height: 1.5em;'>Thank You very much for your interest with KANYADHAANAM MATRIMONY</td></tr>
        <tr><td align='left' style='font-size: 17px;line-height: 1.5em;'>Thank you for being a featured user of <a href='www.kanyadhaanam.com' target='_blank'>www.kanyadhaanam.com</a>. Kindly send your photo & Horoscope to support@kanyadhaanam.com to activate your account or Call 95000 90825</td></tr>
        </table>
        <br>
        <table>
        <tr style='font-size: 15px;line-height: 1.5em;font-weight:bold;'><td>Regards, </tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;font-weight:bold;'><td>KANYADHAANAM MATRIMONY - TEAM</tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;'><td><a href='www.kanyadhaanam.com' target='_blank'>www.kanyadhaanam.com</a></tr></td>
        </table>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/call_icon.png' style=''> &nbsp;95000 90825</p>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/whatsapp_icon.png' style=''> &nbsp;95000 90825</p>
        
        
        <div id='accordion-container' style='font-size: 11px;background: #ffffff;padding: 5px 10px 10px 10px;border: 1px solid #cccccc;;border-radius: 5px;box-shadow: 0 5px 15px #cccccc; width:70%;'>
        
        <h2 class='accordion-header active-header' style=' margin-top: 0px;border-radius: 5px 5px 0 0;background: url(http://www.kanyadhaanam.com/images/active-header.gif) #cef98d;background-repeat: no-repeat;margin: 5px 0 0 0;padding: 5px 20px;cursor: pointer;color: #e23f0c;'><img src='http://www.kanyadhaanam.com/images/lightbulb.png' width='40' style='vertical-align: middle;'>  Qns : How to Upload Photo & horoscope?
        </h2>
        
        <div class='accordion-content open-content' style='width: 766px; display: block;padding: 10px;background: #ffffff;border: 1px solid #cccccc;border-top: 0;border-radius: 0 0 5px 5px;text-align: justify;width: auto;font-size: 16px;font-weight: normal;'>

         <p style='margin: 5px;'>Send Your photos and horoscope to support@kanyadhaanam.com for instant upload.</p>

         <p style='margin: 5px;'>You can also take a selfie or send your photos via WhatsApp to 95000 90825 for instant upload.</p>

         <p style='margin: 5px;'>Please note : It may take up to 2 hours for photo validation, after which it will be visible to everyone.</p>
        
        </div><br>
";
   
   $to = $profile_email;
   $subject = "Activate your Matrimony Account Now - KANYADHAANAM MATRIMONY";

   // Always set content-type when sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    
    // More headers
    $headers .= 'From: <support@kanyadhaanam.com>' . "\r\n";
    
    $send_mail = mail($to,$subject,$msg,$headers);

    }

    $_SESSION['send_success'] = true;
    header("Location: viewregistration.php?submit_id=$profile_send_submit&&status=update&&type=photo");

    } else {
  header("Location: viewregistration.php?submit_id=$profile_send_submit&&status=update&&type=error");  
  }

   }

   if(isset($_POST['update_profile'])){

    $mobile_no = $_POST['profile_send_mobile'];
    
    $profile_name = $_POST['profile_send_name'];
    
    $profile_email = $_POST['profile_send_email'];

    $profile_send_submit = $_POST['profile_send_id'];

    if($mobile_no || $profile_email){

    $data = array();
    $data[] = $profile_id;
    $data[] = date("Y-m-d");
    $data[] = "Update Profile";

    $addsms = new SMS();
    $addsms = $addsms->add($data);
    $addsms_id = $addsms->lastInsertID();

    $msgsend = "Thank you for being a featured user of www.kanyadhaanam.com. Please login and update your profile immediately. If you have any update to Call 95000 90825";
    $url="http://alerts.maxwellsms.com/api/v3/index.php";
    $parameters = "method=sms&api_key=Afebb28266bdbd1300d76c268f10f65b8&to=$mobile_no&sender= KDMMAT&message=$msgsend&format=xml&flash=0";

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $parameters);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $response = curl_exec($ch);
    
    
    if($profile_email){

    $msg= "<table>
        
        <p style='font-size: 18px;margin-bottom:8px;'>Dear {$profile_name},</p>
        
        <tr><td align='left' style='font-size: 17px;line-height: 1.5em;'>Thank you for being a featured user of <a href='www.kanyadhaanam.com' target='_blank'>www.kanyadhaanam.com</a>. Please login and update your profile immediately. If you have any problems to update Call 95000 90825</td></tr>

        </table>
        <br>
        <table>
        <tr style='font-size: 15px;line-height: 1.5em;font-weight:bold;'><td>Regards, </tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;font-weight:bold;'><td>KANYADHAANAM MATRIMONY - TEAM</tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;'><td><a href='www.kanyadhaanam.com' target='_blank'>www.kanyadhaanam.com</a></tr></td>
        </table>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/call_icon.png' style=''> &nbsp;95000 90825</p>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/whatsapp_icon.png' style=''> &nbsp;95000 90825</p>
        
        
        <div id='accordion-container' style='font-size: 11px;background: #ffffff;padding: 5px 10px 10px 10px;border: 1px solid #cccccc;;border-radius: 5px;box-shadow: 0 5px 15px #cccccc; width:70%;'>
        
        <h2 class='accordion-header active-header' style=' margin-top: 0px;border-radius: 5px 5px 0 0;background: url(http://www.kanyadhaanam.com/images/active-header.gif) #cef98d;background-repeat: no-repeat;margin: 5px 0 0 0;padding: 5px 20px;cursor: pointer;color: #e23f0c;'><img src='http://www.kanyadhaanam.com/images/lightbulb.png' width='40' style='vertical-align: middle;'>  Qns : How to Upload Photo & horoscope?
        </h2>
        
        <div class='accordion-content open-content' style='width: 766px; display: block;padding: 10px;background: #ffffff;border: 1px solid #cccccc;border-top: 0;border-radius: 0 0 5px 5px;text-align: justify;width: auto;font-size: 16px;font-weight: normal;'>

         <p style='margin: 5px;'>Send Your photos and horoscope to support@kanyadhaanam.com for instant upload.</p>

         <p style='margin: 5px;'>You can also take a selfie or send your photos via WhatsApp to 95000 90825 for instant upload.</p>
        </div><br>
";
   
   $to = $profile_email;
   $subject = "Update your Profile Now - KANYADHAANAM MATRIMONY";

   // Always set content-type when sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    
    // More headers
    $headers .= 'From: <support@kanyadhaanam.com>' . "\r\n";
    
    $send_mail = mail($to,$subject,$msg,$headers);

    }

    $_SESSION['send_success'] = true;
    header("Location: viewregistration.php?submit_id=$profile_send_submit&&status=update&&type=update");

    } else {
  header("Location: viewregistration.php?submit_id=$profile_send_submit&&status=update&&type=error");  
  }

   }

?>
<!DOCTYPE html>
<html>
   <link rel="stylesheet" href="../css/jquery-ui.css">
<link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="../css/bootstrap-datetimepicker.min.css" />
  
    <script src="../js/jquery-1.12.4.js"></script>
    <script src="../js/jquery-ui.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/moment.js"></script>
    <script src="../js/bootstrap-datetimepicker.js"></script>
<script type="text/javascript">
    function regform(form)

    {

    var numbers = /^[0-9]+$/; 

    var passw = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{6,20}$/;

    var re = /^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$/;

    if(form.member_name.value=="") { alert("Please enter name"); form.member_name.focus(); return false; }

    if(form.password.value=="") { alert("Please enter password"); form.password.focus(); return false; }


    if(form.education.value=="") { alert("Please select education"); form.education.focus(); return false; }

    if(form.employedIn.value=="notworking") {
                                           
    } else {
 
     if(form.occupation_details.value=="") { alert("Please enter  occupation Details"); form.occupation_details.focus(); return false; }
    
    //if(form.occupation.value=="") { alert("Please select occupation"); form.occupation.focus(); return false; }

    // if(form.company_name.value=="") { alert("Please enter occupation details"); form.company_name.focus(); return false; }

    if(form.annualIncome.value=="") { alert("Please enter annual income"); form.annualIncome.focus(); return false; }

    }

    // if(form.bloodgroup.value=="") { alert("Please select blood group"); form.bloodgroup.focus(); return false; }

    if(form.doorNo.value=="") { alert("Please enter door no"); form.doorNo.focus(); return false; }

    if(form.street.value=="") { alert("Please enter street"); form.street.focus(); return false; }

    if(form.city.value=="") { alert("Please enter city"); form.city.focus(); return false; }

    if(form.pincode.value=="") { alert("Please enter pincode"); form.pincode.focus(); return false; }
    
     if(form.pincode.value!="")
    {
    if(!form.pincode.value.match(numbers))  
    {  

    alert('Please enter pincode with only numbers');  
    form.pincode.focus(); return false;
    }
    if (form.pincode.value.length != 6)
    { 
    alert('Please enter your 6 digits pincode exactly');  
    form.pincode.focus(); return false; 
    } 
    }

    if(form.state.value=="") { alert("Please select state"); form.state.focus(); return false; }

    if(form.district.value=="") { alert("Please enter district"); form.district.focus(); return false; }

//  if(form.email.value=="") { alert("Please enter your Email ID"); form.email.focus(); return false; }

    if(form.email.value!="")
    {
    if(!form.email.value.match(re))  
    {  

    alert('Please enter valid Email ID');  
    form.email.focus(); return false;
    }  
    }

    if(form.mobile.value=="") { alert("Please enter mobile number"); form.mobile.focus(); return false; }
    if(form.mobile.value!="")
    {
    if(!form.mobile.value.match(numbers))  
    {  

    alert('Please enter mobile number with only numbers');  
    form.mobile.focus(); return false;
    } 
    if (form.mobile.value.length != 10)
    { 
    alert('Please enter your 10 digits mobile number exactly');  
    form.mobile.focus(); return false; 
    } 

    }

    // if(form.second_mobile.value=="") { alert("Please enter your secondary mobile number"); form.second_mobile.focus(); return false; }
    // if(form.second_mobile.value!="")
    // {
    // if(!form.second_mobile.value.match(numbers))  
    // {  

    // alert('Please enter secondary mobile number with only numbers');  
    // form.second_mobile.focus(); return false;
    // } 
    // if (form.second_mobile.value.length != 10)
    // { 
    // alert('Please enter your 10 digits secondary mobile number exactly');  
    // form.second_mobile.focus(); return false; 
    // } 

    // }

    if(form.landline_code.value!="") {
                                       
   if(form.landline_code.value.length < 3 || form.landline_code.value.length > 5) {
     alert("Please enter landline code 3 to 5 digits only"); form.landline_code.focus(); return false;
   }
   
 }
 
 
     if(form.landline.value!="")
     {
     if(!form.landline.value.match(numbers))  
     {  
     
     alert('Please enter landline number with only numbers');  
     form.landline.focus(); return false;
     }
     if (form.landline.value.length != 8)
     { 
     alert('Please enter your 8 digits landline number exactly');  
     form.landline.focus(); return false; 
     } 
     }

    // if(form.languagesKnown.value=="") { alert("Please enter language"); form.languagesKnown.focus(); return false; }

    if(form.father_name.value=="") { alert("Please enter father's name"); form.father_name.focus(); return false; }


    // if(form.father_occupation.value=="") { alert("Please enter father's occupation"); form.father_occupation.focus(); return false; }

    if(form.mother_name.value=="") { alert("Please enter mother's name"); form.mother_name.focus(); return false; }


    // if(form.mother_occupation.value=="") { alert("Please enter mother's occupation"); form.mother_occupation.focus(); return false; }
    
   

    if(form.date.value=="" && form.month.value=="" && form.year.value=="") { alert("Please select date of birth"); form.date.focus(); return false; }

    if(form.date.value=="") { alert("Please select date"); form.lagnam.focus(); return false; }

    if(form.month.value=="") { alert("Please select month"); form.month.focus(); return false; }

    if(form.year.value=="") { alert("Please select year"); form.year.focus(); return false; }

    if(form.day.value=="") { alert("Please select day of birth"); form.day.focus(); return false; }

    if(form.birthhour.value=="" && form.birthmins.value=="" && form.birthmeridium.value=="") { alert("Please select time of birth"); form.birthhour.focus(); return false; }
                                       
    if(form.birthhour.value=="" ) { alert("Please select hour"); form.birthhour.focus(); return false; }

    if(form.birthmins.value=="" ) { alert("Please select mins"); form.birthmins.focus(); return false; }

    if(form.birthmeridium.value=="" ) { alert("Please select meridiem"); form.birthmeridium.focus(); return false; }


    if(form.place_of_birth.value=="") { alert("Please enter place of birth"); form.place_of_birth.focus(); return false; }

    if(form.order_of_place.value=="") { alert("Please select order of birth"); form.order_of_place.focus(); return false; }


    // if(form.house_name.value=="") { alert("Please enter house name"); form.house_name.focus(); return false; }

    if(form.gothram.value=="") { alert("Please enter gothram"); form.gothram.focus(); return false; }


    if(form.native.value=="") { alert("Please enter native place"); form.native.focus(); return false; }

    if(form.native_district.value=="") { alert("Please enter native district"); form.native_district.focus(); return false; }

    //if(form.family_status[0].checked=="" && form.family_status[1].checked=="" && form.family_status[2].checked=="" && form.family_status[3].checked=="") { alert("Please select famil status"); form.family_status[0].focus(); return false; }

    //if(form.family_type[0].checked=="" && form.family_type[1].checked=="") { alert("Please select famil type"); form.family_type[0].focus(); return false; }

    //if(form.family_value[0].checked=="" && form.family_value[1].checked=="" && form.family_value[2].checked=="" && form.family_value[3].checked=="") { alert("Please select famil value"); form.family_value[0].focus(); return false; }


    if(form.height_ft.value=="" && form.height_cms.value=="") { alert("Please select height"); form.height_ft.focus(); return false; }

    if(form.weight.value=="") { alert("Please select weight"); form.weight.focus(); return false; }


    if(form.star.value=="") { alert("Please select star"); form.star.focus(); return false; }

    if(form.rasi.value=="") { alert("Please select rasi"); form.rasi.focus(); return false; }

    if(form.lagnam.value=="") { alert("Please select lagnam"); form.lagnam.focus(); return false; }

    // if(form.thisai_irrupu.value=="") { alert("Please enter thisai irrupu"); form.thisai_irrupu.focus(); return false; }

    if(form.dosham.value=="yes") {

      if(form.dosham_details.value=="") { alert("Please enter dosham details"); form.dosham_details.focus(); return false; }

      }

    if(form.registeredBy.value=="") { alert("Please select registered by"); form.registeredBy.focus(); return false; }

}
    </script>
    <script type="text/javascript">
   function callfn(form)
 
 {

if(form.send_remarks.value=="") { alert("Please enter remarks"); form.send_remarks.focus(); return false; }

if(form.enter_by.value=="") { alert("Please enter enter by"); form.enter_by.focus(); return false; }

 }

</script>
   <?php include("includes/headertop.php");?>
   <body class="home color-green boxed shadow">
      <div class="root">
         <?php include("includes/header.php");?>
         <section class="content reverse" style=" width: 100%;">
            <section>
                <?php if($_GET['type'] == 'error'){ ?>
                <div  id="message_container" style="text-align: center; color: red;font-size: 18px; ">
                    <span id="">Failed to send. please enter your primary mobile no</span>
                </div>
                <?php } ?>
                <div  id="message_container" style="text-align: center; display: none; color: red;font-size: 18px; ">
                    <span id="message"></span>
                </div>
               <section class="columns" style="margin-top:10px !important;  width: 90%;">
                  <h2><span>Registered Members details</span></h2>
                  
                  
                  <div style=" width: 28%; float: right; ">
                  <form method="post">

                  <input type="hidden" name="profile_send_id" value="<?php echo $profile['id']; ?>">
                  <input type="hidden" name="profile_send_name" value="<?php echo $profile['km_name']; ?>">
                  <input type="hidden" name="profile_send_mobile" value="<?php echo $profile['km_mobile']; ?>">
                  <input type="hidden" name="profile_send_email" value="<?php echo $profile['km_email']; ?>">

                  <input type="hidden" name="submit_id" value="<?php echo $profile['id']; ?>">

                  <span style=" color: #00a651; font-size: 20px;">SMS :</span><br>
                  <?php if($_GET['type'] == 'paid'){ ?>
                  <input type="submit" name="paid_member" value="Become paid member" style="    border: 0px;padding: 0px;margin-bottom: 5px;color: red;;">
                  <?php } else { ?>
                  <input type="submit" name="paid_member" value="Become paid member" style="    border: 0px;padding: 0px;margin-bottom: 5px;color: blue;;">
                  <?php } ?>
                  <div style="clear:both;"></div>
                  <?php if($_GET['type'] == 'latest'){ ?>
                  <input type="submit" name="latest_profile" value="Latest profiles" style="    border: 0px;padding: 0px;margin-bottom: 5px;color: red;;">
                  <?php } else { ?>
                  <input type="submit" name="latest_profile" value="Latest profiles" style="    border: 0px;padding: 0px;margin-bottom: 5px;color: blue;;">
                  <?php } ?>
                  <div style="clear:both;"></div>
                  <?php if($_GET['type'] == 'user'){ ?>
                  <input type="submit" name="user_pass" value="Username and password" style="    border: 0px;padding: 0px;margin-bottom: 5px;color: red;;">
                  <?php } else { ?>
                  <input type="submit" name="user_pass" value="Username and password" style="    border: 0px;padding: 0px;margin-bottom: 5px;color: blue;;">
                  <?php } ?>
                  <div style="clear:both;"></div>
                   <?php if($_GET['type'] == 'photo'){ ?>
                  <input type="submit" name="send_photo" value="Send photo & Horoscope" style="    border: 0px;padding: 0px;margin-bottom: 5px;color: red;;">
                  <?php } else { ?>
                  <input type="submit" name="send_photo" value="Send photo & Horoscope" style="    border: 0px;padding: 0px;margin-bottom: 5px;color: blue;;">
                  <?php } ?>
                  <div style="clear:both;"></div>
                  <?php if($_GET['type'] == 'update'){ ?>
                  <input type="submit" name="update_profile" value="Update your profile" style="    border: 0px;padding: 0px;margin-bottom: 5px;color: red;;">
                  <?php } else { ?>
                  <input type="submit" name="update_profile" value="Update your profile" style="    border: 0px;padding: 0px;margin-bottom: 5px;color: blue;;">
                  <?php } ?>
                  
                  
                  <div style="clear:both;"></div>

                  <span style=" color: #00a651; font-size: 20px;">SMS History :</span><br>

                  <table class="table table-striped table-bordered table-hover" id="dataTables_customer" style="margin-top: 10px;">
                  <thead>
                  <tr class="center heading" style="background-color:#077907;border-color: #077907;color: white">
                    <th style="text-align: center;">Date</th>
                    <th style="text-align: center;">Remarks</th>
                   </tr> 
                  </thead>
                  <tbody>
                  <?php if($smshistorys){ foreach($smshistorys as $smshistory){ ?>
                  <tr>
                  <td style="text-align: center;"><?php echo date_format(new DateTime($smshistory['sms_date']), 'd-m-Y');?></td>
                  <td style="text-align: center;"><?php echo $smshistory['remarks'];?></td>
                  </tr>
                  <?php } } else { ?>
                  <tr>
                  <td colspan="4">No Records Found</td>
                  </tr>
                  <?php } ?>
                  </tbody>
                  </table>
                  </form>
                  <div style="clear:both;"></div>


                  <span style=" color: #00a651; font-size: 20px;">Photo :</span><br><br>
                  <img style="width:180px;height:200px;" src="<?php echo $imgPath; ?>">

                  <br><br>
                  <span style=" color: #00a651; font-size: 20px;">Horoscope :</span><br><br>
                  <?php if($horos['hs_imgPath']){?>
                  <img src="../<?php echo $horos['hs_imgPath'];?>" style=" max-width: 250px;">
                    <?php }else{ ?>
                        <p style="text-align: center;color:red;">Horoscope not available</p>
                    <?php } ?>

                  <br><br>
                  <span style=" color: red; font-size: 16px;font-weight: 600;">Total Login : &nbsp;<?php if($total_logincount){ echo $total_logincount; } else { echo 0; } ?></span><br><br>

                  <div style="clear:both;"></div>

                  <span style=" color: red; font-size: 16px;font-weight: 600;">Last Login : &nbsp;<?php if($lastloginhistory){ echo $lastloginhistory['logged_in_date'].' '.$lastloginhistory['logged_in_time']; } else { echo 'Not Login'; } ?></span><br><br>

                  <div style="clear:both;"></div>

                  <span style=" color: #00a651; font-size: 20px;">Call History :</span><br>

                  <table class="table table-striped table-bordered table-hover" id="dataTables_customer" style="margin-top: 10px;width:100%!important;">
                  <thead>
                  <tr class="center heading" style="background-color:#077907;border-color: #077907;color: white">
                    <th style="">Date</th>
                    <th style="">Remarks</th>
                    <th style="">By</th>
                   </tr> 
                  </thead>
                  <tbody>
                  <?php if($callhistorys){ foreach($callhistorys as $callhistory){ ?>
                  <tr>
                  <td style=""><?php echo date_format(new DateTime($callhistory['call_date']), 'd-m-Y');?></td>
                  <td style=""><?php echo $callhistory['remarks'];?></td>
                  <td style=""><?php echo $callhistory['enter_by'];?></td>
                  </tr>
                  <?php } } else { ?>
                  <tr>
                  <td colspan="4">No Records Found</td>
                  </tr>
                  <?php } ?>
                  </tbody>
                  </table>
                   <div style="clear:both;"></div>
                  <form method="post" name="callForm" onsubmit="return callfn(callForm);" >
                  <span style=" color: #00a651; font-size: 18px;">New Call :</span><br>

                  <input type="hidden" name="profile_call_id" value="<?php echo $profile['id']; ?>">

                  <input type="hidden" name="submit_id" value="<?php echo $profile['id']; ?>">

                  <span style=" color: black; font-size: 15px;">Date : &nbsp;<input type="text" readonly style="padding: 3px;width: 64%;margin-left: 9%;" name="send_date" value="<?php echo date("d-m-Y"); ?>"></span><br>

                  <span style=" color: black; font-size: 15px;">Remarks : &nbsp;<textarea   rows="2" style="min-width: unset!important;min-height: unset!important;" name="send_remarks" ></textarea></span><br><br>

                  <span style=" color: black; font-size: 15px;">Enter By : &nbsp;
                  <select name="enter_by" style="padding: 3px;width: 63%;" > 
                  <option value="" Selected Disabled>-- Select --</option>
                  <option value="Durga">Durga</option>
                  <option value="Sulthana">Sulthana</option>
                  <option value="Divvya">Divvya</option>
                  <option value="Mavitha">Mavitha</option>
                  <option value="Vimala">Vimala</option>
                  </select> 
                  </span><br><br>

                  <input type="submit" name="add_call" style="width: 25%;padding: 3px;background: #93bf1b;color: white;text-align: center;margin-left: 45%;" value="Save">
                  </form>

                  </div>
                  
                  
                  

                  <form  method="post" enctype="multipart/form-data" name="RegisterForm" onsubmit="return regform(RegisterForm);" autocomplete="off">


                  <input type="hidden" name="profile_edit_id" value="<?php echo $profile['id']; ?>">
                  <input type="hidden" name="occupation_old" value="<?php echo $profile['km_occupation']; ?>">

                     <div style="  width: 70%; float: left;">
                        <div style=" border: solid  1px #ccc; border-radius: 5px; padding: 20px;">
                       <table width="50%" border="0" style="font-size: 13px;">
                           <tbody>
                              <span style=" font-size: 20px; color: #0e4805; ;"> Personal Details</span>
                              <tr>
                                 <th>REG ID :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                     <input type="text" id="km_regcode"  name="km_regcode" readonly="" value="<?php echo $profile['km_regcode']?>" class="text" >
                                 </td>
                              </tr>
                              <tr>
                                 <th>Name :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                     <input type="text" id="member_name" name="member_name" placeholder="Name" value="<?php echo $profile['km_name']?>" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Password :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                     <input type="text" id="password" name="password" placeholder="Password" value="<?php echo $profile['km_password']?>" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th width="30%">Gender :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <label class="radio-inline" style="position: relative;bottom: 15px">
                                    <input name="gender" <?php if($profile['km_gender'] == 'female'){echo 'checked';}?> id="gender" type="radio" value="Female" >
                                    </label> Female
                                    <label class="radio-inline" style="position: relative;bottom: 12px">
                                    <input name="gender" <?php if($profile['km_gender'] == 'male'){echo 'checked';}?> id="gender" type="radio" value="Male" >
                                    </label> Male
                                 </td>
                              </tr>
                             <tr>
                                 <th>Caste :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                   
                                        <select style="opacity: 1;"  name="caste" id="castes">
                                                <option value="" Selected Disabled>-- Select Caste --</option>
                                                <?php foreach($castes as $caste){ ?>
                                                <option <?php if($caste['caste'] == $profile['km_caste']){ echo 'selected'; } ?> value="<?php echo $caste['caste']; ?>"><?php echo $caste['caste']; ?></option>
                                                <?php } ?>
                                             </select>
                                 </td>
                              </tr>
                                <tr>
                                 <th> Sub Caste :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                   
                                                   <select name="subcaste"  id="subcaste"  style="opacity: 1;">
                                       <option value="" selected disabled>-- Select State --</option>
                                       <?php foreach($subcastes as $subcaste){ ?>
                                       <option value="<?php echo $subcaste['subcaste'];?>" <?php if($profile['km_subcaste'] == $subcaste['subcaste']){ echo 'selected'; } ?>  ><?php echo $subcaste['subcaste'];?></option>
                                       <?php } ?>
                                    </select>
                                 </td>
                              </tr>
                              <tr>
                                 <th>Education :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <select name="education"   style="opacity: 1;">
                                       <option value="">-- Select Education --</option>
                                       <?php foreach($edu_array as $key => $value){ ?>
                                       <option <?php if($profile['km_education'] == $key){echo 'selected';}?> value="<?php echo $key;?>"><?php echo $value;?></option>
                                       <?php } ?>
                                    </select>
                                 </td>
                              </tr>
                              <tr>
                                 <th>Education Details (Optional) :   </th>
                                 <td>
                                     <textarea rows="4" style="min-height: inherit;" id="education_details" name="education_details" placeholder="Education Details" class="text" autocomplete="off" ><?php echo $profile['km_education_details'];?></textarea>
                                 </td>
                              </tr>
                              <tr>
                                 <th width="30%">Employed in :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <label class="radio-inline" style="position: relative;bottom: 15px">
                                    <input name="employedIn" <?php if($profile['km_employee_in'] == 'government'){echo 'checked';}?> id="employedIn" type="radio" value="government"  checked="">
                                    </label> Government
                                    <label class="radio-inline" style="position: relative;bottom: 12px">
                                    <input name="employedIn" <?php if($profile['km_employee_in'] == 'private'){echo 'checked';}?> id="employedIn" type="radio" value="private" >
                                    </label> Private
                                    <label class="radio-inline" style="position: relative;bottom: 11px">
                                    <input name="employedIn" <?php if($profile['km_employee_in'] == 'business'){echo 'checked';}?> id="employedIn" type="radio" value="business" >
                                    </label> Business
                                    <label class="radio-inline" style="position: relative;bottom: 11px">
                                    <input name="employedIn" <?php if($profile['km_employee_in'] == 'notworking'){echo 'checked';}?> id="employedIn" type="radio" value="notworking" >
                                    </label> Not Working
                                 </td>
                              </tr>
                              <!--<tr>-->
                              <!--   <th>Occupation Old :  <span style="color:#c03131;font-size: 20px;">  </span> </th>-->
                              <!--   <td>-->
                              <!--       <input type="text" value="<?php echo $occu_name; ?>" class="text" autocomplete="off"  >-->
                              <!--   </td>-->
                              <!--</tr>-->
                              <tr id="job1" <?php if($profile['km_employee_in'] == 'notworking'){ ?> style="display:none;" <?php } else { } ?>>
                                 <th>Occupation :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <select name="occupation"   style="opacity: 1;">
                                       <option value="">-- Select Occupation --</option>
                                       <?php foreach($occupations as $occupation){ ?>
                                       <option <?php if($profile['km_occupation'] == $occupation['id']){echo 'selected';}?> value="<?php echo $occupation['id'];?>"><?php echo $occupation['occupation'];?></option>
                                       <?php } ?>
                                    </select>
                                 </td>
                              </tr>
                            
                    
                              
                              <tr id="job2" <?php if($profile['km_employee_in'] == 'notworking'){ ?> style="display:none;" <?php } else { } ?>>
                                 <th>Occupation Details  :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                     <input type="text" id="occupation_details" value="<?php echo $profile['km_occupation_details'];?>" name="occupation_details" placeholder="Occupation Details" class="text" autocomplete="off" >
                                 </td>
                              </tr>
                              <tr id="job3" <?php if($profile['km_employee_in'] == 'notworking'){ ?> style="display:none;" <?php } else { } ?>>
                                 <th>Annual Income  :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                     <input type="text" id="annualIncome" value="<?php echo $profile['km_annual_income'];?>" name="annualIncome" placeholder="Annual Income" class="text" autocomplete="off"  onkeypress="return onlyNos(event,this);"   Maxlength="7" >
                                 </td>
                              </tr>

                              <tr>
                                 <th>Blood Group :  <span style="color:#c03131;font-size: 20px;">  </span> </th>
                                 <td>
                                    <select name="bloodgroup"   style="opacity: 1;">
                                       <option value="" selected disabled>-- Select Blood Group --</option>
                                       <?php foreach($blood_array as $key => $value){ ?>
                                       <option <?php if($profile['km_blood_group'] == $key){echo 'selected';}?> value="<?php echo $key;?>"><?php echo $value;?></option>
                                       <?php } ?>
                                       <?php 
                                      if($profile['km_blood_group'] == 'donotknow'){?>
                                      <option selected value="donotknow">- Don't Know -</option>     
                                      <?php
                                     }else{
                                      ?>
                                      <option value="donotknow">- Don't Know -</option>
                                     <?php } ?>
                                    </select>
                                 </td>
                              </tr>


                              <tr>
                                 <th>Door NO  :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                     <input type="text" id="doorNo" value="<?php echo $profile['km_doorno'];?>" name="doorNo" placeholder="Door NO" class="text" autocomplete="off" >
                                 </td>
                              </tr>
                              <tr>
                                 <th>Street Name :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                     <input type="text" id="street" value="<?php echo $profile['km_street'];?>" name="street" placeholder="Street Name" class="text" autocomplete="off" >
                                 </td>
                              </tr>
                              <tr>
                                 <th>City :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                     <input type="text" id="city" value="<?php echo $profile['km_city'];?>" name="city" placeholder="City" class="text" autocomplete="off" >
                                 </td>
                              </tr>
                              <tr>
                                 <th>Pincode :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                     <input type="text" id="pincode" value="<?php echo $profile['km_pincode'];?>" name="pincode" placeholder="Pincode" class="text" autocomplete="off" onkeypress="return onlyNos(event,this);"   Maxlength="6">
                                 </td>
                              </tr>
                              <tr>
                                 <th>State :<span style="color:#c03131;font-size: 20px;"> * </span></th>
                                 <td>
                                    <select name="state"  id="states"  style="opacity: 1;">
                                       <option value="" selected disabled>-- Select State --</option>
                                       <?php foreach($states as $state){ ?>
                                       <option value="<?php echo $state['id'];?>" <?php if($profile['km_state'] == $state['id']){ echo 'selected'; } ?>  ><?php echo $state['name'];?></option>
                                       <?php } ?>
                                    </select>
                                 </td>
                              </tr>

                              <tr>
                                 <th>District :<span style="color:#c03131;font-size: 20px;"> * </span></th>
                                 <td>
                                    <select name="district" id="districts"  style="opacity: 1;">
                                       <option value="" selected disabled>-- Select District --</option>
                                       <?php foreach($editdistricts as $district){ ?>
                                       <option value="<?php echo $district['id'];?>" <?php if($profile['km_district'] == $district['id']){ echo 'selected'; } ?>><?php echo $district['name'];?></option>
                                       <?php } ?>
                                    </select>
                                 </td>
                              </tr>
                              
                              <tr>
                                 <th>Email :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                     <input type="email" value="<?php echo $profile['km_email'];?>" name="email" id="email" class="text" placeholder="Email"  autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Mobile No :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                     <input type="text" value="<?php echo $profile['km_mobile'];?>" name="mobile" id="mobile" class="text" placeholder="Mobile No."  onkeypress="return onlyNos(event,this);" autocomplete="off"  Maxlength="10">
                                 </td>
                              </tr>
                               <tr>
                                 <th>Secondary Mobile No :  <span style="color:#c03131;font-size: 20px;">  </span> </th>
                                 <td>
                                     <input type="text" value="<?php echo $profile['km_second_mobile'];?>" name="second_mobile" id="second_mobile" class="text" placeholder="Mobile No."  onkeypress="return onlyNos(event,this);"  autocomplete="off" Maxlength="10">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Landline No (Optional):</th>
                                 <td>
                                 <?php
                                 $landlin = explode("-", $profile['km_landline']);
                                 ?>
                                    <input type="text" id="landline_code" name="landline_code" class="text" value="<?php echo $landlin[0];?>" style="width:20%;float:left;" placeholder="Landline Code."  onkeypress="return Number(event,this);" Maxlength="5">
                                    <input type="text" id="landline" name="landline" class="text" style="width:80%" value="<?php echo $landlin[1];?>" placeholder="Landline No."  onkeypress="return Number(event,this);" Maxlength="8">
                                 </td>
                              </tr>
                              <tr>
                                 <th width="30%">Marital Status :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <label class="radio-inline" style="position: relative;bottom: 15px">
                                    <input name="marital_status" <?php if($profile['km_marital_status'] == 'unmarried'){echo 'checked';}?> id="marital_status" type="radio" value="unMarried">
                                    </label> Unmarried
                                    <label class="radio-inline"  style="position: relative;bottom: 12px">
                                    <input name="marital_status" <?php if($profile['km_marital_status'] == 'widower'){echo 'checked';}?> id="marital_status" type="radio" value="widower" >
                                    </label> Widower
                                    <label class="radio-inline" style="position: relative;bottom: 11px">
                                    <input name="marital_status" <?php if($profile['km_marital_status'] == 'divorced'){echo 'checked';}?> id="marital_status" type="radio" value="divorced" >
                                    </label> Divorced
                                    <label class="radio-inline" style="position: relative;bottom: 11px">
                                    <input name="marital_status" <?php if($profile['km_marital_status'] == 'awaiting'){echo 'checked';}?> id="marital_status" type="radio" value="awaiting" >
                                    </label> Awaiting Divorce
                                 </td>
                              </tr>
                              <tr>
                                 <th>Languages Known :  <span style="color:#c03131;font-size: 20px;">  </span> </th>
                                 <td>
                                     <input type="text" id="languagesKnown" value="<?php echo $profile['km_languages']; ?>" name="languagesKnown" placeholder="Languages Known" class="text" autocomplete="off">
                                     <span>For Example (Tamil, English, .. etc)</span>
                                 </td>
                              </tr>
                              <tr>
                                 <th width="30%">Physical status :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <label class="radio-inline" style="position: relative;bottom: 15px">
                                    <input name="physical_status" <?php if($profile['km_physical_status'] == 'normal'){echo 'checked';}?> id="physical_status" type="radio" value="normal" >
                                    </label> Normal 
                                    <label class="radio-inline" style="position: relative;bottom: 12px">
                                    <input name="physical_status" <?php if($profile['km_physical_status'] == 'challenged'){echo 'checked';}?>  id="physical_status" type="radio" value="challenged" >
                                    </label> Physically challenged
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </div>
                        <br>
                        <div style=" border: solid  1px #ccc; border-radius: 5px; padding: 20px;">
                            <table style="font-size: 13px;">
                           <tbody>
                              <span style=" font-size: 20px; color: #0e4805; ;"> Family Status</span>
                              <tr>
                                 <th>Father's Name :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" value="<?php echo $profile['km_father_name']; ?>" id="father_name" name="father_name" placeholder="Father's Name" class="text"  autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Father's Occupation :  <span style="color:#c03131;font-size: 20px;"> </span> </th>
                                 <td>
                                     <input type="text" value="<?php echo $profile['km_father_occupation']; ?>" id="father_occupation" name="father_occupation" placeholder="Father's Occupation" class="text" autocomplete="off" >
                                 </td>
                              </tr>
                              <tr>
                                 <th>Mother's Name :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" value="<?php echo $profile['km_mother_name']; ?>" id="mother_name" name="mother_name" placeholder="Mother's Name" class="text"  autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Mother's Occupation :  <span style="color:#c03131;font-size: 20px;">  </span> </th>
                                 <td>
                                    <input type="text" value="<?php echo $profile['km_mother_occupation']; ?>" id="mother_occupation" name="mother_occupation" placeholder="Mother's Occupation" class="text" >
                                 </td>
                              </tr>
                              <tr>
                                 <th>D.O.B :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <table width="100%" style="font-size: 13px;">
                                       <tbody>
                                          <tr>
                                              <?php
                                              $split_date = explode('-', $profile['km_dateofbirth']);
                                              ?>
                                             <td style=" margin: 0px; padding: 0px;">
                                                <select name="date"  style="opacity: 1;width: 64px;">
                                                    <option value=""  disabled>- Date -</option>
                                                    <?php foreach($date_array as $date){?>
                                                    <option <?php if($split_date[2] == $date){echo 'selected';}?> value="<?php echo $date; ?>"><?php echo $date; ?></option>
                                                    <?php } ?>
                                                </select>
                                                </span>
                                             </td>
                                             <td>
                                                <select name="month"  style="opacity: 1;width: 76px;">
                                                    <option value="" disabled>- Month -</option>
                                                    <?php foreach($month_array as $key => $month){?>
                                                    <option <?php if($split_date[1] == $key){echo 'selected';}?> value="<?php echo $key; ?>"><?php echo $month; ?></option>
                                                    <?php } ?>
                                                </select>
                                                </span>
                                             </td>
                                             <td>
                                                <select name="year"  style="opacity: 1;width: 64px;">
                                                    <option value=""  disabled>- Year -</option>
                                                    <?php for($year = date('Y')-18;$year >= date('Y')-50;$year--){?>
                                                    <option <?php if($split_date[0] == $year){echo 'selected';}?> value="<?php echo $year; ?>"><?php echo $year; ?></option>
                                                    <?php } ?>
                                                 </select>
                                                </span>
                                             </td>
                                             <td>
                                                <select name="day"  style="opacity: 1;">
                                                    <option value="" disabled>- Day -</option>
                                                    <?php foreach($day_array as $day){?>
                                                    <option <?php if($profile['km_dayofbirth'] == $day){echo 'selected';}?> value="<?php echo $day; ?>"><?php echo $day; ?></option>
                                                    <?php } 
                                                    if($profile['km_dayofbirth'] == 'donotknow'){?>
                                                    <option selected value="donotknow">- Don't Know -</option>
                                                        
                                                   <?php
                                                   }else{
                                                    ?>
                                                    <option value="donotknow">- Don't Know -</option>
                                                   <?php } ?>
                                                </select>
                                                </span>
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>

                               <?php
                              $km_birth = explode(' ', $profile['km_birthtime']);

                              $birth_mery = $km_birth[1];

                              $birth_b = explode(":", $km_birth[0]);
                              
                              ?>
                              <tr>
                                 <th>Time of Birth :</th>
                                 <td>
                                    <table width="100%">
                                       <tbody>
                                          <tr>
                                             <td style=" margin: 0px; padding: 0px;">
                                                <select  name="birthhour" >
                                             <option value="" Selected Disabled>Hours</option>
                                             <?php for($hours = 1; $hours <= 12; $hours++ ){ ?>
                                             <option <?php if($birth_b[0] == $hours){echo 'selected';}?> value="<?php echo $hours; ?>"><?php echo $hours; ?></option>
                                             <?php } ?>
                                          </select>
                                             
                                             </td>
                                             <td>
                                                <select  name="birthmins" >
                                             <option value="" Selected Disabled>Mins</option>
                                             <?php for($mins = 0; $mins <= 59; $mins++ ){ ?>
                                            <option <?php if($birth_b[1] == $mins){echo 'selected';}?>  value="<?php echo $mins; ?>"><?php echo $mins; ?></option>
                                            <?php } ?>
                                          </select>
                                             </td>
                                             <td>
                                                <select  name="birthmeridium" >
                                             <option value="" Selected Disabled>Select</option>
                                             <option value="AM" <?php if($birth_mery == 'AM'){echo 'selected';}?>>AM</option>
                                             <option value="PM" <?php if($birth_mery == 'PM'){echo 'selected';}?>>PM</option>
                                          </select>
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>


                              <tr>
                                 <th>Place of Birth :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" value="<?php echo $profile['km_place_of_birth']; ?>" id="place_of_birth" name="place_of_birth" placeholder="Place of Birth" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Order by Birth :</th>
                                 <td>
                                 <select  id="order_of_place" name="order_of_place" >
                                  <option value="" Selected Disabled> --- Select --- </option>
                                  <?php for($oob = 1; $oob <= 10; $oob++ ){ ?>
                                  <option <?php if($profile['km_order_of_birth'] == $oob){echo 'selected';}?> value="<?php echo $oob; ?>"><?php echo $oob; ?></option>
                                  <?php } ?>
                               </select>
                                 </td>
                              </tr>
                              <tr>
                                 <th>House Name :  <span style="color:#c03131;font-size: 20px;">  </span> </th>
                                 <td>
                                    <input type="text" value="<?php echo $profile['km_housename']; ?>" id="house_name" name="house_name" placeholder="House Name" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Gothram :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" value="<?php echo $profile['km_gothram']; ?>" id="gothram" name="gothram" placeholder="Gothram" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Native Place :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" value="<?php echo $profile['km_native_place']; ?>" id="native" name="native" placeholder="Native Place" class="text" autocomplete="off">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Native District :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <input type="text" value="<?php echo $profile['km_native_district']; ?>" id="native_district" placeholder="Native District" name="native_district" class="text" autocomplete="off">
                                 </td>
                              </tr>

                              <tr>
                            <th width="30%">Family Status :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                            <td>
                               <label class="radio-inline" style="position: relative;bottom: 15px">
                               <input name="family_status" <?php if($profile['km_family_status'] == 'middle'){echo 'checked';}?> id="family_status" type="radio" value="middle">
                               </label> Middle class
                               <label class="radio-inline" style="position: relative;bottom: 12px">
                               <input name="family_status" <?php if($profile['km_family_status'] == 'uppermiddle'){echo 'checked';}?> id="family_status" type="radio" value="uppermiddle" >
                               </label> Upper middle class
                               <label class="radio-inline" style="position: relative;bottom: 11px">
                               <input name="family_status" <?php if($profile['km_family_status'] == 'rich'){echo 'checked';}?> id="family_status" type="radio" value="rich" >
                               </label> Rich
                               <label class="radio-inline" style="position: relative;bottom: 11px">
                               <input name="family_status" <?php if($profile['km_family_status'] == 'affluent'){echo 'checked';}?> id="family_status" type="radio" value="affluent" >
                               </label> Affluent
                            </td>
                            </tr>
                            <tr>
                            <th width="30%">Family Type :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                            <td>
                               <label class="radio-inline" style="position: relative;bottom: 15px">
                               <input name="family_type" <?php if($profile['km_family_type'] == 'joint'){echo 'checked';}?> id="family_type" type="radio" value="joint">
                               </label> Joint
                               <label class="radio-inline" style="position: relative;bottom: 12px">
                               <input name="family_type" <?php if($profile['km_family_type'] == 'nuclear'){echo 'checked';}?> id="family_type" type="radio" value="nuclear" >
                               </label> Nuclear
                            </td>
                            </tr>
                            <tr>
                            <th width="30%">Family Values :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                            <td>
                               <label class="radio-inline" style="position: relative;bottom: 15px">
                               <input name="family_value" <?php if($profile['km_family_value'] == 'orthodox'){echo 'checked';}?> id="family_value" type="radio" value="orthodox">
                               </label> Orthodox
                               <label class="radio-inline" style="position: relative;bottom: 12px">
                               <input name="family_value" <?php if($profile['km_family_value'] == 'traditional'){echo 'checked';}?> id="family_value" type="radio" value="traditional" >
                               </label> Traditional
                               <label class="radio-inline" style="position: relative;bottom: 11px">
                               <input name="family_value" <?php if($profile['km_family_value'] == 'moderate'){echo 'checked';}?> id="family_value" type="radio" value="moderate" >
                               </label> Moderate
                               <label class="radio-inline" style="position: relative;bottom: 11px">
                               <input name="family_value" <?php if($profile['km_family_value'] == 'liberal'){echo 'checked';}?> id="family_value" type="radio" value="liberal" >
                               </label> Liberal
                            </td>
                            </tr>
                            <tr>
                                 <th>No. of Brother(s) Unmarried:</th>
                                 <td>
                                    <table width="100%">
                                       <tbody>
                                          <tr>
                                             <td style=" margin: 0px; padding: 0px;">
                                                <select id="bthrs" name="bcount" style="width: 20%;">
                                                <option value="" Selected Disabled>Select</option>
                                                <?php for($bro = 0; $bro <= 10; $bro++ ){ ?>
                                                <option  <?php if($profile['bcount'] != ''){ if($profile['bcount'] == $bro){echo 'selected';} } ?>  value="<?php echo $bro; ?>" style="color: rgb(0, 79, 0);"><?php echo $bro; ?></option>
                                                 <?php } ?>
                                                </select>
                                                &nbsp; &nbsp; &nbsp;
                                                No. of Brother(s) Married  &nbsp; 
                                                <select id="bthrsm" name="bmcount" style="width: 20%;">
                                                <option value="" Selected Disabled>Select</option>
                                                <?php for($mbro = 0; $mbro <= 10; $mbro++ ){ ?>
                                                <option <?php if($profile['bmcount'] != ''){ if($profile['bmcount'] == $mbro){echo 'selected';} } ?>  value="<?php echo $mbro; ?>" style="color: rgb(0, 79, 0);"><?php echo $mbro; ?></option>
                                                 <?php } ?>
                                                </select>
                                                
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>


                                <tr>
                                 <th>No. of Sister(s) Unmarried:</th>
                                 <td>
                                    <table width="100%">
                                       <tbody>
                                          <tr>
                                             <td style=" margin: 0px; padding: 0px;">
                                                <select id="sisters" name="scount" style="width: 20%;">
                                               <option value="" Selected Disabled>Select</option>
                                              <?php for($sis = 0; $sis <= 10; $sis++ ){ ?>
                                              <option <?php if($profile['scount'] != ''){ if($profile['scount'] == $sis){echo 'selected';} } ?>  value="<?php echo $sis; ?>" style="color: rgb(0, 79, 0);"><?php echo $sis; ?></option>
                                               <?php } ?>
                                              </select>
                                              &nbsp; &nbsp; &nbsp;
                                              No. of Sister(s) Married  &nbsp; 
                                              <select id="sisterscount" name="smcount" style="width: 20%;">
                                              <option value="" Selected Disabled>Select</option>
                                              <?php for($msis = 0; $msis <= 10; $msis++ ){ ?>
                                              <option <?php if($profile['smcount'] != ''){ if($profile['smcount'] == $msis){echo 'selected';} } ?>  value="<?php echo $msis; ?>" style="color: rgb(0, 79, 0);"><?php echo $msis; ?></option>
                                               <?php } ?>
                                              </select>
                                                
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>



                              <?php
                              $split_height = explode(' ', $profile['km_height']);
                              
                              ?>

                              <tr>
                                 <th>Height :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <table width="100%">
                                       <tbody>
                                           <tr style="font-size: 13px;">
                                             <td style=" margin: 0px; padding: 0px;">
                                                <select name="height_ft" id="height_ft" style="opacity: 1;">
                                                    <option <?php if($split_height[1] == 'Cms'){echo 'selected';}?> value=""  disabled>- Feet & Inches -</option>
                                                    <?php foreach($height_array as $height => $height_str){?>
                                                    <option <?php if($split_height[1] != 'Cms' && $height_str == $profile['km_height'] ){ echo 'selected'; }else{ echo '';}?> value="<?php echo $height_str; ?>"><?php echo $height_str; ?></option>
                                                    <?php } ?>
                                                </select>
                                                
                                             </td>
                                             <td>(Or)</td>
                                             <td>
                                                <select name="height_cms" id="height_cms"  style="opacity: 1;">
                                                    <option <?php if($split_height[1] != 'Cms'){echo 'selected';}?> value=""  disabled>- Cms -</option>
                                                    <?php for($height = 135;$height <= 210;$height++){
                                                        $heightChk = $height.' Cms';
                                                        ?>
                                                    <option <?php if($split_height[1] == 'Cms' && $heightChk == $profile['km_height'] ){ echo 'selected'; }?> value="<?php echo $height.' Cms'; ?>"><?php echo $height.' Cms'; ?></option>
                                                    <?php } ?>
                                                 </select>
                                                
                                             </td>
                                             
                                             
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>


                                <tr>
                                 <th>Weight :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <span class="select">
                                      <select name="weight"  style="opacity: 1;">
                                          <option value="" disabled>- Weight -</option>
                                          <?php for($weight = 40;$weight <= 150;$weight++){
                                              $weightChk = $weight.' Kgs';
                                              ?>
                                          <option <?php if($weightChk == $profile['km_weight'] ){ echo 'selected'; }?> value="<?php echo $weight.' Kgs'; ?>"><?php echo $weight.' Kgs'; ?></option>
                                          <?php } ?>
                                       </select>
                                    </span>
                                 </td>
                              </tr>


                               <tr>
                                 <th>Star :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <span class="select">
                                      
                                       <select name="star"  style="opacity: 1;">
                                          <option value="" selected disabled>- Star -</option>
                                          <?php foreach($stars_array as $star){?>
                                          <option <?php if($star == $profile['km_star'] ){ echo 'selected'; }?> value="<?php echo $star; ?>"><?php echo $star; ?></option>
                                          <?php } ?>
                                       </select>
                                    </span>
                                 </td>
                              </tr>


                               <tr>
                                 <th>Raasi :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <span class="select">
                                      <select name="rasi"  style="opacity: 1;">
                                          <option value="" disabled>- Raasi -</option>
                                          <?php foreach($rasi_array as $rasi){?>
                                          <option <?php if($rasi == $profile['km_rasi'] ){ echo 'selected'; }?> value="<?php echo $rasi; ?>"><?php echo $rasi; ?></option>
                                          <?php } ?>
                                       </select>
                                    </span>
                                 </td>
                              </tr>


                               <tr>
                                 <th>Lagnam :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <span class="select">
                                      <select name="lagnam"  style="opacity: 1;">
                                          <option value="" selected disabled>- Lagnam -</option>
                                          <?php foreach($rasi_array as $lagnam){?>
                                          <option <?php if($lagnam == $profile['km_lagnam'] ){ echo 'selected'; }?> value="<?php echo $lagnam; ?>"><?php echo $lagnam; ?></option>
                                          
                                          <?php } 
                                                    if($profile['km_lagnam'] == 'donotknow'){?>
                                                    <option selected value="donotknow">- Don't Know -</option>
                                                        
                                                    <?php
                                                   }else{
                                                    ?>
                                                    <option value="donotknow">- Don't Know -</option>
                                                   <?php } ?>
                                          
                                       </select>
                                    </span>
                                 </td>
                              </tr>


                              <tr>
                                 <th>Thisai Irrupu :  <span style="color:#c03131;font-size: 20px;">  </span> </th>
                                 <td>
                                    <input type="text" id="thisai_irrupu" value="<?php echo $profile['km_thisai_irrupu']; ?>" name="thisai_irrupu" placeholder ='Thisai Irrupu' class="text" autocomplete="off">
                                 </td>
                              </tr>


                              <tr>
                                 <th width="30%">Dosham  :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <label class="radio-inline" style="position: relative;bottom: 15px">
                                    <input name="dosham" <?php if($profile['km_dosham'] == 'yes'){echo 'checked';}?>  id="dosham" type="radio" value="yes">
                                    </label> Yes
                                    <label class="radio-inline" style="position: relative;bottom: 12px">
                                    <input name="dosham" <?php if($profile['km_dosham'] == 'no'){echo 'checked';}?>  id="dosham" type="radio" value="no" >
                                    </label> No
                                    <label class="radio-inline" style="position: relative;bottom: 11px">
                                    <input name="dosham" <?php if($profile['km_dosham'] == 'dontknow'){echo 'checked';}?>  id="dosham" type="radio" value="dontknow">
                                    </label> Don't Know
                                 </td>
                              </tr>
                              <tr id="detail_dosham" <?php if($profile['km_dosham'] == 'yes'){ } else {  ?> style="display:none;" <?php } ?> >
                                 <th>Dosham Details  :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                     <input type="text" id="dosham_details" name="dosham_details" placeholder="Dosham Details" class="text" autocomplete="off" value="<?php echo $profile['km_dosham_details']; ?>">
                                 </td>
                              </tr>
                              <tr>
                                 <th>Registered Date :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <!--<input type="text" name="registered_date"  class="text"  id="registered_date">-->
                                    <input class="form-control text" type="text" name="registered_date" id="registered_date" data-field="datetime" data-date-format="DD-MM-YYYY"  value="<?php echo date_format(new DateTime($profile['km_registered_date']), 'd-m-Y'); ?>" readonly autocomplete="off" style="width: 145px;" >
                                   
                                 </td>
                              </tr>
                              <tr>
                                 <th>Registered By :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    <span class="select">
                                      <select name="registeredBy"  style="opacity: 1;">
                                          <option value="" disabled>- Registered By -</option>
                                          <?php foreach($registeredBy_array as $registeredBy){?>
                                          <option <?php if($registeredBy == $profile['km_registered_by'] ){ echo 'selected'; }?> value="<?php echo $registeredBy; ?>"><?php echo $registeredBy; ?></option>
                                          <?php } ?>
                                       </select>
                                    </span>
                                 </td>
                              </tr>
                              <tr>
                                 <th>Profile Status :  <span style="color:#c03131;font-size: 20px;"> * </span> </th>
                                 <td>
                                    
                                        
                                      <select name="status_val"  style="opacity: 1;">
                                          <option  value="" selected disabled>- Status -</option>
                                          
                                         <?php foreach($profileStatus_array as $prof){ ?>
                                       <option <?php if($profile['km_status'] == $prof){echo 'selected';}?> value="<?php echo $prof;?>"><?php echo $prof;?></option>
                                       <?php } ?>
                                       </select>
                                    </span>
                                 </td>
                              </tr>
                              
                              <tr>
                                 <th></th>
                                 <td>
                                    <input type="submit" name="btn_update" value="SUBMIT" style="background:#93bf1b;color:#ffffff;margin-top:10px;" onclick="return validateUserInfo();">
                                 </td>
                              </tr>
                     </div>
                     </tbody>
                     </table>
                        </div>
                     </div>
                     
                  </form>
               </section>
            </section>
         </section>
         <div style=" clear: both;"></div>
         <?php include("includes/footer.php");?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
 <script language="Javascript" type="text/javascript">
   function onlyNos(e, t) {
       try {
           if (window.event) {
               var charCode = window.event.keyCode;
           }
           else if (e) {
               var charCode = e.which;
           }
           else { return true; }
           if (charCode > 31 && (charCode < 48 || charCode > 57)) {
               return false;
           }
           return true;
       }
       catch (err) {
           alert(err.Description);
       }
   }
   
</script>
  <script>
    $(document).ready(function() {
      var Stats = JSON.parse('<?php echo $castesEncoded; ?>');
      var Dist = JSON.parse('<?php echo $subcastesEncoded; ?>');

      $('#castes').change(function() {
        var categoryId12 = $(this).val();

        $('#subcastes').empty();
        $('#subcastes').append('<option value="" selected disabled>-- Select --</option>');

        $.each(Dist, function(index, element){
          if(element.caste == categoryId12) {
            
            $('#subcastes').append('<option value="' + element.id + '">' + element.subcaste + '</option>');
          }
        });
      });
    });

</script>
<script type="text/javascript">
  $(document).ready(function() {
  $('input[name="dosham"]').click(function() 
   {
    var value = $(this).val();
    if( value == "yes")
    {
    $("#detail_dosham").show();
    }
    else{
    $("#detail_dosham").hide();
    }
  });
});
</script>
 <script type="text/javascript">
  $(document).on('click', '#employedIn', function() {
           var Gend = $(this).val();
            if(Gend == 'notworking'){
                $('#job1').hide();
                $('#job2').hide();
                $('#job3').hide();
            } else {
                $('#job1').show();
                $('#job2').show();
                $('#job3').show();
            }
        });
    
</script>
 <script>
    

    $(document).ready(function() {
      var Stats = JSON.parse('<?php echo $statesEncoded; ?>');
      var Dist = JSON.parse('<?php echo $districtsEncoded; ?>');

      $('#states').change(function() {
        var categoryId = $(this).val();

        $('#districts').empty();
        $('#districts').append('<option value="" selected disabled>-- Select District--</option>');

        $.each(Dist, function(index, element) {
          if(element.state_id == categoryId) {
            $('#districts').append('<option value="' + element.id + '">' + element.name + '</option>');
          }
        });
      });
    });
  
</script>
<script type="text/javascript">

         $(document ).on('keyup','#email', function () {
          var Email_ID = $('#email').val();
          var KMID = $('#km_regcode').val();
          //alert(Email_ID);
          if(Email_ID){
          $.ajax({
          type:'post',
          url:'register_update_validation.php',
          data:{
              flag:'EMail',
              km_Code : KMID,
              gmail : Email_ID,
          },
          success:function(response) {
          var response = response.split("-");
          if(response[0] == 'exists'){
            alert('Email ID already registered..enter another email id');
            document.getElementById("email").value = '';
            document.getElementById("email").focus();
          }
          }
          }); 
            }
          });

         $(document ).on('keyup','#mobile', function () {
          var Mobile_No = $('#mobile').val();
          var KMID = $('#km_regcode').val();
          //alert(Mobile_No);
          if(Mobile_No){
          $.ajax({
          type:'post',
          url:'register_update_validation.php',
          data:{
              flag:'MobileNo',
              km_Code : KMID,
              phone : Mobile_No,
          },
          success:function(response) {
          var response = response.split("-");
          if(response[0] == 'exists'){
            alert('Mobile No already registered..enter another mobile no');
            document.getElementById("mobile").value = '';
            document.getElementById("mobile").focus();
          }
          }
          }); 
            }
          });

         $(document ).on('keyup','#second_mobile', function () {
      var sec_Mobile_No = $('#second_mobile').val();
      var KMID = $('#km_regcode').val();
      if(sec_Mobile_No){
      $.ajax({
      type:'post',
      url:'register_update_validation.php',
      data:{
          flag:'Sec_MobileNo',
          km_Code : KMID,
          sec_phone : sec_Mobile_No,
      },
      success:function(response) {
      var response = response.split("-");
      if(response[0] == 'exists'){
        alert('Secondary Mobile No already registered..enter another secondary mobile no');
        document.getElementById("second_mobile").value = '';
      }
      }
      }); 
        }
      });
 
      </script>
         <?php
        if(isset($result)) {
    ?>
        <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(50000, function() {
                            $('#message').text("");
                            $('#username').focus();
                    });
            }, 50000);
        </script>
    <?php
            }
    ?>
        
      </div>
   </body
   
</html>