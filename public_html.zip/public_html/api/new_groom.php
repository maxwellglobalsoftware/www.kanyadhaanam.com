<?php
header('Content-Type: application/json');
 include("../dbConfig.php");
//   require_once '../init.php';
//     require_once '../KpJMony@321/includes/configure.php';
    //require_once '../KpJMony@321/includes/configure.php';


  

                    
     $newbride = "SELECT * FROM registration LEFT JOIN districts ON districts.id = registration.km_district LEFT JOIN photo_details ON photo_details.pho_userId = registration.km_regcode WHERE registration.km_gender = 'male' AND registration.km_status ='live' GROUP by registration.km_regcode ORDER BY registration.km_regcode DESC LIMIT 30";

  
    $result = $conn->query($newbride);
    if ($result->num_rows > 0)
        {
        while ($row = $result->fetch_assoc())
            {
           $output[] = $row;
           $data = array("message_code"=>1,"data"=>$output);
            }

       
        }
      else
        {
             $result = array("message_code"=>0);
        }
    
     echo json_encode($data);


?>


 
