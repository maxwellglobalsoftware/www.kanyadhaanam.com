<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
ob_start();
session_start();
date_default_timezone_set('Asia/Kolkata');

 include("../dbConfig.php");


$name = $_POST['name'];
$gender = $_POST['gender'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$dob = $_POST['dob'];
$caste = $_POST['caste'];
$sub_caste = $_POST['sub_caste'];

 $register = "SELECT * FROM registration WHERE `km_email` = '$email'";

    $result = $conn->query($register);
    if ($result->num_rows > 0)
        {
        while ($row = $result->fetch_assoc())
            {
          
          echo json_encode(array("response" => 0));
            }

       
        }
        else
        {

$to = "nivetha@maxwellsoftware.com";
$subject = "Registration from www.weddingkondattam.com";

$msg= "<table>
<tr><td align='right'>Name&nbsp;:&nbsp;</td><td>$name</td></tr>
<tr><td align='right'>Gender&nbsp;:&nbsp;</td><td>$gender</td></tr>
<tr><td align='right'>Mobile No&nbsp;:&nbsp;</td><td>$phone</td></tr>
<tr><td align='right'>Email ID&nbsp;:&nbsp;</td><td>$email</td></tr>
<tr><td align='right'>Date of Birth&nbsp;:&nbsp;</td><td>$dob</td></tr>
<tr><td align='right'>Caste&nbsp;:&nbsp;</td><td>$caste</td></tr>
<tr><td align='right'>Subcate&nbsp;:&nbsp;</td><td>$sub_caste</td></tr>
</table><br>";


//Always set content-type when sending HTML email
$headers.= "MIME-version: 1.0\n";
$headers.= "Content-type: text/html; charset= iso-8859-1\n";

//More headers
$headers .= 'From: <donotreply@weddingkondattam.com>' . "\r\n";

$send = mail($to,$subject,$msg,$headers);

if($send){
	$result = "success";
	$s_name = $name;
	$s_email = $email;
	$s_phone  = $phone;
	
	echo json_encode(array("response" => $result,"name" => $s_name, "email" => $s_email, "phone" => $s_phone));
} else {
	$result = "failed";
	
	echo json_encode(array("response" => $result));
}

}

?>

