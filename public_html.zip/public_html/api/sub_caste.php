<?php
header('Content-Type: application/json');
 include("../dbConfig.php");

        $caste = $_POST['caste'];
            
     $caste = "SELECT * FROM sub_caste where caste = '$caste'";

   
    $result = $conn->query($caste);
    if ($result->num_rows > 0)
        {
        while ($row = $result->fetch_assoc())
            {
          $Output[] = $row;
          
          $data = array("message_code"=>1,"data"=>$Output);
            
            }

       
        }
      else
        {
            $result = array("message_code"=>0);
        }
    
     echo json_encode($data);


?>


 
