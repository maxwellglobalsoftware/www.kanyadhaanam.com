<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
   ini_set('memory_limit','256M');
       ob_start();
       session_start();
       if($_SESSION['User_Kamma_Matri']){
           unset($_SESSION['User_Kamma_Matri']);
       }
       date_default_timezone_set('Asia/Kolkata');
       require_once 'init.php';
       require_once 'includes/visitor_count.php';
       require_once 'KANyaMatrI_GST/includes/configure.php';
 $postData = $statusMsg = ''; 
$status = 'error'; 


   
   if(isset($_POST['registeSubmit'])){
     $postData = $_POST; 

     if(isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])){ 
            // Google reCAPTCHA API secret key 
            $secretKey = '6Lc7pKIUAAAAAIP2UYp8boPSggrpTILmGEaGqqoo'; 
             
            // Verify the reCAPTCHA response 
            $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secretKey.'&response='.$_POST['g-recaptcha-response']); 
             
            // Decode json data 
            $responseData = json_decode($verifyResponse); 
             
            // If reCAPTCHA response is valid 
            if($responseData->success){ 
    $member_name = $_POST['member_name'];
    $gender = $_POST['gender'];
    $mobile_no = $_POST['mobile'];
    $mailid = $_POST['email'];
    $caste = $_POST['caste'];
    $subcaste = $_POST['subcaste'];
    $date_of_birth = $_POST['date'].'-'.$_POST['month'].'-'.$_POST['year'];

    $_SESSION['member_name']=$member_name;
    $_SESSION['gender']=$gender;
    $_SESSION['mobile_no']=$mobile_no;
    $_SESSION['mailid']=$mailid;
    $_SESSION['caste']=$caste;
    $_SESSION['subcaste']=$subcaste;
    $_SESSION['date']=$_POST['date'];
    $_SESSION['month'] = $_POST['month'];
    $_SESSION['year'] = $_POST['year'];
   
    $msg= "<table>
   
   <p>Dear {$member_name},</p>
   <tr><td align='left' style='font-size: 18px;line-height: 1.5em;'>Your first step of the sign up process completed in KANYADHAANAM MATRIMONY.</td></tr>
   
   <tr><td align='left' style='font-size: 18px;line-height: 1.5em;'>To get your Username & password Kindly send your full bio-data,photo & horoscope to support@kanyadhaanam.com (or) send through whatsapp  95000 90825. if u have any questions please contact us 95000 90825</td></tr>
   
   <tr style='font-size: 18px;line-height: 1.5em;'><td>Regards</tr></td>
   <tr style='font-size: 18px;line-height: 1.5em;'><td>KANYADHAANAM MATRIMONY - TEAM</tr></td>
   <tr style='font-size: 18px;line-height: 1.5em;'><td>www.kanyadhaanam.com</tr></td>
   </table><br>";
   $cu_date = date("d-m-Y");
   $to = $mailid;
   $subject = $cu_date." - First step of registration Completed in KANYADHAANAM MATRIMONY";
   
   // Always set content-type when sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    
    // More headers
    $headers .= 'From: <support@kanyadhaanam.com>' . "\r\n";
    
    $m = mail($to,$subject,$msg,$headers);
   
   $super_msg= "<table>
          <tr><td align='right'>Name&nbsp;:&nbsp;</td><td>$member_name</td></tr>
          <tr><td align='right'>Gender&nbsp;:&nbsp;</td><td>$gender</td></tr>
          <tr><td align='right'>Mobile No&nbsp;:&nbsp;</td><td>$mobile_no</td></tr>
          <tr><td align='right'>Email ID&nbsp;:&nbsp;</td><td>$mailid</td></tr>
          <tr><td align='right'>Date of Birth&nbsp;:&nbsp;</td><td>$date_of_birth</td></tr>
          </table><br>";
   
   
   $super_to = "support@kanyadhaanam.com";
   $super_subject = "Customer Basic registration details from kanyadhaanam.com";
   
   // Always set content-type when sending HTML email
    $super_headers = "MIME-Version: 1.0" . "\r\n";
    $super_headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    
    // More headers
    $super_headers .= 'From: <support@kanyadhaanam.com>' . "\r\n";
    
    $super_m = mail($super_to,$super_subject,$super_msg,$super_headers);
           $status = 'success'; 
                $statusMsg = 'Your contact request has submitted successfully.'; 
                $postData = '';
                 header("Location: registration.php");
            }else{ 
                $statusMsg = 'Robot verification failed, please try again.'; 
            } 
        }else{ 
            $statusMsg = '<span style="color:red;">Please check on the reCAPTCHA box.</span>'; 
        } 
   
    }
   
       if(isset($_POST['go'])) {
           $username = $_POST['username'];
           $password = $_POST['password'];
   
           $user = new Registration();
           $user = $user->login($username, $password);  
           if($user) {
               $data = array();
               $data[] = $_SESSION['User_Kamma_Matri']['id'];
               $data[] = date_format(new DateTime(), 'd-m-Y');
               $data[] = date_format(new DateTime(), 'h:i A');
   
               $login = new Login();
               $login = $login->setLogin($data);
   
               $_SESSION['logged_id'] = $login->lastInsertID(); 
               
               $today = date('Y-m-d');
           
               $paymentIDs = new Payment();
               $paymentIDs = $paymentIDs->fetch("WHERE pl_userId = '{$_SESSION['User_Kamma_Matri']['km_regcode']}'  ORDER BY id DESC LIMIT 1")->resultSet(); 
               $paymentID = $paymentIDs[0];
            
            
           $payments = new Payment();
           $payments = $payments->fetch("WHERE pl_userId = '{$_SESSION['User_Kamma_Matri']['km_regcode']}' AND id = '{$paymentID['id']}' AND pl_status = 'activate' AND '{$today}' BETWEEN pl_startDate AND pl_expireDate ORDER BY id DESC")->resultSet(); 
           $payment = $payments[0];
    
          // if($payment){
          //  header('Location: profiles.php');
          // } else {
          //  header('Location: membership_pay.php');
          // }
          
          if($paymentID){
              if($payment){
              header('Location: profiles.php');
             } else {
              header('Location: membership_pay.php');
             }
             } else {
              header('Location: profiles.php');
             }
       
       
            //   header('Location: profiles.php');
           } else {
               echo '<script>window.alert("Please enter valid User ID and/or Password");</script>';
               echo '<script>window.location="index.php"</script>';
   //            header('Location: index.php');
           }
       }
       //*********************** Female Profile Details *******************************
       $female_profiles = new Registration();
       $female_profiles = $female_profiles->fetch("WHERE km_gender = 'female' AND km_status = 'live' ORDER BY id DESC ")->resultSet(); 
       
       //*********************** Male Profile Details *******************************
       $male_profiles = new Registration();
       $male_profiles = $male_profiles->fetch("WHERE km_gender = 'male' AND km_status = 'live' ORDER BY id DESC ")->resultSet();  
       
        //// States /////
    $castes = new Registration();
    $castes = $castes->fetchCastes("ORDER BY caste ASC")->resultSet();

    $castesEncoded = json_encode($castes); 

    //// subcastes /////
    $subcastes = new Registration();
    $subcastes = $subcastes->fetchSubcastes("ORDER BY subcaste ASC")->resultSet();

    $subcastesEncoded = json_encode($subcastes);
       
   ?>
<!DOCTYPE html>
<html>
   <head>
      <title>Top Brahmin Matrimony, Top Brahmin Community Matrimony</title>
      <meta name="description" content="Kanniyadhaanam Matrimony, we are one of the leading Top Brahmin Matrimony and Top Brahmin Community Matrimony in Chennai, Tamilnadu. We offered the best service in all over Tamil Nadu without no issues. Our valuable customers should assist our staff guidance at any time for your profile clarifications."/>
      <meta name="keywords" content="Top Brahmin Matrimony, Top Brahmin Community Matrimony, Top Brahmin Matrimony Tamilnadu, Top Brahmin Community Matrimony Tamilnadu, Brahmin Matrimony Chennai"/>
      <script src="https://www.google.com/recaptcha/api.js" async defer></script>
      <link rel="canonical" href="http://www.kanyadhaanam.com/basicregister.php" />
      <?php include("includes/headertop.php");?>
      
   </head>
   </head>
   <body class="home color-green boxed shadow">
      <?php include("includes/header.php");?>
      <div style=" clear:both;"></div>
      <section id="register-home">
         <div class="container">
            <div class="row">
               <div class="col-sm-6 col-xs-12">
                  <h4 style="font-size: 45px;">
                     Registration
                  </h4>
               </div>
            </div>
         </div>
      </section>
      <div class="form-type-one">
         <div class="root">
            <section class="content reverse">
               <section class="main">
                  <style type="text/css">
                     .form-horizontal .control-label {
                     padding-top: 0px !important;
                     margin-bottom: 0;
                     text-align: left;
                     margin-bottom: 10px;
                     }
                     input[type=text], input[type=password]{
                     margin: 0px !important
                     }
                     .home-form-dob {
                     /* width: 29%;*/
                     padding-left: 0px;
                     }
                     .landing-form select {
                     width: 100%;
                     padding: 5px 5px;
                     }
                     .radio-inline input[type=radio] {
                     margin-top: 3px !important;
                     }
                     .checkbox input[type=checkbox], .checkbox-inline input[type=checkbox], .radio input[type=radio], .radio-inline input[type=radio]{
                     margin: 4px 0 0;
                     margin-left: -20px;
                     }
                     @media (max-width: 800px) {
                     .landing-form .col-md-7{
                     width: 100% !important; 
                     float: left;
                     padding-top: 0px;
                     font-size: 12px;
                     }
                     .landing-form .col-md-5{
                     width: 70% !important;
                     float: right;
                     padding-left: 0px;
                     clear: both; 
                     }
                     }
                  </style>
                  <style type="text/css">
                     .capbox {
                     border-width: 0px 12px 0px 0px;
                     display: inline-block;
                     *display: inline; zoom: 1; 
                     width: 100%;
                     /*padding: 0px !important*/
                     }
                     .capbox-inner {
                     font: bold 11px arial, sans-serif;
                     color: #000000;
                     background-color: #ffffff;
                     padding: 3px;
                     -moz-border-radius: 4px;
                     -webkit-border-radius: 4px;
                     border-radius: 0px;
                     /*margin-top: 0px;*/
                     }
                     #CaptchaDiv {
                     font: bold 17px verdana, arial, sans-serif;
                     font-style: italic;
                     color: #000000;
                     background-color: #FFFFFF;
                     padding: 8px;
                     -moz-border-radius: 4px;
                     -webkit-border-radius: 4px;
                     border-radius: 4px;
                     width: 100%;
                     }
                     #CaptchaInput { width: 100%;
                     padding: 8px;
                     font-size: 16px;
                     border: none;
                     border-radius: 0px;
                     border: solid 1px #ccc;}
                     .noleft{
                     padding-left: 0px !important
                     }
                     .nobottom{
                     margin-bottom: 5px !important;
                     padding-top: 10px;
                     clear: both;
                     }
                     .noright{
                     padding-left: 0px !important
                     }
                     .form-group {
                     margin-bottom: 10px !important;
                     }
                     input[type="radio"] {
                     -ms-transform: scale(1.5); /* IE 9 */
                     -webkit-transform: scale(1.5); /* Chrome, Safari, Opera */
                     transform: scale(1.5);
                     }
                  </style>
                  <script>
                     function homefn(form){
                         
                         var re = /^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$/;
                         
                         var numbers = /^[0-9]+$/; 
                         
                         if(form.member_name.value=="") { alert("Please enter name"); form.member_name.focus(); return false; }
                         
                          if(form.mobile.value=="") { alert("Please enter mobile number"); form.mobile.focus(); return false; }
                          if(form.mobile.value!="")
                          {
                          if(!form.mobile.value.match(numbers))  
                          {  
                          
                          alert('Please enter mobile number with only numbers');  
                          form.mobile.focus(); return false;
                          } 
                          if (form.mobile.value.length <10 && form.mobile.value.length != 10)
                          { 
                          alert('Please enter your 10 digits mobile number exactly');  
                          form.mobile.focus(); return false; 
                          } 
                          
                          }
                          
                          if(form.email.value=="") { alert("Please enter your Email ID"); form.email.focus(); return false; }
                          
                          if(form.email.value!="")
                          {
                          if(!form.email.value.match(re))  
                          {  
                          
                          alert('Please enter valid Email ID');  
                          form.email.focus(); return false;
                          }  
                          }
                          
                          
                    

                          
                          if(form.date.value=="" && form.month.value=="" && form.year.value=="") { alert("Please select date of birth"); form.date.focus(); return false; }
                          
                          if(form.date.value=="") { alert("Please select date"); form.date.focus(); return false; }
                          
                          if(form.month.value=="") { alert("Please select month"); form.month.focus(); return false; }
                          
                          if(form.year.value=="") { alert("Please select year"); form.year.focus(); return false; }
                          
                                if(form.caste.value=="") { alert("Please select caste"); form.caste.focus(); return false; }
                          
                          if(form.subcaste.value=="") { alert("Please select subcaste"); form.subcaste.focus(); return false; }
                          
                          var why = "";
                           
                           if(form.CaptchaInput.value == ""){
                           why += "- Please Enter CAPTCHA Code.\n";
                           form.CaptchaInput.focus();
                           }
                           if(form.CaptchaInput.value != ""){
                           if(ValidCaptcha(form.CaptchaInput.value) == false){
                           why += "- The CAPTCHA Code Does Not Match.\n";
                           form.CaptchaInput.focus();
                           }
                           }
                           if(why != ""){
                           alert(why);
                           return false;
                           }
                         
                         
                     }
                  </script>
                       <script>
    $(document).ready(function() {
      var Stats = JSON.parse('<?php echo $castesEncoded; ?>');
      var Dist = JSON.parse('<?php echo $subcastesEncoded; ?>');

      $('#castes').change(function() {
        var categoryId12 = $(this).val();

        $('#subcastes').empty();
        $('#subcastes').append('<option value="" selected disabled>-- Select --</option>');

        $.each(Dist, function(index, element){
          if(element.caste == categoryId12) {
            
            $('#subcastes').append('<option value="' + element.id + '">' + element.subcaste + '</option>');
          }
        });
      });
    });

</script>
                  <section class="landing-form">
                     <div class="bform-content">
                        <div class="form-horizontal form-card">
                           <h4 class="form"><img src="images/interview.png" width="40" height="40" class=""> Your Search is few clicks away...</h4>
                           <form method="post" id="homeForm" action="" name="homeForm" class="form"  onsubmit="return homefn(homeForm);">
                              <div class="col-md-12">
                                 <div class="form-group">
                                 <div class="row">

                                    <div class="col-md-1 col-xs-12">
                                       <label class="control-label">Gender</label>
                                    </div>
                                    <div class="col-md-11 col-xs-12">
                                       <label class="radio-inline radio-label" style=" color: #000;">
                                       <input type="radio" name="gender" checked="" value="Female">
                                       Female &nbsp; &nbsp; </label>
                                       <label class="radio-inline radio-label" style="color: #000;">
                                       <input type="radio" name="gender" value="Male">
                                       Male </label>
                                    </div>

                                    </div>


                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="form-group">
                                    <label class=" control-label">Name</label>
                                    <input type="text" class="form-control" id="member_name" name="member_name" placeholder="Name" autocomplete="off" value="<?php echo !empty($postData['member_name'])?$postData['member_name']:''; ?>" >
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="form-group">
                                    <label class="control-label">Mobile No.</label>
                                    <input class="form-control numberonly" name="mobile" id="mobile" maxlength="10" placeholder="Mobile No" autocomplete="off" onkeypress="return Number(event,this);" value="<?php echo !empty($postData['mobile'])?$postData['mobile']:''; ?>">
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="form-group">
                                    <label class="control-label">E-mail ID</label>
                                    <input type="text" class="form-control"  name="email" id="email" placeholder="Email ID" autocomplete="off" value="<?php echo !empty($postData['email'])?$postData['email']:''; ?>">
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="form-group">
                                    <label class="control-label">Date of birth</label>
                                    <br>
                                    <div style=" clear: both;"></div>
                                    <div>
                                       <label class="pad0 home-form-dob col-md-4 col-sm-4">
                                          <select class="form-control" name="date" >
                                             <option value="" selected disabled>DD</option>
                                             <?php foreach($date_array as $date){?>
                                             <option value="<?php echo $date; ?>" <?php if(!empty($postData['date']==$date)) {echo "selected";}else{} ?>><?php echo $date; ?></option>
                                             <?php } ?>
                                          </select>
                                       </label>
                                       <label class=" pad0 home-form-dob col-md-4 col-sm-4">
                                          <select class="form-control" name="month" >
                                             <option value="" selected disabled>MM</option>
                                             <?php foreach($month_array as $key => $month){?>
                                             <option value="<?php echo $key; ?>" <?php if(!empty($postData['month']==$key)) {echo "selected";}else{} ?>><?php echo $month; ?></option>
                                             <?php } ?>
                                          </select>
                                       </label>
                                       <label class=" pad0 home-form-dob col-md-4 col-sm-4">
                                          <select class="form-control" name="year" >
                                             <option value="" selected disabled>YYYY</option>
                                             <?php for($year = date('Y')-18;$year >= date('Y')-50;$year--){?>
                                             <option value="<?php echo $year; ?>" <?php if(!empty($postData['year']==$year)) {echo "selected";}else{} ?>><?php echo $year; ?></option>
                                             <?php } ?>
                                          </select>
                                       </label>
                                    </div>
                                 </div>
                              </div>
                             <div class="col-md-6">
                                 <div class="form-group">
                                    <label class=" control-label">Caste</label>
                                             <select  class="form-control chosen-select"  name="caste" id="castes">
                                                <option value="" Selected Disabled>-- Select --</option>
                                                <?php foreach($castes as $caste){ ?>
                                                <option value="<?php echo $caste['id']; ?>"><?php echo $caste['caste']; ?></option>
                                                <?php } ?>
                                             </select>
                                          </div>
                                       </div>
                                        
                                       <div class="col-md-6">
                                          <div class="form-group">
                                             <label class=" control-label">Sub Caste</label>
                                             <select  class="form-control chosen-select"  name="subcaste" id="subcastes">
                                                <option value="" Selected Disabled>-- Select --</option>
                                             </select>
                                          </div>
                                       </div>
                              <div style=" clear: both;"></div>
                              <center>

                              <?php if(!empty($statusMsg)){ ?>
    <p class="status-msg <?php echo $status; ?>"><?php echo $statusMsg; ?></p>
<?php } ?>
  <div class="g-recaptcha" data-sitekey="6Lc7pKIUAAAAANoJ3Ty4it31y0bdljF_P2zNdUFp"></div>
</center>
                            <!--   <div class="col-md-12">
                                 <div class="row">
                                    <div class="form-group">
                                       <div class="col-sm-1 col-md-1 col-lg-1 col-xs-12">
                                          <div class="input-group forcap">
                                             <div class="capbox">
                                                <div id="CaptchaDiv">86372</div>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-sm-2 col-md-2 col-lg-2 col-xs-12">
                                          <div class="capbox-inner">
                                            
                                             <input type="hidden" id="txtCaptcha" value="86372">
                                             <input type="text" name="CaptchaInput" id="CaptchaInput" Maxlength="5" placeholder="Enter Captcha" onkeypress="return Number(event,this);"><br>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div> -->
                              <!-- <script>
                                 var a = Math.ceil(Math.random() * 9)+ '';
                                 var b = Math.ceil(Math.random() * 9)+ '';
                                 var c = Math.ceil(Math.random() * 9)+ '';
                                 var d = Math.ceil(Math.random() * 9)+ '';
                                 var e = Math.ceil(Math.random() * 9)+ '';
                                 
                                 var code = a + b + c + d + e;
                                 document.getElementById("txtCaptcha").value = code;
                                 document.getElementById("CaptchaDiv").innerHTML = code;
                                 
                                 // Validate input against the generated number
                                 function ValidCaptcha(){
                                 var str1 = removeSpaces(document.getElementById('txtCaptcha').value);
                                 var str2 = removeSpaces(document.getElementById('CaptchaInput').value);
                                 if (str1 == str2){
                                 return true;
                                 }else{
                                 return false;
                                 }
                                 }
                                 
                                 // Remove the spaces from the entered and generated code
                                 function removeSpaces(string){
                                 return string.split(' ').join('');
                                 }
                              </script> -->
                              <div style=" clear: both;"></div>
                             
                              <div class="col-md-6">
                                 <div class="row">
                                    <div class="form-group">
                                       <div class="col-sm-6 col-md-6">
                                          <input type="submit" name="registeSubmit" class="btn-contact" value="REGISTER NOW">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </form>
                        </div>
                     </div>
                  </section>
                  <script language="Javascript" type="text/javascript">
                     function Number(e, t) {
                         try {
                             if (window.event) {
                                 var charCode = window.event.keyCode;
                             }
                             else if (e) {
                                 var charCode = e.which;
                             }
                             else { return true; }
                             if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                                 return false;
                             }
                             return true;
                         }
                         catch (err) {
                             alert(err.Description);
                         }
                     }
                     
                  </script>
                  <script type="text/javascript">
                     $(document ).on('keyup','#mobile', function () {
                      var Mobile_No = $('#mobile').val();
                      //alert(Mobile_No);
                      if(Mobile_No){
                      $.ajax({
                      type:'post',
                      url:'register_validation.php',
                      data:{
                          flag:'MobileNo',
                          phone : Mobile_No,
                      },
                      success:function(response) {
                      var response = response.split("-");
                      if(response[0] == 'exists'){
                        alert('Mobile No already registered..enter another mobile no');
                        document.getElementById("mobile").value = '';
                        document.getElementById("mobile").focus();
                      }
                      }
                      }); 
                      }
                      });
                     
                     $(document ).on('keyup','#second_mobile', function () {
                     var sec_Mobile_No = $('#second_mobile').val();
                     if(sec_Mobile_No){
                     $.ajax({
                     type:'post',
                     url:'register_validation.php',
                     data:{
                      flag:'Sec_MobileNo',
                      sec_phone : sec_Mobile_No,
                     },
                     success:function(response) {
                     var response = response.split("-");
                     if(response[0] == 'exists'){
                     alert('Secondary Mobile No already registered..enter another secondary mobile no');
                     document.getElementById("second_mobile").value = '';
                     }
                     }
                     }); 
                     }
                     });
                     
                     $(document ).on('keyup','#email', function () {
                      var Email_ID = $('#email').val();
                      if(Email_ID){
                      $.ajax({
                      type:'post',
                      url:'register_validation.php',
                      data:{
                          flag:'EMail',
                          gmail : Email_ID,
                      },
                      success:function(response) {
                      var response = response.split("-");
                      if(response[0] == 'exists'){
                        alert('Email ID already registered..enter another email id');
                        document.getElementById("email").value = '';
                        document.getElementById("email").focus();
                      }
                      }
                      }); 
                      }
                      });
                     
                     
                  </script>
               </section>
            </section>
            <div style=" clear: both;"></div>
         </div>
      </div>
      <div style=" clear: both;"></div>
     <!--  <script src="js/jquery-1.12.4.js"></script> -->
      <?php include("includes/footer.php");?>
      <script src="js/jquery.js"></script>  
      <script>
         // $(document).ready(function() {
         //     $('#username').focus();
         // }); 
         $(document).on('click', '.display_msg', function() {  
             alert('Please Login to view Profile');
             $('#username').focus();
             return false;
         });
         
      </script> 
   </body>
</html>