<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   require_once 'KANyaMatrI_GST/includes/configure.php';
   require_once 'includes/session_handler.php';
   require_once 'init.php';
   
   $profileId = $_SESSION['User_Kamma_Matri']['km_regcode'];
   //*********************** Horoscope Details *******************************
   $profiles = new Registration();
   $profiles = $profiles->fetch("WHERE km_regcode = '{$profileId}'")->resultSet();    
   $profile = $profiles[0];
   
   if(isset($_SESSION['pwdUpdate'])) {
       if($_SESSION['pwdUpdate']) {
           $result = "Password updated successfully";
       } else {
           $result = "Failed to update Password";
       }
       unset($_SESSION['pwdUpdate']);
   }
   if(isset($_SESSION['msg'])){
       $result = $_SESSION['msg']; 
       unset($_SESSION['msg']);
   }
   
   if(isset($_POST['btn_chgpwd'])) {      
       $data = array();   
       
       $oldpwd = $_POST['oldpwd'];
       $newpwd = $_POST['newpwd'];
       $confirmpwd = $_POST['confirmpwd'];
       if($oldpwd == $profile['km_password']){        
           if($newpwd == $confirmpwd){
               $data[] = $newpwd;
               $data[] = $profileId;
               $registration = new Registration();
               $registration = $registration->updatePassword($data);
               $payment_id = $registration->rowCount();
               if($payment_id){   
                   $_SESSION['flag'] = 'success';
                   $_SESSION['pwdUpdate'] = true;
               } else {
                   $_SESSION['flag'] = 'fail';
                   $_SESSION['pwdUpdate'] = false;
               }
           }else{
               $_SESSION['flag'] = 'newpwd';
               $_SESSION['msg'] = 'New and Confirm password doesnot match';
           }
           $_SESSION['oldpwd'] = $oldpwd;
       }else{
           $_SESSION['oldpwd'] = '';
           $_SESSION['flag'] = 'oldpwd';
           $_SESSION['msg'] = 'Please enter valid Old Password';
       }
       
       
       header("Location: change_password.php");
   }
   ?>
<!DOCTYPE html>
<html>
   <?php include("includes/headertop.php");?>
   <script type="text/javascript">
      function changefn(form)
      
      {
      
      if(form.oldpwd.value=="") { alert("Please Enter old Password"); form.oldpwd.focus(); return false; }
      
      if(form.newpwd.value=="") { alert("Please Enter New Password"); form.newpwd.focus(); return false; }
      
      if(form.confirmpwd.value=="") { alert("Please Enter Confirm Password"); form.confirmpwd.focus(); return false; }
      
      if(form.confirmpwd.value!=form.newpwd.value) { alert("Password mismatch"); form.confirmpwd.focus(); return false; }
      
      }
      
   </script>
   <body class="home color-green boxed shadow">
      
         <?php include("includes/headerin.php");?>
         
            <script src="js/jquery-1.12.4.js"></script>
           
            <?php include("includes/bannerin.php");?>
        
         <?php //include("includes/quicksearch.php");?>
         <div class="root">
         <section class="content reverse">
         <?php include("includes/right.php");?>
            <section class="col-md-9 col-xs-12" style=" margin-top: 1%;">
               <table>
                  <tr class="tabletitle" >
                     <td colspan="2" style="  border-top-left-radius: 0.5em; border-top-right-radius: 0.5em;">Change Password</td>
                  </tr>
               </table>
               <div id="result-content">
                  <div  id="message_container" style="text-align: center; display: none; color: red;font-size: 15px; font-weight: bold">
                     <span id="message"></span>
                  </div>
                  <form action="" method="post" enctype="multipart/form-data" name="ChangeForm" onsubmit="return changefn(ChangeForm);">
                     <table   border="0" style=" width: 60%" class="fullwidth">
                        <tbody>
                           <tr>
                              <th style=" padding-left: 10px;">Old Password :</th>
                              <td>
                                 <input type="text" id="oldpwd" name="oldpwd" placeholder="Old Password" class="text" value="<?php echo $_POST['oldpwd']; ?>" >
                              </td>
                           </tr>
                           <tr>
                              <th style=" padding-left: 10px;">New Password :</th>
                              <td>
                                 <input type="password" id="newpwd" name="newpwd" placeholder="New Password" class="text" >
                              </td>
                           </tr>
                           <tr>
                              <th style=" padding-left: 10px;">Confirm Password :</th>
                              <td>
                                 <input type="password" id="confirmpwd" name="confirmpwd" placeholder="Confirm Password" class="text" >
                              </td>
                           </tr>
                           <tr>
                              <td colspan="2">
                                 <input type="submit" name="btn_chgpwd" value="Change Password" style="background:#93bf1b;color:#ffffff;margin-top:10px;margin-left: 50%;" onclick="return validateUserInfo();">
                              </td>
                           </tr>
                        </tbody>
                     </table>
                  </form>
                  <br> 
               </div>
            </section>
            
         </section>
         <div style=" clear: both;"></div>
         </div>
         <?php include("includes/footertop.php");?>
         <?php include("includes/footerin.php");?>
         <?php
            if(isset($result)) {
            ?>
         <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(2000, function() {
                            $('#message').text("");
                            <?php 
               if($_SESSION['flag'] == 'newpwd'){
                   ?>
                                $('#oldpwd').val('<?php echo $_SESSION['oldpwd']; ?>');
                                
                                $('#newpwd').focus();
                           <?php }else if($_SESSION['flag'] == 'oldpwd'){
               ?>
                                            $('#oldpwd').focus();
                                            <?php
               }else if($_SESSION['flag'] == 'fail'){
                ?>
                                 $('#oldpwd').focus();
                                 <?php   
               }else{?>
                                
                          <?php  }
               ?>
                    });
            }, 2000);
         </script>
         <?php
            }
            ?>
      
   </body>
</html>