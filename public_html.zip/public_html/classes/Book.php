<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php

	class Book {

		private $_db = null;

		public function __construct() {
			$this->_db = Database::getInstance();
		}

	////////////////// Booking Details //////////////////
		public function add($data = array()) {
			$sql = "
				INSERT INTO book_details (
					type,
					user_id,
					name,
					phone,
					email,
					d_no,
					street,
					city,
					district,
					landmark,
					pincode,
					state,
					subscription,
					paid_date,
					expiry_date,
					reg_date,
					paid_type
				) VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? 
				)
			";

			$query = $this->_db->query($sql, $data);
                        
                        return $query;
		}

		public function fetch($condition = null) {
			$sql = "
				SELECT *
				FROM book_details
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

		public function update($data) {
			$sql = "
				UPDATE book_details
				SET 
                type = ?,
				user_id = ?,
				name = ?,
				phone = ?,
				email = ?,
				d_no = ?,
				street = ?,
				city = ?,
				district = ?,
				landmark = ?,
				pincode = ?,
				state = ?,
				subscription = ?,
				paid_date = ?,
				expiry_date = ?,
				paid_type = ?
                
				WHERE id = ?
			";
			
			$query = $this->_db->query($sql, $data);

			return $query;
		}

		public function remove($data = array()) {
            $sql = "
                DELETE
                FROM book_details 
                                WHERE id = ?
            ";
            $query = $this->_db->query($sql, $data);

            return $query;
        }

	}

?>