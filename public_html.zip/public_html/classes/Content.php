<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php

	class Content {

		private $_db = null;

		public function __construct() {
			$this->_db = Database::getInstance();
		}

	////////////////// States //////////////////


		public function fetchState($condition = null) {
			$sql = "
				SELECT *
				FROM states
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

		////////////////// Cities //////////////////


		public function fetchDistrict($condition = null) {
			$sql = "
				SELECT *
				FROM districts
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

	}

?>