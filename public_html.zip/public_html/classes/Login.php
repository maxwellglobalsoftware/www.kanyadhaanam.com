<?php

	 class Login {

	 	private $_db = null;
	 	private $_loginId = null;

	 	public function __construct() {
	 		$this->_db = Database::getInstance();
	 	}

	 	public function setLogin($data) {
	 		$sql = "
	 			INSERT INTO login_history_details (
	 				user_id,
	 				logged_in_date,
	 				logged_in_time,
	 				reg_date,
	 				reg_time
	 			) VALUES (
	 				?, ?, ?, CURDATE(), CURTIME()
	 			)
	 		";

	 		$query = $this->_db->query($sql, $data);

	 		return $query;
	 	}

	 	public function setLogout($data) {
	 		$sql = "
	 			UPDATE login_history_details
	 			SET logged_out_time = ?
	 			WHERE id = ?
	 		";

	 		$query = $this->_db->query($sql, $data);

	 		return $query;
	 	}


	 	public function getLoginHistory() {
	 		$sql = "
	 			SELECT *
	 			FROM login_history_details
	 			WHERE logged_out_time != 'NULL'
	 		";

	 		$query = $this->_db->query($sql);

	 		return $query;
	 	}
	 	
	 	public function fetchLogin($condition = null) {
			$sql = "
				SELECT *
				FROM login_history_details
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}
		
		public function addVisitor($data) {
	 		$sql = "
	 			INSERT INTO visitor_count (
	 				vc_session_id,
	 				visiter_ip,
	 				visitin_date
	 			) VALUES (
	 				?, ?, ?
	 			)
	 		";

	 		$query = $this->_db->query($sql, $data);

	 		return $query;
	 	}

	 	public function fetchVisitor($condition = null) {
			$sql = "
				SELECT *
				FROM visitor_count
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

	 }

?>