<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php

	class OTP {

		private $_db = null;

		public function __construct() {
			$this->_db = Database::getInstance();
		}

		public function add($data = array()) {
			$sql = "
				INSERT INTO otp_verify (
					pl_userId,
					pl_primary_mobile,
					pl_primary_code,
					pl_primary_status,					
					pl_secondary_mobile,
					pl_secondary_code,
					pl_secondary_status,	
					reg_date,
					reg_time
				) VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?
				)
			";

			$query = $this->_db->query($sql, $data);
                        
                        return $query;
		}

		public function fetch($condition = null) {
			$sql = "
				SELECT *
				FROM otp_verify
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

		public function update($data) {
			$sql = "
				UPDATE otp_verify
				SET 
                pl_userId = ?,
                pl_primary_mobile = ?,
                pl_primary_code = ?,
                pl_primary_status = ?,					
                pl_secondary_mobile = ?,
                pl_secondary_code = ?,
                pl_secondary_status = ?
				WHERE id = ?
			";
			
			$query = $this->_db->query($sql, $data);

			return $query;
		}
		
		
		////////////// Forget OTP /////////////////

		public function addForgetOTP($data = array()) {
			$sql = "
				INSERT INTO forget_otp (
					pl_userId,
					email_id,
					otp_code,	
					reg_date,
					reg_time
				) VALUES (
                    ?, ?, ?, CURDATE(), CURTIME()
				)
			";

			$query = $this->_db->query($sql, $data);
                        
                        return $query;
		}

		public function fetchForgetOTP($condition = null) {
			$sql = "
				SELECT *
				FROM forget_otp
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

		public function updateForgetOTP($data) {
			$sql = "
				UPDATE forget_otp
				SET 
                pl_userId = ?,
                email_id = ?,
                otp_code = ?
				WHERE pl_userId = ?
			";
			
			$query = $this->_db->query($sql, $data);

			return $query;
		}
		
		
		
		
		
		
		
		///////// email //////////
		
		public function addEmail($data = array()) {
			$sql = "
				INSERT INTO email_verify (
					pl_userId,
					pl_primary_email,
					pl_primary_code,
					pl_primary_status,					
					reg_date,
					reg_time
				) VALUES (
                    ?, ?, ?, ?, ?, ?
				)
			";

			$query = $this->_db->query($sql, $data);
                        
                        return $query;
		}

		public function fetchEmail($condition = null) {
			$sql = "
				SELECT *
				FROM email_verify
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

		public function updateEmail($data) {
			$sql = "
				UPDATE email_verify
				SET 
                pl_userId = ?,
                pl_primary_email = ?,
                pl_primary_code = ?,
                pl_primary_status = ?					
				WHERE id = ?
			";
			
			$query = $this->_db->query($sql, $data);

			return $query;
		}
		

	}

?>