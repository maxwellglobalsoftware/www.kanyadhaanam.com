<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php

	class Partner {

		private $_db = null;

		public function __construct() {
			$this->_db = Database::getInstance();
		}

	////////////////// Partner Preferences //////////////////
		public function add($data = array()) {
			$sql = "
				INSERT INTO partner_preferences (
					pl_userId,
					age_from,
					age_to,
					education,					
					star,
					reg_date,
					reg_time
				) VALUES (
                    ?, ?, ?, ?, ?, ?, ?
				)
			";

			$query = $this->_db->query($sql, $data);
                        
                        return $query;
		}

		public function fetch($condition = null) {
			$sql = "
				SELECT *
				FROM partner_preferences
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

		public function update($data) {
			$sql = "
				UPDATE partner_preferences
				SET 
                pl_userId = ?,
                age_from = ?,
                age_to = ?,
                education = ?,					
                star = ?,
                reg_date = ?,
                reg_time = ?
                
				WHERE id = ?
			";
			
			$query = $this->_db->query($sql, $data);

			return $query;
		}


	////////////////// Shortlist //////////////////
		public function addShortList($data = array()) {
			$sql = "
				INSERT INTO shortlist_profiles (
					pl_userId,
					pv_viewedId,
					pl_viewedDate,
					reg_date,
					reg_time
				) VALUES (
                    ?, ?, ?, CURDATE(), CURTIME()
				)
			";

			$query = $this->_db->query($sql, $data);
                        
                        return $query;
		}

		public function fetchShortList($condition = null) {
			$sql = "
				SELECT *
				FROM shortlist_profiles
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

		public function updateShortList($data) {
			$sql = "
				UPDATE shortlist_profiles
				SET 
                pl_userId = ?,
                pv_viewedId = ?,
                pl_viewedDate = ?,
				WHERE id = ?
			";
			
			$query = $this->_db->query($sql, $data);

			return $query;
		}

	    public function removeShortList($data = array()) {
            $sql = "
                DELETE
                FROM shortlist_profiles 
                                WHERE id = ?
            ";
            $query = $this->_db->query($sql, $data);

            return $query;
        }

	////////////////// Interest //////////////////
		public function addInterest($data = array()) {
			$sql = "
				INSERT INTO interest_profiles (
					pl_userId,
					pv_viewedId,
					interest,
					pl_viewedDate,
					reg_date,
					reg_time
				) VALUES (
                    ?, ?, ?, ?, CURDATE(), CURTIME()
				)
			";

			$query = $this->_db->query($sql, $data);
                        
                        return $query;
		}

		public function fetchInterest($condition = null) {
			$sql = "
				SELECT *
				FROM interest_profiles
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

		public function updateInterest($data) {
			$sql = "
				UPDATE interest_profiles
				SET 
                pl_userId = ?,
                pv_viewedId = ?,
                interest = ?,
                pl_viewedDate = ?
				WHERE id = ?
			";
			
			$query = $this->_db->query($sql, $data);

			return $query;
		}

		public function removeInterest($data = array()) {
            $sql = "
                DELETE
                FROM interest_profiles 
                                WHERE id = ?
            ";
            $query = $this->_db->query($sql, $data);

            return $query;
        }


	}

?>