<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php

	class Payment {

		private $_db = null;

		public function __construct() {
			$this->_db = Database::getInstance();
		}

		public function add($data = array()) {
			$sql = "
				INSERT INTO payment (
					pl_userId,
					pl_name,
					pl_amount,
					pl_startDate,					
					pl_paidDate,
                    pl_expireDate,
                    pl_enteredBy,
                    pl_status,
                    pl_remarks,
					reg_date,
					reg_time,
					txn_id,
					payment_mode
				) VALUES (
                                        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
				)
			";

			$query = $this->_db->query($sql, $data);
                        
                        return $query;
		}

		public function fetch($condition = null) {
			$sql = "
				SELECT *
				FROM payment
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

		public function update($data) {
			$sql = "
				UPDATE payment
				SET 
                pl_userId = ?,
                pl_name = ?,
                pl_amount = ?,
                pl_startDate = ?,					
                pl_paidDate = ?,
                pl_expireDate = ?,
                pl_enteredBy = ?,
                pl_status = ?,
                pl_remarks = ?,
                payment_mode = ?
				WHERE id = ?
			";
			
			$query = $this->_db->query($sql, $data);

			return $query;
		}

		public function updatePassword($data) {
			$sql = "
				UPDATE payment
				SET
                                    password = ?
				WHERE id = ?
			";

			$query = $this->_db->query($sql, $data);

			return $query;
		}

	}

?>