<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php

	class Profile {

		private $_db = null;

		public function __construct() {
			$this->_db = Database::getInstance();
		}

		public function add($data = array()) {
			$sql = "
				INSERT INTO profile_view_details (
					pv_userId,
					pv_paymentId,
					pv_viewedId,
					pl_viewedDate,
					pl_viewedTime,
					contact,
					horoscope,
					reg_date,
					reg_time
				) VALUES (
                       ?, ?, ?, ?, ?, ?, ?, CURDATE(), CURTIME()
				)
			";

			$query = $this->_db->query($sql, $data);
                        
                        return $query;
		}

		public function fetch($condition = null) {
			$sql = "
				SELECT *
				FROM profile_view_details
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

		public function addview($data = array()) {
			$sql = "
				INSERT INTO profileonly_view_details (
					pv_userId,
					pv_paymentId,
					pv_viewedId,
					pl_viewedDate,
					reg_date,
					reg_time
				) VALUES (
                    ?, ?, ?, ?, CURDATE(), CURTIME()
				)
			";

			$query = $this->_db->query($sql, $data);
                        
                        return $query;
		}

		public function fetchview($condition = null) {
			$sql = "
				SELECT *
				FROM profileonly_view_details
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

		public function update($data) {
			$sql = "
				UPDATE profile_view_details
				SET 
                                    user_name = ?,
                                    password = ?,
                                    name = ?,
                                    mobile = ?,					
                                    email = ?,
                                    user_status = ?,
                                    user_type = ?,
                                    organization_id = ?,
                                    dept_type  = ?
				WHERE id = ?
			";
			
			$query = $this->_db->query($sql, $data);

			return $query;
		}
		
		
		public function removeContactProfile($data = array()) {
			$sql = "
				DELETE
				FROM profile_view_details 
                WHERE pv_viewedId = ? AND contact = 1
			";
			$query = $this->_db->query($sql, $data);

			return $query;
		}

		public function removeHoroscopeProfile($data = array()) {
			$sql = "
				DELETE
				FROM profile_view_details 
                WHERE pv_viewedId = ? AND horoscope = 1
			";
			$query = $this->_db->query($sql, $data);

			return $query;
		}

		public function updatePassword($data) {
			$sql = "
				UPDATE profile_view_details
				SET
                                    password = ?
				WHERE id = ?
			";

			$query = $this->_db->query($sql, $data);

			return $query;
		}
		
        public function addHoroscope($data = array()) {
			$sql = "
				INSERT INTO horoscope_details (
					hs_userId,
					hs_imgPath,
					reg_date,
					reg_time
				) VALUES (
                                        ?, ?, CURDATE(), CURTIME()
				)
			";

			$query = $this->_db->query($sql, $data);
                        
                        return $query;
		}
                public function fetchHoroscope($condition = null) {
			$sql = "
				SELECT *
				FROM horoscope_details
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}
                public function removeHoroscope($data = array()) {
			$sql = "
				DELETE
				FROM horoscope_details 
                                WHERE hs_userId = ?
			";
			$query = $this->_db->query($sql, $data);

			return $query;
		}
		
		        public function removeIDHoroscope($data = array()) {
			$sql = "
				DELETE
				FROM horoscope_details 
                                WHERE id = ?
			";
			$query = $this->_db->query($sql, $data);

			return $query;
		}
		
		
                public function addPhotos($data = array()) {
			$sql = "
				INSERT INTO photo_details (
					pho_userId,
					pho_imgPath,
					reg_date,
					reg_time
				) VALUES (
                                        ?, ?, CURDATE(), CURTIME()
				)
			";

			$query = $this->_db->query($sql, $data);
                        
                        return $query;
		}
                public function fetchPhotos($condition = null) {
			$sql = "
				SELECT *
				FROM photo_details
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}
                public function removePhotos($data = array()) {
			$sql = "
				DELETE
				FROM photo_details 
                                WHERE id = ?
			";
			$query = $this->_db->query($sql, $data);

			return $query;
		}
		
		
		  //////////// Profile SMS ////

		public function addsms($data = array()) {
			$sql = "
				INSERT INTO profile_sms_details (
					pv_userId,
					pv_paymentId,
					pv_viewedId,
					pl_viewedDate
				) VALUES (
                       ?, ?, ?, ?
				)
			";

			$query = $this->_db->query($sql, $data);
                        
                        return $query;
		}

		public function fetchprofilesms($condition = null) {
			$sql = "
				SELECT *
				FROM profile_sms_details
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

	}

?>