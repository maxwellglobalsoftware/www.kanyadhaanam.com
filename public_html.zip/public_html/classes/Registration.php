<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php

	class Registration {

		private $_db = null;

		public function __construct() {
			$this->_db = Database::getInstance();
		}
                
                public function login($username, $password = null) {
			$sql = "
				SELECT *
				FROM registration
				WHERE km_regcode = ? and km_status = 'live'
			";
//                        echo '$sql = '.$sql;
			$data = array(
				$username
			);

			$query = $this->_db->query($sql, $data);
			$resultSet = $query->resultSet();
			if(count($resultSet)) {
				$resultSet = $resultSet[0];
				if($resultSet['km_password'] == $password) {
					$_SESSION['User_Kamma_Matri'] = $resultSet;
					return true;
				} else {
					$_SESSION['loginerror'] = false;
					return false;
				}
			} else {
				$_SESSION['loginerror'] = false;
				return false;
			}
		}

		public function add($data = array()) {
			$sql = "
				INSERT INTO registration (
					km_regcode,
					km_name,
					km_password,
					km_gender,					
					km_education, 
                    km_education_details,                                       
                    km_employee_in,
                    km_occupation,
                     km_occupation_details,
				
                    km_annual_income,
                    km_blood_group,
                    km_doorno,                                        
                    km_street,
                    km_city,
                    km_state,
					km_district,
                    km_pincode,                                        
                    km_mobile,  
                    km_second_mobile, 
                    km_email,
                    km_landline,
                    km_marital_status,
                   km_caste,
                   km_subcaste,
                    km_languages,
                    km_physical_status,
                    km_father_name,                                        
                    km_father_occupation,
                    km_mother_name,
					km_mother_occupation,
                    km_dateofbirth,
                    km_dayofbirth, 
                    km_birthtime,                                       
                    km_place_of_birth,
                    km_order_of_birth,
					km_housename,
                    km_gothram,
                    km_native_place,                                        
                    km_native_district,
                    km_family_status,
                    km_family_type,
                    km_family_value,
                    bcount,
                    bmcount,
                    scount,
                    smcount,
                    km_height,
					km_weight,
                    km_star,
                    km_rasi,                                        
                    km_lagnam,
                    km_thisai_irrupu,
					km_dosham,
                    km_dosham_details,
                    km_registered_date,
                    km_registered_by,
                    km_status
                   
					
				) VALUES (
                                       ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
				)
			";

			$query = $this->_db->query($sql, $data);
                        
                        return $query;
		}

		public function fetch($condition = null) {
			$sql = "
				SELECT *
				FROM registration
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

		public function update($data) {
	
			$sql = "
				UPDATE registration
				SET 
                                    km_name = ?,
                                    km_password = ?,
                                    km_gender = ?,				
                                    km_education = ?,
                                    km_education_details = ?,
                                    km_employee_in = ?,
                                    km_occupation = ?,
                                    km_occupation_details = ?,
                                    km_annual_income = ?,
                                    km_blood_group = ?,
                                    km_doorno = ?,                  
                                    km_street = ?,
                                    km_city = ?,
                                    km_state = ?,
                                    km_district = ?,
                                    km_pincode = ?,                 
                                    km_mobile = ?, 
                                    km_second_mobile = ?,
                                    km_email = ?,
                                    km_landline = ?,
                                    km_marital_status = ?,
                                    km_caste = ?,
                                    km_subcaste = ?,
                                    km_languages = ?,
                                    km_physical_status = ?,
                                    km_father_name = ?,             km_father_occupation = ?,
                                    km_mother_name = ?,
                                    km_mother_occupation = ?,
                                    km_dateofbirth = ?,
                                    km_dayofbirth = ?, 
                                    km_birthtime  = ?,                      km_place_of_birth = ?,
                                    km_order_of_birth = ?,
                                    km_housename = ?,
                                    km_gothram = ?,
                                    km_native_place = ?,                    km_native_district = ?,
                                    km_family_status = ?,
                                    km_family_type = ?,
                                    km_family_value = ?,
                                    bcount = ?,
                                    bmcount = ?,
                                    scount = ?,
                                    smcount = ?,
                                    km_height = ?,
                                    km_weight = ?,
                                    km_star = ?,
                                    km_rasi = ?,                            km_lagnam = ?,
                                    km_thisai_irrupu = ?,
                                    km_dosham = ?,
                                    km_dosham_details = ?,
                                    km_registered_by = ?,
                                    km_status = ?

                                   
                                   
				WHERE id = ?
			";
			
		    
		$query = $this->_db->query($sql, $data);

            return $query;
		}

		public function updatePassword($data) {
			$sql = "
				UPDATE registration
				SET
                                    km_password = ?
				WHERE km_regcode = ?
			";

			$query = $this->_db->query($sql, $data);

			return $query;
		}
		
		
		public function updateStatus($data) {
            $sql = "
                UPDATE registration
                SET
                km_status = ?
                WHERE km_regcode = ?
            ";

            $query = $this->_db->query($sql, $data);

            return $query;
        }
		
		
				public function updateFirstMobile($data) {
            $sql = "
                UPDATE registration
                SET
                    km_mobile = ?
                WHERE km_regcode = ?
            ";

            $query = $this->_db->query($sql, $data);

            return $query;
        }

        public function updateSecondMobile($data) {
            $sql = "
                UPDATE registration
                SET
                    km_second_mobile = ?
                WHERE km_regcode = ?
            ";

            $query = $this->_db->query($sql, $data);

            return $query;
        }
        
        
        public function updateEmail($data) {
            $sql = "
                UPDATE registration
                SET
                    km_email = ?
                WHERE km_regcode = ?
            ";

            $query = $this->_db->query($sql, $data);

            return $query;
        }
        
        public function addMailSend($data = array()) {
            $sql = "
                INSERT INTO mail_send_details (
                    km_regcode
                ) VALUES (
                    ?
                )
            ";

            $query = $this->_db->query($sql, $data);
                        
                        return $query;
        }

        public function fetchMailSend($condition = null) {
            $sql = "
                SELECT *
                FROM mail_send_details
            ";

            if(isset($condition)) {
                $sql .= " " . $condition;
            }

            $query = $this->_db->query($sql, null);

            return $query;
        }
        
        
        //////////////// Occupation ///////////

        public function addOccupation($data = array()) {
			$sql = "
				INSERT INTO occupation_details (
					occupation
				
				) VALUES (
                    ?
				)
			";

			$query = $this->_db->query($sql, $data);
                        
                        return $query;
		}

		public function fetchOccupation($condition = null) {
			$sql = "
				SELECT *
				FROM occupation_details
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

		public function updateOccupation($data) {
			$sql = "
				UPDATE occupation_details
				SET 
                     occupation = ?
				WHERE id = ?
			";
			
			$query = $this->_db->query($sql, $data);

			return $query;
		}

		public function removeOccupation($data) {
			$sql = "
				DELETE FROM occupation_details
				WHERE id = ?
			";

			$query = $this->_db->query($sql, $data);

			return $query;
		}



		/////////////  States /////////////

		public function fetchStates($condition = null) {
			$sql = "
				SELECT *
				FROM states
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}


		/////////////  Districts /////////////

		public function fetchDistricts($condition = null) {
			$sql = "
				SELECT *
				FROM districts
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}


            /////////////  Caste /////////////

        public function fetchCastes($condition = null) {

            

            $sql = "
                SELECT *
                FROM caste
            ";

            if(isset($condition)) {
                $sql .= " " . $condition;
            }

            $query = $this->_db->query($sql, null);

            return $query;
        }

        /////////////  Subcaste /////////////

        public function fetchSubcastes($condition = null) {
            $sql = "
                SELECT *
                FROM sub_caste
            ";

            if(isset($condition)) {
                $sql .= " " . $condition;
            }

            $query = $this->_db->query($sql, null);

            return $query;
        }

	}


?>