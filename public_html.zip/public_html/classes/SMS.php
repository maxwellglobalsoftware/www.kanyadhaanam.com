<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php

	class SMS {

		private $_db = null;

		public function __construct() {
			$this->_db = Database::getInstance();
		}

	////////////////// SMS //////////////////
		public function add($data = array()) {
			$sql = "
				INSERT INTO sms_details (
					pl_userId,
					sms_date,
					remarks
				) VALUES (
                    ?, ?, ? 
				)
			";

			$query = $this->_db->query($sql, $data);
                        
                        return $query;
		}

		public function fetch($condition = null) {
			$sql = "
				SELECT *
				FROM sms_details
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

		public function update($data) {
			$sql = "
				UPDATE sms_details
				SET 
                pl_userId = ?,
				sms_date = ?,
				remarks = ?
                
				WHERE id = ?
			";
			
			$query = $this->_db->query($sql, $data);

			return $query;
		}

		public function remove($data = array()) {
            $sql = "
                DELETE
                FROM sms_details 
              WHERE id = ?
            ";
            $query = $this->_db->query($sql, $data);

            return $query;
        }



      ////////////////// Call //////////////////
		public function addCall($data = array()) {
			$sql = "
				INSERT INTO call_details (
					pl_userId,
					call_date,
					remarks,
					enter_by
				) VALUES (
                    ?, ?, ?, ?
				)
			";

			$query = $this->_db->query($sql, $data);
                        
                        return $query;
		}

		public function fetchCall($condition = null) {
			$sql = "
				SELECT *
				FROM call_details
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

		public function updateCall($data) {
			$sql = "
				UPDATE call_details
				SET 
                pl_userId = ?,
				call_date = ?,
				remarks = ?,
				enter_by = ?
                
				WHERE id = ?
			";
			
			$query = $this->_db->query($sql, $data);

			return $query;
		}

		public function removeCall($data = array()) {
            $sql = "
                DELETE
                FROM call_details 
              WHERE id = ?
            ";
            $query = $this->_db->query($sql, $data);

            return $query;
        }

	}

?>