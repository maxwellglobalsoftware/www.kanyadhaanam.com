<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php

	class User {

		private $_db = null;

		public function __construct() {
			$this->_db = Database::getInstance();
		}

		public function login($username, $password = null) {
			$sql = "
				SELECT *
				FROM admin_access
				WHERE user_name = ? and user_status = 'live'
			";
//                        echo '$sql = '.$sql;
			$data = array(
				$username
			);

			$query = $this->_db->query($sql, $data);
			$resultSet = $query->resultSet();
			if(count($resultSet)) {
				$resultSet = $resultSet[0];
				if($resultSet['password'] == $password) {
					$_SESSION['Kamma_Matri'] = $resultSet;
					return true;
				} else {
					$_SESSION['loginerror'] = false;
					return false;
				}
			} else {
				$_SESSION['loginerror'] = false;
				return false;
			}
		}
		
		public function loginOTP($username, $password = null) {
			$sql = "
				SELECT *
				FROM admin_access
				WHERE user_name = ? and user_status = 'live'
			";
//                        echo '$sql = '.$sql;
			$data = array(
				$username
			);

			$query = $this->_db->query($sql, $data);
			$resultSet = $query->resultSet();
			if(count($resultSet)) {
				$resultSet = $resultSet[0];
				if($resultSet['password'] == $password) {
					$_SESSION['Kamma_Manage_Matri'] = $resultSet;
					return true;
				} else {
					$_SESSION['loginerror'] = false;
					return false;
				}
			} else {
				$_SESSION['loginerror'] = false;
				return false;
			}
		}

		public function addUser($data = array()) {
			$sql = "
				INSERT INTO admin_access (
					user_name,
					password,
					name,
					mobile,					
					email,
                                        user_status,
                                        user_type,
					organization_id,
                                        dept_type,
					reg_date,
					reg_time
				) VALUES (
					 ?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE(), CURTIME()
				)
			";

			$query = $this->_db->query($sql, $data);
                        
                        return $query;
		}

		public function getUsers($condition = null) {
			$sql = "
				SELECT *
				FROM admin_access
			";

			if(isset($condition)) {
				$sql .= " " . $condition;
			}

			$query = $this->_db->query($sql, null);

			return $query;
		}

		public function updateUser($data) {
			$sql = "
				UPDATE user_details
				SET 
                                    user_name = ?,
                                    password = ?,
                                    name = ?,
                                    mobile = ?,					
                                    email = ?,
                                    user_status = ?,
                                    user_type = ?,
                                    organization_id = ?,
                                    dept_type  = ?
				WHERE id = ?
			";
			
			$query = $this->_db->query($sql, $data);

			return $query;
		}

		public function updatePassword($data) {
			$sql = "
				UPDATE admin_access
				SET
					password = ?
				WHERE id = ?
			";

			$query = $this->_db->query($sql, $data);

			return $query;
		}

	}

?>