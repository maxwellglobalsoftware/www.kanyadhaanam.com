<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   require_once 'KANyaMatrI_GST/includes/configure.php';
   require_once 'init.php';
   require_once 'includes/common_functions.php';
   require_once 'includes/pagination.php';
   require_once 'includes/db.php';
   require_once 'includes/session_handler.php';
   date_default_timezone_set('Asia/Kolkata');

   $user_id = $_SESSION['User_Kamma_Matri']['id'];
   $km_regcode = $_SESSION['User_Kamma_Matri']['km_regcode'];
   $users = new Registration();
   $users = $users->fetch("WHERE id = '{$user_id}'")->resultSet();
   $user = $users[0];
   if($user['km_gender'] == 'male'){
       $km_gender = 'female';
   }else{
       $km_gender = 'male';
   }
?>
<!DOCTYPE html>
<html>
    <head>
<?php include("includes/headertop.php");?>
</head>
    <body class="home color-green boxed shadow">
        
            <?php include("includes/headerin.php");?>

            <?php include("includes/bannerin.php");?>
                
                <?php //include("includes/quicksearch.php");?>
                <div class="root">
                    <section class="content reverse">
                    <?php include("includes/right.php");?>
                        <section class="col-md-9 col-xs-12" style=" margin-top: 1%;">
                            <table>
                                <tr class="tabletitle" style=" background-color: #fdbd0a;">
                                    <td colspan="2" style="  border-top-left-radius: 0.5em; border-top-right-radius: 0.5em;">Contact Alert</td>
                                </tr>
                            </table>
                            <div id="pagin">
                  <form method="post" id='search_result' action="">
                     <div id="result-content">
                        <h4 style="margin: 1.5em 1em;text-align: left;color: #17800a;margin-bottom: 0px;"> Welcome to Kanyadhaanam,</h4>
                        <h4 style="margin: 1.5em 1em;text-align: left;color: #17800a;margin-bottom: 10px;margin-top: 10px;"> Dear <?php echo $_SESSION['User_Kamma_Matri']['km_name']; ?>,</h4>
                        <p style="margin: 1.5em 1.5em;text-align: left;color: #17800a;font-size: 17px;margin-bottom: 10px;margin-top: 10px;">You have been successfully viewed your desired matches contact numbers, you can continue our services after upgrading your premium.</p>

                        <p style="margin: 1.5em 1.5em;text-align: left;color: #17800a;font-size: 17px;margin-bottom: 10px;margin-top: 10px;">If you have further clarifications please call us at <a style="color:blue;">95000 90825</a></p>
                     </div>
                  </form>
               </div>
                        </section>
                        
                    </section>
                    <div style=" clear: both;"></div>

                     </div>

                    <?php include("includes/footertop.php");?>
                    <?php include("includes/footerin.php");?>
       
    </body>

</html>