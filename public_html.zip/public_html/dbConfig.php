<?php
//Database credentials
$dbHost = 'localhost';
$dbUsername = 'kanya3w90_new';
$dbPassword = 'iyer123@';
$dbName = 'kanya3w90_new';

// $dbUsername = 'root';
// $dbPassword = '';
// $dbName = 'weddingk_matri';

//Connect with the database
$conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

//Display error if failed to connect
if ($db->connect_errno) {
    printf("Connect failed: %s\n", $db->connect_error);
    exit();
}
?>