<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   require_once 'KANyaMatrI_GST/includes/configure.php';
   require_once 'includes/session_handler.php';
   require_once 'init.php';
   date_default_timezone_set('Asia/Kolkata');
   
   $profileId = $_SESSION['User_Kamma_Matri']['km_regcode'];
   $today_date = date("d-m-Y");
   //*********************** Horoscope Details *******************************
   $profiles = new Registration();
   $profiles = $profiles->fetch("WHERE km_regcode = '{$profileId}'")->resultSet();    
   $profile = $profiles[0];

   if(isset($_SESSION['registrationUpdate'])) {     
    if($_SESSION['registrationUpdate']) {
        $result = "Successfully Updated";
    } else {
        $result = "You have made no changes to save";
    }
    unset($_SESSION['registrationUpdate']);
}
   
   if(isset($_POST['btn_update'])) {     
    
    $data = array();
    
    $data[] = $_POST['member_name'];
    $data[] = $_POST['password'];
    $data[] = $_POST['gender'];
    $data[] = $_POST['education'];
    $data[] = $_POST['education_details'];
    $data[] = $_POST['employedIn'];
    $data[] = $_POST['occupation'];
    $data[] = $_POST['occupation_details'];
    $data[] = $_POST['annualIncome'];  
    $data[] = $_POST['bloodgroup'];  
    $data[] = $_POST['doorNo'];
    $data[] = $_POST['street'];
    $data[] = $_POST['city'];
    $data[] = $_POST['state'];
    $data[] = $_POST['district'];
    $data[] = $_POST['pincode'];  
    $data[] = $_POST['mobile'];
    $data[] = $_POST['second_mobile'];
    $data[] = $_POST['email'];
    $data[] = $_POST['landline_code'].'-'.$_POST['landline'];
    $data[] = $_POST['marital_status'];
     $data[] = $_POST['caste'];
      $data[] = $_POST['subcaste'];
    $data[] = $_POST['languagesKnown'];
    $data[] = $_POST['physical_status']; 
    
    $data[] = $_POST['father_name'];
    $data[] = $_POST['father_occupation'];
    $data[] = $_POST['mother_name'];
    $data[] = $_POST['mother_occupation']; 
    $data[] = $_POST['year'].'-'.$_POST['month'].'-'.$_POST['date'];
    $data[] = $_POST['day'];
    $data[] = $_POST['birthhour'].':'.$_POST['birthmins'].' '.$_POST['birthmeridium'];
    $data[] = $_POST['place_of_birth'];
    $data[] = $_POST['order_of_place'];    
    $data[] = $_POST['house_name'];
    $data[] = $_POST['gothram'];
    $data[] = $_POST['native'];
    $data[] = $_POST['native_district'];
    $data[] = $_POST['family_status'];
    $data[] = $_POST['family_type'];
    $data[] = $_POST['family_value'];
    $data[] = $_POST['bcount'];
    $data[] = $_POST['bmcount'];
    $data[] = $_POST['scount'];
    $data[] = $_POST['smcount'];
    if($_POST['height_ft']){
   $data[] = $_POST['height_ft'];  
   } else {
   $data[] = $_POST['height_cms']; 
   }   
    $data[] = $_POST['weight'];
    $data[] = $_POST['star'];
    $data[] = $_POST['rasi'];
    $data[] = $_POST['lagnam'];
    $data[] = $_POST['thisai_irrupu']; 
    $data[] = $_POST['dosham'];
    if($_POST['dosham'] == 'yes'){
    $data[] = $_POST['dosham_details'];  
    } else {
    $data[] = "";
    }
    $data[] = $_POST['registeredBy'];
    $data[] = $_POST['status'];
    
    $data[] = $_POST['user_id'];
    
   
   
  
    $registration = new Registration();
    $registration = $registration->update($data);
    
    
    $registration_id = $registration->rowCount();
 
      if($registration_id){   
        $_SESSION['registrationUpdate'] = true;
    } else {
        $_SESSION['registrationUpdate'] = false;
    }
    header("Location: edit-profile.php");
}


   $primary_otp_success = new OTP();
   $primary_otp_success = $primary_otp_success->fetch("WHERE pl_userId = '{$profileId}' AND  pl_primary_status = 'yes' ORDER BY id DESC")->resultSet(); 
   $primary_mobile = $primary_otp_success[0];

   $secondary_otp_success = new OTP();
   $secondary_otp_success = $secondary_otp_success->fetch("WHERE pl_userId = '{$profileId}' AND  pl_secondary_status = 'yes' ORDER BY id DESC")->resultSet(); 
   $secondary_mobile = $secondary_otp_success[0];
   
   
   $primary_email_success = new OTP();
   $primary_email_success = $primary_email_success->fetchEmail("WHERE pl_userId = '{$profileId}' AND  pl_primary_status = 'yes' ORDER BY id DESC")->resultSet(); 
   $primary_email = $primary_email_success[0];


   //$primary_mobiles = new OTP();
   //$primary_mobiles = $primary_mobiles->fetch("WHERE pl_userId = '{$profileId}' AND reg_date = '{$today_date}' AND pl_primary_mobile = '{$profile['km_mobile']}' ORDER BY id DESC")->resultSet(); 
   //$primary_mobile = $primary_mobiles[0];



   //$secondary_mobiles = new OTP();
   //$secondary_mobiles = $secondary_mobiles->fetch("WHERE pl_userId = '{$profileId}' AND reg_date = '{$today_date}' AND  pl_secondary_mobile = '{$profile['km_second_mobile']}' ORDER BY id DESC")->resultSet(); 
   //$secondary_mobile = $secondary_mobiles[0];

    //// Occupation /////
    $occupations = new Registration();
    $occupations = $occupations->fetchOccupation("ORDER BY occupation ASC")->resultSet();

    //// Districts /////
    $districts = new Registration();
    $districts = $districts->fetchDistricts("ORDER BY name ASC")->resultSet();

    $districtsEncoded = json_encode($districts);

    //// States /////
    $states = new Registration();
    $states = $states->fetchStates("ORDER BY name ASC")->resultSet();

    $statesEncoded = json_encode($states);   


    $editdistricts = new Registration();
    $editdistricts = $editdistricts->fetchDistricts("WHERE state_id = '{$profile['km_state']}' ORDER BY name ASC")->resultSet();


   ?>
<!DOCTYPE html>
<html>
   <?php include("includes/headertop.php");?>
<script type="text/javascript">
	function regform(form)

	{

	var numbers = /^[0-9]+$/; 

	var passw = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{6,20}$/;

	var re = /^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$/;


	if(form.education.value=="") { alert("Please select education"); form.education.focus(); return false; }

	if(form.employedIn.value=="notworking") {
                                           
    } else {

	if(form.occupation.value=="") { alert("Please select occupation"); form.occupation.focus(); return false; }

	if(form.company_name.value=="") { alert("Please enter occupation details"); form.company_name.focus(); return false; }

	if(form.annualIncome.value=="") { alert("Please enter annual income"); form.annualIncome.focus(); return false; }

	}

	if(form.bloodgroup.value=="") { alert("Please select blood group"); form.bloodgroup.focus(); return false; }

	if(form.doorNo.value=="") { alert("Please enter door no"); form.doorNo.focus(); return false; }

	if(form.street.value=="") { alert("Please enter street"); form.street.focus(); return false; }

	if(form.city.value=="") { alert("Please enter city"); form.city.focus(); return false; }

	if(form.pincode.value!="")
	{
	if(!form.pincode.value.match(numbers))  
	{  

	alert('Please enter pincode with only numbers');  
	form.pincode.focus(); return false;
	}
	if (form.pincode.value.length != 6)
	{ 
	alert('Please enter your 6 digits pincode exactly');  
	form.pincode.focus(); return false; 
	} 
	}

	if(form.state.value=="") { alert("Please select state"); form.state.focus(); return false; }

	if(form.district.value=="") { alert("Please select district"); form.district.focus(); return false; }

	if(form.pincode.value=="") { alert("Please enter pincode"); form.pincode.focus(); return false; }


	if(form.email.value=="") { alert("Please enter your Email ID"); form.email.focus(); return false; }
         
     if(form.email.value!="")
     {
     if(!form.email.value.match(re))  
     {  
     
     alert('Please enter valid Email ID');  
     form.email.focus(); return false;
     }  
     }
     
     if(form.mobile.value=="") { alert("Please enter mobile number"); form.mobile.focus(); return false; }
     if(form.mobile.value!="")
     {
     if(!form.mobile.value.match(numbers))  
     {  
     
     alert('Please enter mobile number with only numbers');  
     form.mobile.focus(); return false;
     } 
     if (form.mobile.value.length != 10)
     { 
     alert('Please enter your 10 digits mobile number exactly');  
     form.mobile.focus(); return false; 
     } 
     
     }
     
     if(form.second_mobile.value=="") { alert("Please enter your secondary mobile number"); form.second_mobile.focus(); return false; }
     if(form.second_mobile.value!="")
     {
     if(!form.second_mobile.value.match(numbers))  
     {  
     
     alert('Please enter secondary mobile number with only numbers');  
     form.second_mobile.focus(); return false;
     } 
     if (form.second_mobile.value.length != 10)
     { 
     alert('Please enter your 10 digits secondary mobile number exactly');  
     form.second_mobile.focus(); return false; 
     } 
     
     }

     if(form.landline_code.value!="") {
                                   
         if(form.landline_code.value.length < 3 || form.landline_code.value.length > 5) {
           alert("Please enter landline code 3 to 5 digits only"); form.landline_code.focus(); return false;
         }
         
       }
     
     
     if(form.landline.value!="")
     {
     if(!form.landline.value.match(numbers))  
     {  
     
     alert('Please enter landline number with only numbers');  
     form.landline.focus(); return false;
     }
     if (form.landline.value.length != 8)
     { 
     alert('Please enter your 8 digits landline number exactly');  
     form.landline.focus(); return false; 
     } 
     }


	if(form.languagesKnown.value=="") { alert("Please enter language"); form.languagesKnown.focus(); return false; }

	if(form.height_ft.value=="" && form.height_cms.value=="") { alert("Please select height"); form.height_ft.focus(); return false; }

	if(form.weight.value=="") { alert("Please select weight"); form.weight.focus(); return false; }


	if(form.house_name.value=="") { alert("Please enter house name"); form.house_name.focus(); return false; }

	if(form.gothram.value=="") { alert("Please enter gothram"); form.gothram.focus(); return false; }

	if(form.star.value=="") { alert("Please select star"); form.star.focus(); return false; }

	if(form.rasi.value=="") { alert("Please select rasi"); form.rasi.focus(); return false; }

	if(form.lagnam.value=="") { alert("Please select lagnam"); form.lagnam.focus(); return false; }

	if(form.thisai_irrupu.value=="") { alert("Please enter thisai irrupu"); form.thisai_irrupu.focus(); return false; }

  if(form.dosham.value=="yes") {

  if(form.dosham_details.value=="") { alert("Please enter dosham details"); form.dosham_details.focus(); return false; }

  }


	if(form.father_name.value=="") { alert("Please enter father's name"); form.father_name.focus(); return false; }


	if(form.father_occupation.value=="") { alert("Please enter father's occupation"); form.father_occupation.focus(); return false; }

	if(form.mother_name.value=="") { alert("Please enter mother's name"); form.mother_name.focus(); return false; }


	if(form.mother_occupation.value=="") { alert("Please enter mother's occupation"); form.mother_occupation.focus(); return false; }

	if(form.date.value=="" && form.month.value=="" && form.year.value=="") { alert("Please select date of birth"); form.date.focus(); return false; }

	if(form.date.value=="") { alert("Please select date"); form.lagnam.focus(); return false; }

	if(form.month.value=="") { alert("Please select month"); form.month.focus(); return false; }

	if(form.year.value=="") { alert("Please select year"); form.year.focus(); return false; }

	if(form.day.value=="") { alert("Please select day of birth"); form.day.focus(); return false; }

	if(form.birthhour.value=="" && form.birthmins.value=="" && form.birthmeridium.value=="") { alert("Please select time of birth"); form.birthhour.focus(); return false; }
                                       
   if(form.birthhour.value=="" ) { alert("Please select hour"); form.birthhour.focus(); return false; }
   
   if(form.birthmins.value=="" ) { alert("Please select mins"); form.birthmins.focus(); return false; }
   
   if(form.birthmeridium.value=="" ) { alert("Please select meridiem"); form.birthmeridium.focus(); return false; }

	if(form.place_of_birth.value=="") { alert("Please enter place of birth"); form.place_of_birth.focus(); return false; }

	if(form.order_of_place.value=="") { alert("Please select order of birth"); form.order_of_place.focus(); return false; }

	if(form.native.value=="") { alert("Please enter native place"); form.native.focus(); return false; }

	if(form.native_district.value=="") { alert("Please enter native district"); form.native_district.focus(); return false; }

	if(form.family_status[0].checked=="" && form.family_status[1].checked=="" && form.family_status[2].checked=="" && form.family_status[3].checked=="") { alert("Please select famil status"); form.family_status[0].focus(); return false; }

	 if(form.family_type[0].checked=="" && form.family_type[1].checked=="") { alert("Please select famil type"); form.family_type[0].focus(); return false; }

	 if(form.family_value[0].checked=="" && form.family_value[1].checked=="" && form.family_value[2].checked=="" && form.family_value[3].checked=="") { alert("Please select famil value"); form.family_value[0].focus(); return false; }
	 
	 if(form.bcount.value=="" ) { alert("Please select unmarried brother"); form.bcount.focus(); return false; }
	 
	 if(form.bmcount.value=="" ) { alert("Please select married brother"); form.bmcount.focus(); return false; }
	 
	 if(form.scount.value=="" ) { alert("Please select unmarried sister"); form.scount.focus(); return false; }
	 
	 if(form.smcount.value=="" ) { alert("Please select married sister"); form.smcount.focus(); return false; }
	
	var why = "";
         
     if(form.CaptchaInput.value == ""){
     why += "- Please Enter CAPTCHA Code.\n";
     form.CaptchaInput.focus();
     }
     if(form.CaptchaInput.value != ""){
     if(ValidCaptcha(form.CaptchaInput.value) == false){
     why += "- The CAPTCHA Code Does Not Match.\n";
     form.CaptchaInput.focus();
     }
     }
     if(why != ""){
     alert(why);
     return false;
     }

}


	</script>
   <body class="home color-green boxed shadow">
      
         <?php include("includes/headerin.php");?>
          
      <?php include("includes/bannerin.php");?>
         <?php //include("includes/quicksearch.php");?>
         <div class="root">
         <section class="content reverse">
         <?php include("includes/right.php");?>
            <section class="col-md-9 col-xs-12" style=" margin-top: 1%;">
             <div  id="message_container" style="text-align: center; display: none; color: red;font-size: 18px; font-weight: bold">
                    <span id="message"></span>
                </div>
               <table>
                  <tr class="tabletitle" >
                     <td colspan="2" style="  border-top-left-radius: 0.5em; border-top-right-radius: 0.5em;">Edit Profile</td>
                  </tr>
               </table>
               <div id="result-content">
                  <div class="panel-default panel-ep">
                     <div class="panel-body">
                        <div class="ep-view editProfileContent" style="" id="basicRelDetailsFormview">
                           <form action="" id="PreferForm" name="PreferForm" method="post" onsubmit="return regform(PreferForm);">
                               <input type="hidden" name="user_id" id="user_id" value="<?php echo $profile['id']?>">

                               <input type="hidden" name="password" value="<?php echo $profile['km_password']?>">
                               <input type="hidden" name="gender" value="<?php echo $profile['km_gender']?>">
                               <input type="hidden" name="registeredBy" value="<?php echo $profile['km_registered_by']?>">
                               <input type="hidden" name="status" value="<?php echo $profile['km_status']?>">
                               
                              <div class="form-horizontal">
                                
                                 <div class="panel panel-default" style=" margin-top: 0px;">
                                    <div class="panel-heading clearfix" style="border: 1px solid #e5e5e5;">
                                      
                                       <h3 class="panel-title ep-panel-heading">Personal Details</h3>
                                    </div>
                                    <div class="panel-body">
                                       <div class="ep-view">
                                          <div class="form-horizontal">
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">REG ID <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" placeholder="REG ID" class="form-control" id="km_regcode"  name="km_regcode" readonly="" value="<?php echo $profile['km_regcode']?>">
                                                </div>
                                             </div>
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">Name <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" placeholder="Name" readonly="" class="form-control" name="member_name" id="member_name" value="<?php echo $profile['km_name']?>" autocomplete="off">
                                                </div>
                                             </div>
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">Sub Caste <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" placeholder="Sub Caste" readonly="" class="form-control" name="subcaste" id="subcaste" value="<?php echo $profile['km_subcaste']?>" autocomplete="off">
                                                </div>
                                             </div>
                                                <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">Caste <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" placeholder="Caste" readonly="" class="form-control" name="caste" id="caste" value="<?php echo $profile['km_caste']?>" autocomplete="off">
                                                </div>
                                             </div>
                                             
                                             <div class="form-group editpage">
                                                <label class="col-xs-4 col-sm-4 col-md-4 control-label">Education <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-xs-8 col-sm-8">
                                                    <select name="education" class="form-control" >
			                                       <option value="">-- Select Education --</option>
			                                       <?php foreach($edu_array as $key => $value){ ?>
			                                       <option <?php if($profile['km_education'] == $key){echo 'selected';}?> value="<?php echo $key;?>"><?php echo $value;?></option>
			                                       <?php } ?>
			                                    </select>
                                                </div>
                                             </div>

                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">Education Details (Optional)</label>
                                                <div class="col-sm-8">
                                                <textarea rows="4" id="education_details" name="education_details" style="min-height: inherit!important;" placeholder="Education Details" class="text" autocomplete="off"><?php echo $profile['km_education_details'];?></textarea>
                                                </div>
                                             </div>
                                             
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">Employed in <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <label class="radio-inline">
                                                   <input name="employedIn" <?php if($profile['km_employee_in'] == 'government'){echo 'checked';}?> id="employedIn" type="radio" value="government">
                                                   Government </label>
                                                   <label class="radio-inline">
                                                   <input name="employedIn" <?php if($profile['km_employee_in'] == 'private'){echo 'checked';}?> id="employedIn" type="radio" value="private">
                                                   Private </label>
                                                   <label class="radio-inline">
                                                   <input name="employedIn" <?php if($profile['km_employee_in'] == 'business'){echo 'checked';}?> id="employedIn" type="radio" value="business">
                                                   Business </label>
                                                   <label class="radio-inline">
                                                   <input name="employedIn" <?php if($profile['km_employee_in'] == 'notworking'){echo 'checked';}?> id="employedIn" type="radio" value="notworking">
                                                   Not Working </label>
                                                </div>
                                             </div>
                                             <div class="form-group editpage" id="job1" <?php if($profile['km_employee_in'] == 'notworking'){ ?> style="display:none;" <?php } else { } ?>>
                                                <label class="col-sm-4 col-md-4 control-label col-xs-12">Occupation <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-xs-12 col-sm-8 ">
                                                    <select name="occupation" class="form-control" >
			                                       <option value="">-- Select Occupation --</option>
			                                       <?php foreach($occupations as $occupation){ ?>
			                                       <option <?php if($profile['km_occupation'] == $occupation['id']){echo 'selected';}?> value="<?php echo $occupation['id'];?>"><?php echo $occupation['occupation'];?></option>
			                                       <?php } ?>
			                                    </select>
                                                </div>
                                             </div>

                                             <div class="form-group editpage" id="job2" <?php if($profile['km_employee_in'] == 'notworking'){ ?> style="display:none;" <?php } else { } ?> >
                                                <label class="col-sm-4 control-label nopad1 col-xs-12">Occupation Details <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8 col-xs-12">
                                                   <textarea rows="4" id="occupation_details"  name="occupation_details" style="min-height: inherit!important;" placeholder="Occupation Details" class="form-control" autocomplete="off"><?php echo $profile['km_occupation_details'];?></textarea>
                                                </div>
                                             </div>

                                             <div class="form-group editpage" id="job3" <?php if($profile['km_employee_in'] == 'notworking'){ ?> style="display:none;" <?php } else { } ?> >
                                                <label class="col-sm-4 control-label">Annual Income <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" class="form-control" onkeypress="return IncomeNo(event,this);" id="annualIncome" value="<?php echo $profile['km_annual_income'];?>" name="annualIncome" placeholder="Annual Income" Maxlength="10" autocomplete="off" >
                                                </div>
                                                <script language="Javascript" type="text/javascript">
                                                   function IncomeNo(e, t) {
                                                       try {
                                                           if (window.event) {
                                                               var charCode = window.event.keyCode;
                                                           }
                                                           else if (e) {
                                                               var charCode = e.which;
                                                           }
                                                           else { return true; }
                                                           if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                                                               return false;
                                                           }
                                                           return true;
                                                       }
                                                       catch (err) {
                                                           alert(err.Description);
                                                       }
                                                   }
                                                   
                                                </script>
                                             </div>
                                             <div class="form-group editpage">
                                                <label class="col-xs-4 col-sm-4 col-md-4 control-label">Blood group     <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-xs-8 col-sm-8">
                                                  <select name="bloodgroup" class="form-control" >
			                                       <option value="" selected disabled>-- Select Blood Group --</option>
			                                       <?php foreach($blood_array as $key => $value){ ?>
			                                       <option <?php if($profile['km_blood_group'] == $key){echo 'selected';}?> value="<?php echo $key;?>"><?php echo $value;?></option>
			                                       <?php } ?>
			                                       <?php 
			                                      if($profile['km_blood_group'] == 'donotknow'){?>
			                                      <option selected value="donotknow">- Don't Know -</option>     
			                                      <?php
			                                     }else{
			                                      ?>
			                                      <option value="donotknow">- Don't Know -</option>
			                                     <?php } ?>
			                                    </select>
                                                </div>
                                             </div>
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">Door No <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" id="doorNo" value="<?php echo $profile['km_doorno'];?>" name="doorNo" placeholder="Door NO" class="form-control" autocomplete="off">
                                                </div>
                                             </div>
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">Street Name <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" id="street" value="<?php echo $profile['km_street'];?>" name="street" placeholder="Street Name" class="form-control" autocomplete="off">
                                                </div>
                                             </div>
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">City <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" id="city" value="<?php echo $profile['km_city'];?>" name="city" placeholder="City" class="form-control" autocomplete="off">
                                                </div>
                                             </div>
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">Pincode <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" id="pincode" value="<?php echo $profile['km_pincode'];?>" name="pincode" placeholder="Pincode" Maxlength="6" onkeypress="return Number(event,this);" class="form-control" autocomplete="off">
                                                </div>
                                                
                                             </div>
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 col-md-4 control-label col-xs-12">State <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-xs-12 col-sm-8 ">
                                                    <select name="state" id="states" class="form-control" >
			                                       <option value="">-- Select District --</option>
			                                       <?php foreach($states as $state){ ?>
			                                       <option <?php if($profile['km_state'] == $state['id']){echo 'selected';}?> value="<?php echo $state['id'];?>"><?php echo $state['name'];?></option>
			                                       <?php } ?>
			                                    </select>
                                                </div>
                                             </div>

                                             <div class="form-group editpage">
                                                <label class="col-sm-4 col-md-4 control-label col-xs-12">District <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-xs-12 col-sm-8 ">
                                                    <select name="district" id="districts" class="form-control" >
			                                       <option value="">-- Select District --</option>
			                                       <?php foreach($editdistricts as $district){ ?>
			                                       <option <?php if($profile['km_district'] == $district['id']){echo 'selected';}?> value="<?php echo $district['id'];?>"><?php echo $district['name'];?></option>
			                                       <?php } ?>
			                                    </select>
                                                </div>
                                             </div>
                                             
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">Email ID <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-6">
                                                   <input type="text"  value="<?php echo $profile['km_email'];?>" name="email" id="email" class="form-control" placeholder="Email" readonly style="width:342px;background-color:#ccc!important;" >
                                                </div>
                                                <?php if($primary_email){ ?>
		                                       <div class="col-sm-2" style=" vertical-align: middle; padding-top: 2.5%;">
		                                          <small style="font-weight: normal;font-size: 14px;color: #098244;margin-left: 2%;">(Verified <i class="fa fa-check"></i>)</small>
		                                       </div>
		                                       <?php } else { ?>
		                                       <div class="col-sm-2.5" style=" vertical-align: middle; padding-top: 2.5%;">
		                                          <small style="font-weight: normal;font-size: 14px;color: red;margin-left: 2%;"><a style="color: red;text-decoration:underline;" href="email_verification.php">(Verify Now <i class="fa fa-times" style="font-size:19px;"></i>)</a></small>
		                                       </div>
		                                       <?php } ?>
                                             </div>
                                             <div class="form-group">
                                                <label class="col-sm-4 control-label">Mobile No <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-6">
                                                   <input type="text" class="form-control" value="<?php echo $profile['km_mobile'];?>" onkeypress="return Number(event,this);" Maxlength="10" readonly name="mobile" id="mobile" style="width:342px;background-color:#ccc!important;" >
                                                </div>
                                          		<?php if($primary_mobile){ ?>
		                                       <div class="col-sm-2" style=" vertical-align: middle; padding-top: 2.5%;">
		                                          <small style="font-weight: normal;font-size: 14px;color: #098244;margin-left: 2%;">(Verified <i class="fa fa-check"></i>)</small>
		                                       </div>
		                                       <?php } else { ?>
		                                       <div class="col-sm-2.5" style=" vertical-align: middle; padding-top: 2.5%;">
		                                          <small style="font-weight: normal;font-size: 14px;color: red;margin-left: 2%;"><a style="color: red;text-decoration:underline;" href="otp.php">(Verify Now <i class="fa fa-times" style="font-size:19px;"></i>)</a></small>
		                                       </div>
		                                       <?php } ?>
                                             </div>
                                             <div class="form-group">
                                                <label class="col-sm-4 control-label">Secondary Mobile No <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-6">
                                                   <input type="text"value="<?php echo $profile['km_second_mobile'];?>" name="second_mobile" id="second_mobile" class="form-control" onkeypress="return Number(event,this);" Maxlength="10"  placeholder="Mobile No." onkeypress="return Number(event,this);"  style="width:342px;background-color:#ccc!important;">
                                                </div>
                                                <?php if($secondary_mobile){ ?>
		                                       <div class="col-sm-2" style=" vertical-align: middle; padding-top: 2.5%;">
		                                          <small style="font-weight: normal;font-size: 14px;color: #098244;margin-left: 2%;">(Verified <i class="fa fa-check"></i>)</small>
		                                       </div>
		                                       <?php } else { ?>
		                                       <div class="col-sm-2.5" style=" vertical-align: middle; padding-top: 2.5%;">
		                                          <small style="font-weight: normal;font-size: 14px;color: red;margin-left: 2%;"><a style="color: red;text-decoration:underline;" href="otp.php">(Verify Now <i class="fa fa-times" style="font-size:19px;"></i>)</a></small>
		                                       </div>
		                                       <?php } ?>
                                             </div>
                                             <?php $landlin = explode("-",$profile['km_landline']);  ?>
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label nopad1 col-xs-12">Landline No (Optional)</label>
                                                <div class="col-sm-8 col-xs-12">
                                                   <input type="text"  id="landline_code" value="<?php echo $landlin[0];?>" style="float: left;width: 20%;" name="landline_code" placeholder="Code." class="form-control" onkeypress="return Number(event,this);" Maxlength="5" autocomplete="off">
                                                   <input type="text"  id="landline" value="<?php echo $landlin[1];?>" name="landline" style="float: left;width: 47%;" placeholder="Landline No." class="form-control" onkeypress="return Number(event,this);" Maxlength="8" autocomplete="off">
                                                </div>
                                             </div>
                                             <div class="form-group editpage">
											<label class="col-sm-4 control-label nopad1">Martial Status <span style="color:#c03131;font-size: 20px;"> * </span></label>
											<div class="col-sm-8">
											   <label class="radio-inline">
											   <input name="marital_status" <?php if($profile['km_marital_status'] == 'unmarried'){echo 'checked';}?> id="marital_status" type="radio" value="unmarried"> Unmarried
											   </label>
											   <label class="radio-inline">
											   <input name="marital_status" <?php if($profile['km_marital_status'] == 'widower'){echo 'checked';}?> id="marital_status" type="radio" value="widower">widow / widower
											   </label>
											   <label class="radio-inline">
											   <input name="marital_status" <?php if($profile['km_marital_status'] == 'divorced'){echo 'checked';}?> id="marital_status" type="radio" value="divorced" >Divorced
											   </label>
											   <label class="radio-inline">
											   <input type="radio" name="marital_status" value="awaiting" <?php if($profile['km_marital_status'] == 'awaiting'){echo 'checked';}?> >Awaiting Divorce
											   </label>
											</div>
											</div>
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">Languages Known </label>
                                                <div class="col-sm-8">
                                                   <input type="text"  style="" iid="languagesKnown" value="<?php echo $profile['km_languages']; ?>" name="languagesKnown" placeholder="Languages Known"  class="form-control" autocomplete="off">
                                                   <br>
                                                   <span>For Example (Tamil, English, .. etc)</span>
                                                </div>
                                             </div>

                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">Physical Status <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <label class="radio-inline">
                                                   <input name="physical_status" <?php if($profile['km_physical_status'] == 'normal'){echo 'checked';}?> id="physical_status" type="radio" value="normal" >Normal
                                                   </label>
                                                   <label class="radio-inline">
                                                   <input name="physical_status" <?php if($profile['km_physical_status'] == 'challenged'){echo 'checked';}?>  id="physical_status" type="radio" value="challenged">Physically Challenged
                                                   </label>
                                                </div>
                                             </div>

                                             <div class="form-group" id="incomeDiv">
                                    <label class="col-sm-4 control-label">Height <span style="color:#c03131;font-size: 20px;"> * </span>  </label>
                                    <div class="col-xs-12 col-sm-8">
                                       <label class="col-sm-4">
                                          <select name="height_ft" class="form-control" id="heightInFt" style="opacity: 1;">
                                        <option <?php if($split_height[1] == 'Cms'){echo 'selected';}?> value=""  disabled>- Feet & Inches -</option>
                                        <?php foreach($height_array as $height => $height_str){?>
                                        <option <?php if($split_height[1] != 'Cms' && $height_str == $profile['km_height'] ){ echo 'selected'; }else{ echo '';}?> value="<?php echo $height_str; ?>"><?php echo $height_str; ?></option>
                                        <?php } ?>
                                    </select>
                                       </label>
                                       <label class="col-sm-2">
                                       <span>(or)</span>
                                       </label>
                                       <label class="col-sm-4">
                                          <select name="height_cms" class="form-control" id="heightInCms"  style="opacity: 1;">
                                        <option <?php if($split_height[1] != 'Cms'){echo 'selected';}?> value=""  disabled>- Cms -</option>
                                        <?php for($height = 135;$height <= 210;$height++){
                                            $heightChk = $height.' Cms';
                                            ?>
                                        <option <?php if($split_height[1] == 'Cms' && $heightChk == $profile['km_height'] ){ echo 'selected'; }?> value="<?php echo $height.' Cms'; ?>"><?php echo $height.' Cms'; ?></option>
                                        <?php } ?>
                                     </select>
                                       </label>
                                    </div>
                                 </div>

                                 <div class="form-group">
                                    <label class="col-xs-4 col-sm-4 col-md-4 control-label">Weight <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                    <div class="col-xs-8 col-sm-8">
                                      <select name="weight" class="form-control"  >
                                          <option value="" disabled>- Weight -</option>
                                          <?php for($weight = 40;$weight <= 150;$weight++){
                                              $weightChk = $weight.' Kgs';
                                              ?>
                                          <option <?php if($weightChk == $profile['km_weight'] ){ echo 'selected'; }?> value="<?php echo $weight.' Kgs'; ?>"><?php echo $weight.' Kgs'; ?></option>
                                          <?php } ?>
                                       </select>
                                                                                
                                    </div>
                                 </div>

                                          </div>
                                       </div>
                                    </div>
                                 </div>


                                 <div class="panel panel-default">
                                    <div class="panel-heading clearfix" style="border: 1px solid #e5e5e5;">
                                       
                                       <h3 class="panel-title ep-panel-heading">Astrological Information</h3>
                                    </div>
                                    <div class="panel-body">
                                       <div class="ep-view">
                                          <div class="form-horizontal">
                                             <div class="form-group editpage" id="house_n">
                                                <label class="col-sm-4 control-label">House Name <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" value="<?php echo $profile['km_housename']; ?>" id="house_name" name="house_name" placeholder="House Name" class="form-control" autocomplete="off">
                                                </div>
                                             </div>
                                             <div class="form-group editpage" id="gothram_n">
                                                <label class="col-sm-4 control-label">Gothram <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" value="<?php echo $profile['km_gothram']; ?>" id="gothram" name="gothram" placeholder="Gothram" class="form-control" autocomplete="off">
                                                </div>
                                             </div>
                                             <div class="form-group editpage" id="star_n">
                                                <label class="col-xs-4 col-sm-4 col-md-4 control-label">Star <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-xs-8 col-sm-8">
                                                   <select name="star" class="form-control"  >
		                                          <option value="" selected disabled>- Star -</option>
		                                          <?php foreach($stars_array as $star){?>
		                                          <option <?php if($star == $profile['km_star'] ){ echo 'selected'; }?> value="<?php echo $star; ?>"><?php echo $star; ?></option>
		                                          <?php } ?>
		                                       </select>
                                                </div>
                                             </div>
                                             <div class="form-group editpage" id="rasi_n">
                                                <label class="col-xs-4 col-sm-4 col-md-4 control-label">Rasi <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-xs-8 col-sm-8">
                                                   <select name="rasi" class="form-control"  style="opacity: 1;">
			                                          <option value="" disabled>- Raasi -</option>
			                                          <?php foreach($rasi_array as $rasi){?>
			                                          <option <?php if($rasi == $profile['km_rasi'] ){ echo 'selected'; }?> value="<?php echo $rasi; ?>"><?php echo $rasi; ?></option>
			                                          <?php } ?>
			                                       </select>
                                                </div>
                                             </div>
                                             <div class="form-group editpage" id="lagnam_n">
                                                <label class="col-xs-4 col-sm-4 col-md-4 control-label">Lagnam <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-xs-8 col-sm-8">
                                                   <select name="lagnam"  class="form-control">
                                          <option value="" selected disabled>- Lagnam -</option>
                                          <?php foreach($rasi_array as $lagnam){?>
                                          <option <?php if($lagnam == $profile['km_lagnam'] ){ echo 'selected'; }?> value="<?php echo $lagnam; ?>"><?php echo $lagnam; ?></option>
                                          
                                          <?php } 
                                                    if($profile['km_lagnam'] == 'donotknow'){?>
                                                    <option selected value="donotknow">- Don't Know -</option>
                                                        
                                                    <?php
                                                   }else{
                                                    ?>
                                                    <option value="donotknow">- Don't Know -</option>
                                                   <?php } ?>
                                          
                                       </select>
                                                </div>
                                             </div>
                                             <div class="form-group editpage" id="thisai_n">
                                                <label class="col-sm-4 control-label">Thisai Iruppu <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" id="thisai_irrupu" value="<?php echo $profile['km_thisai_irrupu']; ?>" name="thisai_irrupu" placeholder ='Thisai Irrupu' class="form-control">
                                                </div>
                                             </div>
                                             <div class="form-group editpage" id="dosham_n">
                                                <label class="col-xs-4 col-sm-4 col-md-4 control-label">Dosham <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-xs-8 col-sm-8 col-md-8">
                                                   <label class="radio-inline">
                                                   <input name="dosham" <?php if($profile['km_dosham'] == 'yes'){echo 'checked';}?>  id="dosham" type="radio" value="yes">
                                                   Yes </label>
                                                   <label class="radio-inline">
                                                   <input name="dosham" <?php if($profile['km_dosham'] == 'no'){echo 'checked';}?>  id="dosham" type="radio" value="no">
                                                   No </label>
                                                   <label class="radio-inline">
                                                   <input name="dosham" <?php if($profile['km_dosham'] == 'dontknow'){echo 'checked';}?>  id="dosham" type="radio" value="dontknow">
                                                   Don't Know </label>
                                                </div>
                                             </div>

                                             <div class="form-group editpage" id="detail_dosham" <?php if($profile['km_dosham'] == 'yes'){ } else {  ?> style="display:none;" <?php } ?>>
                                                <label class="col-sm-4 control-label">Dosham Details <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" value="<?php echo $profile['km_dosham_details']; ?>" id="dosham_details" placeholder="Dosham Details" name="dosham_details" class="form-control" autocomplete="off">
                                                </div>
                                             </div>

                                             
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                   

                                 <div class="panel panel-default">
                                    <div class="panel-heading clearfix" style="border: 1px solid #e5e5e5;">
                                      
                                       <h3 class="panel-title ep-panel-heading">Family Information</h3>
                                    </div>
                                    <div class="panel-body">
                                       <div class="ep-view">
                                          <div class="form-horizontal">
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">Father Name <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" value="<?php echo $profile['km_father_name']; ?>" id="father_name" name="father_name" placeholder="Father's Name" class="form-control" autocomplete="off">
                                                </div>
                                             </div>
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">Father Occupation <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" value="<?php echo $profile['km_father_occupation']; ?>" id="father_occupation" name="father_occupation" placeholder="Father's Occupation" class="form-control" autocomplete="off">
                                                </div>
                                             </div>
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">Mother Name <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" value="<?php echo $profile['km_mother_name']; ?>" id="mother_name" name="mother_name" placeholder="Mother's Name" class="form-control" autocomplete="off">
                                                </div>
                                             </div>
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">Mother Occupation <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" value="<?php echo $profile['km_mother_occupation']; ?>" id="mother_occupation" name="mother_occupation" placeholder="Mother's Occupation" class="form-control" autocomplete="off">
                                                </div>
                                             </div>
                                             <div class="form-group editpage" id="incomeDiv">
                                                <label class="col-sm-4 control-label">Date of Birth <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <?php
                                              $split_date = explode('-', $profile['km_dateofbirth']);
                                              ?>

                                                <div class="col-xs-12 col-sm-8">
                                                   <label class="col-sm-3 makefull" style="width: 25%;">
                                                      <select class="form-control" name="date"  style="opacity: 1;">
                                                    <option value=""  disabled>- Date -</option>
                                                    <?php foreach($date_array as $date){?>
                                                    <option <?php if($split_date[2] == $date){echo 'selected';}?> value="<?php echo $date; ?>"><?php echo $date; ?></option>
                                                    <?php } ?>
                                                </select>
                                                   </label>
                                                   <label class="col-sm-3 makefull" style="width: 25%;">
                                                      <select class="form-control" name="month"  style="opacity: 1;">
                                                    <option value="" disabled>- Month -</option>
                                                    <?php foreach($month_array as $key => $month){?>
                                                    <option <?php if($split_date[1] == $key){echo 'selected';}?> value="<?php echo $key; ?>"><?php echo $month; ?></option>
                                                    <?php } ?>
                                                </select>
                                                   </label>
                                                   <label class="col-sm-3">
                                                      <select class="form-control" name="year"  style="opacity: 1;">
                                                    <option value=""  disabled>- Year -</option>
                                                    <?php for($year = date('Y')-21;$year >= date('Y')-50;$year--){?>
                                                    <option <?php if($split_date[0] == $year){echo 'selected';}?> value="<?php echo $year; ?>"><?php echo $year; ?></option>
                                                    <?php } ?>
                                                 </select>
                                                   </label>
                                                </div>
                                             </div>
                                             <div class="form-group editpage">
                                                <label class="col-xs-4 col-sm-4 col-md-4 control-label">Birth of Day  <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-xs-8 col-sm-8">
                                                   <select name="day"  class="form-control">
                                                    <option value="" disabled>- Day -</option>
                                                    <?php foreach($day_array as $day){?>
                                                    <option <?php if($profile['km_dayofbirth'] == $day){echo 'selected';}?> value="<?php echo $day; ?>"><?php echo $day; ?></option>
                                                    <?php } 
                                                    if($profile['km_dayofbirth'] == 'donotknow'){?>
                                                    <option selected value="donotknow">- Don't Know -</option>
                                                        
                                                   <?php
                                                   }else{
                                                    ?>
                                                    <option value="donotknow">- Don't Know -</option>
                                                   <?php } ?>
                                                </select>
                                                </div>
                                             </div>

                                              <div class="form-group editpage" id="incomeDiv">
											<label class="col-sm-4 col-xs-12 control-label nopad1">Time of Birth <span style="color:#c03131;font-size: 20px;"> * </span></label>
											<?php
											$split_mer = explode(' ', $profile['km_birthtime']);
											$split_time = explode(':', $split_mer[0]);

											?>

											<div class="col-xs-12 col-sm-8">
											<label class="col-sm-3 makefull nopad1 nopad" style="width: 25%;padding: 0px;">
											<select class="form-control" name="birthhour"  style="opacity: 1;">
											<option value="" Selected Disabled>Hours</option>
											<?php for($hours = 1; $hours <= 12; $hours++ ){ ?>
											<option value="<?php echo $hours; ?>" <?php if($split_time[0] == $hours){echo 'selected';}?>><?php echo $hours; ?></option>
											<?php } ?>
											</select>
											</label>
											<label class="col-sm-3 makefull nopad1 nopad" style="width: 25%;padding: 0px;">
											<select class="form-control" name="birthmins"  style="opacity: 1;">
											<option value="" Selected Disabled>Mins</option>
											<?php for($mins = 0; $mins <= 59; $mins++ ){ ?>
											<option  value="<?php echo $mins; ?>" <?php if($split_time[1] == $mins){echo 'selected';}?> ><?php echo $mins; ?></option>
											<?php } ?>
											</select>
											</label>
											<label class="col-sm-3 nopad1 nopad" style="padding: 0px;">
											<select class="form-control" name="birthmeridium"  style="opacity: 1;">
											<option value="" Selected Disabled>Meridium</option>
											<option value="AM" <?php if($split_mer[1] == "AM"){echo 'selected';}?> >AM</option>
											<option value="PM" <?php if($split_mer[1] == "PM"){echo 'selected';}?> >PM</option>
											</select>
											</label>
											</div>
											</div>
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">Place of Birth <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" value="<?php echo $profile['km_place_of_birth']; ?>" id="place_of_birth" name="place_of_birth" placeholder="Place of Birth" class="form-control" autocomplete="off">
                                                </div>
                                             </div>
                                              <div class="form-group editpage">
                                                <label class="col-sm-4 col-xs-12 control-label nopad1">Order of Birth <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8 col-xs-12">
                                                <select class="form-control" id="order_of_place" name="order_of_place" >
		                                          <option value="" Selected Disabled> --- Select --- </option>
		                                          <?php for($oob = 1; $oob <= 10; $oob++ ){ ?>
		                                          <option value="<?php echo $oob; ?>" <?php if($profile['km_order_of_birth'] == $oob){ echo 'selected'; } ?> ><?php echo $oob; ?></option>
		                                          <?php } ?>
		                                       	  </select>
                                                </div>
                                             </div>
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">Native Place <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" value="<?php echo $profile['km_native_place']; ?>" id="native" name="native" placeholder="Native Place" class="form-control" autocomplete="off">
                                                </div>
                                             </div>
                                             <div class="form-group editpage">
                                                <label class="col-sm-4 control-label">Native District <span style="color:#c03131;font-size: 20px;"> * </span></label>
                                                <div class="col-sm-8">
                                                   <input type="text" value="<?php echo $profile['km_native_district']; ?>" id="native_district" placeholder="Native District" name="native_district" class="form-control" autocomplete="off">
                                                </div>
                                             </div>

                                             <div class="form-group editpage">
											<label class="col-sm-4 control-label nopad1">Family Status <span style="color:#c03131;font-size: 20px;"> * </span></label>
											<div class="col-sm-8">
											<label class="radio-inline">
											<input name="family_status" <?php if($profile['km_family_status'] == 'middle'){echo 'checked';}?> id="family_status" type="radio" value="middle"> Middle class
											</label>
											<label class="radio-inline">
											<input name="family_status" <?php if($profile['km_family_status'] == 'uppermiddle'){echo 'checked';}?> id="family_status" type="radio" value="uppermiddle">Upper middle class
											</label>
											<label class="radio-inline">
											<input name="family_status" <?php if($profile['km_family_status'] == 'rich'){echo 'checked';}?> id="family_status" type="radio" value="rich" >Rich
											</label>
											<label class="radio-inline">
											<input type="radio" name="family_status" id="family_status" value="affluent" <?php if($profile['km_family_status'] == 'affluent'){echo 'checked';}?> >Affluent
											</label>
											</div>
											</div>

											<div class="form-group editpage">
											<label class="col-sm-4 control-label nopad1">Family Type <span style="color:#c03131;font-size: 20px;"> * </span></label>
											<div class="col-sm-8">
											<label class="radio-inline">
											<input name="family_type" <?php if($profile['km_family_type'] == 'joint'){echo 'checked'; }?> id="family_type" type="radio" value="joint"> Joint
											</label>
											<label class="radio-inline">
											<input name="family_type" <?php if($profile['km_family_type'] == 'nuclear'){echo 'checked';}?> id="family_type" type="radio" value="nuclear">Nuclear
											</label>
											</div>
											</div>

											<div class="form-group editpage">
											<label class="col-sm-4 control-label nopad1">Family Values <span style="color:#c03131;font-size: 20px;"> * </span></label>
											<div class="col-sm-8">
											   <label class="radio-inline">
											   <input name="family_value" <?php if($profile['km_family_value'] == 'orthodox'){echo 'checked';}?> id="family_value" type="radio" value="orthodox"> Orthodox
											   </label>
											   <label class="radio-inline">
											   <input name="family_value" <?php if($profile['km_family_value'] == 'traditional'){echo 'checked';}?> id="family_value" type="radio" value="traditional">Traditional
											   </label>
											   <label class="radio-inline">
											   <input name="family_value" <?php if($profile['km_family_value'] == 'moderate'){echo 'checked';}?> id="family_value" type="radio" value="moderate" >Moderate
											   </label>
											   <label class="radio-inline">
											   <input type="radio" name="family_value" id="family_value" value="liberal" <?php if($profile['km_family_value'] == 'liberal'){echo 'checked';}?> >Liberal
											   </label>
											</div>
											</div>

											<div class="form-group editpage" >
											<label class="col-xs-12 col-sm-4 col-md-4 control-label">No. of Brother(s) Unmarried<span style="color:#c03131;font-size: 20px;"> * </span></label>
											<div class="col-xs-12 col-sm-8" >
											   <div class="reginput" style="width:100%!important;">
											      <select id="bthrs" name="bcount" class="form-control" style="width: 15%!important;display: inline;float:left;">
											          <option value="" Selected Disabled>Select</option>
											         <?php for($bro = 0; $bro <= 10; $bro++ ){ ?>
											         <option <?php if($profile['bcount'] == $bro){ echo 'selected'; } ?> value="<?php echo $bro; ?>" style="color: rgb(0, 79, 0);"><?php echo $bro; ?></option>
											         <?php } ?>
											      </select>
											      &nbsp; &nbsp; &nbsp;
											      <label style="float: left;margin-left: 5%;">No. of Brother(s) Married  <span style="color:#c03131;font-size: 20px;"> * </span>&nbsp; </label>
											      <select id="bthrsm" name="bmcount" class="form-control" style="width: 15%!important;display: inline;">
											         <option value="" Selected Disabled>Select</option>
											         <?php for($mbro = 0; $mbro <= 10; $mbro++ ){ ?>
											         <option <?php if($profile['bmcount'] == $mbro){ echo 'selected'; } ?> value="<?php echo $mbro; ?>" style="color: rgb(0, 79, 0);"><?php echo $mbro; ?></option>
											         <?php } ?>
											      </select>
											   </div>
											</div>
											</div>
											<div class="form-group editpage" >
											<label class="col-xs-12 col-sm-4 col-md-4 control-label">No. of Sister(s) Unmarried<span style="color:#c03131;font-size: 20px;"> * </span></label>
											<div class="col-xs-12 col-sm-8" >
											   <div class="reginput" style="width:100%!important;">
											      <select id="bthrs" name="scount" class="form-control" style="width: 15%!important;display: inline;float:left;">
											         <option value="" Selected Disabled>Select</option>
											         <?php for($sis = 0; $sis <= 10; $sis++ ){ ?>
											         <option <?php if($profile['scount'] == $sis){ echo 'selected'; } ?> value="<?php echo $sis; ?>" style="color: rgb(0, 79, 0);"><?php echo $sis; ?></option>
											         <?php } ?>
											      </select>
											      &nbsp; &nbsp; &nbsp;
											     <label style="float: left;margin-left: 5%;"> No. of  Sister(s) &nbsp;  Married  <span style="color:#c03131;font-size: 20px;"> * </span>&nbsp;  </label> 
											      <select id="bthrsm" name="smcount" class="form-control" style="width: 15%!important;display: inline;">
											         <option value="" Selected Disabled>Select</option>
											         <?php for($msis = 0; $msis <= 10; $msis++ ){ ?>
											         <option <?php if($profile['smcount'] == $msis){ echo 'selected'; } ?> value="<?php echo $msis; ?>" style="color: rgb(0, 79, 0);"><?php echo $msis; ?></option>
											         <?php } ?>
											      </select>
											   </div>
											</div>
											</div>
                                             
                    <div class="form-group editpage">
                         <div class="col-sm-12" style="text-align: center;">
                                    <div class="capbox" style="border-width: 0px 12px 0px 0px;   display: inline-block; zoom: 1; /* padding: 8px 40px 15px 8px; */">
                                       <div id="CaptchaDiv" style="font: bold 17px verdana, arial, sans-serif; font-style: italic; color: #000000; background-color: #FFFFFF; padding: 4px; -moz-border-radius: 4px; -webkit-border-radius: 4px; border-radius: 4px; border: solid 1px #ccc;"></div>
                                       <div class="capbox-inner" style="font: bold 11px arial, sans-serif; color: #000000; background-color: #d6e9f5; margin: 5px auto 0px auto; padding: 13px; -moz-border-radius: 4px; -webkit-border-radius: 4px; border-radius: 4px;">
                                          Type the above number:
                                          <br><br>
                                          <input type="hidden" id="txtCaptcha">
                                          <input type="text" name="CaptchaInput" id="CaptchaInput" size="15" style="  border: solid 1px #007ed4; border-radius: 5px; height: 30px;" autocomplete="off" onkeypress="return Number(event,this);" Maxlength="5">
                                          <br>
                                       </div>
                                    </div>
                                </div>
                                </div>
                              
                                          </div>
                                       </div>
                                    </div>
                                 </div>

<script type="text/javascript">
                        // Captcha Script
                        
                        var a = Math.ceil(Math.random() * 9)+ '';
                        var b = Math.ceil(Math.random() * 9)+ '';
                        var c = Math.ceil(Math.random() * 9)+ '';
                        var d = Math.ceil(Math.random() * 9)+ '';
                        var e = Math.ceil(Math.random() * 9)+ '';
                        
                        var code = a + b + c + d + e;
                        document.getElementById("txtCaptcha").value = code;
                        document.getElementById("CaptchaDiv").innerHTML = code;
                        
                        // Validate input against the generated number
                        function ValidCaptcha(){
                        var str1 = removeSpaces(document.getElementById('txtCaptcha').value);
                        var str2 = removeSpaces(document.getElementById('CaptchaInput').value);
                        if (str1 == str2){
                        return true;
                        }else{
                        return false;
                        }
                        }
                        
                        // Remove the spaces from the entered and generated code
                        function removeSpaces(string){
                        return string.split(' ').join('');
                        }
                        
                     </script>

                                 <div class="panel panel-default">
                                    <div class="panel-body">
                                      
                                       <div class="ep-view">
                                          <div class="form-horizontal">

                                             <center>
                                                <div class="form-group editpage">
                                                   <div class="col-xs-12 col-sm-12">
                                                      <input type="submit" style="padding: 10px 22px;" class="btn btn-primary btn-reg-process" name="btn_update" value="Update">
                                                   </div>
                                                </div>
                                             </center>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div style="clear:both;"></div>
                              </div>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
               
            </section>
             
          

         </section>
         <div style=" clear: both;"></div>
         </div>
         <?php include("includes/footertop.php");?>
         <?php include("includes/footerin.php");?>
         <?php//include("includes/footer.php");?>
         <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
         <script type="text/javascript">
  $(document).ready(function() {
  $('input[name="dosham"]').click(function() 
   {
    var value = $(this).val();
    if( value == "yes")
    {
    $("#detail_dosham").show();
    }
    else{
    $("#detail_dosham").hide();
    }
  });
});
</script>
 <script>
    

    $(document).ready(function() {
      var Stats = JSON.parse('<?php echo $statesEncoded; ?>');
      var Dist = JSON.parse('<?php echo $districtsEncoded; ?>');

      $('#states').change(function() {
        var categoryId = $(this).val();

        $('#districts').empty();
        $('#districts').append('<option value="" selected disabled>-- Select District--</option>');

        $.each(Dist, function(index, element) {
          if(element.state_id == categoryId) {
            $('#districts').append('<option value="' + element.id + '">' + element.name + '</option>');
          }
        });
      });
    });
  
</script>
         <?php
        if(isset($result)) {
	?>
        <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(50000, function() {
                            $('#message').text("");
                            $('#username').focus();
                    });
            }, 50000);
        </script>
	<?php
            }
	?>
	<script language="Javascript" type="text/javascript">
function PinNo(e, t) {
   try {
       if (window.event) {
           var charCode = window.event.keyCode;
       }
       else if (e) {
           var charCode = e.which;
       }
       else { return true; }
       if (charCode > 31 && (charCode < 48 || charCode > 57)) {
           return false;
       }
       return true;
   }
   catch (err) {
       alert(err.Description);
   }
}

</script>
	<script language="Javascript" type="text/javascript">
function Number(e, t) {
   try {
       if (window.event) {
           var charCode = window.event.keyCode;
       }
       else if (e) {
           var charCode = e.which;
       }
       else { return true; }
       if (charCode > 31 && (charCode < 48 || charCode > 57)) {
           return false;
       }
       return true;
   }
   catch (err) {
       alert(err.Description);
   }
}

</script>
       
      
   </body>
</html>