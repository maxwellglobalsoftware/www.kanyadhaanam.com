<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
ob_start();
session_start();
require_once 'KANyaMatrI_GST/includes/configure.php';
require_once 'includes/session_handler.php';
require_once 'init.php';
require_once 'includes/pagination.php';
require_once 'includes/db.php';

$profileId = $_SESSION['User_Kamma_Matri']['km_regcode'];
$today_date = date("d-m-Y");
   //*********************** Horoscope Details *******************************
 $profiles = new Registration();
   $profiles = $profiles->fetch("WHERE km_regcode = '{$profileId}'")->resultSet(); 
   $profile = $profiles[0];
   
   $profile_email = $profile['km_email'];

   $profile_name = $profile['km_name'];


   if(isset($_SESSION['otp_added'])) {
    if($_SESSION['otp_added']) {
        $result = "Email ID Successfully Verified";
    } else {
        $result = "Failed to verify";
    }
    unset($_SESSION['otp_added']);
}


     if(isset($_POST['edit_first_function'])){
  
    $edit_primary = new registration();
    $edit_primary = $edit_primary->fetch("WHERE km_regcode = '{$profileId}' ORDER BY id DESC")->resultSet(); 
    $edit_primary = $edit_primary[0];

    }

    if(isset($_POST['send_first'])){

    if($_POST['km_email'] == $profile_email){

      $data = array();
      $prime_otp = mt_rand(42336,97887);
      $data[] = $profileId;
      $data[] = $_POST['km_email'];
      $data[] = $prime_otp;
      $data[] = "no";
      $data[] = date("d-m-Y");
      $data[] = date("h:i A");

      $otpverify = new OTP();
      $otpverify = $otpverify->addEmail($data);
      $otpverify_id = $otpverify->lastInsertID();

       $email_send = $_POST['km_email'];

        $msg= "<table>
        
        <p style='font-size: 18px;'>Dear {$profile_name},</p>
        
        <tr><td align='left' style='font-size: 17px;line-height: 1.5em;'>Your OTP for Email ID verification is {$prime_otp}. Do not share with anyone.</td></tr>
        </table>
        <br>
        <table>
        <tr style='font-size: 15px;line-height: 1.5em;'><td>Regards, </tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;'><td>KANYADHAANAM MATRIMONY - TEAM</tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;'><td><a href='www.kanyadhaanam.com' target='_blank'>www.kanyadhaanam.com</a></tr></td>
        </table>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/call_icon.png' style=''> &nbsp;95000 90825 </p>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/whatsapp_icon.png' style=''> &nbsp;95000 90825 </p>
        
        
        <div id='accordion-container' style='font-size: 11px;background: #ffffff;padding: 5px 10px 10px 10px;border: 1px solid #cccccc;;border-radius: 5px;box-shadow: 0 5px 15px #cccccc; width:70%;'>
        
        <h2 class='accordion-header active-header' style=' margin-top: 0px;border-radius: 5px 5px 0 0;background: url(http://www.kanyadhaanam.com/images/active-header.gif) #cef98d;background-repeat: no-repeat;margin: 5px 0 0 0;padding: 5px 20px;cursor: pointer;color: #e23f0c;'><img src='http://www.kanyadhaanam.com/images/lightbulb.png' width='40' style='vertical-align: middle;'>  Qns : How to change my Email ID after verification ?
        </h2>
        
        <div class='accordion-content open-content' style='width: 766px; display: block;padding: 10px;background: #ffffff;border: 1px solid #cccccc;border-top: 0;border-radius: 0 0 5px 5px;text-align: justify;width: auto;font-size: 16px;font-weight: normal;'>
         <p> Send Your  Email ID to support@kanyadhaanam.com for instant update. </p>
        
         <p> You can also reah our customer support&nbsp;&nbsp;<img src='http://www.kanyadhaanam.com/images/call_icon.png' style=''>&nbsp;95000 90825  (or)&nbsp;&nbsp;<img src='http://www.kanyadhaanam.com/images/whatsapp_icon.png' style=''>95000 90825 . </p>
        </div>
        
        ";
	   
	   $to = $email_send;
	   $subject = "Verify your Email ID Now - KANYADHAANAM MATRIMONY";

	   // Always set content-type when sending HTML email
	    $headers = "MIME-Version: 1.0" . "\r\n";
	    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	    
	    // More headers
	    $headers .= 'From: <donotreply@kanyadhaanam.com>' . "\r\n";
	    
	    $send_mail = mail($to,$subject,$msg,$headers);

      if($otpverify_id){
          header("Location: email_verification.php");
      }

    } else {

      $MailID = $_POST['km_email'];

      $updatenew = new Registration();
      $updatenew = $updatenew->updateEmail(array(
        $MailID,
        $profileId
      ));

      $data = array();
      $prime_otp = mt_rand(42336,97887);
      $data[] = $profileId;
      $data[] = $_POST['km_email'];
      $data[] = $prime_otp;
      $data[] = "no";
      $data[] = date("d-m-Y");
      $data[] = date("h:i A");

      $otpverify = new OTP();
      $otpverify = $otpverify->addEmail($data);
      $otpverify_id = $otpverify->lastInsertID();

       $email_send = $_POST['km_email'];

       $msg= "<table>
        
        <p style='font-size: 18px;'>Dear {$profile_name},</p>
        
        <tr><td align='left' style='font-size: 17px;line-height: 1.5em;'>Your OTP for Email ID verification is {$prime_otp}. Do not share with anyone.</td></tr>
        </table>
        <br>
        <table>
        <tr style='font-size: 15px;line-height: 1.5em;'><td>Regards, </tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;'><td>KANYADHAANAM MATRIMONY - TEAM</tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;'><td><a href='www.kanyadhaanam.com' target='_blank'>www.kanyadhaanam.com</a></tr></td>
        </table>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/call_icon.png' style=''> &nbsp;95000 90825 </p>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/whatsapp_icon.png' style=''> &nbsp;95000 90825 </p>
        
        
        <div id='accordion-container' style='font-size: 11px;background: #ffffff;padding: 5px 10px 10px 10px;border: 1px solid #cccccc;;border-radius: 5px;box-shadow: 0 5px 15px #cccccc; width:70%;'>
        
        <h2 class='accordion-header active-header' style=' margin-top: 0px;border-radius: 5px 5px 0 0;background: url(http://www.kanyadhaanam.com/images/active-header.gif) #cef98d;background-repeat: no-repeat;margin: 5px 0 0 0;padding: 5px 20px;cursor: pointer;color: #e23f0c;'><img src='http://www.kanyadhaanam.com/images/lightbulb.png' width='40' style='vertical-align: middle;'>  Qns : How to change my Email ID after verification ?
        </h2>
        
        <div class='accordion-content open-content' style='width: 766px; display: block;padding: 10px;background: #ffffff;border: 1px solid #cccccc;border-top: 0;border-radius: 0 0 5px 5px;text-align: justify;width: auto;font-size: 16px;font-weight: normal;'>
         <p> Send Your Email ID to support@kanyadhaanam.com for instant update. </p>
        
         <p> You can also reah our customer support&nbsp;&nbsp;<img src='http://www.kanyadhaanam.com/images/call_icon.png' style=''>&nbsp;95000 90825  (or)&nbsp;&nbsp;<img src='http://www.kanyadhaanam.com/images/whatsapp_icon.png' style=''>95000 90825 . </p>
        </div>
        
        ";
	   
	   $to = $email_send;
	   $subject = "Verify your Email ID Now - KANYADHAANAM MATRIMONY";

	   // Always set content-type when sending HTML email
	    $headers = "MIME-Version: 1.0" . "\r\n";
	    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	    
	    // More headers
	    $headers .= 'From: <donotreply@kanyadhaanam.com>' . "\r\n";
	    
	    $send_mail = mail($to,$subject,$msg,$headers);


      if($otpverify_id){
          header("Location: email_verification.php");
      }

    }


   }

   if(isset($_POST['primary_submit'])){


      $primary_emails = new OTP();
      $primary_emails = $primary_emails->fetchEmail("WHERE pl_userId = '{$profileId}' AND reg_date = '{$today_date}' AND pl_primary_email = '{$profile_email}' AND pl_primary_code = '{$_POST['primary_otp']}' ORDER BY id DESC")->resultSet(); 
      $primary_email = $primary_emails[0];

      if($primary_email){

      $data = array();
      $data[] = $profileId;
      $data[] = $primary_email['pl_primary_email'];
      $data[] = $_POST['primary_otp'];
      $data[] = "yes";
      $data[] = $primary_email['id'];

      $updateotpverify = new OTP();
      $updateotpverify = $updateotpverify->updateEmail($data);
      $updateotpverify_id = $updateotpverify->rowCount();

      if($updateotpverify_id){
         $_SESSION['otp_added'] = true;
      }
      header("Location: email_verification.php");
   } else {
      $_SESSION['otp_added'] = false;
      header("Location: email_verification.php");
   }
   } 

 
   $primary_otp_success = new OTP();
   $primary_otp_success = $primary_otp_success->fetchEmail("WHERE pl_userId = '{$profileId}' AND  pl_primary_status = 'yes' ORDER BY id DESC")->resultSet(); 
   $primary_otp_success = $primary_otp_success[0];

   $primary_emails = new OTP();
   $primary_emails = $primary_emails->fetchEmail("WHERE pl_userId = '{$profileId}' AND reg_date = '{$today_date}' AND pl_primary_email = '{$profile_email}' ORDER BY id DESC")->resultSet(); 
   $primary_email = $primary_emails[0];

   ?>
<!DOCTYPE html>
<html>
<script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
   <?php include("includes/headertop.php");?>
<script>
    function firstfn(form){
        
        var re = /^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$/;
        
        if(form.km_email.value=="") { alert("Please enter your Email ID"); form.km_email.focus(); return false; }
    if(form.km_email.value!="")
    {
        
    if(!form.km_email.value.match(re))  
         {  
         
         alert('Please enter valid Email ID');  
         form.km_email.focus(); return false;
         }  
    
    }
                                    
        
    }
</script>
   <body class="home color-green boxed shadow">
      
         <?php include("includes/headerin.php");?>
        
            <script src="js/jquery-1.12.4.js"></script>
           
            <?php include("includes/bannerin.php");?>
         
         <?php //include("includes/quicksearch.php");?>

         <div class="root">
         <section class="content reverse">
         <?php include("includes/right.php");?>
            <section class="col-md-9 col-xs-12" style=" margin-top: 1%;">
            <div class="row" id="message_container" style="padding: 10px;font-size:16px;text-align: center; display: none; color: blue; font-weight: bold">
                              <div class="col-md-12">
                                      <span id="message"></span>
                              </div>   
                        </div>
               <table>
                  <tr class="tabletitle" >
                     <td colspan="2" style="  border-top-left-radius: 0.5em; border-top-right-radius: 0.5em;">Email OTP Verification</td>
                  </tr>
               </table>
               <div id="result-content">
                  <div class="panel-default panel-ep">
                     <div class="panel-body">
                        <div class="ep-view editProfileContent" style="" id="basicRelDetailsFormview">


                              <div class="form-horizontal verify">
                                 <div class="form-group required">
                                    <label class="col-sm-4 control-label">Email ID </label>
                                    <form  id='search_result' name="FirstForm" method="post" onsubmit="return firstfn(FirstForm);">
                                    <input type="hidden" id="primary_id" name="primary_id" value="" />
                                    <div class="col-sm-8">
                                       <div class="col-sm-7" style=" padding-right: 0px; padding-left: 0px;">
                                          <input type="text"  class="form-control" id="km_email" <?php if($primary_email['pl_primary_email']){ ?> readonly style="background-color: #eee;" <?php } else if($primary_otp_success){ ?> readonly    style="background-color: #eee;" <?php } else if($edit_primary){ ?> autofocus="autofocus" <?php } else { ?> readonly    style="background-color: #eee;" <?php } ?> name="km_email" placeholder="Email ID" required="" value="<?php echo $profile_email; ?>" style=" width: 100%"> 

                                          <?php 

                                          if($primary_otp_success){ } else 

                                          if($primary_email['pl_primary_email']){ 


                                             ?>
                                           <div class="col-sm-12" style=" padding-left: 0px; padding-right: 0px;">
                                          <label class="col-sm-6 control-label" style=" width: 38%; padding-left: 0px ; padding-right: 0px; float: left; ">Enter OTP </label>

                                           <input type="text" class="form-control makeboxfull" id="primary_otp" Maxlength="5"  autofocus="autofocus" name="primary_otp" placeholder="Enter OTP" onkeypress="return PrimaryNo(event,this);" required="" style=" width: 40%">

                                           <script language="Javascript" type="text/javascript">
 
                                      function PrimaryNo(e, t) {
                                          try {
                                              if (window.event) {
                                                  var charCode = window.event.keyCode;
                                              }
                                              else if (e) {
                                                  var charCode = e.which;
                                              }
                                              else { return true; }
                                              if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                                                  return false;
                                              }
                                              return true;
                                          }
                                          catch (err) {
                                              alert(err.Description);
                                          }
                                      }
                               
                                  </script>
                                            <strong style=" color: #e80a0a;"><input type="submit" style="color: #ffffff;background-color: #0ca10a;border: 0px;height: 30px;padding-top: 5px;" name="primary_submit" value="Verify"> &nbsp; &nbsp;  </strong>
                                           </div>
                                           <?php } else { ?>
                                           <div class="col-sm-5" style=" vertical-align: middle; padding-bottom: 3.5%; padding-right: 0px;">
                                         
                                          <strong style=" color: #e80a0a;"><input type="submit" style="color: #1f22ad;background-color: white;border: 0px;" name="send_first" value="Send OTP"> &nbsp; &nbsp;  </strong>
                                       </div>
                                       <?php } ?>
                                       </div>
                                       </form>
                                       <?php if($primary_otp_success){ ?>
                                       <div class="col-sm-5" style=" vertical-align: middle; padding-top: 3.5%;">
                                          <small>(Verified <i class="fa fa-check"></i>)</small>
                                       </div>
                                       <?php } else { ?>
                                       <form method="post">
                                       <div class="col-sm-5" style=" vertical-align: middle; padding-top: 1.5%; padding-right: 0px;">
                                       
                                          <strong style=" color: #e80a0a;">
                                          <i  class="fa fa-pencil" style="color: #1f22ad;" aria-hidden="true"></i><input <?php if($primary_email['pl_primary_email']){ ?> readonly style="cursor: inherit;color: #1f22ad;background-color: white;border: 0px;width: 60px; " <?php } else if($edit_primary){  ?> readonly style="cursor: inherit;color: #1f22ad;background-color: white;border: 0px;width: 60px; " <?php } else  { ?> type="submit"  <?php } ?> style="color: #1f22ad;background-color: white;border: 0px;" name="edit_first_function" value="Edit" > &nbsp; (Not Verified) </strong>
                                       </div>
                                       </form>
                                       <?php } ?>
                                    </div>
                                    

                                  
                                 </div>
                              </div>


                        </div>
                     </div>
                  </div>
               </div>
            </section>
            
         </section>
         <div style=" clear: both;"></div>
         </div>
         <?php include("includes/footertop.php");?>
         
         <?php include("includes/footerin.php");?>
         <script language="Javascript" type="text/javascript">
           function Number(e, t) {
               try {
                   if (window.event) {
                       var charCode = window.event.keyCode;
                   }
                   else if (e) {
                       var charCode = e.which;
                   }
                   else { return true; }
                   if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                       return false;
                   }
                   return true;
               }
               catch (err) {
                   alert(err.Description);
               }
           }
           
        </script>
      <?php
        if(isset($result)) {
   ?>
        <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(1000, function() {
                            $('#message').text("");
                            $('#username').focus();
                    });
            }, 5000);
        </script>
   <?php
            }
   ?>
      
   </body>
</html>