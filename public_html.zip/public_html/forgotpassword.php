<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   if($_SESSION['User_Kamma_Matri']){
       unset($_SESSION['User_Kamma_Matri']);
   }
   date_default_timezone_set('Asia/Kolkata');
   require_once 'init.php';
   require_once 'KANyaMatrI_GST/includes/configure.php';
   
    if(isset($_POST['submit'])) {
   
   
           $email_id = $_POST['email_id'];
   
       $users = new Registration();
       $users = $users->fetch("WHERE km_email = '{$email_id}' AND km_status = 'live'")->resultSet();
       $user = $users[0];
   
       if($user){
   
          $user_name = $user['km_name'];
          $user_pass = $user['km_password'];
          $userID = $user['km_regcode'];
   
   
          $to = $user['km_email'];
    $subject = "Forgot Password request from www.kanyadhaanam.com";
   
    $msg = "<table>
   
        <p style='font-size: 18px;margin-bottom:8px;'>Dear {$user_name},</p>
   
        <tr style='font-size: 15px;line-height: 1.5em;'><td>User ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp; <b>$userID</b></td></tr>
   
        <tr style='font-size: 15px;line-height: 1.5em;'><td>Password&nbsp;:&nbsp; <b>$user_pass</b></td></tr>
   
        <tr style='font-size: 15px;line-height: 1.5em;'><td><a href='http://www.kanyadhaanam.com/login.php' target='_blank' style='color:blue;text-decoration:underline;'>Click here to login</a></tr></td>
   
        </table>
   
        <br>
        <table>
        <tr style='font-size: 15px;line-height: 1.5em;font-weight:bold;'><td>Regards, </tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;font-weight:bold;'><td>KANYADHAANAM MATRIMONY - TEAM</tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;'><td><a href='www.kanyadhaanam.com' target='_blank'>www.kanyadhaanam.com</a></tr></td>
        </table>
   
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/call_icon.png' style=''> &nbsp;95000 90825</p>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/whatsapp_icon.png' style=''> &nbsp;95000 90825</p>
   
        <div id='accordion-container' style='font-size: 11px;background: #ffffff;padding: 5px 10px 10px 10px;border: 1px solid #cccccc;;border-radius: 5px;box-shadow: 0 5px 15px #cccccc; width:75%;'>
        
        <h2 class='accordion-header active-header' style=' margin-top: 0px;border-radius: 5px 5px 0 0;background: url(http://www.kanyadhaanam.com/images/active-header.gif) #cef98d;background-repeat: no-repeat;margin: 5px 0 0 0;padding: 5px 20px;cursor: pointer;color: #e23f0c;'><img src='http://www.kanyadhaanam.com/images/lightbulb.png' width='40' style='vertical-align: middle;'>  Qns : How do I Login?
        </h2>
        
        <div class='accordion-content open-content' style='width: 766px; display: block;padding: 10px;background: #ffffff;border: 1px solid #cccccc;border-top: 0;border-radius: 0 0 5px 5px;text-align: justify;width: auto;font-size: 16px;font-weight: normal;'>
   
         <p style='margin: 5px;line-height: 1.5em;'><img src='http://www.kanyadhaanam.com/images/answer.png'> :  Enter your <b>User ID</b> and <b>Password</b> in the respective boxes and Click on the <b>Login</b> button to login</p>
   
         <p style='margin: 5px;line-height: 1.5em;margin-left: 4.5%;'>to your account.</p>
        
        </div>
   
        <h2 class='accordion-header active-header' style=' margin-top: 0px;border-radius: 5px 5px 0 0;background: url(http://www.kanyadhaanam.com/images/active-header.gif) #cef98d;background-repeat: no-repeat;margin: 5px 0 0 0;padding: 5px 20px;cursor: pointer;color: #e23f0c;'><img src='http://www.kanyadhaanam.com/images/lightbulb.png' width='40' style='vertical-align: middle;'>  Qns : Why is the message <b>Invalid User ID / Password</b> being displayed when I try to login?
        </h2>
   
        <div class='accordion-content open-content' style='width: 766px; display: block;padding: 10px;background: #ffffff;border: 1px solid #cccccc;border-top: 0;border-radius: 0 0 5px 5px;text-align: justify;width: auto;font-size: 16px;font-weight: normal;'>
   
         <p style='margin: 5px;line-height: 1.5em;'><img src='http://www.kanyadhaanam.com/images/answer.png'> :  You could have received these messages due to any of the below reasons.</p>
   
         <p style='margin: 5px;line-height: 1.5em;margin-left: 4.5%;'>You might have entered incorrect spelling.</p>
   
         <p style='margin: 5px;line-height: 1.5em;margin-left: 4.5%;'>Unnecessary spaces in the User ID typed. Ensure that you don’t add any spaces.</p>
   
         <p style='margin: 5px;line-height: 1.5em;margin-left: 4.5%;'>Do not try to login with your Email ID.</p>
        
        </div>
   
        </div>
        
        ";
   
            // Always set content-type when sending HTML email
      $headers = "MIME-Version: 1.0" . "\r\n";
      $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
   
      // More headers
      $headers .= 'From: <support@kanyadhaanam.com>' . "\r\n";
   
      $send = mail($to,$subject,$msg,$headers);
   
      if($send){
        echo '<script>window.alert("Password sent to your email id");</script>';
              echo '<script>window.location="login.php"</script>';
      }
   
         } else {
             echo '<script>window.alert("Please enter valid registered email id");</script>';
             echo '<script>window.location="forgotpassword.php"</script>';
     //            header('Location: index.php');
         }
   
    }
   
   
   //*********************** Female Profile Details *******************************
   $female_profiles = new Registration();
   $female_profiles = $female_profiles->fetch("WHERE km_gender = 'female' AND km_status = 'live' ORDER BY id DESC ")->resultSet(); 
   
   //*********************** Male Profile Details *******************************
   $male_profiles = new Registration();
   $male_profiles = $male_profiles->fetch("WHERE km_gender = 'male' AND km_status = 'live' ORDER BY id DESC ")->resultSet();    
   
   ?>
<!DOCTYPE html>
<html>
   <head>
      <title>Kanyadhaanam Matrimony</title>
      <?php include("includes/headertop.php");?>
      <style type="text/css">table {
         width: 90%;
         border: none;
         margin: 0px auto;
         }
      </style>
      <script type="text/javascript">
         function forgotfn(form)
         
         {
         
         var re = /^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$/;
         
         if(form.email_id.value=="") { alert("Please Enter Registered Email ID"); form.email_id.focus(); return false; }
         
         if(form.email_id.value!="")
         {
         if(!form.email_id.value.match(re))  
            {  
            alert("Please enter valid Email ID"); form.email_id.focus();
            return false;
            }  
         }
         
         }
         
      </script>
   </head>
   <body class="home color-green boxed shadow">
      <?php include("includes/header.php");?>
      <section id="register-home">
            <div class="container">
               <div class="row">
                  
                  <div class="col-sm-6 col-xs-12">
                     <h4 style="font-size: 45px;">
                        FORGOT PASSWORD
                     </h4>
                  </div>
               </div>
            </div>
         </section>
      <div class="root">
         <script src="js/jquery-1.12.4.js"></script>
         <section class="content reverse">
            <section class="main">
               <section class="columns" style="margin-top:10px !important;  width: 80%; ">
                  <h2><span>  Forgot Password Assistance</span></h2>
                  <div  id="message_container" style="text-align: center; display: none; color: red;font-size: 18px; font-weight: bold">
                     <span id="message"></span>
                  </div>
                  <form role="form"  method="post" name="ForgotForm" onsubmit="return forgotfn(ForgotForm);">
                     <div class="form-group col-md-5 col-xs-12">
                     <div class="row">

                        <label for="uid" style=" font-size: 20px;"><i class="fa fa-envelope" style=" color: #f38502; "></i> E-mail ID : <span></span></label>
                        <input type="text" class="form-control required fullwidth" name="email_id" style=" padding: 20px 10px;"  placeholder="Enter Email Address here">
                        </div>

                     </div>

                     <div style=" clear: both;"></div>


                     <button type="submit" name="submit" class="btn btn-success btn-block makemybutton" style="background: #c32143; border: none;"> <i class="fa fa-send"></i> Send</button>  
                     <p style=" color: #c32143; font-family: 'Open Sans', sans-serif;">Enter Your Regsitered Email ID *</p>
                  </form>
               </section>
            </section>
         </section>
         <div style=" clear: both;"></div>
         <script type="text/javascript">
            $(document).ready(function()
            {
              //Add Inactive Class To All Accordion Headers
              $('.accordion-header').toggleClass('inactive-header');
              
              //Set The Accordion Content Width
              var contentwidth = $('.accordion-header').width();
              $('.accordion-content').css({'width' : contentwidth });
              
              //Open The First Accordion Section When Page Loads
              $('.accordion-header').first().toggleClass('active-header').toggleClass('inactive-header');
              $('.accordion-content').first().slideDown().toggleClass('open-content');
              
              // The Accordion Effect
              $('.accordion-header').click(function () {
                if($(this).is('.inactive-header')) {
                  $('.active-header').toggleClass('active-header').toggleClass('inactive-header').next().slideToggle().toggleClass('open-content');
                  $(this).toggleClass('active-header').toggleClass('inactive-header');
                  $(this).next().slideToggle().toggleClass('open-content');
                }
                
                else {
                  $(this).toggleClass('active-header').toggleClass('inactive-header');
                  $(this).next().slideToggle().toggleClass('open-content');
                }
              });
              
              return false;
            });
         </script>
         <script>
            $(document).ready(function(){
            $('#tabs').tabs();
            $('#tabs').css('display', 'block');
            });
         </script>
         <br><br>
         <?php
            if(isset($result)) {
            ?>
         <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(50000, function() {
                            $('#message').text("");
                            $('#username').focus();
                    });
            }, 50000);
         </script>
         <?php
            }
            ?>
      </div>
      <?php include("includes/footer.php");?>
   </body>
</html>