<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
ob_start();
session_start();
 require_once 'KANyaMatrI_GST/includes/configure.php';
 require_once 'init.php';
 require_once 'pagination.php';
 //require_once 'db.php';
date_default_timezone_set('Asia/Kolkata');

function profile_details($profile_id,$regcode){
    $pv_viewedId = $profile_id;
    $km_regcode = $regcode;
    unset($_SESSION['pv_viewedId']);
    $_SESSION['pv_viewedId'] = $pv_viewedId;
    //******************** Profile View Details ***************************

    //******************** horoscope ***************************
    if($_POST['submit_flag'] == 'profile' && $_POST['profile_type'] == 'horoscope'){
        $pv_viewedId = $_POST['submit_id'];
        $today = date('Y-m-d');
        
        $paymentIDs = new Payment();
        $paymentIDs = $paymentIDs->fetch("WHERE pl_userId = '{$km_regcode}'  ORDER BY id DESC LIMIT 1")->resultSet(); 
        $paymentID = $paymentIDs[0];  
        
        $payments = new Payment();
        $payments = $payments->fetch("WHERE pl_userId = '{$km_regcode}' AND id = '{$paymentID['id']}' AND pl_status = 'activate' AND '{$today}' BETWEEN pl_startDate AND pl_expireDate ORDER BY id DESC")->resultSet(); 
        $payment = $payments[0];  

      

//        echo '$payment[id] = '.$payment['id'];
//        echo '<BR>';
        if(count($payments)){
            $profiles = new Profile();

            $profiles = $profiles->fetch("WHERE pv_userId = '{$km_regcode}' AND pv_paymentId = '{$payment['id']}' AND horoscope = '1' GROUP BY pv_viewedId")->resultSet(); 
            //$profiles = $profiles->fetch("WHERE pv_userId = '{$km_regcode}' AND pv_paymentId = '{$payment['id']}' AND horoscope = '1'")->resultSet();

//            echo 'count($profiles) = '.count($profiles);
//            exit();
            if(count($profiles) >= 20){
                $profiles = new Profile();
                $profiles = $profiles->fetch("WHERE pv_userId = '{$km_regcode}' AND pv_viewedId = '{$pv_viewedId}' AND pv_paymentId = '{$payment['id']}' AND horoscope = '1' GROUP BY pv_viewedId")->resultSet();
                //$profiles = $profiles->fetch("WHERE pv_userId = '{$km_regcode}' AND pv_viewedId = '{$pv_viewedId}' AND pv_paymentId = '{$payment['id']}' AND horoscope = '1'")->resultSet();

                if($profiles){
                    header("Location: viewhoroscopeprofile.php");
                }else{
                    header("Location: horoscope_alert.php");
                }                
            }else{                 
                $data = array();
                $data[] = $km_regcode;
                $data[] = $payment['id'];
                $data[] = $pv_viewedId;
                $data[] = date('Y-m-d');
                $data[] = date("h:i A");
                $data[] = 0;
                $data[] = 1;
                $profile = new Profile();
                $profile = $profile->add($data);
                $profile_id = $profile->lastInsertID();
                if($profile_id){
                    header("Location: viewhoroscopeprofile.php");
                }
            }     
        }else{
            header("Location: membership.php");
        }
    }

        //******************** Contact ***************************

        if($_POST['submit_flag'] == 'profile' && $_POST['profile_type'] == 'contact'){
        $pv_viewedId = $_POST['submit_id'];
        $today = date('Y-m-d');
        
        $paymentIDs = new Payment();
        $paymentIDs = $paymentIDs->fetch("WHERE pl_userId = '{$km_regcode}'  ORDER BY id DESC LIMIT 1")->resultSet(); 
        $paymentID = $paymentIDs[0];  
        
        $payments = new Payment();
        $payments = $payments->fetch("WHERE pl_userId = '{$km_regcode}' AND id = '{$paymentID['id']}' AND pl_status = 'activate' AND '{$today}' BETWEEN pl_startDate AND pl_expireDate ORDER BY id DESC")->resultSet(); 
        $payment = $payments[0];  
        
//        echo '$payment[id] = '.$payment['id'];
//        echo '<BR>';
        if(count($payments)){
            $profiles = new Profile();

            $profiles = $profiles->fetch("WHERE pv_userId = '{$km_regcode}' AND pv_paymentId = '{$payment['id']}' AND contact = '1' GROUP BY pv_viewedId")->resultSet(); 
            //$profiles = $profiles->fetch("WHERE pv_userId = '{$km_regcode}' AND pv_paymentId = '{$payment['id']}' AND contact = '1'")->resultSet();

//            echo 'count($profiles) = '.count($profiles);
//            exit();
            if(count($profiles) >= 20){
                $profiles = new Profile();
                $profiles = $profiles->fetch("WHERE pv_userId = '{$km_regcode}' AND pv_viewedId = '{$pv_viewedId}' AND pv_paymentId = '{$payment['id']}' AND contact = '1' GROUP BY pv_viewedId")->resultSet();
                //$profiles = $profiles->fetch("WHERE pv_userId = '{$km_regcode}' AND pv_viewedId = '{$pv_viewedId}' AND pv_paymentId = '{$payment['id']}' AND contact = '1'")->resultSet();

                if($profiles){
                    header("Location: viewcontactprofile.php");
                }else{
                    header("Location: contact_alert.php");
                }                
            }else{                 
                $data = array();
                $data[] = $km_regcode;
                $data[] = $payment['id'];
                $data[] = $pv_viewedId;
                $data[] = date('Y-m-d');
                $data[] = date("h:i A");
                $data[] = 1;
                $data[] = 0;
                $profile = new Profile();
                $profile = $profile->add($data);
                $profile_id = $profile->lastInsertID();
                if($profile_id){
                    header("Location: viewcontactprofile.php");
                }
            }     
        }else{
            header("Location: membership.php");
        }
    }


    //******************** Profile Only view ***************************
    if($_POST['submit_flag'] == 'view'){
        $pv_viewedId = $_POST['submit_id'];
        $today = date('Y-m-d');
        
        $paymentIDs = new Payment();
        $paymentIDs = $paymentIDs->fetch("WHERE pl_userId = '{$km_regcode}'  ORDER BY id DESC LIMIT 1")->resultSet(); 
        $paymentID = $paymentIDs[0];  
        
        $payments = new Payment();
        $payments = $payments->fetch("WHERE pl_userId = '{$km_regcode}' AND id = '{$paymentID['id']}' AND pl_status = 'activate' AND '{$today}' BETWEEN pl_startDate AND pl_expireDate ORDER BY id DESC")->resultSet(); 
        $payment = $payments[0];    
        
        
//        echo '$payment[id] = '.$payment['id'];
//        echo '<BR>';
        if(count($payments)){
                $data = array();
                $data[] = $km_regcode;
                $data[] = $payment['id'];
                $data[] = $pv_viewedId;
                $data[] = date('Y-m-d');
                $profile = new Profile();
                $profile = $profile->addview($data);
                $profile_id = $profile->lastInsertID();
                if($profile_id){
                    
                $getprofilesms = new Profile();
                $getprofilesms = $getprofilesms->fetchprofilesms("WHERE pv_userId = '{$km_regcode}' AND pv_paymentId = '{$payment['id']}' AND pv_viewedId = '{$pv_viewedId}' ORDER BY id DESC")->resultSet(); 
                $getprofilesms = $getprofilesms[0]; 

                if($getprofilesms){
                $_SESSION['sms_alert'] = 'no';
                } else {

                $arr = array();
                $arr[] = $km_regcode;
                $arr[] = $payment['id'];
                $arr[] = $pv_viewedId;
                $arr[] = date('Y-m-d');

                $profilesms = new Profile();
                $profilesms = $profilesms->addsms($arr);
                $profilesms_id = $profilesms->lastInsertID();

                $_SESSION['sms_alert'] = 'yes';
                }
                    
                    header("Location: viewbasicprofile.php");
                }    
        }else{
            header("Location: membership.php");
        }
    }

    // if($_POST['submit_flag'] == 'album'){
    //     header("Location: viewalbum.php");
    // }  
    
    if($_POST['submit_flag'] == 'album'){

        $today = date('Y-m-d');
        
        $paymentIDs = new Payment();
        $paymentIDs = $paymentIDs->fetch("WHERE pl_userId = '{$km_regcode}'  ORDER BY id DESC LIMIT 1")->resultSet(); 
        $paymentID = $paymentIDs[0];  
        
        $payments = new Payment();
        $payments = $payments->fetch("WHERE pl_userId = '{$km_regcode}' AND id = '{$paymentID['id']}' AND pl_status = 'activate' AND '{$today}' BETWEEN pl_startDate AND pl_expireDate ORDER BY id DESC")->resultSet(); 
        $payment = $payments[0];  

        if(count($payments)){
         header("Location: viewalbum.php");   
        } else {
         header("Location: membership.php");  
        }
        
    }  
    
    
    
    //******************** ShortList ***************************
        if($_POST['submit_flag'] == 'add_shortlist'){
        $pv_viewedId = $_POST['submit_id'];
        $pv_pagereturn = $_POST['page_return'];
        $data = array();
        $data[] = $km_regcode;
        $data[] = $pv_viewedId;
        $data[] = date('Y-m-d');
        $shortlist_profile = new Partner();
        $shortlist_profile = $shortlist_profile->addShortList($data);
        $shortlist_profile_id = $shortlist_profile->lastInsertID();
        if($shortlist_profile_id){
            header("Location: $pv_pagereturn.php");
        }    
    }

        if($_POST['submit_flag'] == 'remove_shortlist'){
        $pv_viewedId = $_POST['submit_id'];
        $pv_pagereturn = $_POST['page_return'];
        $data = array();
        $data[] = $pv_viewedId;
        
        $get_shortlists = new Partner();
        $get_shortlists = $get_shortlists->fetchShortList("WHERE id ='{$pv_viewedId}'")->resultSet();
        $get_shortlist = $get_shortlists[0];

        $_SESSION['pv_viewedId'] = $get_shortlist['pv_viewedId'];

        $shortlist_profile = new Partner();
        $shortlist_profile = $shortlist_profile->removeShortList($data);
        $shortlist_profile_id = $shortlist_profile->rowCount();
        
        if($shortlist_profile_id){
            header("Location: $pv_pagereturn.php");
        }    
    }



    //******************** Interest ***************************
        if($_POST['submit_flag'] == 'add_interest'){
        $pv_viewedId = $_POST['submit_id'];
        $pv_pagereturn = $_POST['page_return'];
        $data = array();
        $data[] = $km_regcode;
        $data[] = $pv_viewedId;
        $data[] = $_POST['interest_value'];
        $data[] = date('Y-m-d');
        $interest_profile = new Partner();
        $interest_profile = $interest_profile->addInterest($data);
        $interest_profile_id = $interest_profile->lastInsertID();
        if($interest_profile_id){
            header("Location: $pv_pagereturn.php");
        }    
    }

        if($_POST['submit_flag'] == 'remove_interest'){
        $pv_viewedId = $_POST['submit_id'];
        $pv_pagereturn = $_POST['page_return'];
        $data = array();
        $data[] = $pv_viewedId;
        
        $get_interests = new Partner();
        $get_interests = $get_interests->fetchInterest("WHERE id ='{$pv_viewedId}'")->resultSet();
        $get_interest = $get_interests[0];

        $_SESSION['pv_viewedId'] = $get_interest['pv_viewedId'];

        $interest_profile = new Partner();
        $interest_profile = $interest_profile->removeInterest($data);
        $interest_profile_id = $interest_profile->rowCount();
        
        if($interest_profile_id){
            header("Location: $pv_pagereturn.php");
        }    
    }
    
    
}



?>