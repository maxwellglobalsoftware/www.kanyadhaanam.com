<footer>
   <section class="widgets">
      <div class="container">
         <div class="vdivide">
            <div class="col-md-3 col-xs-12">
               <h2 style=" margin-top: 0px; color: #fff; font-size: 30px; font-weight: 600">QUICK LINKS</h2>
               <div class="dot">
                  <ul>
                     <li><a href="tamil-brahmin-iyer-brides.php" title="New Brides"><i class="fa fa-angle-double-right" aria-hidden="true"></i> New Brides</a></li>
                     <li><a href="tamil-brahmin-iyer-grooms.php" title="New Grooms"><i class="fa fa-angle-double-right" aria-hidden="true"></i> New Grooms</a></li>
                     <li><a href="basicregister.php" title="Registration"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Registration</a></li>
                     <li><a href="login.php" title="Registration"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Login</a></li>
                  </ul>
               </div>
            </div>
            <div class="col-md-3 col-xs-12">
               <h2 style=" margin-top: 0px; color: #fff; font-size: 30px; font-weight: 600">INFORMATION</h2>
               <div class="dot">
                  <ul>
                     <li><a href="forgotpassword.php"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Forgot Password? </a></li>
                     <li><a href="" title=""><i class="fa fa-angle-double-right" aria-hidden="true"></i> FAQ</a></li>
                     <li><a href="" title=""><i class="fa fa-angle-double-right" aria-hidden="true"></i> Privacy Policy</a></li>
                     <li><a href="" title=""><i class="fa fa-angle-double-right" aria-hidden="true"></i> Terms and Conditions</a></li>
                  </ul>
               </div>
            </div>
            <div class="col-md-5 col-xs-12">
               <h2 style=" margin-top: 0px; color: #fff; font-size: 30px; font-weight: 600">NEED HELP?</h2>
               <p style=" font-size: 20px; color: #fff;">
                  <span style=" line-height: 32px; color: #fff;">
                  Aachaarya Enterprises,<br>
                  45/22, Singarachari St, <br>
                  Triplicane, Chennai - 600005.</span>
               </p>
               <p style=" font-size: 20px; color: #fff;">
                  <i class="fa fa-phone"></i> Call Us :  95000 90825
                  <br>      
                  <i class="fa fa-envelope"></i> <a href="mailto:support@kanyadhaanam.com" style=" color: #fff; "> support@kanyadhaanam.com</a> 
               </p>
               
                 <br>

               <ul class="footer-widget-social"> 
            <li><a href="https://www.facebook.com/Kanyadhaanam-Matrimony-807795049593936/?modal=admin_todo_tour" target="_blank"><i class="fa fa-facebook"></i></a></li>
            <li><a href="https://twitter.com/kanyadhaanam" target="_blank"><i class="fa fa-twitter"></i></a></li>
           
          
            <li><a href="https://in.pinterest.com/kanyadhaanamm/" target="_blank"><i class="fa fa-pinterest-p"></i> </a></li>            
            <li><a href="https://www.linkedin.com/in/kanyadhaanam-matrimony-8a1189184/" target="_blank"><i class="fa fa-linkedin"></i> </a></li>
            
           </ul>
            </div>
         </div>
      </div>
   </section>
</footer>
<section class="footnote" style=" background-color: #e98e07;">
   <div class="container">
      <div class="col-md-12 col-xs-12">
          <p style=" color: #fff; font-size: 15px; float: left; " class="makecenter">
            Copyrights @ 2019 Aacharya Enterprises. All Rights Reserved
         </p>

         <p style=" float: right;">

         <a href="https://www.maxwellglobalsoftware.com/india/mobile-application-development.php" target="_blank" alt="Best Mobile App Company in Chennai" title="Best Mobile App Development Company in Chennai" style="color:#fff;font-size: 14px;text-align: right;">Best Mobile App Development Company in Chennai - MAXWELL GLOBAL SOFTWARE</a>

         </p>

      </div>
   </div>
</section>
<script src="js/owl.carousel.min.js"></script>