<footer>
   
  <section class="footnote">
   <div class="container">
      <div class="col-md-12 col-xs-12">
         <p style=" color: #fff; text-align: center;" class="makecenter">
           Copyrights @ 2019 Aacharya Enterprises. All Rights Reserved
         </p>
      </div>
      
   </div>
</section>
   
</footer>

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
</script>
 

                            <script src="js/jquery-1.12.4.js"></script>
                            <script src="js/jquery-ui.js"></script>
                            <script>
                                $(function() {
                                    $("#tabs").tabs();
                                });
                            </script>