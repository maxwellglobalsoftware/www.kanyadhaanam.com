<div class="root">

<div style=" border: solid 3px #940406; margin-bottom: 30px; text-align: center; margin-top: 30px;">

<h3 style=" color: #305e03">Now you can send to us your photo and horoscope through WhatsApp.</h3>

<h2 style=" font-weight: bold; padding-bottom: 10px;"><span style=" color: #df3204">WhatsApp No. :  95000 90825  </span></h2>

</div>

</div>



<script type="text/javascript">
                  $(document).ready(function()
                  {
                    //Add Inactive Class To All Accordion Headers
                    $('.accordion-header').toggleClass('inactive-header');
                    
                    //Set The Accordion Content Width
                    var contentwidth = $('.accordion-header').width();
                    $('.accordion-content').css({'width' : contentwidth });
                    
                    //Open The First Accordion Section When Page Loads
                    $('.accordion-header').first().toggleClass('active-header').toggleClass('inactive-header');
                    $('.accordion-content').first().slideDown().toggleClass('open-content');
                    
                    // The Accordion Effect
                    $('.accordion-header').click(function () {
                      if($(this).is('.inactive-header')) {
                        $('.active-header').toggleClass('active-header').toggleClass('inactive-header').next().slideToggle().toggleClass('open-content');
                        $(this).toggleClass('active-header').toggleClass('inactive-header');
                        $(this).next().slideToggle().toggleClass('open-content');
                      }
                      
                      else {
                        $(this).toggleClass('active-header').toggleClass('inactive-header');
                        $(this).next().slideToggle().toggleClass('open-content');
                      }
                    });
                    
                    return false;
                  });
               </script>
               
               
               <script>
                  $(document).ready(function(){
                  $('#tabs').tabs();
                  $('#tabs').css('display', 'block');
                  });
               </script>


