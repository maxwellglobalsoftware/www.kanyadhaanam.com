<?php $PageNameArr=explode("/",$_SERVER['PHP_SELF']);
   $CrPage=$PageNameArr[count($PageNameArr)-1];
   
   
   $Class1=($CrPage=='index.php')?'active':'';
   $Class2=($CrPage=='tamil-nadu-brahmin-brides.php')?'active':'';
   $Class3=($CrPage=='tamil-nadu-brahmin-grooms.php')?'active':'';
   $Class4=($CrPage=='')?'active':'';
   $Class5=($CrPage=='')?'active':'';
   $Class6=($CrPage=='')?'active':'';
   
   $requestFileInfo = pathinfo($_SERVER['REQUEST_URI']);
   
   ?>
<style type="text/css">.member-login {
   border: 0px solid #000;
   float: right;
   /*margin-top: 12px;*/
   }
   .member-login a{
   float: right;
   clear: both;
   }
   .username{
   width: 130px;
   }
   .password{
   width: 135px;
   }
   .member-login a:hover{
   text-decoration: underline;
   color: #c00;
   }
   .login {
   margin: 10px 0px;
   padding-top: 13px;
   float: left;
   font-size: 12px;
   font-weight: normal;
   color: #fff;
   line-height: 20px;
   /*padding-left: 10px;
   border:dotted;*/
   padding-left: 10px;
   }
   .input-text {
   line-height: 18px;
   border: 1px solid #b5181a !important;
   font-size: 12px;
   font-weight: normal;
   color: #000;
   width: 90px;
   padding: 4px 15px;
   text-align: left;
   border-radius: 0px;
   padding: 0px;
   }
   .button-go {
   background: #b5181a;
   /*border: 0px solid #b5181a;*/
   font-size: 16px;
   color: #FFFFFF;
   cursor: pointer;
   margin: 0px;
   border-radius: 3px;
   padding: 9px 15px;
   line-height: 18px;
   /*-moz-border-radius: 0px;
   -webkit-border-radius: 0px;
   border-radius: 0px;*/
   }
</style>
<script type="text/javascript">function loginfn(form) {
   if(form.username.value=="") {
      alert("Please Enter User ID");
      form.username.focus();
      return false;
   }
   if(form.password.value=="") {
      alert("Please Enter Password");
      form.password.focus();
      return false;
   }
   }
   
</script>
<header class="h5">
   <section class="topbar">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <p class="pull-left" style=" color: #fff; font-size: 16px;">
                  <img src="images/trust.png" width="25" height="25"> Trusted Matrimony in Tamilnadu
               </p>
               <p class="pull-right"  style=" color: #fff; padding-top: 4px; font-size: 16px;">
                  <i class="fa fa-phone"></i> Support : 95000 90825 &nbsp; &nbsp; &nbsp;
                  <i class="fa fa-envelope-o"></i>  Email ID : <a href="mailto:support@kanyadhaanam.com" style=" color: #fff;" class="white">support@kanyadhaanam.com</a>
               </p>
            </div>
         </div>
      </div>
   </section>
   <section class="main-header">
      <div class="container">
         <div class="row">
            <div class="col-md-3 col-xs-12 logotop">
               
                  <a href="index.php"><img src="images/logo.png" alt="Kanyadhaanam Matrimony" title="Kanyadhaanam Matrimony" align="left"></a>
               
            </div>
            <div class="col-md-5 col-xs-12">
               <nav id='cssmenu'>
                  <div id="head-mobile"></div>
                  <div class="logo" style="left: 40px;">Menu</div>
                  <div class="buttonin"></div>
                  <ul>
                     <li class="<?php echo $Class1;?>"><a href='index.php'> Home</a></li>
                    

                     <li class="<?php echo $Class2;?>" onclick="return confirm_click();"><a href="basicregister.php"> New Brides </a></li>
                     <li class="<?php echo $Class3;?>" onclick="return confirm_click();"><a href="basicregister.php"> New Grooms </a></li>
                     <li><a href="basicregister.php" style=" margin: 0px;     padding-top: 18px;     padding-left: 15px; font-size: 14px; border: none; "> <button class="btn-contact sty-margin-top-20 btn-mobile" style="padding: 10px 25px;  background-color: #fd9500;   border-radius: 100px!important;">Register</button> </a></li>
                  </ul>
               </nav>
            </div>
            <div class="col-md-4 col-xs-12">
               <nav class="prowidth notop">
                  <div class="member-login">
                     <form name="LogForm" method="post" action="index.php" onsubmit="return loginfn(LogForm);">
                        <div class="login relative username"><input class="input-text" type="text" id="username" name="username" placeholder="User ID" style=" padding: 8px; margin: 0px;"></div>
                        <div class="login relative password"><input placeholder="Password" class="input-text" type="password" name="password" onclick="this.value='';" style=" padding: 8px; margin: 0px; "></div>
                        <div class="login"><input name="go" type="submit" class="button-go ui-corner-all makefull" value="Login"></div>
                     </form>
                  </div>
               </nav>
            </div>
         </div>
         <script type="text/javascript">(function($) {
            $.fn.menumaker=function(options) {
               var cssmenu=$(this), settings=$.extend( {
                  format: "dropdown", sticky: false
               }
               , options);
               return this.each(function() {
                  $(this).find(".buttonin").on('click', function() {
                     $(this).toggleClass('menu-opened');
                     var mainmenu=$(this).next('ul');
                     if (mainmenu.hasClass('open')) {
                        mainmenu.slideToggle().removeClass('open');
                     }
                     else {
                        mainmenu.slideToggle().addClass('open');
                        if (settings.format==="dropdown") {
                           mainmenu.find('ul').show();
                        }
                     }
                  }
                  );
                  cssmenu.find('li ul').parent().addClass('has-sub');
                  multiTg=function() {
                     cssmenu.find(".has-sub").prepend('<span class="submenu-button"></span>');
                     cssmenu.find('.submenu-button').on('click', function() {
                        $(this).toggleClass('submenu-opened');
                        if ($(this).siblings('ul').hasClass('open')) {
                           $(this).siblings('ul').removeClass('open').slideToggle();
                        }
                        else {
                           $(this).siblings('ul').addClass('open').slideToggle();
                        }
                     }
                     );
                  }
                  ;
                  if (settings.format==='multitoggle') multiTg();
                  else cssmenu.addClass('dropdown');
                  if (settings.sticky===true) cssmenu.css('position', 'fixed');
                  resizeFix=function() {
                     var mediasize=1000;
                     if ($( window).width() > mediasize) {
                        cssmenu.find('ul').show();
                     }
                     if ($(window).width() <=mediasize) {
                        cssmenu.find('ul').hide().removeClass('open');
                     }
                  }
                  ;
                  resizeFix();
                  return $(window).on('resize', resizeFix);
               }
               );
            }
            ;
            }
            
            )(jQuery);
            (function($) {
            $(document).ready(function() {
               $("#cssmenu").menumaker( {
                  format: "multitoggle"
               }
               );
            }
            );
            }
            
            )(jQuery);
         </script>
          <script type="text/javascript">
function confirm_click()
{
return confirm("You must register to access profiles!");
}

</script>
      </div>
      <div class="clear"></div>
   </section>
</header>