<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT | E_WARNING));?>
<?php 
   //    ob_start();
       session_start();
       require_once 'init.php';
       date_default_timezone_set('Asia/Kolkata');
       if($_SESSION['User_Kamma_Matri']){
   //        print_r($_SESSION['User_Kamma_Matri']);
           $username = $_SESSION['User_Kamma_Matri']['km_name'];
           $km_photos_regcode = $_SESSION['User_Kamma_Matri']['km_regcode'];
           $km_joining_gender = $_SESSION['User_Kamma_Matri']['km_gender'];
           if($km_joining_gender == 'male'){
               $km_join_gender = 'female';
           }else{
               $km_join_gender = 'male';
           }
       }
   
   
       $get_preferences = new Partner();
       $get_preferences = $get_preferences->fetch("WHERE pl_userId = '{$km_photos_regcode}'")->resultSet(); 
       $get_preference = $get_preferences[0]; 
       $cur_year = date('Y');
       $prefer_age_to = $get_preference['age_to'];;
   
       $to_year = ($cur_year - ($get_preference['age_from'] - 1));
   
       $from_year = ($cur_year - $prefer_age_to);
   
       $prefer_education = explode(",", $get_preference['education']);
   
       $prefer_star = explode(",", $get_preference['star']);
       
       $pre_edu = $get_preference['education'];
       
       $pre_star = $get_preference['star'];
       
   
   
    if($get_preference['star']){
       
       
       $preferences_profiles_list = new Registration();
      $preferences_profiles_list = $preferences_profiles_list->fetch("WHERE km_gender = '{$km_join_gender}' AND   YEAR(km_dateofbirth) BETWEEN '{$from_year}' AND '{$to_year}' AND (km_star = '{$prefer_star[0]}' OR km_star = '{$prefer_star[1]}' OR km_star = '{$prefer_star[2]}' OR km_star = '{$prefer_star[3]}' OR km_star = '{$prefer_star[4]}' OR km_star = '{$prefer_star[5]}' OR km_star = '{$prefer_star[6]}' OR km_star = '{$prefer_star[7]}' OR km_star = '{$prefer_star[8]}' OR km_star = '{$prefer_star[9]}' OR km_star = '{$prefer_star[10]}' OR km_star = '{$prefer_star[11]}' OR km_star = '{$prefer_star[12]}' OR km_star = '{$prefer_star[13]}' OR km_star = '{$prefer_star[14]}' OR km_star = '{$prefer_star[15]}' OR km_star = '{$prefer_star[16]}' OR km_star = '{$prefer_star[17]}' OR km_star = '{$prefer_star[18]}' OR km_star = '{$prefer_star[19]}' OR km_star = '{$prefer_star[20]}') AND km_status = 'live' ORDER BY id DESC")->resultSet();
      $preferences_profiles_list = count($preferences_profiles_list);
       
       
       
   }
       
       $today_date = date('Y-m-d');
       
       $payment_history = new Payment();
       $payment_history = $payment_history->fetch("WHERE pl_userId = '{$km_photos_regcode}' ORDER BY id DESC")->resultSet(); 
       $payment_history = $payment_history[0];
       
       $paymentIDs = new Payment();
       $paymentIDs = $paymentIDs->fetch("WHERE pl_userId = '{$km_photos_regcode}'  ORDER BY id DESC LIMIT 1")->resultSet(); 
       $paymentID = $paymentIDs[0];
   
       $paid_payment_details = new Payment();
       $paid_payment_details = $paid_payment_details->fetch("WHERE pl_userId = '{$km_photos_regcode}' AND id = '{$paymentID['id']}' AND pl_status = 'activate' AND '{$today_date}' BETWEEN pl_startDate AND pl_expireDate ORDER BY id DESC")->resultSet(); 
       $payment = $paid_payment_details[0];
   
       if($payment){
        $view_plan = 30;
       }
      
   
       if($payment){
   
        $count_contact_profiles = new Profile();
        $count_contact_profiles = $count_contact_profiles->fetch("WHERE pv_userId = '{$km_photos_regcode}' AND pv_paymentId = '{$payment['id']}' AND contact = '1' GROUP BY pv_viewedId")->resultSet();
   
        $count_horoscope_profiles = new Profile();
        $count_horoscope_profiles = $count_horoscope_profiles->fetch("WHERE pv_userId = '{$km_photos_regcode}' AND pv_paymentId = '{$payment['id']}' AND horoscope = '1' GROUP BY pv_viewedId")->resultSet();
       }
   
       $photo_profiles = new Profile();
       $photo_profiles = $photo_profiles->fetchPhotos("WHERE pho_userId = '{$km_photos_regcode}' AND pho_imgPath LIKE '%_padangal_%'")->resultSet();
       $profile_photo_paths = $photo_profiles[0];
   
       if($profile_photo_paths['pho_imgPath']){
       $imgPath =  $profile_photo_paths['pho_imgPath'];
   
       $image_file = fopen($imgPath, 'r');
       $imgPath = fread($image_file, filesize($imgPath));
       }else{
       if($_SESSION['User_Kamma_Matri']['km_gender'] == 'male'){
           $imgPath = 'images/male.png';
   
           $image_file = fopen($imgPath, 'r');
           $imgPath = fread($image_file, filesize($imgPath));
       }else{
           $imgPath = 'images/female.png';
   
           $image_file = fopen($imgPath, 'r');
           $imgPath = fread($image_file, filesize($imgPath));
       }
        
      }
   
   
   ?>
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<header class="h5">
   <section class="topbar">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <p class="width1" style=" color: #fff;">
                  <img src="images/support.png">
                  Support : 95000 90825  
               </p>
               <p class="width2"  style=" color: #fff;">
                  <img src="images/whatsappicon.png">  WhatsApp :95000 90825 
               </p>
               <p  class="width3" style=" color: #fff;">  <img src="images/mail.png"> Email ID : <a href="mailto:support@kanyadhaanam.com" style=" color: #fff;" class="white">support@kanyadhaanam.com</a>
               </p>
               <p class="pull-right hidden-xs" style=" color: #fff; ">  <img src="images/hand.png"> Find your special someone!</p>
            </div>
         </div>
      </div>
   </section>
   <section class="main-header">
      <div class="container" style=" padding-left: 0px">
         <div class="col-md-4 col-xs-12" style=" padding-left: 0px">
            <p class="title">
               <a href="profiles.php">
               <img src="images/logo.png"  alt="kanyadhaanam matrimony" title="kanyadhaanam matrimony" align="left">
               </a>
            </p>
         </div>
         <div class="col-md-8 col-xs-12">
            <nav class="nomargin prowidth nopromargin">
               <div style=" float: right; color: #f90808; font-size: 16px;" class="makeheadin needpadin profilein"> Welcome, 
                  <span style="  color: #ef1899; "><?php if($username){$user = $username;}else{$user = 'Guest';} echo $user;?> (<?php echo $_SESSION['User_Kamma_Matri']['km_regcode']; ?>) &nbsp;&nbsp;</span> 
                  <span class="promar">
                  <a href="index.php" style=" color: #ffffff;
                     font-weight: normal;
                     background-color: #b6161b;
                     padding: 7px;"> <i class="fa fa-power-off"></i> Logout </a>  </span>
               </div>
               <ul class="headertop makehide" style=" list-style-type: none; margin-top: 20px;">
                  <strong style="color:#077907; font-size: 16px;" class="makebig">NEED SUPPORT ?</strong>
                  <br>  <br>
                  <li style=" float: left; padding-right: 20px;" class="makeheadin">
                     <div><font style="color:#e40c0c;font-size:18px;" class="makesmallfont"> 
                        <span class="lookgood">
                        <strong><i class="fa fa-phone" aria-hidden="true" class="lookgood"></i></strong> Call Us :95000 90825
                        </span>
                        </font>
                     </div>
                  </li>
                  <li style=" float: left; padding-right: 20px; " class="makeheadin">
                     <div ><font style="color: #077907;font-size:18px;" class="makesmallfont"><strong><i class="fa fa-whatsapp" aria-hidden="true" style="color: #077907; font-size: 20px"></i></strong> 95000 90825</font></div>
                  </li>
                  <li style="float: left;" class="makeheadin">
                     <div ><font style="color: #f75b00;font-size:18px; " class="makesmallfont"><strong><i class="fa fa-envelope" aria-hidden="true" style="color: #f75b00"></i></strong> <a href="mailto:support@kanyadhaanam.com" style="color: #f75b00;">support@kanyadhaanam.com</a></font></div>
                  </li>
               </ul>
            </nav>
         </div>
      </div>
      <section style=" background-color:#b5181a;">
         <div class="container">
            <div class="row">
               <nav id='cssmenu'>
                  <div id="head-mobile"></div>
                  <div class="logo" >Menu</div>
                  <div class="buttonin"></div>
                  <ul>
                     <li class="parent"><a href="profiles.php">Home</a></li>
                     <li class="parent">
                        <a href="javascript:void(0)">Profile </a>
                        <ul>
                           <li><a href="myprofile.php">My Profile</a></li>
                           <li><a href="edit-profile.php">Edit My Profile</a></li>
                           <li><a href="otp.php"> Mobile OTP Verification</a></li>
                           <li><a href="email_verification.php"> Email OTP Verification</a></li>
                           <li><a href="myalbum.php">My Album</a></li>
                           <li><a href="myhoroscope.php">My Horoscope</a></li>
                           <li><a href="my_shortlisted_history.php">Who Shortlisted Me <span></span></a></li>
                           <li><a href="my_exp_interest_history.php">Who Interest Me <span></span></a></li>
                           <li><a href="myhoroscopeviewed_history.php">Who Viewed My Horoscope <span></span></a></li>
                           <li><a href="mycontactviewed_history.php">Who Viewed My Mobile No <span></span></a></li>
                           <li><a href="change_password.php">Change Password <span></span></a></li>
                        </ul>
                     </li>
                     <li class="parent">
                        <a href="javascript:void(0)">Profile Search </a>
                        <ul>
                           <li><a href="profiles.php?age_search=#tabs-1">Age Wise Search</a></li>
                           <li><a href="profiles.php?star_search=#tabs-2">Star Wise Search</a></li>
                           <li><a href="profiles.php?edu_search=#tabs-3">Education Search</a></li>
                           <li><a href="profiles.php?id_search=#tabs-4">ID Search</a></li>
                           <li><a href="profiles.php?marital_search=#tabs-5">Marital Search</a></li>
                        </ul>
                     </li>
                     <li class="parent">
                        <a href="javascript:void(0)">Matches </a>
                        <ul>
                           <li><a href="recommend_matches.php">Recommended Matches  <span>(<?php if($preferences_profiles_list) { echo $preferences_profiles_list; } else { echo 0; } ?>)</span></a></li>
                           <li><a href="profiles.php">Just Joined Matches</a></li>
                        </ul>
                     </li>
                     <li class="parent">
                        <a href="javascript:void(0)">My  History </a>
                        <ul>
                           <li><a href="totalprofile_history.php">Profile History</a></li>
                           <li><a href="contact_history.php">Contact History</a></li>
                           <li><a href="horoscope_history.php">Horoscope History</a></li>
                           <li><a href="shortlisted_history.php">Shortlisted Profiles History</a></li>
                           <li><a href="exp_interest_history.php"> Interest Sent History</a></li>
                        </ul>
                     </li>
                     <!--<li class="parent"><a href="membership.php">Membership</a></li>-->
                     <?php if($payment_history){ ?>
                     <li class="parent">
                        <a href="javascript:void(0)">Membership</a>
                        <ul>
                           <li><a href="membership.php">Upgrade</a></li>
                           <li><a href="payment_history.php">Payment History</a></li>
                        </ul>
                     </li>
                     <?php } else { ?>
                     <li class="parent"><a href="membership.php">Membership</a></li>
                     <?php } ?>
                     <!--  <li class="parent right"><a href="payment-details.php">Payment</a></li> -->
                     <li class="parent"><a href="partnerpreferences.php">Partner Preferences</a></li>
                  </ul>
               </nav>
            </div>
         </div>
      </section>
      <div class="clear"></div>
   </section>
</header>
<style>
   .landing-form p {
   margin: 1em 0;
   }
   .slider {
   height: 410px !important;
   }
   .text {
   padding: 5px;
   width: 94%;
   color: #000;
   border: 1px solid #ccc;
   border-radius: 2px;
   background: #fff;
   }
   .content>aside section table td {
   padding: 1px 0;
   color: #3f3f3f;
   font-size: 12px;
   }
   .content>aside section table th {
   padding: 1px 0;
   color: #666666;
   font-size: 11px;
   border-bottom: 0px solid #e5e5e5;
   }
   #cssmenu>ul>li>a{
   padding-top: 14px !important;
   padding-bottom: 14px;
   color: #fff;
   }
   #cssmenu>ul>li:hover, #cssmenu ul li.active:hover, #cssmenu ul li.active, #cssmenu ul li.has-sub.active:hover{
   border-bottom: none;
   }
</style>
<script type="text/javascript">(function($) {
   $.fn.menumaker=function(options) {
      var cssmenu=$(this), settings=$.extend( {
         format: "dropdown", sticky: false
      }
      , options);
      return this.each(function() {
         $(this).find(".buttonin").on('click', function() {
            $(this).toggleClass('menu-opened');
            var mainmenu=$(this).next('ul');
            if (mainmenu.hasClass('open')) {
               mainmenu.slideToggle().removeClass('open');
            }
            else {
               mainmenu.slideToggle().addClass('open');
               if (settings.format==="dropdown") {
                  mainmenu.find('ul').show();
               }
            }
         }
         );
         cssmenu.find('li ul').parent().addClass('has-sub');
         multiTg=function() {
            cssmenu.find(".has-sub").prepend('<span class="submenu-button"></span>');
            cssmenu.find('.submenu-button').on('click', function() {
               $(this).toggleClass('submenu-opened');
               if ($(this).siblings('ul').hasClass('open')) {
                  $(this).siblings('ul').removeClass('open').slideToggle();
               }
               else {
                  $(this).siblings('ul').addClass('open').slideToggle();
               }
            }
            );
         }
         ;
         if (settings.format==='multitoggle') multiTg();
         else cssmenu.addClass('dropdown');
         if (settings.sticky===true) cssmenu.css('position', 'fixed');
         resizeFix=function() {
            var mediasize=1000;
            if ($( window).width() > mediasize) {
               cssmenu.find('ul').show();
            }
            if ($(window).width() <=mediasize) {
               cssmenu.find('ul').hide().removeClass('open');
            }
         }
         ;
         resizeFix();
         return $(window).on('resize', resizeFix);
      }
      );
   }
   ;
   }
   
   )(jQuery);
   (function($) {
   $(document).ready(function() {
      $("#cssmenu").menumaker( {
         format: "multitoggle"
      }
      );
   }
   );
   }
   
   )(jQuery);
</script>