<html lang="en">
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
   <!-- <meta name="viewport" content="width=1170, User-scalable=yes"> -->
   <link rel="icon" href="images/favicon.png" type="image/x-icon">
   <link href="css/style.css" rel="stylesheet" type="text/css" media="screen">
   <link href="css/font-awesome.css" rel="stylesheet" type="text/css">
   <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
   <link href="css/style-headers.css" rel="stylesheet" type="text/css" media="screen">
   <link href="css/style-colors.css" rel="stylesheet" type="text/css" media="screen">
   <link href="css/pagination.css" rel="stylesheet" type="text/css" media="screen">
   <link href="css/grey.css" rel="stylesheet" type="text/css" media="screen">
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <script src="js/jquery.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <link href="css/owl.carousel.css" rel="stylesheet">
   <link href="css/slider.css" rel="stylesheet">
   <link rel="stylesheet" href="css/jquery-ui.css">
   <style type="text/css">@font-face {
      font-family: 'blogger_sansregular';
      src: url('fonts/Blogger_Sans-webfont.eot');
      src: url('fonts/Blogger_Sans-webfont.eot?#iefix') format('embedded-opentype'),
      url('fonts/Blogger_Sans-webfont.woff2') format('woff2'),
      url('fonts/Blogger_Sans-webfont.woff') format('woff'),
      url('fonts/Blogger_Sans-webfont.ttf') format('truetype'),
      url('fonts/Blogger_Sans-webfont.svg#blogger_sansregular') format('svg');
      font-weight: normal;
      font-style: normal;
      }
   </style>
   <link href="https://fonts.googleapis.com/css?family=Mukta+Malar" rel="stylesheet">