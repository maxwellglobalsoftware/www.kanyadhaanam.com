<?php

/**
 * @link: http://www.Awcore.com/dev
 */
 
   function pagination($query, $per_page = 10,$page = 1, $url){ 
        if($url == 'profiles.php'){ 
            
        $profiles_pages = new Registration();
        $profiles_pages = $profiles_pages->fetch("WHERE {$query} ")->resultSet();
        $total = count($profiles_pages);
   
        // $query = "SELECT COUNT(*) as `num` FROM registration WHERE {$query}";
        // $row = mysqli_fetch_array(mysqli_query($db,$query));
        // $total = $row['num'];
        } else if($url == 'contact_history.php'){
            
            $contact_profiles = new Profile();
            $contact_profiles = $contact_profiles->fetch($query)->resultSet();
            $total = count($contact_profiles);
   
            // $query = "SELECT COUNT(*) as `num` FROM {$query}";
            // $row = mysqli_fetch_array(mysqli_query($db,$query));
            // $total = $row['num'];

       } else if($url == 'horoscope_history.php'){
           
            $horos_profiles = new Profile();
            $horos_profiles = $horos_profiles->fetch($query)->resultSet();
            $total = count($horos_profiles);
            
            // $query = "SELECT COUNT(*) as `num` FROM {$query}";
            // $row = mysqli_fetch_array(mysqli_query($db,$query));
            // $total = $row['num'];

       } else if($url == 'totalprofile_history.php'){
           
           $total_profiles = new Profile();
           $total_profiles = $total_profiles->fetchview($query)->resultSet();
           $total = count($total_profiles);
   
            // $query = "SELECT COUNT(*) as `num` FROM {$query}";
            // $row = mysqli_fetch_array(mysqli_query($db,$query));
            // $total = $row['num'];
       } else if($url == 'myprofileviewed_history.php'){
            $query = "SELECT COUNT(*) as `num` FROM {$query}";
            $row = mysqli_fetch_array(mysqli_query($db,$query));
            $total = $row['num'];

       } else if($url == 'mycontactviewed_history.php'){
           
           $mycontact_profiles = new Profile();
           $mycontact_profiles = $mycontact_profiles->fetch($query)->resultSet();
           $total = count($mycontact_profiles);
            // $query = "SELECT COUNT(*) as `num` FROM {$query}";
            // $row = mysqli_fetch_array(mysqli_query($db,$query));
            // $total = $row['num'];

       } else if($url == 'myhoroscopeviewed_history.php'){
           
           $myhorosprofiles = new Profile();
           $myhorosprofiles = $myhorosprofiles->fetch($query)->resultSet();    
           $total = count($myhorosprofiles);
            // $query = "SELECT COUNT(*) as `num` FROM {$query}";
            // $row = mysqli_fetch_array(mysqli_query($db,$query));
            // $total = $row['num'];
            
            
       } else if($url == 'exp_interest_history.php'){
            $profiles = new Partner();
            $profiles = $profiles->fetchInterest($query)->resultSet();
            $total = count($profiles);
       } else if($url == 'my_exp_interest_history.php'){
            $profiles = new Partner();
            $profiles = $profiles->fetchInterest($query)->resultSet();
            $total = count($profiles);
       } else if($url == 'shortlisted_history.php'){
            $profiles = new Partner();
            $profiles = $profiles->fetchShortList($query)->resultSet();
            $total = count($profiles);
       } else if($url == 'my_shortlisted_history.php'){
            $profiles = new Partner();
            $profiles = $profiles->fetchShortList($query)->resultSet();
            $total = count($profiles);
       } else if($url == 'recommend_matches.php'){
            $profiles = new Registration();
            $profiles = $profiles->fetch($query)->resultSet();
            $total = count($profiles);
       } else if($url == 'search_results.php'){
            $searches = new Registration();
            $searches = $searches->fetch($query)->resultSet();
            $total = count($searches);
       } else if($url == 'payment_contact_profile_details.php'){
       		$profiles = new Profile();
			$contactprofiles = $profiles->fetch($query)->resultSet();  
            $total = count($contactprofiles);
       } else if($url == 'payment_horoscope_profile_details.php'){
       		$profiles = new Profile();
			$horoscopeprofiles = $profiles->fetch($query)->resultSet();  
            $total = count($horoscopeprofiles);
       } 
       else{
            $query = "SELECT COUNT(*) as `num` FROM {$query}";
            $row = mysqli_fetch_array(mysqli_query($db,$query));
            $total = $row['num'];
       }
       $url = '?';
        $adjacents = "2"; 

    	$page = ($page == 0 ? 1 : $page);  
    	$start = ($page - 1) * $per_page;								
		
    	$prev = $page - 1;							
    	$next = $page + 1;
        $lastpage = ceil($total/$per_page);
    	$lpm1 = $lastpage - 1;
    	
    	$pagination = "";
    	if($lastpage > 1)
    	{	
    		$pagination .= "<ul class='pagination' style='float:right;'>";
                    $pagination .= "<li class='details'>Page $page of $lastpage</li>";
    		if ($lastpage < 7 + ($adjacents * 2))
    		{	
    			for ($counter = 1; $counter <= $lastpage; $counter++)
    			{
    				if ($counter == $page)
    					$pagination.= "<li><a class='current'>$counter</a></li>";
    				else
    					$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";					
    			}
    		}
    		elseif($lastpage > 5 + ($adjacents * 2))
    		{
    			if($page < 1 + ($adjacents * 2))		
    			{
    				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
    				{
    					if ($counter == $page)
    						$pagination.= "<li><a class='current'>$counter</a></li>";
    					else
    						$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";					
    				}
    				$pagination.= "<li class='dot'>...</li>";
    				$pagination.= "<li><a href='{$url}page=$lpm1'>$lpm1</a></li>";
    				$pagination.= "<li><a href='{$url}page=$lastpage'>$lastpage</a></li>";		
    			}
    			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
    			{
    				$pagination.= "<li><a href='{$url}page=1'>1</a></li>";
    				$pagination.= "<li><a href='{$url}page=2'>2</a></li>";
    				$pagination.= "<li class='dot'>...</li>";
    				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
    				{
    					if ($counter == $page)
    						$pagination.= "<li><a class='current'>$counter</a></li>";
    					else
    						$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";					
    				}
    				$pagination.= "<li class='dot'>..</li>";
    				$pagination.= "<li><a href='{$url}page=$lpm1'>$lpm1</a></li>";
    				$pagination.= "<li><a href='{$url}page=$lastpage'>$lastpage</a></li>";		
    			}
    			else
    			{
    				$pagination.= "<li><a href='{$url}page=1'>1</a></li>";
    				$pagination.= "<li><a href='{$url}page=2'>2</a></li>";
    				$pagination.= "<li class='dot'>..</li>";
    				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
    				{
    					if ($counter == $page)
    						$pagination.= "<li><a class='current'>$counter</a></li>";
    					else
    						$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";					
    				}
    			}
    		}
    		
    		if ($page < $counter - 1){ 
    			$pagination.= "<li><a href='{$url}page=$next'>Next</a></li>";
                $pagination.= "<li><a href='{$url}page=$lastpage'>Last</a></li>";
    		}else{
    			$pagination.= "<li><a class='current'>Next</a></li>";
                $pagination.= "<li><a class='current'>Last</a></li>";
            }
    		$pagination.= "</ul>\n";		
    	}
    
    
        return $pagination;
    } 
?>