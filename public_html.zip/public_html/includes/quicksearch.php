<style type="text/css">
   .form-horizontal .control-label {
   padding-top: 0px !important;
   margin-bottom: 0;
   text-align: left;
   }
   input[type=text], input[type=password]{
   margin: 0px !important
   }
   .home-form-dob {
   width: 29%;
   padding-left: 0px;
   }
   .landing-form select {
   width: 100%;
   padding: 5px 5px;
   }
   .radio-inline input[type=radio] {
   margin-top: 3px !important;
   }
   .checkbox input[type=checkbox], .checkbox-inline input[type=checkbox], .radio input[type=radio], .radio-inline input[type=radio]{
   margin: 4px 0 0;
   margin-left: -20px;
   }
   @media (max-width: 800px) {
   .landing-form .col-md-7{
   width: 100% !important; 
   float: left;
   padding-top: 0px;
   font-size: 12px;
   }
   .landing-form .col-md-5{
   width: 70% !important;
   float: right;
   padding-left: 0px;
   clear: both; 
   }
   }
</style>
<style type="text/css">
   .capbox {
   border-width: 0px 12px 0px 0px;
   display: inline-block;
   *display: inline; zoom: 1; 
   width: 100%;
   padding: 0px !important
   }
   .capbox-inner {
   font: bold 11px arial, sans-serif;
   color: #000000;
   background-color: #ffffff;
   padding: 3px;
   -moz-border-radius: 4px;
   -webkit-border-radius: 4px;
   border-radius: 0px;
   margin-top: 0px;
   }
   #CaptchaDiv {
   font: bold 17px verdana, arial, sans-serif;
   font-style: italic;
   color: #000000;
   background-color: #FFFFFF;
   padding: 5px;
   -moz-border-radius: 4px;
   -webkit-border-radius: 4px;
   border-radius: 4px;
   width: 100%;
   }
   #CaptchaInput { width: 100%;
   padding: 5px;
   font-family: 'Work Sans', sans-serif;
   font-size: 12px;
   border: none;
   border-radius: 0px; }
   .noleft{
   padding-left: 0px !important
   }
   .nobottom{
   margin-bottom: 5px !important;
   padding-top: 10px;
   clear: both;
   }
   .noright{
   padding-left: 0px !important
   }

   .form-group {
    margin-bottom: 10px !important;
}
</style>
<script>
   function homefn(form){
       
       var re = /^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$/;
       
       var numbers = /^[0-9]+$/; 
       
       if(form.member_name.value=="") { alert("Please enter name"); form.member_name.focus(); return false; }
       
        if(form.mobile.value=="") { alert("Please enter mobile number"); form.mobile.focus(); return false; }
        if(form.mobile.value!="")
        {
        if(!form.mobile.value.match(numbers))  
        {  
        
        alert('Please enter mobile number with only numbers');  
        form.mobile.focus(); return false;
        } 
        if (form.mobile.value.length <10 && form.mobile.value.length != 10)
        { 
        alert('Please enter your 10 digits mobile number exactly');  
        form.mobile.focus(); return false; 
        } 
        
        }
        
        if(form.email.value=="") { alert("Please enter your Email ID"); form.email.focus(); return false; }
        
        if(form.email.value!="")
        {
        if(!form.email.value.match(re))  
        {  
        
        alert('Please enter valid Email ID');  
        form.email.focus(); return false;
        }  
        }
        
        if(form.date.value=="" && form.month.value=="" && form.year.value=="") { alert("Please select date of birth"); form.date.focus(); return false; }
        
        if(form.date.value=="") { alert("Please select date"); form.date.focus(); return false; }
        
        if(form.month.value=="") { alert("Please select month"); form.month.focus(); return false; }
        
        if(form.year.value=="") { alert("Please select year"); form.year.focus(); return false; }
        
        var why = "";
         
         if(form.CaptchaInput.value == ""){
         why += "- Please Enter CAPTCHA Code.\n";
         form.CaptchaInput.focus();
         }
         if(form.CaptchaInput.value != ""){
         if(ValidCaptcha(form.CaptchaInput.value) == false){
         why += "- The CAPTCHA Code Does Not Match.\n";
         form.CaptchaInput.focus();
         }
         }
         if(why != ""){
         alert(why);
         return false;
         }
       
       
   }
</script>
<section class="landing-form">
   <div class="bform-content">
      <div class="form-horizontal">
         <form method="post" id="homeForm" action="registration.php" name="homeForm"   onsubmit="return homefn(homeForm);">
            <h3 style="color:#FFFFFF;font-weight:400; margin-top:0px; margin-bottom: 5px; font-size: 18px;">Free Registration </h3>
            <hr style="margin-bottom:20px; margin-top:10px;">
            <div class="form-group">
               <label class="col-xs-4 col-sm-4 col-md-4 control-label">Name</label>
               <div class="col-xs-8 col-sm-8">
                  <input type="text" class="form-control" id="member_name" name="member_name" placeholder="Name" autocomplete="off" >
               </div>
            </div>
            <div class="form-group">
               <label class="col-xs-4 col-sm-4 col-md-4 control-label">Gender</label>
               <div class="col-xs-8 col-sm-8 col-md-8">
                  <label class="radio-inline">
                  <input type="radio" name="gender" checked="" value="Female">
                  Female </label>
                  <label class="radio-inline">
                  <input type="radio" name="gender" value="Male">
                  Male </label>
               </div>
            </div>
            <div class="form-group">
               <label class="col-xs-4 col-sm-4 col-md-4 control-label">Mobile No.</label>
               <div class="col-xs-8 col-sm-8">
                  <input class="form-control numberonly" name="mobile" id="mobile" maxlength="10" placeholder="Mobile No" autocomplete="off" onkeypress="return Number(event,this);">
               </div>
            </div>
            <div class="form-group">
               <label class="col-xs-4 col-sm-4 col-md-4 control-label">E-mail ID</label>
               <div class="col-xs-8 col-sm-8">
                  <input type="text" class="form-control" value="" name="email" id="email" placeholder="Email ID" autocomplete="off" >
               </div>
            </div>
            <div class="form-group">
               <label class="col-xs-4 col-sm-4 col-md-4 control-label">Date of birth</label>
               <div class="col-xs-8 col-sm-8">
                  <label class="radio-inline pad0 home-form-dob">
                     <select class="form-control" name="date" >
                        <option value="" selected disabled>DD</option>
                        <?php foreach($date_array as $date){?>
                        <option value="<?php echo $date; ?>"><?php echo $date; ?></option>
                        <?php } ?>
                     </select>
                  </label>
                  <label class="radio-inline pad0 home-form-dob">
                     <select class="form-control" name="month" >
                        <option value="" selected disabled>MM</option>
                        <?php foreach($month_array as $key => $month){?>
                        <option value="<?php echo $key; ?>"><?php echo $month; ?></option>
                        <?php } ?>
                     </select>
                  </label>
                  <label class="radio-inline pad0 home-form-dob">
                     <select class="form-control" name="year" >
                        <option value="" selected disabled>YYYY</option>
                        <?php for($year = date('Y')-18;$year >= date('Y')-50;$year--){?>
                        <option value="<?php echo $year; ?>"><?php echo $year; ?></option>
                        <?php } ?>
                     </select>
                  </label>
               </div>
            </div>
            <div class="form-group nobottom">

            <label class="col-xs-4 col-sm-4 col-md-4 control-label"></label>


              
                  <div class="col-sm-12 col-md-4 col-lg-4">
                     <div class="input-group forcap" style=" width: 100%;">
                        <center>
                           <div class="capbox">
                              <div id="CaptchaDiv">86372</div>
                           </div>
                        </center>
                     </div>
                  </div>
                  <div class="col-sm-12  col-md-4 col-lg-4 noleft">
                     <div class="capbox-inner">
                        <!-- Type the above number:<br> -->
                        <input type="hidden" id="txtCaptcha" value="86372">
                        <input type="text" name="CaptchaInput" id="CaptchaInput" Maxlength="5" placeholder="Enter Captcha" onkeypress="return Number(event,this);"><br>
                     </div>
                  </div>
                  <!--    <label class="checkbox-inline"></label>-->
                  <!--   <input type="checkbox" checked="" value="1" name="terms" id="terms" required="">-->
                  <!--I have read and agree to the <a href="terms.php" target="_blank" style=" color: #fdf202">T&amp;C</a> and <a href="privacy.php" target="_blank" style=" color: #fdf202">Privacy Policy</a> </label>-->
               
               
            </div>
            
            <script>
                        var a = Math.ceil(Math.random() * 9)+ '';
                        var b = Math.ceil(Math.random() * 9)+ '';
                        var c = Math.ceil(Math.random() * 9)+ '';
                        var d = Math.ceil(Math.random() * 9)+ '';
                        var e = Math.ceil(Math.random() * 9)+ '';
                        
                        var code = a + b + c + d + e;
                        document.getElementById("txtCaptcha").value = code;
                        document.getElementById("CaptchaDiv").innerHTML = code;
                        
                        // Validate input against the generated number
                        function ValidCaptcha(){
                        var str1 = removeSpaces(document.getElementById('txtCaptcha').value);
                        var str2 = removeSpaces(document.getElementById('CaptchaInput').value);
                        if (str1 == str2){
                        return true;
                        }else{
                        return false;
                        }
                        }
                        
                        // Remove the spaces from the entered and generated code
                        function removeSpaces(string){
                        return string.split(' ').join('');
                        }
            </script>

            <div class="form-group">
               <label class="col-xs-4 col-sm-4 col-md-4 control-label"></label>


            <div class="col-sm-6 col-md-6">
                  <input type="submit" name="registeSubmit" class="btn btn-yellow btn-quick-search" value="REGISTER NOW" style="background: #077907; color: #fff;">
               </div>

               </div>


         </form>
      </div>
   </div>
</section>
 <script language="Javascript" type="text/javascript">
            function Number(e, t) {
                try {
                    if (window.event) {
                        var charCode = window.event.keyCode;
                    }
                    else if (e) {
                        var charCode = e.which;
                    }
                    else { return true; }
                    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                        return false;
                    }
                    return true;
                }
                catch (err) {
                    alert(err.Description);
                }
            }
            
         </script>
<script type="text/javascript">
   $(document ).on('keyup','#mobile', function () {
    var Mobile_No = $('#mobile').val();
    //alert(Mobile_No);
    if(Mobile_No){
    $.ajax({
    type:'post',
    url:'register_validation.php',
    data:{
        flag:'MobileNo',
        phone : Mobile_No,
    },
    success:function(response) {
    var response = response.split("-");
    if(response[0] == 'exists'){
      alert('Mobile No already registered..enter another mobile no');
      document.getElementById("mobile").value = '';
      document.getElementById("mobile").focus();
    }
    }
    }); 
    }
    });
   
   $(document ).on('keyup','#second_mobile', function () {
   var sec_Mobile_No = $('#second_mobile').val();
   if(sec_Mobile_No){
   $.ajax({
   type:'post',
   url:'register_validation.php',
   data:{
    flag:'Sec_MobileNo',
    sec_phone : sec_Mobile_No,
   },
   success:function(response) {
   var response = response.split("-");
   if(response[0] == 'exists'){
   alert('Secondary Mobile No already registered..enter another secondary mobile no');
   document.getElementById("second_mobile").value = '';
   }
   }
   }); 
   }
   });
   
   $(document ).on('keyup','#email', function () {
    var Email_ID = $('#email').val();
    if(Email_ID){
    $.ajax({
    type:'post',
    url:'register_validation.php',
    data:{
        flag:'EMail',
        gmail : Email_ID,
    },
    success:function(response) {
    var response = response.split("-");
    if(response[0] == 'exists'){
      alert('Email ID already registered..enter another email id');
      document.getElementById("email").value = '';
      document.getElementById("email").focus();
    }
    }
    }); 
    }
    });
   
   
</script>