
<aside>
   <section style="padding:5px;background:#fff;border-radius:15px;">
      <div class="right">
         <div style="border:1px solid #ddd; border-radius:5px; -moz-border-radius:5px; -webkit-border-radius:5px; margin-bottom:10px; margin-top: -12px;">
            <h1 style="  margin-top: 0px;">Search</h1>
            <div>
               <ul style=" line-height: 42px; margin-left: 5%;">
                  <li><a href="profiles.php?id_search=#tabs-4"> <img src="images/s1.png"> &nbsp;
                  ID Search</a> </li>

                  <li><a href="profiles.php?age_search=#tabs-1"> <img src="images/s2.png"> &nbsp; Age Wise Search</a> </li>


                  <li><a href="profiles.php?star_search=#tabs-2"> <img src="images/s3.png"> &nbsp; Star Wise Search</a> </li>


                  <li><a href="profiles.php?edu_search=#tabs-3"> <img src="images/s4.png"> &nbsp; Education Search</a> </li>
                  
                  <li><a href="profiles.php?marital_search=#tabs-5"> <img src="images/s1.png"> &nbsp;
                  Marital Search</a> </li>
                  
                
                  
               </ul>
            </div>
         </div>
         <div class="space"></div>
         <div style="border:1px solid #ddd; border-radius:5px; -moz-border-radius:5px; -webkit-border-radius:5px; margin-bottom:10px; margin-top: -12px;">
            <h1 style="  margin-top: 0px;">Personal Settings</h1>
            <div>
               <ul style="  line-height: 42px; margin-left: 5%;">
                  
                  <li><a href="myprofile.php"> <img src="images/user.png"> &nbsp; &nbsp;My Profile</a></li>


                  <li><a href="otp.php"> <span class="sp icon-edtlogout" data-toggle="tooltip" title="" data-original-title="Mobile OTP Verification"></span>Mobile OTP Verification</a></li>
                  
                   <li><a href="email_verification.php"> <span class="sp icon-edtlogout" data-toggle="tooltip" title="" data-original-title="Mobile OTP Verification"></span>Email OTP Verification</a></li>


                  <li><a href="myalbum.php"> <span class="sp icon-album" data-toggle="tooltip" title="" data-original-title="My Album" aria-describedby="tooltip639756"></span> My Album</a></li>
                  <li><a href="myhoroscope.php"> <span class="sp icon-edthoros" data-toggle="tooltip" title="" data-original-title="My Horoscope" aria-describedby="tooltip20681"></span> My horoscope</a></li>
                  <li><a href="edit-profile.php"> <span class="sp icon-edtmyprofile" data-toggle="tooltip" title="" data-original-title="Edit My Profile" aria-describedby="tooltip807945"></span> Edit My Profile</a></li>
                  
                  <li><a href="change_password.php"> <span class="sp icon-edtcngpwd" data-toggle="tooltip" title="" data-original-title="Change Password" aria-describedby="tooltip604078"></span> Change Password</a></li>
               </ul>
            </div>
         </div>
      </div>
   </section>
 
</aside>

