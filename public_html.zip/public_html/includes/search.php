  <script>
               $(document).ready(function(){
               $('#tabs').tabs();
               $('#tabs').css('display', 'block');
               });
            </script>


 <div id="tabs" style="display: none;">
                  <ul>
                     <li><a href="#tabs-1">Age Search</a></li>
                     <li><a href="#tabs-2">Star Search</a></li>
                     <li><a href="#tabs-3">Education Search</a></li>
                     <li><a href="#tabs-4">ID Search</a></li>
                     <li><a href="#tabs-5">Marital Search</a></li>
                    
                  </ul>
                  <div id="tabs-1">
                     <div id="regional-search-area" style="border:0px solid #006600; width:100%; padding-top:5px; padding-bottom:5px;  display:block; ">
                        <div class="search-label" style="width:50px; font-size: 16px; margin-top: 10px;"><b>Age  : </b></div>
                        <form method="post" action="">
                           <div>
                              <select name="agefrom" id="agefrom" class="agedesign">
                                 <option value="21" >21</option>
                                 <?php for($age = 22; $age <= 50; $age++ ){?>
                                 <option value="<?php echo $age;?>"><?php echo $age;?></option>
                                 <?php } ?>
                              </select>
                              &nbsp;To
                              <select name="ageto" id="ageto" class="agedesign">
                                 <option value="21" >21</option>
                                 <?php for($age = 22; $age <= 50; $age++ ){?>
                                 <option  value="<?php echo $age;?>"><?php echo $age;?></option>
                                 <?php } ?>
                              </select>
                              <div class="regional-search-button" style=" float: right; margin-left: -100px;">
                                 <button type="submit" data-refresh="Loading..." data-label="Search Listings" name="age_result" class="button1 makeright" style=" margin-left: -350px; margin-top: -5px;
                                  font-size: 16px;">Search </button>
                              </div>
                           </div>
                        </form>
                     </div>
                  </div>
                  <div id="tabs-2">
                     <form method="post" action="">
                        <div id="regional-search-area" style="border:0px solid #006600; width:600px; padding-top:5px; padding-bottom:5px;  display:block;  ">
                           <div class="search-label-left" style="width:50px;"><b>Age : </b></div>
                           <div class="search-input-left">
                              <select name="agefrom" id="agefrom">
                                 <option value="21" >21</option>
                                 <?php for($age = 22; $age <= 50; $age++ ){?>
                                 <option value="<?php echo $age;?>"><?php echo $age;?></option>
                                 <?php } ?>
                              </select>
                              &nbsp;To
                              <select name="ageto" id="ageto">
                                 <option value="21" >21</option>
                                 <?php for($age = 22; $age <= 50; $age++ ){?>
                                 <option  value="<?php echo $age;?>"><?php echo $age;?></option>
                                 <?php } ?>
                              </select>
                           </div>
                           <div class="search-label" style="width:40px;"><b>Star : </b></div>
                           <div style=" margin-top: 4px;">
                              <select name="star" id="religion" class="validate-selection">
                                 <option value="" selected disabled>- Star -</option>
                                 <?php foreach($stars_array as $star){?>
                                 <option value="<?php echo $star; ?>"><?php echo $star; ?></option>
                                 <?php } ?>
                              </select>
                              <div class="regional-search-button" style="float: right;  margin-right: -22%;
                                 margin-top: -5px;">
                                 <button type="submit" data-refresh="Loading..." data-label="Search Listings" name="star_result" class="button1 makeright" style="width: 150px; font-size: 16px;">Search </button>
                              </div>
                           </div>
                        </div>
                     </form>
                  </div>
                  <div id="tabs-3">
                     <form method="post" action="">
                        <div id="regional-search-area" style="border:0px solid #006600; width:760px; padding-top:5px; padding-bottom:5px;  display:block;  ">
                           <div class="search-label-left" style="width:40px;"><b>Age</b> : </div>
                           <div class="search-input-left">
                              <select name="agefrom" id="agefrom">
                                 <option value="21" >21</option>
                                 <?php for($age = 22; $age <= 50; $age++ ){?>
                                 <option value="<?php echo $age;?>"><?php echo $age;?></option>
                                 <?php } ?>
                              </select>
                              &nbsp;To
                              <select name="ageto" id="ageto">
                                 <option value="21" >21</option>
                                 <?php for($age = 22; $age <= 50; $age++ ){?>
                                 <option  value="<?php echo $age;?>"><?php echo $age;?></option>
                                 <?php } ?>
                              </select>
                           </div>
                           <div class="search-label" style="width:90px;"><b>Education</b> : </div>
                           <div style=" margin-top: 4px;">
                              <select name="education" id="religion" class="validate-selection">
                                 <option value="" selected disabled>-- Select Education --</option>
                                 <?php foreach($edu_array as $key => $value){ ?>
                                 <option value="<?php echo $key;?>"><?php echo $value;?></option>
                                 <?php } ?>
                              </select>
                              <div class="regional-search-button" style="float: right; margin-right: 13%;">
                                 <button type="submit" data-refresh="Loading..." data-label="Search Listings" name="edu_result" class="button1 makeright" style="width: 150px; margin-top: -3px; font-size: 16px;">Search </button>
                              </div>
                           </div>
                        </div>
                     </form>
                  </div>
                  <div id="tabs-4">
                     <form method="post" action="">
                        <div id="regional-search-area" style="border:0px solid #006600; width:760px; padding-top:5px; padding-bottom:5px;  display:block;  ">
                           <div class="search-label-left" style="width:110px;"><b>Matrimony ID</b> : </div>
                           <div>
                              <input type="text" id="id_search" name="id_search" placeholder="ID" style="width:150px;padding: 5px;" class="text" required="">
                             
                              <div class="regional-search-button" style="float: right; margin-right: 40%; margin-top: 10px;">
                                 <button type="submit" data-refresh="Loading..." data-label="Search Listings" name="id_result" class="button1 makeright" style="width: 150px; margin: -5px 0px 0 0px; font-size: 16px; ">Search </button>
                              </div>
                           </div>
                        </div>
                     </form>
                  </div>
                  <div id="tabs-5">
                     <form method="post" action="">
                        <div id="regional-search-area" style="border:0px solid #006600; width:800px; padding-top:5px; padding-bottom:5px;  display:block;  ">
                           <div class="search-label-left" style="width:50px;"><b>Age : </b></div>
                           <div class="search-input-left">
                              <select name="agefrom" id="agefrom">
                                 <option value="21" >21</option>
                                 <?php for($age = 22; $age <= 50; $age++ ){?>
                                 <option value="<?php echo $age;?>"><?php echo $age;?></option>
                                 <?php } ?>
                              </select>
                              &nbsp;To
                              <select name="ageto" id="ageto">
                                 <option value="21" >21</option>
                                 <?php for($age = 22; $age <= 50; $age++ ){?>
                                 <option  value="<?php echo $age;?>"><?php echo $age;?></option>
                                 <?php } ?>
                              </select>
                           </div>
                           <div class="search-label-left" style=""><b>Marital Status  : </b></div>
                           <select name="marital_search" id="marital_search" class="validate-selection" required="" style="width: 20%; margin-top: 5px;">
                              <option value="" selected disabled>-- Select --</option>
                              <option value="unMarried">Unmarried</option>
                              <option value="widower">Widower</option>
                              <option value="divorced">Divorced</option>
                              <option value="awaiting">Awaiting Divorce</option>
                           </select>
                           <div class="regional-search-button" style="float: right; margin-top: 0px; margin-right: 20%;">
                              <button type="submit" data-refresh="Loading..." data-label="Search Listings" name="marital_result" class="button1 makeright" style="width: 150px;  font-size: 16px;">Search </button>
                           </div>
                        </div>
                     </form>
                  </div>
                 
               </div>
               <div style=" clear: both;"></div>
               <div class="space"></div>