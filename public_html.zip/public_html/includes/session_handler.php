<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
ob_start();
session_start();
if($_SESSION['User_Kamma_Matri'] == "" || empty($_SESSION['User_Kamma_Matri']) || !($_SESSION['User_Kamma_Matri'])){
    header('Location: index.php');
}
?>

