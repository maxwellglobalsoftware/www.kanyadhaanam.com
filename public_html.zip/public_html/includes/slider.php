


<section id="banner_sec banner">
   <div id="first-slider">
      <div id="carousel-example-generic" class="carousel slide carousel-fade" data-ride="carousel">
         <!-- Indicators -->
         <ol class="carousel-indicators">
            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>
            <li data-target="#carousel-example-generic" data-slide-to="2" class=""></li>
         </ol>
         <!-- Wrapper for slides -->
         <div class="carousel-inner" role="listbox">
            <!-- Item 1 -->
            <div class="item slide2 active" title="Iyer Iyengar Matrimony Website">
               <div class="row">
                  <div class="container">
                     <div class="col-md-7 text-left" >
                        <h3 data-animation="animated bounceInDown" style="font-family: 'Mukta Malar', sans-serif; font-size: 43px;
                           margin-bottom: 10px;
                           text-transform: capitalize;
                           color: rgba(255,255,255,255);
                           font-weight: 600;
                           text-shadow: 2px 2px 1px #000000;
                           text-align: left;">பிராமண சமூகத்தினருக்கான ப்ரத்யேக திருமண சேவை வலைதளம்.</h3>
                     </div>
                  </div>
               </div>
            </div>
            <div class="item slide1" title="Brahmin Iyer Iyengar Matrimony">
               <div class="row">
                  <div class="container">
                     <div class="col-md-8 text-left" >
                        <h3 data-animation="animated bounceInDown" style=" font-size: 43px;
                           margin-bottom: 10px;
                           text-transform: capitalize;
                           color: rgba(255,255,255,255);
                           font-weight: 600;
                           text-shadow: 2px 2px 1px #000000;
                           text-align: left;">Exclusive Website For
                           Brahmin Community
                        </h3>
                     </div>
                  </div>
               </div>
            </div>
            <!-- Item 2 -->
            <!-- Item 3 -->
            <div class="item slide3" title="Brahmin Community Matrimony">
               <div class="row">
                  <div class="container">
                     <div class="col-md-8 text-left">
                        <h3 style="font-family: 'Mukta Malar', sans-serif; font-size: 43px;
                           margin-bottom: 10px;
                           text-transform: capitalize;
                           color: rgba(255,255,255,255);
                           font-weight: 600;
                           text-shadow: 2px 2px 1px #000000;
                           text-align: left; line-height: 1.7em;">1000 திற்கும் மேற்பட்ட புதிய வரன்கள்... <br> பதிவு இலவசம்!</h3>
                     </div>
                  </div>
               </div>
            </div>
            <!-- Item 4 --> 
            <!-- End Item 4 --> 
         </div>
      </div>
   </div>
</section>

<script type="text/javascript">$(function(){
    $('.carousel').carousel({
      interval: 1000,
      autoplay:true
    });
});</script>