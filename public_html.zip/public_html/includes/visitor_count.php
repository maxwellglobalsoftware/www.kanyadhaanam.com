<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
ob_start();
session_start();
require_once 'init.php';
date_default_timezone_set('Asia/Kolkata');

if($_SESSION['new_user']!='yes')
{
$_SESSION['new_user']='yes';
$ipAddr=$_SERVER['REMOTE_ADDR'];
//echo $_SERVER['REMOTE_ADDR'];
$visitin_date=date('Y-m-d H:i:s');
$_SESSION['sessionID']=session_id();
//echo $_SESSION['sessionID'];

$data = array();
$data[] = $_SESSION['sessionID'];
$data[] = $ipAddr;
$data[] = date("d-m-Y");

$visitor = new Login();
$visitor = $visitor->addVisitor($data);
$visitor = $visitor->lastInsertID();

}

$getvisitors = new Login();
$getvisitors = $getvisitors->fetchVisitor()->resultSet();
$vcount=count($getvisitors);
?>