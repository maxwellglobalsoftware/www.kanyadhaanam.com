<?php 
    //    ********************* SERVER *************
    $GLOBALS['mysql'] = array(
        'host' => 'localhost',
        'username' => 'kanya3w90_new',
        'password' => 'iyer123@',
        'database' => 'kanya3w90_new'
    );
    //    ********************* LOCAL *************
//   $GLOBALS['mysql'] = array(
//       'host' => 'localhost',
//       'username' => 'root',
//       'password' => '',
//       'database' => 'kanyadhaa_matri'
//   );

    function __autoload($class) {
        require_once 'classes/' . $class . '.php';
    }

?>