<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../init.php';
header("Content-Type: application/vnd.ms-excel");
header("Content-disposition: attachment; filename=customer_details.xls");

if($_POST['report'] == "book_details") {
    
	$getbooks= new Book();
    $getbooks = $getbooks->fetch("ORDER BY id DESC")->resultSet();


    echo"<table border='1'>"
    . "<tr>"
            . "<th>S.No</th>"
            . "<th>Reg ID</th>"
            . "<th>Reg Username</th>"
            . "<th>Reg Mobile</th>"
            . "<th>Name</th>"
            . "<th>Mobile</th>"
            . "<th>Address</th>"
            . "<th>Subscription</th>"
            . "<th>Paid Date</th>"
            . "<th>Expiry Date</th>"
            . "</tr>";
    $sno = 1;
    foreach($getbooks as $getbook){ 


        $profiles = new Registration();
        $profiles = $profiles->fetch("WHERE km_regcode = '{$getbook['user_id']}'")->resultSet();
        $profile = $profiles[0];


        $address = $getbook['d_no'].','.$getbook['street'].','.$getbook['city'].','.$getbook['landmark'].','.$getbook['district'].','.$getbook['pincode'];

        if($loginhistory){

        } else {

    
        echo"<tr>"
            . "<td>".$sno."</td>"
            . "<td>".$profile['km_regcode']."</td>"
            . "<td>".ucwords($profile['km_name'])."</td>"
            . "<td>".$profile['km_mobile']."</td>"
            . "<td>".ucwords($getbook['name'])."</td>"
            . "<td>".$getbook['phone']."</td>"
            . "<td>".$address."</td>"
            . "<td>".$getbook['subscription']."</td>"
            . "<td>".$getbook['paid_date']."</td>"
            . "<td>".$getbook['expiry_date']."</td>"
        . "</tr>";
        $sno++;
    }
}

}


?>