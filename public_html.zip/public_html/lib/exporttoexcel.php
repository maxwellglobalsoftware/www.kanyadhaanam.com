<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT)); ?>
<?php
ini_set('memory_limit','128M');
date_default_timezone_set('Asia/Kolkata');
require_once '../init.php';
header("Content-Type: application/vnd.ms-excel");
header("Content-disposition: attachment; filename=profile_report.xls");

if($_POST['report'] == "profile_report") {
    
    $condition = stripslashes($_POST['observations']);
	$getprofiles= new Registration();
	$getprofiles = $getprofiles->fetch($condition)->resultSet();


    echo"<table border='1'>"
    . "<tr>"
            . "<th>S.No</th>"
            . "<th>Reg ID</th>"
            . "<th>Name</th>"
            . "<th>Gender</th>"
            . "<th>Date of birth</th>"
            . "<th>Mobile</th>"
            . "<th>Secondary Mobile</th>"
            . "<th>Email ID</th>"
            . "<th>City</th>"
            . "<th>Reg Date</th>"
            . "<th>Reg By</th>"
            . "<th>Status</th>"
            . "</tr>";
    $sno = 1;
    foreach($getprofiles as $profile){ 
    
        echo"<tr>"
            . "<td>".$sno."</td>"
            . "<td>".$profile['km_regcode']."</td>"
            . "<td>".$profile['km_name']."</td>"
            . "<td>".ucwords($profile['km_gender'])."</td>"
            . "<td>".date_format(new DateTime($profile['km_dateofbirth']), 'd-m-Y')."</td>"
            . "<td>".$profile['km_mobile']."</td>"
            . "<td>".$profile['km_second_mobile']."</td>"
            . "<td>".$profile['km_email']."</td>"
            . "<td>".$profile['km_city']."</td>"
            . "<td>".date_format(new DateTime($profile['km_registered_date']), 'd-m-Y')."</td>"
            . "<td>".$profile['km_registered_by']."</td>"
            . "<td>".$profile['km_status']."</td>"
        . "</tr>";
        $sno++;
    }
}


?>