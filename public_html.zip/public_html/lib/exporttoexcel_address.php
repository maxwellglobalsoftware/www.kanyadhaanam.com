<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../init.php';
header("Content-Type: application/vnd.ms-excel");
header("Content-disposition: attachment; filename=profile_report.xls");

if($_POST['report'] == "profile_report") {
    
	$getprofiles= new Registration();
	$getprofiles = $getprofiles->fetch("WHERE km_status = 'live' AND km_registered_by = 'byself' ORDER BY id DESC")->resultSet();


    echo"<table border='1'>"
    . "<tr>"
            . "<th>S.No</th>"
            . "<th>Name</th>"
            . "<th>Reg ID</th>"
            . "<th>Mobile No</th>"
            . "<th>Email ID</th>"
            . "<th>Address</th>"
            . "</tr>";
    $sno = 1;
    foreach($getprofiles as $profile){ 


   $address = $profile['km_doorno'].', '.$profile['km_street'].', '.$profile['km_city'].','.$profile['km_district'].', '.$profile['km_pincode'];


        echo"<tr>"
            . "<td>".$sno."</td>"
            . "<td>".$profile['km_regcode']."</td>"
            . "<td>".$profile['km_name']."</td>"
            . "<td>".$profile['km_mobile']."</td>"
            . "<td>".$profile['km_email']."</td>"
            . "<td>".$address."</td>"
        . "</tr>";
        $sno++;
    }
}


?>