<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../init.php';
header("Content-Type: application/vnd.ms-excel");
header("Content-disposition: attachment; filename=loginuser_report.xls");

if($_POST['report'] == "loginuser_report") {
    
	$condition = stripslashes($_POST['observations']);
    $logins = new Login();
    $logins = $logins->fetchLogin($condition)->resultSet(); 


    echo"<table border='1'>"
    . "<tr>"
            . "<th>S.No</th>"
            . "<th>Reg ID</th>"
            . "<th>Name</th>"
            . "<th>Email ID</th>"
            . "<th>Mobile</th>"
            . "<th>Expiry Date</th>"
            . "</tr>";
    $sno = 1;
    foreach($logins as $login){ 

        $profiles = new Registration();
        $profiles = $profiles->fetch("WHERE id = '{$login['user_id']}'")->resultSet();
        $profile = $profiles[0];

        $paymentIDs = new Payment();
        $paymentIDs = $paymentIDs->fetch("WHERE pl_userId = '{$profile['km_regcode']}' ORDER BY id DESC LIMIT 1")->resultSet(); 
        $paymentID = $paymentIDs[0];
    
        echo"<tr>"
            . "<td>".$sno."</td>"
            . "<td>".$profile['km_regcode']."</td>"
            . "<td>".ucwords($profile['km_name'])."</td>"
            . "<td>".$profile['km_email']."</td>"
            . "<td>".$profile['km_mobile']."</td>"
            . "<td>".date_format(new DateTime($paymentID['pl_expireDate']), 'd-m-Y')."</td>"
        . "</tr>";
        $sno++;
    }
}


?>