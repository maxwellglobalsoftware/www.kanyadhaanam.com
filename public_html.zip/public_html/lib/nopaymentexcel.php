<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../init.php';
header("Content-Type: application/vnd.ms-excel");
header("Content-disposition: attachment; filename=nopayment_report.xls");

if($_POST['report'] == "no_payment_report") {


	$getprofiles= new Registration();
	$getprofiles = $getprofiles->fetch("WHERE km_status = 'live' ORDER BY id DESC")->resultSet();

	echo"<table border='1'>"
    . "<tr>"
    . "<th>S.No</th>"
    . "<th>Name</th>"
    . "<th>Reg ID</th>"
    . "<th>Mobile No</th>"
    . "<th>Email ID</th>"
    . "</tr>";
    $sno = 1;
	foreach($getprofiles as $getprofile){

	$payments = new Payment();
    $payments = $payments->fetch("WHERE pl_userId = '{$getprofile['km_regcode']}'")->resultSet();
    $payment = $payments[0];

    if($payment){

    } else {

    echo"<tr>"
            . "<td>".$sno."</td>"
            . "<td>".$getprofile['km_regcode']."</td>"
            . "<td>".$getprofile['km_name']."</td>"
            . "<td>".$getprofile['km_mobile']."</td>"
            . "<td>".$getprofile['km_email']."</td>"
        . "</tr>";
        $sno++;



    }

	}



}



?>