<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../init.php';
header("Content-Type: application/vnd.ms-excel");
header("Content-disposition: attachment; filename=not_horoscopeupload_profiles.xls");

if($_POST['report'] == "nothoroscope_report") {
    
	$condition = stripslashes($_POST['observations']);
    $profiles = new Registration();
    $profiles = $profiles->fetch($condition)->resultSet();


    echo"<table border='1'>"
    . "<tr>"
            . "<th>S.No</th>"
            . "<th>Reg ID</th>"
            . "<th>Name</th>"
            . "<th>Email ID</th>"
            . "<th>Mobile</th>"
            . "<th>Registered Date</th>"
            . "<th>Registered By</th>"
            . "</tr>";
    $sno = 1;
    foreach($profiles as $profile){ 

        $horos = new Profile();
        $horos = $horos->fetchHoroscope("WHERE hs_userId = '{$profile['km_regcode']}'")->resultSet();
        $horos = $horos[0];

        if($horos){

        } else {
    
        echo"<tr>"
            . "<td>".$sno."</td>"
            . "<td>".$profile['km_regcode']."</td>"
            . "<td>".ucwords($profile['km_name'])."</td>"
            . "<td>".$profile['km_email']."</td>"
            . "<td>".$profile['km_mobile']."</td>"
            . "<td>".date_format(new DateTime($profile['km_registered_date']), 'd-m-Y')."</td>"
            . "<td>".$profile['km_registered_by']."</td>"
        . "</tr>";
        $sno++;
    }
    }
}


?>