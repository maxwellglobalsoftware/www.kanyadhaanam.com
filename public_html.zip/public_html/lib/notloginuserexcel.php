<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../init.php';
header("Content-Type: application/vnd.ms-excel");
header("Content-disposition: attachment; filename=notloginuser_report.xls");

if($_POST['report'] == "notloginuser_report") {
    
	$getprofiles= new Registration();
    $getprofiles = $getprofiles->fetch("WHERE km_status = 'live' ORDER BY id DESC")->resultSet();


    echo"<table border='1'>"
    . "<tr>"
            . "<th>S.No</th>"
            . "<th>Reg ID</th>"
            . "<th>Name</th>"
            . "<th>Email ID</th>"
            . "<th>Mobile</th>"
            . "</tr>";
    $sno = 1;
    foreach($getprofiles as $profile){ 


        $loginhistorys = new Login();
        $loginhistorys = $loginhistorys->fetchLogin("WHERE user_id = '{$profile['id']}' ORDER BY id DESC")->resultSet(); 
        $loginhistory = $loginhistorys[0];

        if($loginhistory){

        } else {

    
        echo"<tr>"
            . "<td>".$sno."</td>"
            . "<td>".$profile['km_regcode']."</td>"
            . "<td>".ucwords($profile['km_name'])."</td>"
            . "<td>".$profile['km_email']."</td>"
            . "<td>".$profile['km_mobile']."</td>"
        . "</tr>";
        $sno++;
    }
}

}


?>