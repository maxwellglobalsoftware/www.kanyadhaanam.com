<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../init.php';
header("Content-Type: application/vnd.ms-excel");
header("Content-disposition: attachment; filename=payment_report.xls");

if($_POST['report'] == "payment_report") {


	if($_POST['export_status'] == 'not_paid'){

	$getprofiles= new Registration();
	$getprofiles = $getprofiles->fetch("WHERE km_status = 'live' ORDER BY id DESC")->resultSet();


	echo"<table border='1'>"
    . "<tr>"
    . "<th>S.No</th>"
    . "<th>Name</th>"
    . "<th>Reg ID</th>"
    . "<th>Mobile No</th>"
    . "<th>Email ID</th>"
    . "</tr>";
    $sno = 1;
	foreach($getprofiles as $getprofile){

	$payments = new Payment();
    $payments = $payments->fetch("WHERE pl_userId = '{$getprofile['km_regcode']}' AND pl_status = 'activate'")->resultSet();
    $payment = $payments[0];

    if($payment){

    } else {

    echo"<tr>"
            . "<td>".$sno."</td>"
            . "<td>".$getprofile['km_regcode']."</td>"
            . "<td>".$getprofile['km_name']."</td>"
            . "<td>".$getprofile['km_mobile']."</td>"
            . "<td>".$getprofile['km_email']."</td>"
        . "</tr>";
        $sno++;



    }

	}

	} else {
    
    $condition = stripslashes($_POST['observations']);
    $payments = new Payment();
    $payments = $payments->fetch($condition)->resultSet(); 


    echo"<table border='1'>"
    . "<tr>"
            . "<th>S.No</th>"
            . "<th>Reg ID</th>"
            . "<th>Name</th>"
            . "<th>Mobile No</th>"
            . "<th>Email ID</th>"
            . "<th>Status</th>"
            . "<th>Amount</th>"
            . "<th>Paid Date</th>"
            . "<th>Start Date</th>"
            . "<th>Expire Date</th>"
            . "<th>Transac ID</th>"
            . "<th>Payment Mode</th>"
            . "</tr>";
    $sno = 1;
    foreach($payments as $payment){ 

        $profiles = new Registration();
        $profiles = $profiles->fetch("WHERE km_regcode = '{$payment['pl_userId']}'")->resultSet();
        $profile = $profiles[0];
    
        echo"<tr>"
            . "<td>".$sno."</td>"
            . "<td>".$payment['pl_userId']."</td>"
            . "<td>".$profile['km_name']."</td>"
            . "<td>".$profile['km_mobile']."</td>"
            . "<td>".$profile['km_email']."</td>"
            . "<td>".$payment['pl_status']."</td>"
            . "<td>".$payment['pl_amount']."</td>"
            . "<td>".date_format(new DateTime($payment['pl_paidDate']), 'd-m-Y')."</td>"
            . "<td>".date_format(new DateTime($payment['pl_startDate']), 'd-m-Y')."</td>"
            . "<td>".date_format(new DateTime($payment['pl_expireDate']), 'd-m-Y')."</td>"
            . "<td>".$payment['txn_id']."</td>"
            . "<td>".$payment['payment_mode']."</td>"
        . "</tr>";
        $sno++;
    }

}


}



?>