<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   if($_SESSION['User_Kamma_Matri']){
       unset($_SESSION['User_Kamma_Matri']);
   }
   date_default_timezone_set('Asia/Kolkata');
   require_once 'init.php';
   require_once 'KANyaMatrI_GST/includes/configure.php';
   
   if(isset($_SESSION['registrationAdded'])) {     
   if($_SESSION['registrationAdded']) {
       $result = "Registration Added<BR>".$_SESSION['userinfo'];
   } else {
       $result = "Failed to add Registration";
   }
   unset($_SESSION['registrationAdded']);
   }
   
   if(isset($_SESSION['profile_active'])) {     
    if($_SESSION['profile_active']) {
        $result = "Your profile has been activated. Login here";
    } else {
        $result = "Failed to activated";
    }
    unset($_SESSION['profile_active']);
   }
   
   if(isset($_SESSION['already_active'])) {     
    if($_SESSION['already_active']) {
        $result = "Your profile already activated. Login here";
    } 
    unset($_SESSION['already_active']);
   }
   
   if(isset($_POST['go'])) {
       $username = $_POST['username'];
       $password = $_POST['password'];
   
       $user = new Registration();
       $user = $user->login($username, $password);  
       if($user) {
           $data = array();
           $data[] = $_SESSION['User_Kamma_Matri']['id'];
           $data[] = date_format(new DateTime(), 'd-m-Y');
           $data[] = date_format(new DateTime(), 'h:i A');
   
           $login = new Login();
           $login = $login->setLogin($data);
   
           $_SESSION['logged_id'] = $login->lastInsertID();   
           
           $today = date('Y-m-d');
           
           $paymentIDs = new Payment();
           $paymentIDs = $paymentIDs->fetch("WHERE pl_userId = '{$_SESSION['User_Kamma_Matri']['km_regcode']}'  ORDER BY id DESC LIMIT 1")->resultSet(); 
           $paymentID = $paymentIDs[0];
        
        
     $payments = new Payment();
     $payments = $payments->fetch("WHERE pl_userId = '{$_SESSION['User_Kamma_Matri']['km_regcode']}' AND id = '{$paymentID['id']}' AND pl_status = 'activate' AND '{$today}' BETWEEN pl_startDate AND pl_expireDate ORDER BY id DESC")->resultSet(); 
     $payment = $payments[0];
   
    //  if($payment){
    //    header('Location: profiles.php');
    //  } else {
    //    header('Location: membership_pay.php');
    //  }
    
     if($paymentID){
      if($payment){
      header('Location: profiles.php');
     } else {
      header('Location: membership_pay.php');
     }
     } else {
      header('Location: profiles.php');
     }
             
             
           
        //   header('Location: profiles.php');
       } else {
           echo '<script>window.alert("Please enter valid User ID and/or Password");</script>';
           echo '<script>window.location="login.php"</script>';
   //            header('Location: index.php');
       }
   }
   
   
      if(isset($_GET['profile_no'])){
   
    $prof_no = $_GET['profile_no'];
    $res_no = $_GET['response_no'];
   
    $getregis = new Registration();
    $getregis = $getregis->fetch("WHERE id = '{$res_no}' AND km_regcode = '{$prof_no}' ORDER BY id DESC")->resultSet();
    $getreg = $getregis[0];
   
    if($getreg){
   
      $alreadyregis = new Registration();
      $alreadyregis = $alreadyregis->fetch("WHERE id = '{$res_no}' AND km_regcode = '{$prof_no}' AND km_status = 'live' ORDER BY id DESC")->resultSet();
      $alreadyreg = $alreadyregis[0];
   
      if($alreadyreg){
   
        $_SESSION['already_active'] = true;
        header('Location: login.php');
   
      } else {
   
      $data = array();
      $data[] = 'live';
      $data[] = $getreg['km_regcode'];
   
      $updatestatus = new Registration();
      $updatestatus = $updatestatus->updateStatus($data);
      $updatestatus_id = $updatestatus->rowCount();
   
      $arr = array();
      $arr[] = $getreg['km_regcode'];
      $arr[] = $getreg['km_email'];
      $arr[] = "";
      $arr[] = "yes";
      $arr[] = date("d-m-Y");
      $arr[] = date("h:i A");
   
      $otpverify = new OTP();
      $otpverify = $otpverify->addEmail($arr);
      $otpverify_id = $otpverify->lastInsertID();
   
      if($updatestatus_id){
        $_SESSION['profile_active'] = true;
      } else {
        $_SESSION['profile_active'] = false;
      }
   
      header('Location: login.php');
   
      }
   
    }
   
   }
   
   
   //*********************** Female Profile Details *******************************
   $female_profiles = new Registration();
   $female_profiles = $female_profiles->fetch("WHERE km_gender = 'female' AND km_status = 'live' ORDER BY id DESC ")->resultSet(); 
   
   //*********************** Male Profile Details *******************************
   $male_profiles = new Registration();
   $male_profiles = $male_profiles->fetch("WHERE km_gender = 'male' AND km_status = 'live' ORDER BY id DESC ")->resultSet();    
   
   ?>
<!DOCTYPE html>
<html>
   <head>
      <title>Kanyadhaanam Matrimony</title>
      <?php include("includes/headertop.php");?>
      <style type="text/css">table {
         width: 90%;
         border: none;
         margin: 0px auto;
         }
      </style>
      <script type="text/javascript">
         function logfn(form)
         
         {
         
         
         if(form.username.value=="") { alert("Please Enter User ID"); form.username.focus(); return false; }
         
         if(form.password.value=="") { alert("Please Enter Password"); form.password.focus(); return false; }
         
         }
         
      </script>
   </head>
   <body class="home color-green boxed shadow">
      <?php include("includes/header.php");?>
      <section id="register-home">
         <div class="container">
            <div class="row">
               <div class="col-sm-6 col-xs-12">
                  <h4 style="font-size: 45px;">
                     Members Login
                  </h4>
               </div>
            </div>
         </div>
      </section>
      <script src="js/jquery-1.12.4.js"></script>
      <div class="root">
         <section class="content reverse">
            <section class="main">
               <section class="columns col-md-6 col-sm-6" style="margin-top:30px !important; ">
                  <div class="panel" style="margin-left: 0px; width: 100%">
                     <div class="panel-heading">
                        <h3 style="font-family: 'Open Sans', sans-serif; margin-top: 0px; color: #f0452d; font-size: 26px;">Login to your account</h3>
                     </div>
                     <div class="panel-body">
                        <div  id="message_container" style="text-align: center;  color: blue;font-size: 18px; font-weight: bold;margin-left: 0px;">
                           <span id="message"></span>
                        </div>
                        <form  name="LoginForm" method="post"  onsubmit="return logfn(LoginForm);">
                           <div class="form-group">
                              <label for="uid" style=" font-size: 20px;"><i class="fa fa-user" style="     color: #f38502;"></i> User ID<span></span></label>
                              <input type="text" style="padding: 20px 10px;" class="form-control" name="username" autofocus="autofocus"  placeholder="User ID" >
                           </div>
                           <div class="form-group" style=" margin-top: 10px;">
                              <label for="pwd" style=" font-size: 20px;"><i class="fa fa-lock" style="    color: #f38502;"></i> Password<span></span></label>
                              <input type="password" style="padding: 20px 10px;" class="form-control" name="password"  placeholder="Enter password">
                           </div>
                           <button type="submit" name="go" class="btn btn-success btn-block makemybutton" style="background: #c32143; border: none;     float: left;"> <i class="fa fa-power-off"></i> Login</button>
                           <a href="forgotpassword.php" style=" float: right; padding-top: 20px; font-size: 20px;"><i class="fa fa-key"></i> Forgot Password</a>
                        </form>
                     </div>
                  </div>
               </section>

               <div class="col-md-6 login-form-2" style="margin-top: 30px !important;">
                  <h3>Register now for FREE</h3>
                  <ul class="list-docs-items">
                     <li> <img src="images/bullet (2).gif"> Find your soulmate for simple steps</li>
                     <li><img src="images/bullet (2).gif"> 100% Verified Profiles Only</li>
                     <li><img src="images/bullet (2).gif"> most trusted matrimonial</li>
                     <li><img src="images/bullet (2).gif"> no hidden fees</li>
                     <li><img src="images/bullet (2).gif"> safe and secure</li>
                     <li><img src="images/bullet (2).gif"> 100 % Register Free &amp;  Instant Activation</li>
                     <li> <img src="images/bullet (2).gif"> Service Designed for Brahmin</li>
                  </ul>
                  <div class="clearfix"></div>
               </div>



            </section>
         </section>
         <div style=" clear: both;"></div>
         <script type="text/javascript">
            $(document).ready(function()
            {
              //Add Inactive Class To All Accordion Headers
              $('.accordion-header').toggleClass('inactive-header');
              
              //Set The Accordion Content Width
              var contentwidth = $('.accordion-header').width();
              $('.accordion-content').css({'width' : contentwidth });
              
              //Open The First Accordion Section When Page Loads
              $('.accordion-header').first().toggleClass('active-header').toggleClass('inactive-header');
              $('.accordion-content').first().slideDown().toggleClass('open-content');
              
              // The Accordion Effect
              $('.accordion-header').click(function () {
                if($(this).is('.inactive-header')) {
                  $('.active-header').toggleClass('active-header').toggleClass('inactive-header').next().slideToggle().toggleClass('open-content');
                  $(this).toggleClass('active-header').toggleClass('inactive-header');
                  $(this).next().slideToggle().toggleClass('open-content');
                }
                
                else {
                  $(this).toggleClass('active-header').toggleClass('inactive-header');
                  $(this).next().slideToggle().toggleClass('open-content');
                }
              });
              
              return false;
            });
         </script>
         <script>
            $(document).ready(function(){
            $('#tabs').tabs();
            $('#tabs').css('display', 'block');
            });
         </script>
         <?php
            if(isset($result)) {
            ?>
         <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(50000, function() {
                            $('#message').text("");
                            $('#username').focus();
                    });
            }, 50000);
         </script>
         <?php
            }
            ?>
      </div>
      <br><br>
      <?php include("includes/footer.php");?>
   </body>
</html>