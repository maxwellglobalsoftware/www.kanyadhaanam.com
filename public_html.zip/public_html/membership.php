<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   require_once 'includes/session_handler.php';
   
   
   if(isset($_POST['pay'])){
   
        $_SESSION['amount'] = 1000;
        $_SESSION['firstname'] = $_SESSION['User_Kamma_Matri']['km_name'];
        $_SESSION['email'] = $_SESSION['User_Kamma_Matri']['km_email'];
        $_SESSION['phone'] = $_SESSION['User_Kamma_Matri']['km_mobile'];
        $_SESSION['productinfo'] = $_SESSION['User_Kamma_Matri']['km_regcode'];
        $_SESSION['surl'] = 'http://www.kanyadhaanam.com/payment_success.php';
        $_SESSION['furl'] = 'http://www.kanyadhaanam.com/payment_failure.php';
        $_SESSION['service_provider'] = 'payu_paisa';
   
        header('Location: confirm.php');
   }
   
   
   ?>
<!DOCTYPE html>
<html>
   <head>
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <style type="text/css">/* Table 1 Style */
         table.table1{
         font-size: 18px;
         font-weight: bold;
         line-height: 1.4em;
         font-style: normal;
         border-collapse:separate;
         border-spacing: 2px;
         }
         .table1 thead th {
         padding: 15px;
         text-align: center;
         color: #fff;
         
         border: 1px solid #ffa500;
         border-bottom: 3px solid #fd5b18;
         background-color: #fd9500;
         
         }
         .table1 thead th:empty{
         background:transparent;
         border:none;
         }
         .table1 tbody th{
         color:#d22525;
         text-align: left;
         /*text-shadow:1px 1px 1px #568F23;*/
         background-color: #c833180d;
         /*border: 1px solid #ea6515;*/
        
         padding:0px 10px;
         
         }
         .table1 tfoot td{
         color: #9CD009;
         font-size:32px;
         text-align:center;
         padding:10px 0px;
         text-shadow:1px 1px 1px #444;
         }
         .table1 tfoot th{
         color:#000;
         }
         .table1 tbody td{
         padding:10px;
         text-align:center;
         background-color:#fcf4f38c;
         border: 2px solid #E7EFE0;
         -moz-border-radius:2px;
         -webkit-border-radius:2px;
         border-radius:2px;
         color:#000;
         text-shadow:1px 1px 1px #fff;
         }
         .table1 tbody span.check::before{
         content : url(../images/check0.png)
         }
      </style>
      <?php include("includes/headertop.php");?>
   </head>
   <body class="home color-green boxed shadow">
      <?php include("includes/headerin.php");?>
      <?php include("includes/bannerin.php");?>
      <?php //include("includes/quicksearch.php");?>
      <div class="root">
         <section class="content reverse">
            <?php include("includes/right.php");?>
            <section class="col-md-9 col-xs-12" style=" margin-top: 1%;">
               <h3 style=" margin-top: 10px; color: #175905;">MEMBERSHIP BENEFITS</h3>
               <div align="center" class="table-responsive" style="width: 95%">
                  <table class="table1" >
                     <thead>
                        <tr>
                           <th>MEMBERSHIP FEE</th>
                           <th scope="col" abbr="Starter"><i class="fa fa-inr"></i> 1000 </th>
                           </th>
                           <th scope="col" abbr="Medium">1 Month</th>
                        </tr>
                     </thead>
                     <tbody>
                        <tr>
                           <th scope="row">View Full Profiles</th>
                           <td>Unlimited</td>
                           <td>1 Month</td>
                        </tr>
                        <tr>
                           <th scope="row">Verified Contacts</th>
                           <td>30</td>
                           <td>1 Month</td>
                        </tr>
                        <tr>
                           <th scope="row">Horoscope Download</th>
                           <td>30</td>
                           <td>1 Month</td>
                        </tr>
                        <tr>
                           <th scope="row">Matching SMS Alerts</th>
                           <td>Unlimited</td>
                           <td>1 Month</td>
                        </tr>

                         <tr>
                           <th scope="row">Album Photo View</th>
                           <td>Unlimited</td>
                           <td>1 Month</td>
                        </tr>


                        <tr>
                           <th scope="row">Express Interest</th>
                           <td>Unlimited</td>
                           <td>1 Month</td>
                        </tr>
                        <tr>
                           <!--bgcolor="#e6e6e6"-->
                           <td class="tdheadbold">&nbsp;</td>
                           <td class="tdheadbold">&nbsp;</td>
                           <form method="post" name="PlanForm" id="PlanForm" target="_blank">
                              <td class="tdcontent" style=" padding-top: 20px;
                                 padding-bottom: 20px;">
                                 <input name="pay" type="submit" class="orang_button" value="Make Payment" alt="Pay Now"><!--green_button-->
                              </td>
                           </form>
                        </tr>
                     </tbody>
                  </table>
                  
               </div>
               <div style=" clear: both;"></div>
               <div class="space"></div>
            </section>
         </section>
         <div style=" clear: both;"></div>
      </div>
      <?php include("includes/footertop.php");?>
      <?php include("includes/footerin.php");?>
   </body>
</html>