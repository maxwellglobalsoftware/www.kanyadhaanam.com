<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   require_once 'KANyaMatrI_GST/includes/configure.php';
   require_once 'init.php';
   require_once 'includes/pagination.php';
   require_once 'includes/db.php';
   
   $profileId = $_SESSION['User_Kamma_Matri']['km_regcode'];
   $profiles = new Registration();
   $profiles = $profiles->fetch("WHERE km_regcode = '{$profileId}'")->resultSet();    
   $profile = $profiles[0];
   //*********************** Photo Details *******************************
   $photos = new Profile();
   $photos = $photos->fetchPhotos("WHERE pho_userId = '{$profile['km_regcode']}' AND pho_imgPath LIKE '%_profile_%'")->resultSet();
   $profile_photos = $photos[0];
   
   
   //// Occupation /////
   $occupations = new Registration();
   $occupations = $occupations->fetchOccupation("WHERE id = '{$profile['km_occupation']}' ORDER BY occupation ASC")->resultSet();
   $occupation = $occupations[0];
   
   //// Districts /////
   $districts = new Registration();
   $districts = $districts->fetchDistricts("WHERE id = '{$profile['km_district']}' ORDER BY name ASC")->resultSet();
   $district = $districts[0];
   
   
   
   $photos = new Profile();
   $photos = $photos->fetchPhotos("WHERE pho_userId = '{$profile['km_regcode']}' AND pho_imgPath NOT LIKE '%_profile_%'")->resultSet();
   
   
   if($profile_photos['pho_imgPath']){
       $loginimgPath =  $profile_photos['pho_imgPath'];
   
       $image_file = fopen($loginimgPath, 'r');
       $loginimgPath = fread($image_file, filesize($loginimgPath));
   
   }else{
       if($profile['km_gender'] == 'male'){
           $loginimgPath = 'images/male.png';
   
       $image_file = fopen($loginimgPath, 'r');
       $loginimgPath = fread($image_file, filesize($loginimgPath));
   
       }else{
           $loginimgPath = 'images/female.png';
   
       $image_file = fopen($loginimgPath, 'r');
       $loginimgPath = fread($image_file, filesize($loginimgPath));
       }
        
   }
   
   
   ?>
<!DOCTYPE html>
<html>
   <head>
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <?php include("includes/headertop.php");?>
   </head>
   <body class="home color-green boxed shadow">
      <?php include("includes/headerin.php");?>
      <?php include("includes/bannerin.php");?>
      <?php //include("includes/quicksearch.php");?>
      <div class="root">
         <section class="content reverse">
            <?php include("includes/right.php");?>
            <section class="col-md-9 col-xs-12" style=" margin-top: 1%;">
               <div class="space"></div>
               <table>
                  <tr class="tabletitle" style=" background-color: #f0452d;">
                     <td colspan="2" style="  border-top-left-radius: 0.5em; border-top-right-radius: 0.5em;">View Album</td>
                  </tr>
               </table>
               <div id="pagin" style=" margin-top: -20px;">
                  <form method="post" id='search_result' action="">
                     <div id="r-content" class="style50" style="min-height: 270px;">
                        <div class="r-content-left">
                           <span class="profile">Profie ID : <?php echo $profile['km_regcode'];?> </span>
                           <div class="r-content-photo">
                              <a href=""> <img width="150" height="170" border="0" src="data:image/jpeg;base64,<?php echo base64_encode($loginimgPath); ?>"></a>
                           </div>
                           <div class="r-content-top-2">
                              <div class="r-content-top-btn">
                                 <a href="myprofile.php" class="button1 red"> View full profile</a>
                              </div>
                              <!--  <div class="r-content-top-btn" style="margin-top:10px;"><a href="" class="button1 red"> View Photo Album</a>
                                 </div> -->
                              <div class="r-content-top-btn"> </div>
                           </div>
                        </div>
                        <div class="r-content-right-top">
                           <div class="r-content-top-1">
                              <table width="426" cellspacing="0" cellpadding="0" border="0">
                                 <tbody>
                                    <?php 
                                       $from = new DateTime($profile['km_dateofbirth']);
                                       $to   = new DateTime('today');
                                       $age = $from->diff($to)->y;                                                     
                                       ?>
                                    <tr>
                                       <td height="22" style=" color:#0f50e2;font-weight:bold; text-transform: uppercase;" colspan="3"><?php echo $profile['km_name'];?>&nbsp;
                                       </td>
                                    </tr>
                                    <tr>
                                       <td width="124" height="20" style="color:#000">Age / Height</td>
                                       <td width="20">:</td>
                                       <td width="182" style="color:#333"> <?php echo $age.' Yrs';?> / <?php echo $profile['km_height'];?>
                                    <tr>
                                       <td height="20" style="color:#000" valign="top">
                                          Star
                                       </td>
                                       <td valign="top">
                                          :
                                       </td>
                                       <td style="color:#333">
                                          <?php echo $profile['km_star'];?>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td height="20" style="color:#000" valign="top">
                                          District
                                       </td>
                                       <td valign="top">
                                          :
                                       </td>
                                       <td style="color:#333">
                                          <?php 
                                             if($profile['km_district']){ 
                                             if($district){ 
                                                echo $district['name']; } 
                                                else { echo $profile['km_district']; }
                                                } else { echo 'N / A'; } 
                                             ?>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td height="19" style="color:#000">Qualification</td>
                                       <td height="19">:</td>
                                       <td height="19" style="color:#333"><?php echo $edu_array[$profile['km_education']];?></td>
                                    </tr>
                                    <tr>
                                       <td height="20" style="color:#000">Profession</td>
                                       <td>:</td>
                                       <td height="19" style="color:#333">
                                          <?php
                                             if($profile['km_employee_in'] == 'notworking'){
                                                 echo 'Not Working';
                                             } else {
                                              if($profile['km_occupation']){ 
                                              if($occupation){ 
                                                echo $occupation['occupation']; } 
                                                else { echo $profile['km_occupation']; }
                                                } else { echo 'N / A'; } 
                                             }
                                              ?>
                                       </td>
                                    </tr>
                                       <tr>
                                       <td height="20" style="color:#000" valign="top">
                                          SubCaste
                                       </td>
                                       <td valign="top">
                                          :
                                       </td>
                                       <td style="color:#333">
                                          <?php if($profile['km_subcaste']){ echo $profile['km_subcaste']; } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                  </form>
                  <h2 style=" color: #045f04;">Album</h2>
                  <div>
                     <script src="js/jquery-1.11.3.min.js" type="text/javascript"></script>
                     <script src="js/jssor.slider-22.1.9.mini.js" type="text/javascript"></script>
                     <script type="text/javascript">
                        jQuery(document).ready(function($) {
                        
                            var jssor_1_options = {
                                $AutoPlay: false,
                                $AutoPlaySteps: 1,
                                $SlideDuration: 160,
                                $SlideWidth: 540,
                                $SlideSpacing: 1,
                                $Cols: 1,
                                $ArrowNavigatorOptions: {
                                    $Class: $JssorArrowNavigator$,
                                    $Steps: 1
                                },
                                $BulletNavigatorOptions: {
                                    $Class: $JssorBulletNavigator$,
                                    $SpacingX: 1,
                                    $SpacingY: 1
                                }
                            };
                        
                            var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);
                        
                            function ScaleSlider() {
                                var refSize = jssor_1_slider.$Elmt.parentNode.clientWidth;
                                if (refSize) {
                                    refSize = Math.min(refSize, 540);
                                    jssor_1_slider.$ScaleWidth(refSize);
                                } else {
                                    window.setTimeout(ScaleSlider, 30);
                                }
                            }
                            ScaleSlider();
                            $(window).bind("load", ScaleSlider);
                            $(window).bind("resize", ScaleSlider);
                            $(window).bind("orientationchange", ScaleSlider);
                            /*responsive code end*/
                        });
                     </script>
                     <style>
                        .jssorb03 {
                        position: absolute;
                        }
                        .jssorb03 div,
                        .jssorb03 div:hover,
                        .jssorb03 .av {
                        position: absolute;
                        /* size of bullet elment */
                        width: 21px;
                        height: 21px;
                        text-align: center;
                        line-height: 21px;
                        color: white;
                        font-size: 12px;
                        background: url('images/b03.png') no-repeat;
                        overflow: hidden;
                        cursor: pointer;
                        }
                        .jssorb03 div {
                        background-position: -5px -4px;
                        }
                        .jssorb03 div:hover,
                        .jssorb03 .av:hover {
                        background-position: -35px -4px;
                        }
                        .jssorb03 .av {
                        background-position: -65px -4px;
                        }
                        .jssorb03 .dn,
                        .jssorb03 .dn:hover {
                        background-position: -95px -4px;
                        }
                        .jssora03l,
                        .jssora03r {
                        display: block;
                        position: absolute;
                        /* size of arrow element */
                        width: 55px;
                        height: 55px;
                        cursor: pointer;
                        background: url('images/a13.png') no-repeat;
                        overflow: hidden;
                        }
                        .jssora03l {
                        background-position: -3px -33px;
                        }
                        .jssora03r {
                        background-position: -63px -33px;
                        }
                        .jssora03l:hover {
                        background-position: -123px -33px;
                        }
                        .jssora03r:hover {
                        background-position: -183px -33px;
                        }
                        .jssora03l.jssora03ldn {
                        background-position: -243px -33px;
                        }
                        .jssora03r.jssora03rdn {
                        background-position: -303px -33px;
                        }
                        .jssora03l.jssora03lds {
                        background-position: -3px -33px;
                        opacity: .3;
                        pointer-events: none;
                        }
                        .jssora03r.jssora03rds {
                        background-position: -63px -33px;
                        opacity: .3;
                        pointer-events: none;
                        }
                     </style>
                     <?php 
                        if($photos){
                        
                        ?>
                     <div id="jssor_1" style="position:relative;left:0px;width:540px;height:600px;overflow:hidden;visibility:hidden;">
                        <!-- Loading Screen -->
                        <div data-u="loading" style="position:absolute;top:0px;left:0px;background-color:rgba(0,0,0,0.7);">
                           <div style="filter: alpha(opacity=70); opacity: 0.7; position: absolute; display: block; top: 0px; left: 0px; width: 100%; height: 100%;"></div>
                           <div style="position:absolute;display:block;background:url('images/loading.gif') no-repeat center center;top:0px;left:0px;width:100%;height:100%;"></div>
                        </div>
                        <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:540px;height:600px;overflow:hidden;">
                           <?php 
                              foreach($photos as $photo){
                              //                                                echo $photo['pho_imgPath'];
                                  ?>
                           <div>
                              <img data-u="image" style="width:540px;" src="<?php echo $photo['pho_imgPath'];?>" />
                           </div>
                           <?php } ?>
                        </div>
                        <span data-u="arrowleft" class="jssora03l" style="top:0px;left:8px;width:55px;height:55px;" data-autocenter="2"></span>
                        <span data-u="arrowright" class="jssora03r" style="top:0px;right:8px;width:55px;height:55px;" data-autocenter="2"></span>
                     </div>
                     <?php 
                        }else{
                            ?>
                     <div id="result-content">
                        <h4 style="margin: 1.5em 1em;text-align: center;color: #17800a;">
                           <p style=" font-size: 16px; padding-top: 10px; line-height:30px;"> <img src="images/lightbulb.png" width="35" style="vertical-align: bottom;">
                              To upload your profile photo kindly mail us by attaching your photo at <a href="mailto:support@kanyadhaanam.com">support@kanyadhaanam.com.</a> Alternatively, you can reach us at  95000 90825
                           </p>
                        </h4>
                     </div>
                     <?php
                        }                                
                        ?>
                  </div>
                  <br> <br> 
               </div>
               <div style="clear:both;"></div>
               <div class="space"></div>
               
            </section>
         </section>
         <div style=" clear: both;"></div>
      </div>
      <?php include("includes/footertop.php");?>
      <?php include("includes/footerin.php");?>
   </body>
</html>