<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   require_once 'KANyaMatrI_GST/includes/configure.php';
   require_once 'includes/session_handler.php';
   require_once 'init.php';
   require_once 'includes/pagination.php';
   require_once 'includes/db.php';
   
   $profileId = $_SESSION['User_Kamma_Matri']['km_regcode'];
   //*********************** Horoscope Details *******************************
   $horos = new Profile();
   $horos = $horos->fetchHoroscope("WHERE hs_userId = '{$profileId}'")->resultSet();
   $horos = $horos[0];
   ?>
<!DOCTYPE html>
<html>
   <head>
      <?php include("includes/headertop.php");?>
   </head>
   <body class="home color-green boxed shadow">
      <?php include("includes/headerin.php");?>
      <?php include("includes/bannerin.php");?>
      <?php //include("includes/quicksearch.php");?>
      <div class="root">
         <section class="content reverse">
            <?php include("includes/right.php");?>
            <section class="col-md-9 col-xs-12" style=" margin-top: 1%;">
               <table>
                  <tr class="tabletitle" >
                     <td colspan="2" style="  border-top-left-radius: 0.5em; border-top-right-radius: 0.5em;">Horoscope Details </td>
                  </tr>
               </table>
               <div id="result-content">
                  <div class="basic-info-title-box">
                     <div class="spacer"></div>
                     <div>
                        <?php if($horos['hs_imgPath']){?>
                        <img style='padding: 5px; width: 100%' src="<?php echo $horos['hs_imgPath'];?>">
                     </div>
                     <?php }else{ ?>
                     <p style="text-align: center;color:red;">
                     <p style=" font-size: 16px; padding-top: 10px; line-height:30px;"> <img src="images/lightbulb.png" width="35" style="vertical-align: bottom;"> To upload your horoscope. Kindly mail us by attaching your horoscope and send us at <a href="mailto:support@kanyadhaanam.com"> support@kanyadhaanam.com.</ Alternatively, feel free to call us at  95000 90825  for uploading horoscope</p>
                     </p>
                     <?php } ?>
                  </div>
                  <p>&nbsp;</p>
               </div>
            </section>
         </section>
         <div style=" clear: both;"></div>
      </div>
      <?php include("includes/footertop.php");?>
      <?php include("includes/footerin.php");?>
   </body>
</html>