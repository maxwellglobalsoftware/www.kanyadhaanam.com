<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   require_once 'KANyaMatrI_GST/includes/configure.php';
   require_once 'includes/session_handler.php';
   require_once 'init.php';
   require_once 'includes/pagination.php';
   require_once 'includes/db.php';
   
   $profileId = $_SESSION['User_Kamma_Matri']['km_regcode'];
   //*********************** Profile Details *******************************
   $profiles = new Registration();
   $profiles = $profiles->fetch("WHERE km_regcode = '{$profileId}'")->resultSet();    
   $profile = $profiles[0];
   //*********************** Horoscope Details *******************************
   //$horos = new Profile();
   //$horos = $horos->fetchHoroscope("WHERE hs_userId = '{$profile['km_regcode']}'")->resultSet();
   //$horos = $horos[0];
   //*********************** Photo Details *******************************
   $photos = new Profile();
   $photos = $photos->fetchPhotos("WHERE pho_userId = '{$profile['km_regcode']}' AND pho_imgPath LIKE '%_profile_%'")->resultSet();
   $photo = $photos[0];

   //// Occupation /////
    $occupations = new Registration();
    $occupations = $occupations->fetchOccupation("WHERE id = '{$profile['km_occupation']}' ORDER BY occupation ASC")->resultSet();
    $occupation = $occupations[0];
    
    //// Districts /////
    $districts = new Registration();
    $districts = $districts->fetchDistricts("WHERE id = '{$profile['km_district']}' ORDER BY name ASC")->resultSet();
    $district = $districts[0];
   
   
    $horoscopes = new Profile();
      $horoscopes = $horoscopes->fetchHoroscope("WHERE hs_userId = '{$profile['km_regcode']}'")->resultSet();
      $horoscope = $horoscopes[0];
   
      if($horoscope['hs_imgPath']){
       $horPath = $horoscope['hs_imgPath'];
   
       $horos_file = fopen($horPath, 'r');
       $horPath = fread($horos_file, filesize($horPath));
   
      }
      
         if($photo['pho_imgPath']){
          $imgPath =  $photo['pho_imgPath'];
   
          $image_file = fopen($imgPath, 'r');
          $imgPath = fread($image_file, filesize($imgPath));
   
      }else{
          if($profile['km_gender'] == 'male'){
              $imgPath = 'images/male.png';
   
              $image_file = fopen($imgPath, 'r');
              $imgPath = fread($image_file, filesize($imgPath));
          }else{
              $imgPath = 'images/female.png';
   
              $image_file = fopen($imgPath, 'r');
              $imgPath = fread($image_file, filesize($imgPath));
          }
           
      }
   
   
   
   ?>
<!DOCTYPE html>
<html>
   <head>
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>

      <style type="text/css">
     
     #photo-area {
    
     float: none !important;
     text-align: center;
}
   </style>
      <?php include("includes/headertop.php");?>
   </head>
   <body class="home color-green boxed shadow">
      
         <?php include("includes/headerin.php");?>
         <?php include("includes/bannerin.php");?>
         <?php //include("includes/quicksearch.php");?>
         <div class="root">
         <section class="content reverse">
         <?php include("includes/right.php");?>
            <section class="col-md-9 col-xs-12" style=" margin-top: 1%;">
               <table>
                  <tr class="tabletitle" >
                     <td colspan="2" style="  border-top-left-radius: 0.5em; border-top-right-radius: 0.5em;">My Profile </td>
                  </tr>
               </table>
               <div id="result-content">
                  <div id="result-box">
                    
                     <div id="result-box-top-middle">
                        <div class="profile-id-text-results"> <?php echo ucwords($profile['km_name']); ?> &nbsp; (<?php echo $profile['km_regcode'];?>) </div>
                        <div class="profile-id-text-results" style="width:100px;"> </div>
                     </div>
                     
                     <div class="spacer"></div>
                     <div id="result-box-content2">
                        <div id="photo-area">
                           <div class="photo-album">
                              <div class="photo-content">
                                 <img src="data:image/jpeg;base64,<?php echo base64_encode($imgPath); ?>" width="auto" height="auto" alt="" style="padding-top: 2px; max-width: 300px; border:0px;">
                              </div>
                           </div>
                           <div class="photo-text"  style="cursor:pointer;"></div>
                        </div>
                        <div class="spacer"></div>
                     </div>
                     
                     
                     
                     <div class="spacer"></div>
                  </div>
                  <br>
                
                  <div class="basic-info-title-box">
                     
                     <div id="info-3-title-middle">
                        <div class="full-profile-title-text-1">Basic Information</div>
                     </div>
                     
                     <div class="spacer"></div>
                     <div class="basic-information-box" style=" min-height:310px;     height: auto;    width: 98.8%; float: left; padding-bottom: 30px;">

                     <div style=" float: left; width: 60%;" class="fullwidth">
                     
                        <?php 
                           $from = new DateTime($profile['km_dateofbirth']);
                           $to   = new DateTime('today');
                           $age = $from->diff($to)->y;
                           ?>
                        <div class="profile-q">Name : </div>
                        <div class="profile-a"><span class="information-text">
                           <?php echo ucwords($profile['km_name']); ?> </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q">Age : </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($age){ ?>
                           <?php if($age == $cur_Year){ echo 'N / A'; } else { echo $age.' Yrs'; } ?>
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q">D.O.B : </div>
                        <div class="profile-a">
                           <span class="information-text">
                           <?php if($profile['km_dateofbirth']){ ?>
                           <?php if($profile['km_dateofbirth'] == '0000-00-00'){ ?>
                           <?php echo 'N / A'; } else { ?>
                           <?php echo date_format(new DateTime($profile['km_dateofbirth']), 'd-m-Y'); ?> 
                           <?php } ?>
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q">Email ID : </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($profile['km_email']){ ?> 
                           <?php echo $profile['km_email']; ?> 
                           <?php } else { echo 'N / A'; } ?> 
                           </span>
                        </div>
                         <div class="spacer"></div>
                        <div class="profile-q">SubCaste : </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($profile['km_subcaste']){ ?> 
                           <?php echo $profile['km_subcaste']; ?> 
                           <?php } else { echo 'N / A'; } ?> 
                           </span>
                        </div>
                         <div class="spacer"></div>
                        <div class="profile-q">Caste : </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($profile['km_caste']){ ?> 
                           <?php echo $profile['km_caste']; ?> 
                           <?php } else { echo 'N / A'; } ?> 
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q">Marital Status : </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($profile['km_marital_status']){ ?> 
                           <?php echo ucwords($profile['km_marital_status']); ?> 
                           <?php } else { echo 'N / A'; } ?> 
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q">Place of Birth : </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($profile['km_place_of_birth']){ ?>
                           <?php echo ucwords($profile['km_place_of_birth']); ?> 
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q">Order of Birth : </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($profile['km_order_of_birth']){ ?>
                           <?php echo ucwords($profile['km_order_of_birth']); ?> 
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q">Day of Birth : </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($profile['km_dayofbirth']){ ?>
                           <?php echo ucwords($profile['km_dayofbirth']); ?> 
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q">Time of Birth : </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($profile['km_birthtime']){ ?>
                           <?php echo ucwords($profile['km_birthtime']); ?> 
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q">
                           Height :
                        </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($profile['km_height']){ ?> 
                           <?php echo $profile['km_height']; ?> 
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q">
                           Weight :
                        </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($profile['km_weight']){ ?> 
                           <?php echo $profile['km_weight']; ?> 
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q">
                           Blood Group :
                        </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($profile['km_blood_group']){ ?> 
                           <?php if($profile['km_blood_group'] == 'donotknow'){ ?>
                           <?php echo "Don't Know"; ?> 
                           <?php } else { ?>
                           <?php echo $blood_array[$profile['km_blood_group']]; ?>
                           <?php } ?>
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q">
                           Physical status :
                        </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($profile['km_physical_status']){ ?> 
                           <?php echo $profile['km_physical_status']; ?> 
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q">
                           Languages Known :

                          
                        </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($profile['km_languages']){ ?> 
                           <?php echo $profile['km_languages']; ?> 
                           <?php } else { echo 'N / A'; } ?>
                           </span>


                        </div>



                        </div>


                        

                         <div id="information-area-2anew">
                        <div style="padding-left:0px;">
                           <div style="padding-top:10px; width:280px; cursor:pointer; float: left;  color:#b10000; font-weight: bold; font-size: 18px;">
                              <img src="images/man-user.png" width="32"> Contact Details<br><br>
                              <div style=" margin-left: 12%; line-height: 36px;">
                                 <span><img src="images/mobile.png" width="25">  <?php echo $profile['km_mobile']; ?></span><br>
                                 <?php if($profile['km_second_mobile']){ ?>
                                 <span ><img src="images/mobile.png" width="25">  <?php echo $profile['km_second_mobile']; ?></span>
                                 <?php } else if($profile['km_landline']){ ?>
                                 <span ><img src="images/call.png" width="25">  <?php echo $profile['km_landline']; ?></span>
                                 <?php } ?>
                              </div>
                           </div>
                        </div>
                     </div>
                     </div>
                    
                  </div>
                  <div style=" clear: both;"></div>
                  <div class="basic-info-title-box">
                     
                     <div id="info-4-title-middle">
                        <div class="full-profile-title-text">
                           <b>Education &amp; Career</b>
                        </div>
                     </div>
                     
                     <div class="spacer"></div>
                     <div class="basic-information-box" style=" height:210px;">
                        <BR />
                        <div class="profile-q">Education : </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($profile['km_education']){ ?> 
                           <?php echo $edu_array[$profile['km_education']]; ?> 
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q">Education Details : </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($profile['km_education_details']){ ?> 
                           <?php echo $profile['km_education_details']; ?> 
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>

                        <div class="spacer"></div>
                        <div class="profile-q">Occupation : </div>
                        <div class="profile-a"><span class="information-text">
                           <?php 
                           if($profile['km_employee_in'] == 'notworking'){
                             echo 'Not Working';
                         } else {
                          if($profile['km_occupation']){ 
                          if($occupation){ 
                          	echo $occupation['occupation']; } 
                          	else { echo $profile['km_occupation']; }
                          	} else { echo 'N / A'; } 
                         }
                            ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q">Occupation Details : </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($profile['km_company_name']){ ?> 
                           <?php echo $profile['km_company_name']; ?> 
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q">Employed in : </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($profile['km_employee_in']){ ?> 
                           <?php echo $profile['km_employee_in']; ?> 
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q">
                           Annual Income :
                        </div>
                        <div class="profile-a"><span class="information-text">
                           <?php if($profile['km_annual_income']){ ?> 
                           <?php echo $profile['km_annual_income']; ?> 
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                     </div>
                     <div style=" clear: both;"></div>
                     <div class="basic-info-title-box">
                        
                        <div id="info-3-title-middle">
                           <div class="full-profile-title-text-1">Religious &amp; Social Background</div>
                        </div>
                        
                        <div class="spacer"></div>
                        <div class="basic-information-box" style=" min-height:240px;">
                           <div class="profile-q-long">House Name :</div>
                           <div class="profile-a-small"><span class="information-text">
                              <?php if($profile['km_housename']){ ?>
                              <?php echo ucwords($profile['km_housename']); ?>  
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q-long">Gothram :</div>
                           <div class="profile-a-small"><span class="information-text">
                              <?php if($profile['km_gothram']){ ?>
                              <?php echo ucwords($profile['km_gothram']); ?>
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q-long">Star :</div>
                           <div class="profile-a-small"><span class="information-text">
                              <?php if($profile['km_star']){ ?>
                              <?php echo ucwords($profile['km_star']); ?>
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q-long">Raasi :</div>
                           <div class="profile-a-small"><span class="information-text">
                              <?php if($profile['km_rasi']){ ?>
                              <?php echo ucwords($profile['km_rasi']); ?>
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q-long">Chevvai Dosham :</div>
                           <div class="profile-a-small"><span class="information-text">
                              <?php if($profile['km_dosham']){ ?>
                              <?php echo ucwords($profile['km_dosham']); ?>
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q-long">Lagnam :</div>
                           <div class="profile-a-small"><span class="information-text">
                              <?php if($profile['km_lagnam']){ ?>
                              <?php echo ucwords($profile['km_lagnam']); ?>
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q-long">Thisai irrupu :</div>
                           <div class="profile-a-small"><span class="information-text">
                              <?php if($profile['km_thisai_irrupu']){ ?>
                              <?php echo ucwords($profile['km_thisai_irrupu']); ?> 
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                        </div>
                     </div>
                  </div>
                  <br>
                  <div style=" clear: both;"></div>
                  <div class="basic-info-title-box">
                     
                     <div id="info-3-title-middle">
                        <div class="full-profile-title-text-1">Family Information</div>
                     </div>
                     
                     <div class="spacer"></div>
                     <div class="basic-information-box" style=" min-height:270px;">
                        <div class="profile-q-long">Father's Name :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                           <?php if($profile['km_father_name']){ ?>
                           <?php echo ucwords($profile['km_father_name']); ?>
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q-long">Father's Professional :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                           <?php if($profile['km_father_occupation']){ ?>
                           <?php echo ucwords($profile['km_father_occupation']); ?>
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q-long">Mother's Name :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                           <?php if($profile['km_mother_name']){ ?>
                           <?php echo ucwords($profile['km_mother_name']); ?>
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q-long">Mother's Professional :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                           <?php if($profile['km_mother_occupation']){ ?>
                           <?php echo ucwords($profile['km_mother_occupation']); ?> 
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q-long">Family Status :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                        <?php if($profile['km_family_status']){ ?>
                        <?php echo ucwords($profile['km_family_status']); ?> 
                        <?php } else { ?>   <a href="edit-profile.php"><label class="" style="background-color: white;cursor: pointer;color: blue;border: none;font-weight: bold;margin-top: -1px;">Update<label style="color:red;font-size: 20px;">&nbsp;</label></label></a> <?php } ?>
                        </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q-long">Family Type :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                        <?php if($profile['km_family_type']){ ?>
                        <?php echo ucwords($profile['km_family_type']); ?> 
                        <?php } else { ?> <a href="edit-profile.php"><label class="" style="background-color: white;cursor: pointer;color: blue;border: none;font-weight: bold;margin-top: -1px;">Update<label style="color:red;font-size: 20px;">&nbsp;</label></label></a> <?php } ?>
                        </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q-long">Family Value :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                        <?php if($profile['km_family_value']){ ?>
                        <?php echo ucwords($profile['km_family_value']); ?> 
                        <?php } else { ?> <a href="edit-profile.php"><label class="" style="background-color: white;cursor: pointer;color: blue;border: none;font-weight: bold;margin-top: -1px;">Update<label style="color:red;font-size: 20px;">&nbsp;</label></label></a> <?php } ?>
                        </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q-long" style="margin-top:2%">Unmarried Brother :</div>
                        <div class="profile-a-small" style="margin-top:2%;"><span class="information-text">
                        <?php if($profile['bcount'] == ''){ ?>
                        <a href="edit-profile.php"><label class="" style="background-color: white;cursor: pointer;color: blue;border: none;font-weight: bold;margin-top: -1px;">Update<label style="color:red;font-size: 20px;">&nbsp;</label></label></a>
                        <?php } else { echo $profile['bcount']; } ?> 
                        </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q-long">Married Brother :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                        <?php if($profile['bmcount'] == ''){ ?>
                        <a href="edit-profile.php"><label class="" style="background-color: white;cursor: pointer;color: blue;border: none;font-weight: bold;margin-top: -1px;">Update<label style="color:red;font-size: 20px;">&nbsp;</label></label></a>
                        <?php } else { echo $profile['bmcount']; } ?> 
                        </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q-long">Unmarried Sister :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                        <?php if($profile['scount'] == ''){ ?>
                        <a href="edit-profile.php"><label class="" style="background-color: white;cursor: pointer;color: blue;border: none;font-weight: bold;margin-top: -1px;">Update<label style="color:red;font-size: 20px;">&nbsp;</label></label></a>
                        <?php } else { echo $profile['scount']; } ?>
                        </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q-long">Married Sister :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                        <?php if($profile['smcount'] == ''){ ?>
                        <a href="edit-profile.php"><label class="" style="background-color: white;cursor: pointer;color: blue;border: none;font-weight: bold;margin-top: -1px;">Update<label style="color:red;font-size: 20px;">&nbsp;</label></label></a>
                        <?php } else { echo $profile['smcount']; } ?>
                        </span>
                        </div>
                        <div class="spacer"></div>

                        <div class="spacer"></div>
                        <div class="profile-q-long">Native Place :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                           <?php if($profile['km_native_place']){ ?>
                           <?php echo ucwords($profile['km_native_place']); ?> 
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q-long">Native District :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                           <?php if($profile['km_native_district']){ ?>
                           <?php echo ucwords($profile['km_native_district']); ?> 
                           <?php } else { echo 'N / A'; } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <?php if($profile['km_doorno'] || $profile['km_street']){ ?>
                        <div class="profile-q-long">Living Address :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                           <?php if($profile['km_doorno']){ ?>
                           <?php echo ucwords($profile['km_doorno']); ?> , 
                           <?php } ?>
                           <?php if($profile['km_street']){ ?>
                           <?php echo ucwords($profile['km_street']); ?> , 
                           <?php } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <?php } ?>
                        <?php if($profile['km_doorno'] || $profile['km_street']){ ?>
                        <div class="profile-q-long"></div>
                        <?php } else { ?>
                        <div class="profile-q-long">Living Address :</div>
                        <?php } ?>
                        <div class="profile-a-small" style="width:320px;"><span class="information-text">
                           <?php if($profile['km_city']){ ?>
                           <?php echo ucwords($profile['km_city']); ?> , 
                           <?php } ?>
                           <?php if($profile['km_district']){ ?>
                           <?php 
                           if($district){ 
                            echo $district['name']; } 
                            else { echo $user['km_district']; }
                           ?> , 
                           <?php } ?>
                           <?php if($profile['km_pincode']){ ?>
                           <?php echo ucwords($profile['km_pincode']); ?> . 
                           <?php } ?>
                           </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="spacer"></div>
                     </div>
                  </div>
                  <p>&nbsp;</p>
               </div>
               <div style="clear:both"></div>
               <div class="space"></div>
              
            </section>
            
         </section>
         </div>
         <div style=" clear: both;"></div>
         <?php include("includes/footertop.php");?>
         <?php include("includes/footerin.php");?>
      </div>
   </body>
</html>