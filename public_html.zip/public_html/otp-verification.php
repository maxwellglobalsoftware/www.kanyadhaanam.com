<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   require_once 'KANyaMatrI_GST/includes/configure.php';
   require_once 'includes/session_handler.php';
   require_once 'init.php';
   
   $profileId = $_SESSION['User_Kamma_Matri']['km_regcode'];
   //*********************** Horoscope Details *******************************
   $profiles = new Registration();
   $profiles = $profiles->fetch("WHERE km_regcode = '{$profileId}'")->resultSet();    
   $profile = $profiles[0];
   
   if(isset($_SESSION['pwdUpdate'])) {
       if($_SESSION['pwdUpdate']) {
           $result = "Password updated successfully";
       } else {
           $result = "Failed to update Password";
       }
       unset($_SESSION['pwdUpdate']);
   }
   if(isset($_SESSION['msg'])){
       $result = $_SESSION['msg']; 
       unset($_SESSION['msg']);
   }
   
   if(isset($_POST['btn_chgpwd'])) {      
       $data = array();   
       
       $oldpwd = $_POST['oldpwd'];
       $newpwd = $_POST['newpwd'];
       $confirmpwd = $_POST['confirmpwd'];
       if($oldpwd == $profile['km_password']){        
           if($newpwd == $confirmpwd){
               $data[] = $newpwd;
               $data[] = $profileId;
               $registration = new Registration();
               $registration = $registration->updatePassword($data);
               $payment_id = $registration->rowCount();
               if($payment_id){   
                   $_SESSION['flag'] = 'success';
                   $_SESSION['pwdUpdate'] = true;
               } else {
                   $_SESSION['flag'] = 'fail';
                   $_SESSION['pwdUpdate'] = false;
               }
           }else{
               $_SESSION['flag'] = 'newpwd';
               $_SESSION['msg'] = 'New and Confirm password doesnot match';
           }
           $_SESSION['oldpwd'] = $oldpwd;
       }else{
           $_SESSION['oldpwd'] = '';
           $_SESSION['flag'] = 'oldpwd';
           $_SESSION['msg'] = 'Please enter valid Old Password';
       }
       
       
       header("Location: change_password.php");
   }
   ?>
<!DOCTYPE html>
<html>
   <?php include("includes/headertop.php");?>
   <body class="home color-green boxed shadow">
      <div class="root">
         <?php include("includes/headerin.php");?>
         
            <script src="js/jquery-1.12.4.js"></script>
           
            <?php include("includes/bannerin.php");?>
        
         <?php //include("includes/quicksearch.php");?>
         <section class="content reverse">
            <section class="main" style=" margin-top: 1%;">
               <table>
                  <tr class="tabletitle" >
                     <td colspan="2" style="  border-top-left-radius: 0.5em; border-top-right-radius: 0.5em;">OTP Mobile Number Verification</td>
                  </tr>
               </table>
               <div id="result-content">
                  <div class="panel-default panel-ep">
                     <div class="panel-body">
                        <div class="ep-view editProfileContent" style="" id="basicRelDetailsFormview">
                           <div class="form-horizontal verify">
                              <div class="form-group required">
                                 <label class="col-sm-4 control-label">Primary Mobile Number </label>
                                 <form id="search_result" name="FirstForm" method="post">
                                    <input type="hidden" id="primary_id" name="primary_id" value="">
                                    <div class="col-sm-8">
                                       <div class="col-sm-7" style=" padding-right: 0px; padding-left: 0px;">
                                          <input type="text" class="form-control" id="km_mobile" disabled="" autofocus="autofocus" name="km_mobile" placeholder="Primary Mobile Number" required="" value="1234567890" style=" width: 100%"> 
                                          <div class="col-sm-5" style=" vertical-align: middle; padding-bottom: 3.5%; padding-right: 0px;">
                                             <strong style=" color: #e80a0a;"><input type="submit" style="color: #1f22ad;background-color: white;border: 0px;" name="send_first" value="Send OTP"> &nbsp; &nbsp;  </strong>
                                          </div>
                                       </div>
                                       <div class="col-sm-5" style=" vertical-align: middle; padding-top: 1.5%; padding-right: 0px;">
                                          <strong style=" color: #e80a0a;">
                                          <i class="fa fa-pencil" style="color: #1f22ad;" aria-hidden="true"></i><input type="submit" style="color: #1f22ad;background-color: white;border: 0px;" name="edit_first_function" value="Edit"> &nbsp; (Not Verified) </strong>
                                       </div>
                                    </div>
                                 </form>
                                 <label class="col-sm-4 control-label">Secondary Mobile Number</label>
                                 <form name="prefForm" id="secondary_search_result" method="post">
                                    <input type="hidden" id="secondary_id" name="secondary_id" value="">
                                    <div class="col-sm-8">
                                       <div class="col-sm-7" style="padding-left: 0px; padding-right: 0px;">
                                          <input type="text" autofocus="autofocus" class="form-control" id="km_second_mobile" disabled="" value="9994624134" name="km_second_mobile" placeholder="Secondary Mobile Number" required="" style=" width: 100%"> 
                                       </div>
                                       <div class="col-sm-5" style=" vertical-align: middle; padding-top: 3.5%;">
                                          <small>(Verified <i class="fa fa-check"></i>)</small>
                                       </div>
                                       <!-- <div class="col-sm-5" style=" vertical-align: middle; padding-top: 3.5%;">
                                          <small>(Verified <i class="fa fa-check"></i>)</small>
                                          </div> -->
                                    </div>
                                 </form>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <?php include("includes/right.php");?>
         </section>
         <div style=" clear: both;"></div>
         <?php include("includes/footertop.php");?>
         
         <?php include("includes/footer.php");?>
         <?php
            if(isset($result)) {
            ?>
         <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(2000, function() {
                            $('#message').text("");
                            <?php 
               if($_SESSION['flag'] == 'newpwd'){
                   ?>
                                $('#oldpwd').val('<?php echo $_SESSION['oldpwd']; ?>');
                                
                                $('#newpwd').focus();
                           <?php }else if($_SESSION['flag'] == 'oldpwd'){
               ?>
                                            $('#oldpwd').focus();
                                            <?php
               }else if($_SESSION['flag'] == 'fail'){
                ?>
                                 $('#oldpwd').focus();
                                 <?php   
               }else{?>
                                
                          <?php  }
               ?>
                    });
            }, 2000);
         </script>
         <?php
            }
            ?>
      </div>
   </body>
</html>