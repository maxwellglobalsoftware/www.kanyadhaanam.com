<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   require_once 'KANyaMatrI_GST/includes/configure.php';
   require_once 'includes/session_handler.php';
   require_once 'init.php';
   
   $profileId = $_SESSION['User_Kamma_Matri']['km_regcode'];
   //*********************** Partner Preferences Details *******************************
    $get_partners = new Partner();
   $get_partners = $get_partners->fetch("WHERE pl_userId = '{$profileId}' ORDER BY id DESC LIMIT 1")->resultSet(); 
   $get_partner = $get_partners[0];
   
   if(isset($_POST['submit_id'])){
       profile_details($_POST['submit_id'],$profileId);
   } 
   
   if($get_partner){
    header("Location: update_preferences.php");
   }
   
   if(isset($_POST['save_preference'])){
   
    $data = array();
   
    $data[] = $profileId;
    $data[] = $_POST['age_from'];
    $data[] = $_POST['age_to'];
    if($_POST['education']){
    $data[] = implode(",", $_POST['education']);
    } else {
    $data[] = "";
    }
    if($_POST['star']){
    $data[] = implode(",", $_POST['star']); 
    } else {
    $data[] = ""; 
    }
    $data[] = date("d-m-Y");
    $data[] = date("h:i A");
   
    $partner = new Partner();
    $partner = $partner->add($data);
    $partner_id = $partner->lastInsertID();
   
    if($partner_id){
      $_SESSION['prefer_added'] = true;
      header("Location: update_preferences.php");
    }
   }
   
   
   $get_partners = new Partner();
   $get_partners = $get_partners->fetch("WHERE pl_userId = '{$profileId}' ORDER BY id DESC")->resultSet(); 
   $get_partner = $get_partners[0];
   ?>
<!DOCTYPE html>
<html>
   <?php include("includes/headertop.php");?>

   <style type="text/css">
     
     .checkbox input[type=checkbox], .checkbox-inline input[type=checkbox], .radio input[type=radio], .radio-inline input[type=radio] {
    position: absolute;
    margin-top: 4px\9;
    margin-left: -20px;
     margin-top: 2px !important; 
}
   </style>


   <body class="home color-green boxed shadow">
     
         <?php include("includes/headerin.php");?>
         
            <script src="js/jquery-1.12.4.js"></script>
            
            <?php include("includes/bannerin.php");?>
        
         <?php //include("includes/quicksearch.php");?>

          <div class="root">
         <section class="content reverse">

         <?php include("includes/right.php");?>

            <section class="col-md-9 col-xs-12" style=" margin-top: 1%;">
               <table>
                  <tr class="tabletitle" >
                     <td colspan="2" style="  border-top-left-radius: 0.5em; border-top-right-radius: 0.5em;">Partner Preferences</td>
                  </tr>
               </table>
               <div id="result-content">
                  <p style="padding-bottom:5px; padding-left: 10px; padding-top: 10px;">Here, you can view the list of matching profiles based on your partner’s preference. One might
                     be your special someone!
                  </p>
                  <div class="panel-default panel-ep">
                     <div class="panel-body">
                        <div class="ep-view editProfileContent" style="" id="basicRelDetailsFormview">
                           <form action="" id="PreferForm" name="prefForm" method="post" onsubmit="return preferfn(prefForm);">
                              <input type="hidden" id="partner_id" name="partner_id" value="3">
                              <div class="form-horizontal">
                                 <div class="form-group required">
                                    <label class="col-md-3 control-label fullwidth" style=" padding-top: 0px; font-size: 18px; text-align: left;">Preferred Age : </label>
                                    <div class="pull-left makeleft maketop">
                                       <label class="control-label" style=" padding-top: 0px;">From</label>
                                    </div>
                                    <div class="col-md-2 makesmall">
                                       <select id="age_from" name="age_from" class="form-control">
                                          <option value="21" >21</option>
                                          <?php for($age = 22; $age <= 50; $age++ ){?>
                                          <option value="<?php echo $age;?>"><?php echo $age;?></option>
                                          <?php } ?>
                                       </select>
                                    </div>
                                    <div class="pull-left makeleft maketop">
                                       <label class="control-label" style=" padding-top: 0px;">To</label>
                                    </div>
                                    <div class="col-md-2 makesmall">
                                       <select id="age_to" name="age_to" class="form-control">
                                          <option value="21" >21</option>
                                          <?php for($age = 22; $age <= 50; $age++ ){?>
                                          <option value="<?php echo $age;?>"><?php echo $age;?></option>
                                          <?php } ?>
                                       </select>
                                    </div>
                                 </div>

                                 <br>


                                 <div class="form-group required">
                                    <label class="col-md-2 control-label fullwidth maketop" style="  font-size: 18px;">Education</label>
                                    <div class="col-md-10 makeclear">
                                       <?php foreach($edu_array as $key => $value){ ?>
                                       <div class="col-md-4 col-xs-6">
                                          <label class="checkbox-inline">
                                          <input type="checkbox" value="<?php echo $key;?>" name="education[]"><?php echo $value;?>
                                          </label>
                                       </div>
                                       <?php } ?>
                                    </div>
                                 </div>
                                 <br>


                                 <div class="form-group required">
                                    <label class="col-md-2 control-label fullwidth" style=" padding-top: 0px; font-size: 18px;">Star</label>
                                    <div class="col-md-10">
                                       <?php foreach($stars_array as $star){?>
                                       <div class="col-md-4 col-xs-6">
                                          <label style="min-height: 45px;" class="checkbox-inline">
                                          <input type="checkbox" name="star[]" value="<?php echo $star; ?>"><?php echo $star; ?>
                                          </label>
                                       </div>
                                       <?php } ?>
                                    </div>
                                 </div>

                                 <center>

                                 <div class="form-group required">
                                    <div class="col-md-12">
                                       <div class="capbox">
                                          <div id="CaptchaDiv">99212</div>
                                          <div class="capbox-inner">
                                             <input type="hidden" id="txtCaptcha" value="99212" >
                                             <input type="text" name="CaptchaInput" placeholder="Enter Captcha" id="CaptchaInput" size="15" style="  border: solid 1px #007ed4; width: 90%;  border-radius: 5px; height: 25px;
                                                padding: 15px; ">
                                             <br>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 </center>

                                 <center>

                                 <div class="form-group">
                                    <button type="submit" class="btn btn-white btn-sm"  name="save_preference" style=" background-color: #f58220; color: #fff;" data-toggle="modal" data-target=""><i class="fa fa-save"></i> Save</button>
                                 </div>

                                 </center>


                              </div>
                              <script type="text/javascript">
                                 function preferfn(form)
                                 
                                 {
                                 
                                 var educheckboxSelectedCount = 0;
                                 
                                  $.each($('input[type=checkbox]:checked'), function(index, element) {
                                        educheckboxSelectedCount++;
                                      });
                                 
                                 if(educheckboxSelectedCount == 0) {
                                    alert("Please select any one education or star");
                                    return false;
                                      }
                                 
                                 
                                 
                                 var why = "";
                                 
                                 if(form.CaptchaInput.value == ""){
                                 why += "- Please Enter CAPTCHA Code.\n";
                                 }
                                 if(form.CaptchaInput.value != ""){
                                 if(ValidCaptcha(form.CaptchaInput.value) == false){
                                 why += "- The CAPTCHA Code Does Not Match.\n";
                                 }
                                 }
                                 if(why != ""){
                                 alert(why);
                                 return false;
                                 }
                                 }
                                 
                                 
                                 var a = Math.ceil(Math.random() * 9)+ '';
                                 var b = Math.ceil(Math.random() * 9)+ '';
                                 var c = Math.ceil(Math.random() * 9)+ '';
                                 var d = Math.ceil(Math.random() * 9)+ '';
                                 var e = Math.ceil(Math.random() * 9)+ '';
                                 
                                 var code = a + b + c + d + e;
                                 document.getElementById("txtCaptcha").value = code;
                                 document.getElementById("CaptchaDiv").innerHTML = code;
                                 
                                 // Validate input against the generated number
                                 function ValidCaptcha(){
                                 var str1 = removeSpaces(document.getElementById('txtCaptcha').value);
                                 var str2 = removeSpaces(document.getElementById('CaptchaInput').value);
                                 if (str1 == str2){
                                 return true;
                                 }else{
                                 return false;
                                 }
                                 }
                                 
                                 // Remove the spaces from the entered and generated code
                                 function removeSpaces(string){
                                 return string.split(' ').join('');
                                 }
                                 
                              </script>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            
         </section>
         <div style=" clear: both;"></div>
         </div>
         <?php include("includes/footertop.php");?>
         <?php include("includes/footerin.php");?>
      
   </body>
</html>