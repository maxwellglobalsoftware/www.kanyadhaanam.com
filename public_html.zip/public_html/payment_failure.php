<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
ob_start();
session_start();
require_once 'KANyaMatrI_GST/includes/configure.php';
require_once 'includes/session_handler.php';
require_once 'init.php';
require_once 'includes/pagination.php';
require_once 'includes/db.php';
date_default_timezone_set('Asia/Kolkata');

$status=$_POST["status"];
$firstname=$_POST["firstname"];
$amount=$_POST["amount"];
$txnid=$_POST["txnid"];

$posted_hash=$_POST["hash"];
$key=$_POST["key"];
$productinfo=$_POST["productinfo"];
$email=$_POST["email"];

$salt="wSXvanYJLp";

If (isset($_POST["additionalCharges"])) {
       $additionalCharges=$_POST["additionalCharges"];
        $retHashSeq = $additionalCharges.'|'.$salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
        
                  }
    else {    

        $retHashSeq = $salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;

         }
         $hash = hash("sha512", $retHashSeq);

        // echo $hash.'- 1';

        // echo '<br>';

        // echo $posted_hash.'- 2';

       if ($hash != $posted_hash) {
           $result = "<h3 style='margin:1em;font-size: 20px;'>Invalid Transaction. Please try again</h3>";
           }
       else {

        $result = "<h3 style='margin:1em;font-size: 20px;'>Your payment status is ". $status .".</h3>";
        $result .= "<h4 style='margin:1em;font-size: 20px;'>Your Transaction ID for this transaction is ".$txnid.".</h4>";
        $result .= "<h3 style='margin:1em;font-size: 20px;'>Please Try again.</h3>";
          
         } 
?>
<!DOCTYPE html>
<html>
<?php include("includes/headertop.php");?>

    <body class="home color-green boxed shadow">
       
            <?php include("includes/headerin.php");?>
             <?php include("includes/bannerin.php");?>
                 <div class="root">
                    <section class="content reverse">
                    <?php include("includes/right.php");?>
                        <section class="col-md-9 col-xs-12" style=" margin-top: 1%;">
                        <form method="post">
                            <h3 style=" margin-top: 10px; color: #175905;">PAYMENT FAILURE</h3>
                            <br>


                            <form method="post" id='search_result' action="">
                             <div id="result-content">
                                <?php echo $result; ?>
                             </div>
                          </form>

                        
                            <div style=" clear: both;"></div>

                            <div class="space"></div>
                            </form>
                        </section>

                        

                    </section>
                    <div style=" clear: both;"></div>

                     </div>

                    <?php include("includes/footertop.php");?>
                    <?php include("includes/footer.php");?>
       
    </body>

</html>