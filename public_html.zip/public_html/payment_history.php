<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
ob_start();
session_start();
require_once 'KANyaMatrI_GST/includes/configure.php';
require_once 'includes/session_handler.php';
require_once 'init.php';
require_once 'includes/pagination.php';
require_once 'includes/db.php';

$pay_profileId = $_SESSION['User_Kamma_Matri']['km_regcode'];

//   $payment_historys = new Payment();
//   $payment_historys = $payment_historys->fetch("WHERE pl_userId = '{$pay_profileId}' AND pl_status = 'activate' ORDER BY id DESC")->resultSet(); 

   $payment_historys = new Payment();
   $payment_historys = $payment_historys->fetch("WHERE pl_userId = '{$pay_profileId}' ORDER BY id DESC")->resultSet(); 

   if(isset($_POST['view_payment_id'])){

    $_SESSION['view_payment_id'] = $_POST['view_payment_id'];
    
    if($_POST['profile_type'] == 'contact'){
       header("Location: payment_contact_profile_details.php"); 
    } else {
       header("Location: payment_horoscope_profile_details.php"); 
    }

     
} 
   ?>
<!DOCTYPE html>
<html>
   <head>
       
       <style>
       
       th {
    text-align: center !important;
}
           
           
       </style>
       
       
       <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <?php include("includes/headertop.php");?>
   </head>
   <body class="home color-green boxed shadow">
      
         <?php include("includes/headerin.php");?>
    <?php include("includes/bannerin.php");?>
         
         <?php //include("includes/quicksearch.php");?>
         <div class="root">
         <section class="content reverse">
         <?php include("includes/right.php");?>
            <section class="col-md-9 col-xs-12" style=" margin-top: 1%;">
                
                
               
              
               
                
                
               <h3 style=" margin-top: 10px; color: #175905;">PAYMENT HISTORY</h3>
              
             <div align="center">
               
             
                  <table border="0" cellspacing="0" cellpadding="2" style="border:1px solid #224e9b">
                     <thead>
                     <tr style="height: 30px;border-bottom: 1px solid;">
                     <!--<th style="border-right:1px solid #224e9b;">Profile ID</th>-->
                     <!--<th style="border-right:1px solid #224e9b">Name</th>-->
                     <th style="border-right:1px solid #224e9b;">Plan</th>
                     <th style="border-right:1px solid #224e9b">Activation Date</th>
                     <th style="border-right:1px solid #224e9b">Expiry Date</th>
                     <th style="border-right:1px solid #224e9b">Used Contact</th>
                     <th style="border-right:1px solid #224e9b">Remaining Contact</th>
                     <th style="border-right:1px solid #224e9b">Used Horoscope</th>
                     <th style="border-right:1px solid #224e9b">Remaining Horoscope</th>
                     <th style="border-right:1px solid #224e9b">Status</th>
                     <!--<th style="border-right:1px solid #224e9b">Amount</th>-->
                     </tr>
                     </thead>
                     <tbody>
                     <?php
                     foreach($payment_historys as $payment_history){
                     ?>
                        <tr bgcolor="#e1fbbb" style="height: 30px;border-bottom: 1px solid;">
                            
                            <?php

                        $contact_count_profiles = new Profile();
                        $contact_count_profiles = $contact_count_profiles->fetch("WHERE pv_userId = '{$pay_profileId}' AND pv_paymentId = '{$payment_history['id']}' AND contact = '1' GROUP BY pv_viewedId")->resultSet();

                        $horos_count_profiles = new Profile();
                        $horos_count_profiles = $horos_count_profiles->fetch("WHERE pv_userId = '{$pay_profileId}' AND pv_paymentId = '{$payment_history['id']}' AND horoscope = '1' GROUP BY pv_viewedId")->resultSet();

                        ?>

                           <!--<td width="13%"  style="border-right: 1px solid #224e9b!important;border-left: 1px solid #224e9b!important;text-align: center;">-->
                           <!--<form target="_blank" method="post" id='search_result'>-->
                           <!--<input type="hidden" name="view_payment_id" value="<?php echo $payment_history['id'];?>">-->
                           <!--<input type="submit"  style="cursor: pointer;padding: 0px;color: blue;border: none;font-weight: bold;" value="<?php echo $payment_history['pl_name']; ?>">-->
                           <!--</form>-->
                           <!--</td>-->
                           <!--<td width="23%" class="blu_txt" style="border-right: 1px solid #224e9b!important;text-align: center;"><strong><?php echo $_SESSION['User_Kamma_Matri']['km_name']; ?></strong></td>-->
                           <td width="13%" class="blu_txt" style="border-right: 1px solid #224e9b!important;text-align: center;"><strong><?php echo $payment_history['pl_name']; ?></strong></td>
                           <td width="23%" class="blu_txt" style="border-right: 1px solid #224e9b!important;text-align: center;"><strong><?php echo date_format(new DateTime($payment_history['pl_startDate']), 'd-m-Y');?></strong></td>
                           <td width="23%" class="blu_txt" style="border-right: 1px solid #224e9b!important;text-align: center;"><strong><?php echo date_format(new DateTime($payment_history['pl_expireDate']), 'd-m-Y');?></strong></td>
                           <td width="13%"  style="border-right: 1px solid #224e9b!important;border-left: 1px solid #224e9b!important;text-align: center;">
                           <form target="_blank" method="post" id='search_result'>
                           <input type="hidden" name="view_payment_id" value="<?php echo $payment_history['id'];?>">
                           <input type="hidden" name="profile_type" value="contact">
                           <?php if($contact_count_profiles){ ?>
                           <input type="submit"  style="cursor: pointer;padding: 0px;color: blue; padding: 5px; border: none;font-weight: bold;" value="<?php if($contact_count_profiles){ echo count($contact_count_profiles); } else { echo 0; } ?>">
                           <?php } else { ?>
                           <input type="button"  style="cursor: inherit;padding: 0px;color: blue; padding: 5px; border: none;font-weight: bold;" value="<?php if($contact_count_profiles){ echo count($contact_count_profiles); } else { echo 0; } ?>">
                           <?php } ?>
                           </form>
                           </td>
                            <td width="13%" class="blu_txt" style="border-right: 1px solid #224e9b!important;text-align: center;"><strong>
                           <?php 
                           echo $remain_contact = 30 - count($contact_count_profiles); ?>
                           </strong></td>
                           <td width="13%"  style="border-right: 1px solid #224e9b!important;border-left: 1px solid #224e9b!important;text-align: center;">
                           <form target="_blank" method="post" id='search_result'>
                           <input type="hidden" name="view_payment_id" value="<?php echo $payment_history['id'];?>">
                           <input type="hidden" name="profile_type" value="horoscope">
                           <?php if($horos_count_profiles){ ?>
                           <input type="submit"  style="cursor: pointer;padding: 0px;color: blue; padding: 5px; border: none;font-weight: bold;" value="<?php if($horos_count_profiles){ echo count($horos_count_profiles); } else { echo 0; } ?>">
                           <?php } else { ?>
                           <input type="button"  style="cursor: inherit;padding: 0px;color: blue; padding: 5px; border: none;font-weight: bold;" value="<?php if($horos_count_profiles){ echo count($horos_count_profiles); } else { echo 0; } ?>">
                           <?php } ?>
                           </form>
                           </td>
                           <td width="23%" class="blu_txt" style="border-right: 1px solid #224e9b!important;text-align: center;"><strong>
                           <?php 
                           echo $remain_horos = 30 - count($horos_count_profiles); ?>
                           </strong></td>
                            <td width="23%" class="blu_txt" style="border-right: 1px solid #224e9b!important;text-align: center;"><strong>
                           <?php echo ucwords($payment_history['pl_status']); ?>
                           </strong></td>
                           <!--<td width="23%" class="blu_txt" style="border-right: 1px solid #224e9b!important;text-align: center;"><strong>-->
                           <!--<?php echo $payment_history['pl_amount']; ?>-->
                           <!--</strong></td>-->
                        </tr>
                        <?php } ?>
                     </tbody>
                  </table>
                  <br> 
                 
               </div>
               
               <div class="space"></div>
               
               <div style="clear:both"></div>
               
              


                  




               </div>


               
            </section>
            
         </section>
         <div style=" clear: both;"></div>
         </div>
         <?php include("includes/footertop.php");?>
         <?php include("includes/footerin.php");?>
      
   </body>
</html>