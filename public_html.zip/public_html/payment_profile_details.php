<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   require_once 'KANyaMatrI_GST/includes/configure.php';
   require_once 'init.php';
   require_once 'includes/common_functions.php';
   require_once 'includes/pagination.php';
   require_once 'includes/db.php';
   require_once 'includes/session_handler.php';
   date_default_timezone_set('Asia/Kolkata');
   

   $page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
   $limit = 10;
   $startpoint = ($page * $limit) - $limit;
   
   
   $user_id = $_SESSION['User_Kamma_Matri']['id'];
   $km_regcode = $_SESSION['User_Kamma_Matri']['km_regcode'];
   $users = new Registration();
   $users = $users->fetch("WHERE id = '{$user_id}'")->resultSet();
   $user = $users[0];
   if($user['km_gender'] == 'male'){
       $km_gender = 'female';
   }else{
       $km_gender = 'male';
   }
  
   
   if(isset($_POST['submit_id'])){
       profile_details($_POST['submit_id'],$km_regcode);  
   }
   
  //*************************** Search Results **************************************
   if(isset($_SESSION['view_payment_id'])){

$statement = "";
$profiles = new Profile();
$contactprofiles = $profiles->fetch("WHERE pv_userId = '{$km_regcode}' AND pv_paymentId = '{$_SESSION['view_payment_id']}' AND contact = '1' GROUP BY pv_viewedId ORDER BY id DESC")->resultSet();    
$statement = "profile_view_details WHERE pv_userId = '{$km_regcode}' AND pv_paymentId = '{$_SESSION['view_payment_id']}' AND contact = '1' GROUP BY pv_viewedId";


$horoscopeprofiles = $profiles->fetch("WHERE pv_userId = '{$km_regcode}' AND pv_paymentId = '{$_SESSION['view_payment_id']}' AND horoscope = '1' GROUP BY pv_viewedId ORDER BY id DESC")->resultSet();    
$statement = "profile_view_details WHERE pv_userId = '{$km_regcode}' AND pv_paymentId = '{$_SESSION['view_payment_id']}' AND horoscope = '1' GROUP BY pv_viewedId";



// $contactprofiles = $profiles->fetch("WHERE pv_userId = '{$km_regcode}' AND pv_paymentId = '{$_SESSION['view_payment_id']}' AND contact = '1' ORDER BY id DESC")->resultSet();    
// $statement = "profile_view_details WHERE pv_userId = '{$km_regcode}' AND pv_paymentId = '{$_SESSION['view_payment_id']}' AND contact = '1'";


// $horoscopeprofiles = $profiles->fetch("WHERE pv_userId = '{$km_regcode}' AND pv_paymentId = '{$_SESSION['view_payment_id']}' AND horoscope = '1' ORDER BY id DESC")->resultSet();    
// $statement = "profile_view_details WHERE pv_userId = '{$km_regcode}' AND pv_paymentId = '{$_SESSION['view_payment_id']}' AND horoscope = '1'";

}
   
   

   ?>
<!DOCTYPE html>
<html>
   <head>

  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
      <?php include("includes/headertop.php");?>
   </head>
   <body class="home color-green boxed shadow">
      
         <?php include("includes/headerin.php");?>
         <?php include("includes/bannerin.php");?>
         <?php //include("includes/quicksearch.php");?>
         <div class="root">
         <section class="content reverse">
         <?php include("includes/right.php");?>
            <section class="col-md-9 col-xs-12" style=" margin-top: 1%;">
               <div style=" clear: both;"></div>
               <div class="space"></div>
               <table>
                  <tr class="tabletitle" style=" background-color: #e23f0c;">
                     <td colspan="2" style="  border-top-left-radius: 0.5em; border-top-right-radius: 0.5em; color: #fff; font-weight: normal;">Contact Profiles History</td>
                  </tr>
               </table>
               <div id="pagin">
                  <form method="post" id='search_result' action="">
                     <input type="hidden" id="submit_id" name="submit_id" value="" />
                     <input type="hidden" id="submit_flag" name="submit_flag" value="" />
                     <input type="hidden" id="profile_type" name="profile_type" value="" />
                     <input type="hidden" id="page_return" name="page_return" value="" />
                     <input type="hidden" id="interest_value" name="interest_value" value="" />
                     <?php 
                             if(count($contactprofiles)){
                                foreach($contactprofiles as $profile){
                                    $users = new Registration();
                                    $users = $users->fetch("WHERE km_regcode = '{$profile['pv_viewedId']}'")->resultSet();
                                    $user = $users[0];                                    
//                                    print_r($user);
                                    $photos = new Profile();
                                    $photos = $photos->fetchPhotos("WHERE pho_userId = '{$user['km_regcode']}' AND pho_imgPath LIKE '%_profile_%' ORDER BY id DESC LIMIT 1")->resultSet();
                                    $photo = $photos[0];
                                    if($photo['pho_imgPath']){
                                        $tot_profileimgPath =  $photo['pho_imgPath'];

                                        $image_file = fopen($tot_profileimgPath, 'r');
                                        $tot_profileimgPath = fread($image_file, filesize($tot_profileimgPath));
                                    }else{
                                        $tot_profileimgPath = 'images/'.$user['km_gender'].'.png';

                                        $image_file = fopen($tot_profileimgPath, 'r');
                                        $tot_profileimgPath = fread($image_file, filesize($tot_profileimgPath));
                                    } 

                                    $from = new DateTime($user['km_dateofbirth']);
		                            $to   = new DateTime('today');
		                            $age = $from->diff($to)->y;
		                            $cur_Year = date("Y");
                        
                         
                            ?>
                     <div id="r-content" class="style50">
                        <div class="r-content-left">
                           <span class="profile">Profie ID : <?php echo $user['km_regcode']; ?> </span>
                           <div class="r-content-photo">
                              <!--<a href="viewalbum.php">--> 
                              <img width="140" height="140" border="0" src="data:image/jpeg;base64,<?php echo base64_encode($tot_profileimgPath); ?>">
                              <!--</a>-->
                           </div>
                           <div class="r-content-top-2">
                              <div class="r-content-top-btn">
                                 <input type="button" id="<?php echo $user['km_regcode']; ?>" class="button1 red view_profile" style="width: 160px;" value="View full profile" />
                              </div>
                              <div class="r-content-top-btn"> </div>
                           </div>
                        </div>
                        <div class="r-content-right-top">
                           <div class="r-content-top-1">
                              <table width="526" cellspacing="0" cellpadding="0" border="0">
                                 <tbody>
                                    <tr>
                                       <td height="22" class="maketop"  style=" color:#de0f7e;font-weight:bold; text-transform: uppercase; padding-top: 0px; padding-bottom: 0px; margin-top: 0px; margin-bottom: 0px;" colspan="3"><?php echo $user['km_name'];?>&nbsp;
                                       </td>
                                       <td style="padding-top: 0px; padding-bottom: 0px; margin-top: 0px; margin-bottom: 0px; float: right;">
                                          <div class=" box-match-data-actions">
                                             <a   data-toggle="modal" data-target="#sendoptionsModal"><span data-toggle="tooltip" title="" id="<?php echo $user['km_regcode']; ?>" class="sp icon-sms2 view_album" data-original-title="View Album"></span>
                                             </a>
                                             <a   data-toggle="modal" data-target="#sendHOROModal"><span id="<?php echo $user['km_regcode']; ?>" class="sp icon-mplanet2 horoscope" data-toggle="tooltip" title="" data-original-title="View Horoscope "></span></a>
                                             <a   data-toggle="modal" data-target="#contactnowModal">
                                             <span id="<?php echo $user['km_regcode']; ?>" data-original-title="View Mobile Number" data-toggle="tooltip" title="" class="sp icon-viewcontact number"></span>
                                             </a>
                                          </div>
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                              <table width="426" cellspacing="0" cellpadding="0" border="0">
                                 <tbody>
                                    <tr>
                                       <td width="124" height="20" style="color:#000">Age / Height</td>
                                       <td width="20">:</td>
                                       <td width="182" style="color:#333"> 
                                       <?php if($age && $user['km_height']){ ?>
                                       <?php echo $age; ?> / <?php echo $user['km_height']; ?>   
                                       <?php } else if($age){ ?>
                                       <?php if($age == $cur_Year){ echo 'N / A'; } else { echo $age; } ?>
                                       <?php } else if($user['km_height']){?>
                                       <?php echo $user['km_height']; ?> 
                                       <?php } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td height="20" style="color:#000" valign="top">
                                          Star
                                       </td>
                                       <td valign="top">
                                          :
                                       </td>
                                       <td style="color:#333">
                                            <?php if($user['km_star']){ echo $user['km_star']; } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td height="20" style="color:#000" valign="top">
                                          Location
                                       </td>
                                       <td valign="top">
                                          :
                                       </td>
                                       <td style="color:#333">
                                          <?php if($user['km_city']){ echo $user['km_city']; } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td height="19" style="color:#000">Qualification</td>
                                       <td height="19">:</td>
                                       <td height="19" style="color:#333">
                                          <?php  if($user['km_education']){ echo $edu_array[$user['km_education']]; } else { echo 'N / A'; } ?>
                                           </td>
                                    </tr>
                                    
                                    <tr>
                                       <td height="20" style="color:#000">Profession</td>
                                       <td>:</td>
                                       <td style="color:#333">
                                            <?php if($user['km_occupation']){ echo $user['km_occupation']; } else { echo 'N / A'; } ?>
                                           </td>
                                    </tr>
                                       <tr>
                                       <td height="20" style="color:#000" valign="top">
                                          SubCaste
                                       </td>
                                       <td valign="top">
                                          :
                                       </td>
                                       <td style="color:#333">
                                          <?php if($user['km_subcaste']){ echo $user['km_subcaste']; } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>

                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                     <?php }  
                        }else{
                            ?>
                     <div id="result-content">
                        <h4 style="margin: 1.5em 1em;text-align: center;color: #17800a;"> Contact Profile not available. </h4>
                     </div>
                     <?php
                        }                                
                        ?>
                  </form>
               </div>



               <br>
               <table>
                  <tr class="tabletitle" style=" background-color: #e23f0c;">
                     <td colspan="2" style="  border-top-left-radius: 0.5em; border-top-right-radius: 0.5em; color: #fff; font-weight: normal;">Horoscope Profiles History</td>
                  </tr>
               </table>
               <div id="pagin">
                  <form method="post" id='search_result' action="">
                     <input type="hidden" id="submit_id" name="submit_id" value="" />
                     <input type="hidden" id="submit_flag" name="submit_flag" value="" />
                     <input type="hidden" id="profile_type" name="profile_type" value="" />
                     <input type="hidden" id="page_return" name="page_return" value="" />
                     <input type="hidden" id="interest_value" name="interest_value" value="" />
                     <?php 
                             if(count($horoscopeprofiles)){
                                foreach($horoscopeprofiles as $profile){
                                    $users = new Registration();
                                    $users = $users->fetch("WHERE km_regcode = '{$profile['pv_viewedId']}'")->resultSet();
                                    $user = $users[0];                                    
//                                    print_r($user);
                                    $photos = new Profile();
                                    $photos = $photos->fetchPhotos("WHERE pho_userId = '{$user['km_regcode']}' AND pho_imgPath LIKE '%_profile_%' ORDER BY id DESC LIMIT 1")->resultSet();
                                    $photo = $photos[0];
                                    if($photo['pho_imgPath']){
                                        $tot_profileimgPath =  $photo['pho_imgPath'];

                                        $image_file = fopen($tot_profileimgPath, 'r');
                                        $tot_profileimgPath = fread($image_file, filesize($tot_profileimgPath));
                                    }else{
                                        $tot_profileimgPath = 'images/'.$user['km_gender'].'.png';

                                        $image_file = fopen($tot_profileimgPath, 'r');
                                        $tot_profileimgPath = fread($image_file, filesize($tot_profileimgPath));
                                    } 

                                    $from = new DateTime($user['km_dateofbirth']);
		                            $to   = new DateTime('today');
		                            $age = $from->diff($to)->y;
		                            $cur_Year = date("Y");
                        
                         
                            ?>
                     <div id="r-content" class="style50">
                        <div class="r-content-left">
                           <span class="profile">Profie ID : <?php echo $user['km_regcode']; ?> </span>
                           <div class="r-content-photo">
                              <!--<a href="viewalbum.php">--> 
                              <img width="140" height="140" border="0" src="data:image/jpeg;base64,<?php echo base64_encode($tot_profileimgPath); ?>">
                              <!--</a>-->
                           </div>
                           <div class="r-content-top-2">
                              <div class="r-content-top-btn">
                                 <input type="button" id="<?php echo $user['km_regcode']; ?>" class="button1 red view_profile" style="width: 160px;" value="View full profile" />
                              </div>
                              <div class="r-content-top-btn"> </div>
                           </div>
                        </div>
                        <div class="r-content-right-top">
                           <div class="r-content-top-1">
                              <table width="526" cellspacing="0" cellpadding="0" border="0">
                                 <tbody>
                                    <tr>
                                       <td height="22" class="maketop"  style=" color:#de0f7e;font-weight:bold; text-transform: uppercase; padding-top: 0px; padding-bottom: 0px; margin-top: 0px; margin-bottom: 0px;" colspan="3"><?php echo $user['km_name'];?>&nbsp;
                                       </td>
                                       <td style="padding-top: 0px; padding-bottom: 0px; margin-top: 0px; margin-bottom: 0px; float: right;">
                                          <div class=" box-match-data-actions">
                                             <a   data-toggle="modal" data-target="#sendoptionsModal"><span data-toggle="tooltip" title="" id="<?php echo $user['km_regcode']; ?>" class="sp icon-sms2 view_album" data-original-title="View Album"></span>
                                             </a>
                                             <a   data-toggle="modal" data-target="#sendHOROModal"><span id="<?php echo $user['km_regcode']; ?>" class="sp icon-mplanet2 horoscope" data-toggle="tooltip" title="" data-original-title="View Horoscope "></span></a>
                                             <a   data-toggle="modal" data-target="#contactnowModal">
                                             <span id="<?php echo $user['km_regcode']; ?>" data-original-title="View Mobile Number" data-toggle="tooltip" title="" class="sp icon-viewcontact number"></span>
                                             </a>
                                          </div>
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                              <table width="426" cellspacing="0" cellpadding="0" border="0">
                                 <tbody>
                                    <tr>
                                       <td width="124" height="20" style="color:#000">Age / Height</td>
                                       <td width="20">:</td>
                                       <td width="182" style="color:#333"> 
                                       <?php if($age && $user['km_height']){ ?>
                                       <?php echo $age; ?> / <?php echo $user['km_height']; ?>   
                                       <?php } else if($age){ ?>
                                       <?php if($age == $cur_Year){ echo 'N / A'; } else { echo $age; } ?>
                                       <?php } else if($user['km_height']){?>
                                       <?php echo $user['km_height']; ?> 
                                       <?php } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td height="20" style="color:#000" valign="top">
                                          Star
                                       </td>
                                       <td valign="top">
                                          :
                                       </td>
                                       <td style="color:#333">
                                            <?php if($user['km_star']){ echo $user['km_star']; } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td height="20" style="color:#000" valign="top">
                                          Location
                                       </td>
                                       <td valign="top">
                                          :
                                       </td>
                                       <td style="color:#333">
                                          <?php if($user['km_city']){ echo $user['km_city']; } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td height="19" style="color:#000">Qualification</td>
                                       <td height="19">:</td>
                                       <td height="19" style="color:#333">
                                          <?php  if($user['km_education']){ echo $edu_array[$user['km_education']]; } else { echo 'N / A'; } ?>
                                           </td>
                                    </tr>
                                    
                                    <tr>
                                       <td height="20" style="color:#000">Profession</td>
                                       <td>:</td>
                                       <td style="color:#333">
                                            <?php if($user['km_occupation']){ echo $user['km_occupation']; } else { echo 'N / A'; } ?>
                                           </td>
                                    </tr>
                                       <tr>
                                       <td height="20" style="color:#000" valign="top">
                                          SubCaste
                                       </td>
                                       <td valign="top">
                                          :
                                       </td>
                                       <td style="color:#333">
                                          <?php if($user['km_subcaste']){ echo $user['km_subcaste']; } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>

                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                     <?php }  
                        }else{
                            ?>
                     <div id="result-content">
                        <h4 style="margin: 1.5em 1em;text-align: center;color: #17800a;"> Horoscope Profile not available. </h4>
                     </div>
                     <?php
                        }                                
                        ?>
                  </form>
               </div>
            </section>
            
         </section>
         <div style=" clear: both;"></div>
          </div>
         <?php include("includes/footertop.php");?>
         <?php include("includes/footerin.php");?>
        <script>
            $(document).on('click', '.horoscope', function() {                  
                var service_id =  $(this).attr('id');
                $('#submit_id').val(service_id);
                $('#submit_flag').val('profile');  
                $('#profile_type').val('horoscope');               
                $('#search_result').attr('method', 'post');
                $('#search_result').attr('action', 'payment_profile_details.php');
                $('#search_result').submit();
            });
            $(document).on('click', '.number', function() {                  
                var service_id =  $(this).attr('id');
                $('#submit_id').val(service_id);
                $('#submit_flag').val('profile'); 
                $('#profile_type').val('contact');
                $('#search_result').attr('method', 'post');
                $('#search_result').attr('action', 'payment_profile_details.php');
                $('#search_result').submit();
            });
            $(document).on('click', '.view_profile', function() {                  
                var service_id =  $(this).attr('id');
                $('#submit_id').val(service_id);
                $('#submit_flag').val('view'); 
                $('#search_result').attr('method', 'post');
                $('#search_result').attr('action', 'payment_profile_details.php');
                $('#search_result').submit();
            });
            $(document).on('click', '.view_album', function() {                  
                var service_id =  $(this).attr('id');
                $('#submit_id').val(service_id);
                $('#submit_flag').val('album'); 
                $('#search_result').attr('method', 'post');
                $('#search_result').attr('action', 'payment_profile_details.php');
                $('#search_result').submit();
            });

        </script>
     
   </body>
</html>