<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
ob_start();
session_start();
require_once 'KANyaMatrI_GST/includes/configure.php';
require_once 'init.php';
require_once 'includes/common_functions.php';
require_once 'includes/pagination.php';
require_once 'includes/db.php';
require_once 'includes/session_handler.php';


$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
$limit = 10;
$startpoint = ($page * $limit) - $limit;


$user_id = $_SESSION['User_Kamma_Matri']['id'];
$km_regcode = $_SESSION['User_Kamma_Matri']['km_regcode'];
$users = new Registration();
$users = $users->fetch("WHERE id = '{$user_id}'")->resultSet();
$user = $users[0];
if($user['km_gender'] == 'male'){
    $km_gender = 'female';
}else{
    $km_gender = 'male';
}

if(isset($_POST['submit_id'])){
    profile_details($_POST['submit_id'],$km_regcode);  
}

//*************************** Search Results **************************************

$statement = "";
$profiles = new Profile();
$profiles = $profiles->fetch("WHERE pv_userId = '{$km_regcode}' GROUP BY pv_viewedId LIMIT {$startpoint} , {$limit}")->resultSet();    
$statement = "profile_view_details WHERE pv_userId = '{$km_regcode}' GROUP BY pv_viewedId";
//echo '$statement = '.$statement;
//*************************** Search Results **************************************
$today = date('Y-m-d');
$payments = new Payment();
$payments = $payments->fetch("WHERE pl_userId = '{$km_regcode}' AND '{$today}' BETWEEN pl_startDate AND pl_expireDate ORDER BY id DESC")->resultSet(); 
$payment = $payments[0];

$count_profiles = new Profile();
$count_profiles = $count_profiles->fetch("WHERE pv_userId = '{$km_regcode}' AND pv_paymentId = '{$payment['id']}' GROUP BY pv_viewedId")->resultSet(); 

?>
<!DOCTYPE html>
<html>
<head>
<?php include("includes/headertop.php");?>
</head>
    <body class="home color-green boxed shadow">
        <div class="root">
            <?php include("includes/headerin.php");?>
                <section class="slider11 p05" style="  float: left; width: 65%">

                    <img src="images/kammavar.jpg">

                    <?php //include("includes/banner.php");?>
                </section>
                <?php //include("includes/quicksearch.php");?>
                    <section class="content reverse">
                        <section class="main" style=" margin-top: 1%;">

                            <link rel="stylesheet" href="css/jquery-ui.css">
                            <link href="css/pagination.css" rel="stylesheet" type="text/css" />
                            <link href="css/grey.css" rel="stylesheet" type="text/css" />

                            <script src="js/jquery-1.12.4.js"></script>
                            <script src="js/jquery-ui.js"></script>
                            <script>
                                $(function() {
                                    $("#tabs").tabs();
                                });
                            </script>

                            

                            <div style=" clear: both;"></div>

                            
                            <div  style="background-color: #17800a;color: #fff;font-size: 18px;border-radius: 10px;text-align: center;width: 100%;">
                                    <table  >
                                        <tr >
                                            <th colspan="6" style="text-align: center;height: 30px;font-size: 18px;font-weight:normal;">Current Plan - (<?php echo $payment['pl_startDate'].' to '.$payment['pl_expireDate']; ?>)</th>
                                        </tr>
                                        <tr>
                                            <td style="text-align: left;padding-left: 5%;height: 30px;">AVAILABLE</td>
                                            <td style="text-align: left;height: 30px;font-size: 18px;font-weight:bold;color:#fdf50a;"><label style="color:#fdf50a;cursor: pointer;text-decoration: underline;" class="open"><?php echo 30 ?></label></td>
                                            <td style="text-align: left;padding-left: 10%;height: 30px;">VIEWED</td>
                                            <td style="text-align: left;height: 30px;font-size: 18px;font-weight:bold;color:#fdf50a;"><label style="color:#fdf50a;cursor: pointer;text-decoration: underline;" class="closed"><?php echo count($count_profiles); ?></label></td>
                                            <td style="text-align: left;padding-left: 10%;height: 30px;">REMAINING</td>
                                            <td style="text-align: left;height: 30px;font-size: 18px;font-weight:bold;color:#fdf50a;"><label style="color:#fdf50a;cursor: pointer;text-decoration: underline;" class="closed"><?php echo 30 - count($count_profiles); ?></label></td>
                                        </tr>                                                                                                                        
                                    </table>
                                </div>
                            <div class="space"></div>
                            

                            <table>
                                <tr class="tabletitle" style=" background-color: #fdbd0a;">
                                    <td colspan="2" style="  border-top-left-radius: 0.5em; border-top-right-radius: 0.5em;">Profiles</td>
                                </tr>
                            </table>
                            <div id="pagin">
                                <form method="post" id='search_result' action="">
                                    <input type="hidden" id="submit_id" name="submit_id" value="" />
                                    <input type="hidden" id="submit_flag" name="submit_flag" value="" />
                                    
                             
                                <?php 
                                if(count($profiles)){
                                foreach($profiles as $profile){
                                    $users = new Registration();
                                    $users = $users->fetch("WHERE km_regcode = '{$profile['pv_viewedId']}'")->resultSet();
                                    $user = $users[0];                                    
//                                    print_r($user);
                                    $photos = new Profile();
                                    $photos = $photos->fetchPhotos("WHERE pho_userId = '{$user['km_regcode']}' AND pho_imgPath LIKE '%_profile_%' ORDER BY id DESC LIMIT 1")->resultSet();
                                    $photo = $photos[0];
                                    if($photo['pho_imgPath']){
                                        $imgPath =  $photo['pho_imgPath'];
                                    }else{
                                        $imgPath = 'images/'.$user['km_gender'].'.png';                                
                                    } 
                                    ?>
                                <div id="r-content" class="style50">
                                    <div class="r-content-left">
                                    <span class="profile">Profie ID : <?php echo $user['km_regcode']; ?> </span>
                                        <div class="r-content-photo">
                                            
                                            <!--<a href="viewalbum.php">--> 
                                                <img width="150" height="170" border="0" src="<?php echo $imgPath; ?>">
                                            <!--</a>-->
                                        </div>
                                        <div class="r-content-top-2">
                                            <div class="r-content-top-btn">
                                                <input type="button" id="<?php echo $user['km_regcode']; ?>" class="button1 red view_profile" style="width: 160px;" value="View full profile" />
                                            </div>
                                            <div class="r-content-top-btn" style="margin-top:10px;">                                                
                                                <input type="button" id="<?php echo $user['km_regcode']; ?>" class="button1 red view_album" style="width: 160px;" value="View Photo Album" />
                                            </div>
                                            <div class="r-content-top-btn"> </div>
                                        </div>
                                    </div>
                                    <div class="r-content-right-top">
                                        <div class="r-content-top-1">
                                            <table width="426" cellspacing="0" cellpadding="0" border="0">
                                                <tbody>
                                                    <tr>
                                                        <td height="22" style=" color:#0f50e2;font-weight:bold; text-transform: uppercase;" colspan="3"><?php echo strtoupper($user['km_name']); ?>&nbsp;
                                                        </td>
                                                    </tr>
                                                    <?php 
                                                    $from = new DateTime($user['km_dateofbirth']);
                                                    $to   = new DateTime('today');
                                                    $age = $from->diff($to)->y;                                                    
                                                    ?>
                                                    
                                                    <tr>
                                                        <td width="124" height="20" style="color:#999">Age / Height</td>
                                                        <td width="20">:</td>
                                                        <td width="182" style="color:#333"> <?php echo $age; ?> / <?php echo $user['km_height']; ?>
                                                    </tr>       

                                                    <tr>
                                                        <td height="20" style="color:#999" valign="top">
                                                            Star
                                                        </td>
                                                        <td valign="top">
                                                            :
                                                        </td>
                                                        <td style="color:#333">
                                                            <?php echo $user['km_star']; ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td height="20" style="color:#999" valign="top">
                                                            Location
                                                        </td>
                                                        <td valign="top">
                                                            :
                                                        </td>
                                                        <td style="color:#333">
                                                            <?php echo $user['km_city']; ?>
                                                        </td>
                                                    </tr><tr>
                                                        <td height="19" style="color:#999">Qualification</td>
                                                        <td height="19">:</td>
                                                        <td height="19" style="color:#333"><?php echo $edu_array[$user['km_education']]; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td height="20" style="color:#999">Profession</td>
                                                        <td>:</td>
                                                        <td style="color:#333"><?php echo $user['km_occupation']; ?></td>
                                                    </tr>
                                                      <tr>
                                       <td height="20" style="color:#000" valign="top">
                                          SubCaste
                                       </td>
                                       <td valign="top">
                                          :
                                       </td>
                                       <td style="color:#333">
                                          <?php if($user['km_subcaste']){ echo $user['km_subcaste']; } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>
                                                </tbody>
                                            </table>

                                            <div class="down">
                                                <br />
                                                   
                                                    <button type="button" id="<?php echo $user['km_regcode']; ?>" class="contact" style="width:110px;height: 32px;padding-left: 0px;padding-right: 0px;background: none;box-shadow: 0 0px 0px rgba(0, 0, 0, 0);">
                                                        <img src="images/contact.png" width="110" height="auto" style="background: transparent;background-color: white;box-shadow: none;">
                                                    </button>
                                                    <button type="button" id="<?php echo $user['km_regcode']; ?>" class="horoscope" style="margin-left: 20%;width:110px;height: 23px;padding-left: 0px;padding-right: 0px;background: none;box-shadow: 0 0px 0px rgba(0, 0, 0, 0);">
                                                        <img src="images/horoicon.png" width="110" height="auto" style="background: transparent;background-color: white;box-shadow: none;">
                                                    </button>
                                                

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php }  
                                }else{
                                    ?>
                                    <div id="result-content">
                                <h4 style="margin: 1.5em 1em;text-align: center;color: #17800a;"> Profile not available. </h4>
                            </div>
                                    <?php
                                }                                
                                ?>
                               
                                </form>
                            </div>
                            <?php
                            $url = 'profile_history.php';
                            echo pagination($statement,$limit,$page,$url);
                            ?>
                        </section>



                        <?php include("includes/right.php");?>

                    </section>
                    <div style=" clear: both;"></div>

                    <?php include("includes/footertop.php");?>
                    <?php include("includes/footer.php");?>
        </div>
        
        <script>
            $(document).on('click', '.horoscope', function() {                  
                var service_id =  $(this).attr('id');
                $('#submit_id').val(service_id);
                $('#submit_flag').val('profile');                
                $('#search_result').attr('method', 'post');
                $('#search_result').attr('action', 'search_results.php');
                $('#search_result').submit();
            });
            $(document).on('click', '.contact', function() {                  
                var service_id =  $(this).attr('id');
                $('#submit_id').val(service_id);
                $('#submit_flag').val('profile'); 
                $('#search_result').attr('method', 'post');
                $('#search_result').attr('action', 'search_results.php');
                $('#search_result').submit();
            });
            $(document).on('click', '.view_profile', function() {                  
                var service_id =  $(this).attr('id');
                $('#submit_id').val(service_id);
                $('#submit_flag').val('profile'); 
                $('#search_result').attr('method', 'post');
                $('#search_result').attr('action', 'search_results.php');
                $('#search_result').submit();
            });
            $(document).on('click', '.view_album', function() {                  
                var service_id =  $(this).attr('id');
                $('#submit_id').val(service_id);
                $('#submit_flag').val('album'); 
                $('#search_result').attr('method', 'post');
                $('#search_result').attr('action', 'search_results.php');
                $('#search_result').submit();
            });

        </script>
    </body>

</html>