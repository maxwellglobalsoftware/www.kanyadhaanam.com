<?php error_reporting(E_ALL^E_NOTICE); ?>
<?php
  ob_start();
  session_start();
  require_once 'init.php';

        if($_POST['flag'] == 'MobileNo'){
            
        $phone_no = $_POST['phone'];

        $registration = new Registration();
        $registration = $registration->fetch("WHERE km_mobile = '{$phone_no}'")->resultSet();
        $regis = $registration[0];

        if($regis){
          $result = "exists";
        } else {
          $result = "success";  
        }

        echo $result.'-'.$phone_no;
        
        }
        
        if($_POST['flag'] == 'HomeMobileNo'){
            
        $phoneNo = $_POST['phoneNo'];

        $registration = new Registration();
        $registration = $registration->fetch("WHERE km_mobile = '{$phoneNo}'")->resultSet();
        $registration = $registration[0];

        if($registration){
          $result = "exis";
        } else {
          $result = "success";  
        }

        echo $result.'-'.$phoneNo;
        
        }

        if($_POST['flag'] == 'Sec_MobileNo'){
            
        $sec_phone_no = $_POST['sec_phone'];

        $registration = new Registration();
        $registration = $registration->fetch("WHERE km_second_mobile = '{$sec_phone_no}'")->resultSet();
        $registration = $registration[0];

        if($registration){
          $result = "exists";
        } else {
          $result = "success";  
        }

        echo $result.'-'.$sec_phone_no;
        
        }

        if($_POST['flag'] == 'EMail'){
            
        $gmail = $_POST['gmail'];

        $registration = new Registration();
        $registration = $registration->fetch("WHERE km_email = '{$gmail}'")->resultSet();
        $registration = $registration[0];

        if($registration){
          $result = "exists";
        } else {
          $result = "success";  
        }

        echo $result.'-'.$gmail;
        
        }


?>