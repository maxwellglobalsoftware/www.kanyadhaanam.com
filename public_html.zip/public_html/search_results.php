<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   require_once 'KANyaMatrI_GST/includes/configure.php';
   require_once 'init.php';
   require_once 'includes/common_functions.php';
   require_once 'includes/pagination.php';
   require_once 'includes/db.php';
   require_once 'includes/session_handler.php';
   date_default_timezone_set('Asia/Kolkata');
   
   
   $page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
   $limit = 10;
   $startpoint = ($page * $limit) - $limit;
   
   
   $user_id = $_SESSION['User_Kamma_Matri']['id'];
   $km_regcode = $_SESSION['User_Kamma_Matri']['km_regcode'];
   $users = new Registration();
   $users = $users->fetch("WHERE id = '{$user_id}'")->resultSet();
   $user = $users[0];
   if($user['km_gender'] == 'male'){
       $km_gender = 'female';
   }else{
       $km_gender = 'male';
   }
   
   if(isset($_POST['submit_id'])){
       profile_details($_POST['submit_id'],$km_regcode);
   }
   //*************************** Search Results **************************************

   $today = date('Y-m-d');
   
   
   $paymentIDs = new Payment();
   $paymentIDs = $paymentIDs->fetch("WHERE pl_userId = '{$km_regcode}'  ORDER BY id DESC LIMIT 1")->resultSet(); 
   $paymentID = $paymentIDs[0];
   
   
   $payments = new Payment();
   $payments = $payments->fetch("WHERE pl_userId = '{$km_regcode}'  AND id = '{$paymentID['id']}' AND pl_status = 'activate' AND '{$today}' BETWEEN pl_startDate AND pl_expireDate ORDER BY id DESC")->resultSet(); 
   $payment = $payments[0];
   
   
   
   if(isset($_SESSION['star'])){
   //    echo 'INN I';
       $sql = "WHERE YEAR(km_dateofbirth) BETWEEN '{$_SESSION['agefrom']}' AND '{$_SESSION['ageto']}' AND km_status = 'live' AND km_star = '{$_SESSION['star']}' AND id <> '{$user_id}' AND km_gender = '{$km_gender}' LIMIT {$startpoint} , {$limit}";
       $statement = "";
       $users = new Registration();
       $users = $users->fetch("WHERE YEAR(km_dateofbirth) BETWEEN '{$_SESSION['agefrom']}' AND '{$_SESSION['ageto']}' AND km_status = 'live' AND km_star = '{$_SESSION['star']}' AND id <> '{$user_id}' AND km_gender = '{$km_gender}' LIMIT {$startpoint} , {$limit}")->resultSet();    
       $statement = "registration WHERE YEAR(km_dateofbirth) BETWEEN '{$_SESSION['agefrom']}' AND '{$_SESSION['ageto']}' AND km_status = 'live' AND km_star = '{$_SESSION['star']}' AND id <> '{$user_id}' AND km_gender = '{$km_gender}'";
       $search_star = "";
       
   }else if(isset($_SESSION['education'])){
   //    echo 'INN II';
       $sql = "WHERE YEAR(km_dateofbirth) BETWEEN '{$_SESSION['agefrom']}' AND '{$_SESSION['ageto']}' AND km_status = 'live' AND km_education = '{$_SESSION['education']}' AND id <> '{$user_id}' AND km_gender = '{$km_gender}' LIMIT {$startpoint} , {$limit}";
       $statement = "";
       $users = new Registration();
       $users = $users->fetch("WHERE YEAR(km_dateofbirth) BETWEEN '{$_SESSION['agefrom']}' AND '{$_SESSION['ageto']}' AND km_status = 'live' AND km_education = '{$_SESSION['education']}' AND id <> '{$user_id}' AND km_gender = '{$km_gender}' LIMIT {$startpoint} , {$limit}")->resultSet();    
       $statement = "registration WHERE YEAR(km_dateofbirth) BETWEEN '{$_SESSION['agefrom']}' AND '{$_SESSION['ageto']}' AND km_status = 'live' AND km_education = '{$_SESSION['education']}' AND id <> '{$user_id}' AND km_gender = '{$km_gender}'";
       $search_education = "";
   } else if(isset($_SESSION['marital_search'])){
   //    echo 'INN II';
       $sql = "WHERE YEAR(km_dateofbirth) BETWEEN '{$_SESSION['agefrom']}' AND '{$_SESSION['ageto']}' AND km_status = 'live' AND km_marital_status = '{$_SESSION['marital_search']}' AND id <> '{$user_id}' AND km_gender = '{$km_gender}' LIMIT {$startpoint} , {$limit}";
       $statement = "";
       $users = new Registration();
       $users = $users->fetch("WHERE YEAR(km_dateofbirth) BETWEEN '{$_SESSION['agefrom']}' AND '{$_SESSION['ageto']}' AND km_status = 'live' AND km_marital_status = '{$_SESSION['marital_search']}' AND id <> '{$user_id}' AND km_gender = '{$km_gender}' LIMIT {$startpoint} , {$limit}")->resultSet();    
       $statement = "registration WHERE YEAR(km_dateofbirth) BETWEEN '{$_SESSION['agefrom']}' AND '{$_SESSION['ageto']}' AND km_status = 'live' AND km_marital_status = '{$_SESSION['marital_search']}' AND id <> '{$user_id}' AND km_gender = '{$km_gender}'";
       $search_education = "";
   } else if(isset($_SESSION['district_search'])){
  // echo 'INN IIII';
  //      exit();
       $sql = "WHERE YEAR(km_dateofbirth) BETWEEN '{$_SESSION['agefrom']}' AND '{$_SESSION['ageto']}' AND km_status = 'live' AND km_district = '{$_SESSION['district_search']}' AND id <> '{$user_id}' AND km_gender = '{$km_gender}' LIMIT {$startpoint} , {$limit}";
       $statement = "";
       $users = new Registration();
       $users = $users->fetch("WHERE YEAR(km_dateofbirth) BETWEEN '{$_SESSION['agefrom']}' AND '{$_SESSION['ageto']}' AND km_status = 'live' AND km_district = '{$_SESSION['district_search']}' AND id <> '{$user_id}' AND km_gender = '{$km_gender}' LIMIT {$startpoint} , {$limit}")->resultSet();    
       $statement = "registration WHERE YEAR(km_dateofbirth) BETWEEN '{$_SESSION['agefrom']}' AND '{$_SESSION['ageto']}' AND km_status = 'live' AND km_district = '{$_SESSION['district_search']}' AND id <> '{$user_id}' AND km_gender = '{$km_gender}'";
   } else if(isset($_SESSION['occupation_search'])){
       //  echo 'INN IIIII';
       // exit();
       $sql = "WHERE YEAR(km_dateofbirth) BETWEEN '{$_SESSION['agefrom']}' AND '{$_SESSION['ageto']}' AND km_status = 'live' AND km_occupation = '{$_SESSION['occupation_search']}' AND id <> '{$user_id}' AND km_gender = '{$km_gender}' LIMIT {$startpoint} , {$limit}";
       $statement = "";
       $users = new Registration();
       $users = $users->fetch("WHERE YEAR(km_dateofbirth) BETWEEN '{$_SESSION['agefrom']}' AND '{$_SESSION['ageto']}' AND km_status = 'live' AND km_occupation = '{$_SESSION['occupation_search']}' AND id <> '{$user_id}' AND km_gender = '{$km_gender}' LIMIT {$startpoint} , {$limit}")->resultSet();    
       $statement = "registration WHERE YEAR(km_dateofbirth) BETWEEN '{$_SESSION['agefrom']}' AND '{$_SESSION['ageto']}' AND km_status = 'live' AND km_occupation = '{$_SESSION['occupation_search']}' AND id <> '{$user_id}' AND km_gender = '{$km_gender}'";
   } else if(isset($_SESSION['id_search'])){
   //    echo 'INN II';
       $sql = "WHERE km_status = 'live' AND id <> '{$user_id}' AND km_regcode = '{$_SESSION['id_search']}' AND km_gender = '{$km_gender}' LIMIT {$startpoint} , {$limit}";
       $statement = "";
       $users = new Registration();
       $users = $users->fetch("WHERE km_status = 'live' AND id <> '{$user_id}' AND km_regcode = '{$_SESSION['id_search']}' AND km_gender = '{$km_gender}' LIMIT {$startpoint} , {$limit}")->resultSet();    
       $statement = "registration WHERE km_status = 'live' AND id <> '{$user_id}' AND km_regcode = '{$_SESSION['id_search']}' AND km_gender = '{$km_gender}'";   
       unset($_SESSION['id_search']);
   }else{    
   //    echo 'INN III';
       $sql = "WHERE YEAR(km_dateofbirth) BETWEEN '{$_SESSION['agefrom']}' AND '{$_SESSION['ageto']}' AND km_status = 'live' AND id <> '{$user_id}' AND km_gender = '{$km_gender}' LIMIT {$startpoint} , {$limit}";
       $statement = "";
       $users = new Registration();
       $users = $users->fetch("WHERE YEAR(km_dateofbirth) BETWEEN '{$_SESSION['agefrom']}' AND '{$_SESSION['ageto']}' AND km_status = 'live' AND id <> '{$user_id}' AND km_gender = '{$km_gender}' LIMIT {$startpoint} , {$limit}")->resultSet();    
       $statement = "registration WHERE YEAR(km_dateofbirth) BETWEEN '{$_SESSION['agefrom']}' AND '{$_SESSION['ageto']}' AND km_status = 'live' AND id <> '{$user_id}' AND km_gender = '{$km_gender}'";
   }
   //echo 'count($users) = '.count($users);
   //echo '<BR>';
   //echo '$statement = '.$statement;
   //echo '<BR>';
   //echo '$sql = '.$sql;
   //*************************** Search Results **************************************
   
   ?>
<!DOCTYPE html>
<html>
   <head>
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <?php include("includes/headertop.php");?>
   </head>
   <body class="home color-green boxed shadow">
     
      <?php include("includes/headerin.php");?>
      <?php include("includes/bannerin.php");?>
      <?php //include("includes/quicksearch.php");?>
      <div class="root">
      <section class="content reverse">
      <?php include("includes/right.php");?>
         <section class="col-md-9 col-xs-12">
            <link rel="stylesheet" href="css/jquery-ui.css">
            <link href="css/pagination.css" rel="stylesheet" type="text/css" />
            <link href="css/grey.css" rel="stylesheet" type="text/css" />
            <script src="js/jquery-1.12.4.js"></script>
            <script src="js/jquery-ui.js"></script>
            <script>
               $(function() {
                   $("#tabs").tabs();
               });
            </script>
            <div style=" clear: both;"></div>
            <div class="space"></div>
            <table>
               <tr class="tabletitle" style=" background-color: #f0452d">
                  <td colspan="2" style="  border-top-left-radius: 0.5em; border-top-right-radius: 0.5em;">Profiles</td>
               </tr>
            </table>
            <div id="pagin">
               <form method="post" id='search_result' action="">
                  <input type="hidden" id="submit_id" name="submit_id" value="" />
                  <input type="hidden" id="submit_flag" name="submit_flag" value="" />
                  <input type="hidden" id="profile_type" name="profile_type" value="" />
                  <input type="hidden" id="page_return" name="page_return" value="" />
                  <input type="hidden" id="interest_value" name="interest_value" value="" />
                  <?php 
                     if(count($users)){
                     foreach($users as $user){
                         $photos = new Profile();
                         $photos = $photos->fetchPhotos("WHERE pho_userId = '{$user['km_regcode']}' AND pho_imgPath LIKE '%_profile_%' ORDER BY id DESC LIMIT 1")->resultSet();
                         $photo = $photos[0];
                         if($photo['pho_imgPath']){
                             $imgPath =  $photo['pho_imgPath'];
                         }else{
                             $imgPath = 'images/'.$user['km_gender'].'.png';                                
                         }

                         $view_only_horos = new Profile();
                         $view_only_horos = $view_only_horos->fetchHoroscope("WHERE hs_userId = '{$user['km_regcode']}'")->resultSet();
                         $view_only_horos = $view_only_horos[0];
                         
                         //// Occupation /////
                            $occupations = new Registration();
                            $occupations = $occupations->fetchOccupation("WHERE id = '{$user['km_occupation']}' ORDER BY occupation ASC")->resultSet();
                            $occupation = $occupations[0];
                            
                            //// Districts /////
                            $districts = new Registration();
                            $districts = $districts->fetchDistricts("WHERE id = '{$user['km_district']}' ORDER BY name ASC")->resultSet();
                            $district = $districts[0];
                         
                           $primary_otp_success = new OTP();
                           $primary_otp_success = $primary_otp_success->fetch("WHERE pl_userId = '{$user['km_regcode']}' AND  pl_primary_status = 'yes' ORDER BY id DESC")->resultSet(); 
                           $primary_otp_success = $primary_otp_success[0];
                
                           $secondary_otp_success = new OTP();
                           $secondary_otp_success = $secondary_otp_success->fetch("WHERE pl_userId = '{$user['km_regcode']}' AND  pl_secondary_status = 'yes' ORDER BY id DESC")->resultSet(); 
                           $secondary_otp_success = $secondary_otp_success[0];
                
                           $primary_email_success = new OTP();
                           $primary_email_success = $primary_email_success->fetchEmail("WHERE pl_userId = '{$user['km_regcode']}' AND  pl_primary_status = 'yes' ORDER BY id DESC")->resultSet(); 
                           $primary_email_success = $primary_email_success[0];


                         ?>
                  <div id="r-content" class="style50">
                     <div class="r-content-left">
                        <span class="profile">Profie ID : <?php echo $user['km_regcode']; ?> </span>
                        <div class="r-content-photo">
                           <!--<a href="viewalbum.php">--> 
                           <img width="150" height="170" border="0" src="<?php echo $imgPath; ?>">
                           <!--</a>-->
                        </div>
                        <div class="r-content-top-2">
                           <div class="r-content-top-btn">
                              <input type="button" id="<?php echo $user['km_regcode']; ?>" class="button1 red view_profile" style="width: 160px;" value="View full profile" />
                           </div>
                           <!--<div class="r-content-top-btn" style="margin-top:10px;">                                                -->
                           <!--    <input type="button" id="<?php echo $user['km_regcode']; ?>" class="button1 red view_album" style="width: 160px;" value="View Photo Album" />-->
                           <!--</div>-->
                           <div class="r-content-top-btn"> </div>
                        </div>
                     </div>
                     <div class="r-content-right-top">
                        <div class="r-content-top-1" style="width:100%">
                           <table width="426" cellspacing="0" cellpadding="0" border="0">
                              <tbody>
                                 <tr>
                                    <td height="22" style=" color:#0f50e2;font-weight:bold; text-transform: uppercase;" colspan="3">
                                       <?php echo strtoupper($user['km_name']); ?>&nbsp; 
                                       <?php if($primary_otp_success){ ?>
                                       <img src="images/verified.png" title="Verified Profile>
                                       <?php } ?>
                                       
                                       <div class=" box-match-data-actions">
                                          <a  data-toggle="modal" data-target="#sendoptionsModal"><span data-toggle="tooltip" title="" id="<?php echo $user['km_regcode']; ?>" class="sp icon-sms2 view_album tooltip" data-original-title="View Album"><span class="tooltiptext">View Album</span></span>
                                          </a>
                                          <?php if($view_only_horos){ ?>
                                          <a   data-toggle="modal" data-target="#sendHOROModal"><span id="<?php echo $user['km_regcode']; ?>" class="sp icon-mplanet2 horoscope tooltip" data-toggle="tooltip" title="" data-original-title="View Horoscope "><span class="tooltiptext">View Horoscope</span></span></a>
                                          <?php } else { ?>
                                          <a   data-toggle="modal" data-target="#sendHOROModal"><span id="<?php echo $user['km_regcode']; ?>" class="sp icon-mplanet2 no_horoscope tooltip" data-toggle="tooltip" title="" data-original-title="View Horoscope "><span class="tooltiptext">View Horoscope</span></span></a>
                                          <?php } ?>
                                          <a   data-toggle="modal" data-target="#contactnowModal"><span id="<?php echo $user['km_regcode']; ?>" class="sp icon-viewcontact tooltip number" data-toggle="tooltip" title="" data-original-title="View Contact "><span class="tooltiptext">View Contact</span></span></a>
                                       </div>
                                    </td>
                                 </tr>
                                 <?php 
                                    $from = new DateTime($user['km_dateofbirth']);
                                    $to   = new DateTime('today');
                                    $age = $from->diff($to)->y;                                                    
                                    ?>
                                 <tr>
                                    <td width="124" height="20" style="color:#000">Age / Height</td>
                                    <td width="20">:</td>
									<td width="182" style="color:#333"> 
	                                  <?php if($age && $user['km_height']){ ?>
	                                  <?php echo $age; ?> / <?php echo $user['km_height']; ?>   
	                                  <?php } else if($age){ ?>
	                                  <?php if($age == $cur_Year){ echo 'N / A'; } else { echo $age; } ?>
	                                  <?php } else if($user['km_height']){?>
	                                  <?php echo $user['km_height']; ?> 
	                                  <?php } else { echo 'N / A'; } ?>
	                               </td>
                                 </tr>
                                 <tr>
                                    <td height="20" style="color:#000" valign="top">
                                       Star
                                    </td>
                                    <td valign="top">
                                       :
                                    </td>
                                    <td style="color:#333">
                                          <?php if($user['km_star']){ echo $user['km_star']; } else { echo 'N / A'; } ?>
                                       </td>
                                 </tr>
                                 <tr>
                                    <td height="20" style="color:#000" valign="top">
                                       District
                                    </td>
                                    <td valign="top">
                                       :
                                    </td>
                                    <td style="color:#333">
                                           <?php 
                                          if($user['km_district']){ 
                                          if($district){ 
                                          	echo $district['name']; } 
                                          	else { echo $user['km_district']; }
                                          	} else { echo 'N / A'; } 
                                          ?>
                                       </td>
                                 </tr>
                                 <tr>
                                    <td height="19" style="color:#000">Qualification</td>
                                    <td height="19">:</td>
                                    <td height="19" style="color:#333">
                                          <?php  if($user['km_education']){ echo $edu_array[$user['km_education']]; } else { echo 'N / A'; } ?>
                                       </td>
                                 </tr>
                                 <tr>
                                    <td height="20" style="color:#000">Profession</td>
                                    <td>:</td>
                                    <td style="color:#333">
                                         <?php
                                         if($user['km_employee_in'] == 'notworking'){
                                             echo 'Not Working';
                                         } else {
                                          if($user['km_occupation']){ 
                                          if($occupation){ 
                                          	echo $occupation['occupation']; } 
                                          	else { echo $user['km_occupation']; }
                                          	} else { echo 'N / A'; } 
                                         }
                                          ?>
                                       </td>
                                 </tr>
                                      <tr>
                                       <td height="20" style="color:#000" valign="top">
                                          SubCaste
                                       </td>
                                       <td valign="top">
                                          :
                                       </td>
                                       <td style="color:#333">
                                          <?php if($user['km_subcaste']){ echo $user['km_subcaste']; } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>
                                 <tr>
                                       <td height="20" style="color:#000" valign="top">
                                          Marital Status
                                       </td>
                                       <td valign="top">
                                          :
                                       </td>
                                       <td style="color:#333">
                                          <?php if($user['km_marital_status']){ echo ucwords($user['km_marital_status']); } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>
                              </tbody>
                           </table>
                          
                           <div class="col-md-3 nopad first">
                              <?php
                                 $get_interests = new Partner();
                                 $get_interests = $get_interests->fetchInterest("WHERE pl_userId ='{$km_regcode}' AND pv_viewedId = '{$user['km_regcode']}'")->resultSet();
                                 $get_interest = $get_interests[0];
                                 
                                 if($get_interest){
                                  ?>

                              <?php if($payment){ ?>
                              <a class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-green padding-lr-zero"  title="Send Interest">
                              <i class="fa fa-paper-plane"></i>&nbsp;<span id="<?php echo $get_interest['id']; ?>" class="remove_interest">Interest Sent</span>
                              </a>
                              <?php } else { ?>
                              <a class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-green padding-lr-zero"  title="Send Interest">
                              <i class="fa fa-paper-plane"></i>&nbsp;<span id="<?php echo $get_interest['id']; ?>" class="interest_pay">Interest Sent</span>
                              </a>
                              <?php } ?>


                              <?php } else { ?>

                              <?php if($payment){ ?>
                              <a  style="border-color: #de0f7e!important;background: #de0f7e!important;color: white;width:125px;" class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-green padding-lr-zero" data-toggle="modal" data-target="#myModal_<?php echo $user['km_regcode']; ?>" title="Send Interest">
                              <i class="fa fa-paper-plane"></i>&nbsp;<span> Send Interest</span>
                              </a>
                              <?php } else { ?>
                              <a  style="border-color: #de0f7e!important;background: #de0f7e!important;color: white;width:125px;" class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-green padding-lr-zero" title="Send Interest">
                              <i class="fa fa-paper-plane"></i>&nbsp;<span class="interest_pay"> Send Interest</span>
                              </a>
                              <?php }  ?>


                              <?php } ?>
                              <!-- Modal -->
                              <div class="modal fade" id="myModal_<?php echo $user['km_regcode']; ?>" role="dialog">
                                 <div class="modal-dialog">
                                    <div class="modal-header">
                                       <button type="button" class="close" data-dismiss="modal">&times;</button>
                                       <h4 class="modal-title">Express Interest</h4>
                                    </div>
                                    <!-- Modal content-->
                                    <div class="modal-content">
                                       <div class="modal-body">
                                          <div class="modal-body xxl-16 xl-16 m-16 l-16 s-16 xs-16">
                                             <div class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 margin-top-10px-320px margin-top-10px-480px ne-mrg-top-10-768 margin-top-10px-999">
                                                <ul class="list-unstyled">
                                                   <li>
                                                      <input  name="exp_interest_<?php echo $user['km_regcode']; ?>" id="exp_interest_<?php echo $user['km_regcode']; ?>"  type="radio" value="I am interested in your profile. Please Accept if you are interested."> I am interested in your profile. Please Accept if you are interested.
                                                   </li>
                                                   <li><input name="exp_interest_<?php echo $user['km_regcode']; ?>" id="exp_interest2_<?php echo $user['km_regcode']; ?>"  type="radio" value="You are the kind of person we have been looking for. Please respond to proceed further."> You are the kind of person we have been looking for. Please respond to proceed further.</li>
                                                   <li><input name="exp_interest_<?php echo $user['km_regcode']; ?>" id="exp_interest3_<?php echo $user['km_regcode']; ?>" class="radio-inline" type="radio" value=" We liked your profile and interested to take it forward. Please reply at the earliest."> We liked your profile and interested to take it forward. Please reply at the earliest.</li>
                                                   <li><input name="exp_interest_<?php echo $user['km_regcode']; ?>" id="exp_interest4_<?php echo $user['km_regcode']; ?>" class="radio-inline" type="radio" value="You seem to be the kind of person who suits our family. We would like to contact your parents to proceed further."> You seem to be the kind of person who suits our family. We would like to contact your parents to proceed further.</li>
                                                   <li><input name="exp_interest_<?php echo $user['km_regcode']; ?>" id="exp_interest5_<?php echo $user['km_regcode']; ?>" class="radio-inline" type="radio" value="You profile matches my sister's/brother's profile. Please 'Accept' if you are interested."> Your profile is matching to my profile. Please 'Accept' if you are interested.</li>
                                                   <li><input name="exp_interest_<?php echo $user['km_regcode']; ?>"  id="exp_interest6_<?php echo $user['km_regcode']; ?>" class="radio-inline" type="radio" value="Our children's profile seems to match. Please reply to proceed further."> My profile seems to match. Please reply to proceed further.</li>
                                                   <li><input name="exp_interest_<?php echo $user['km_regcode']; ?>" id="exp_interest7_<?php echo $user['km_regcode']; ?>" class="radio-inline" type="radio" value="We find a good life partner in you for our friend. Please reply to proceed further."> We find a good life partner in you for our friend. Please reply to proceed further.</li>
                                                </ul>
                                             </div>
                                          </div>
                                          <div class="clearfix"></div>
                                       </div>
                                       <div class="modal-footer">
                                          <?php
                                             $cur_date = date("d-m-Y"); 
                                             $day =  date("D",strtotime($cur_date));
                                             ?>
                                          <p class="pull-left text-danger" style=" margin-top: 15px;
                                             padding-left: 10px;"><?php echo $day; ?>  <?php echo date("d M, Y h:i A"); ?> </p>
                                          <button type="submit" name="send-interest" value="submit" class="button add_interest_<?php echo $user['km_regcode']; ?>" id="<?php echo $user['km_regcode']; ?>">Send Interest</button>
                                          <button type="button" class="button-green button" data-dismiss="modal">Close</button>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <script type="text/javascript">
                                 $(document).on('click', '.add_interest_<?php echo $user['km_regcode']; ?>', function() {                  
                                 var service_id =  $(this).attr('id');
                                 // alert(service_id);
                                 $('#submit_id').val(service_id);
                                 $('#submit_flag').val('add_interest');
                                 if (document.getElementById("exp_interest_<?php echo $user['km_regcode']; ?>").checked == false && document.getElementById("exp_interest2_<?php echo $user['km_regcode']; ?>").checked == false && document.getElementById("exp_interest3_<?php echo $user['km_regcode']; ?>").checked == false && document.getElementById("exp_interest4_<?php echo $user['km_regcode']; ?>").checked == false && document.getElementById("exp_interest5_<?php echo $user['km_regcode']; ?>").checked == false && document.getElementById("exp_interest6_<?php echo $user['km_regcode']; ?>").checked == false && document.getElementById("exp_interest7_<?php echo $user['km_regcode']; ?>").checked == false) {
                                 alert("Please select any one express interest");
                                 return false;
                                 }
                                 if(document.getElementById("exp_interest_<?php echo $user['km_regcode']; ?>").checked == true){
                                 var exp_interest = document.getElementById("exp_interest_<?php echo $user['km_regcode']; ?>").value;
                                 $('#interest_value').val(exp_interest);
                                 } else if(document.getElementById("exp_interest2_<?php echo $user['km_regcode']; ?>").checked == true){
                                 var exp_interest2 = document.getElementById("exp_interest2_<?php echo $user['km_regcode']; ?>").value;
                                 $('#interest_value').val(exp_interest2);
                                 } else if(document.getElementById("exp_interest3_<?php echo $user['km_regcode']; ?>").checked == true){
                                 var exp_interest3 = document.getElementById("exp_interest3_<?php echo $user['km_regcode']; ?>").value;
                                 $('#interest_value').val(exp_interest3);
                                 } else if(document.getElementById("exp_interest4_<?php echo $user['km_regcode']; ?>").checked == true){
                                 var exp_interest4 = document.getElementById("exp_interest4_<?php echo $user['km_regcode']; ?>").value;
                                 $('#interest_value').val(exp_interest4);
                                 } else if(document.getElementById("exp_interest5_<?php echo $user['km_regcode']; ?>").checked == true){
                                 var exp_interest5 = document.getElementById("exp_interest5_<?php echo $user['km_regcode']; ?>").value;
                                 $('#interest_value').val(exp_interest5);
                                 } else if(document.getElementById("exp_interest6_<?php echo $user['km_regcode']; ?>").checked == true){
                                 var exp_interest6 = document.getElementById("exp_interest6_<?php echo $user['km_regcode']; ?>").value;
                                 $('#interest_value').val(exp_interest6);
                                 } else if(document.getElementById("exp_interest7_<?php echo $user['km_regcode']; ?>").checked == true){
                                 var exp_interest7 = document.getElementById("exp_interest7_<?php echo $user['km_regcode']; ?>").value;
                                 $('#interest_value').val(exp_interest7);
                                 } 
                                 $('#page_return').val('exp_interest_history'); 
                                 $('#search_result').attr('method', 'post');
                                 $('#search_result').attr('target', 'blank');
                                 $('#search_result').attr('action', 'profiles.php');
                                 $('#search_result').submit();
                                 });
                              </script>
                           </div>

                            <div class="col-md-3 nopad first">
                              <?php
                                 $get_shortlists = new Partner();
                                 $get_shortlists = $get_shortlists->fetchShortList("WHERE pl_userId ='{$km_regcode}' AND pv_viewedId = '{$user['km_regcode']}' ")->resultSet();
                                 $get_shortlist = $get_shortlists[0];
                                 if($get_shortlist){
                                  ?>

                              <?php if($payment){ ?>
                              <a style="border-color: #f3840a;background-color: #f35101;" class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-orange padding-lr-zero" title="Add to Shortlist">
                              <i class="fa fa-filter ne_mrg_ri8_10"></i>
                              <span id="<?php echo $get_shortlist['id']; ?>" class="remove_shortlist"> Shortlisted</span>
                              </a>
                              <?php } else { ?>
                              <a style="border-color: #f3840a;background-color: #f35101;" class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-orange padding-lr-zero" title="Add to Shortlist">
                              <i class="fa fa-filter ne_mrg_ri8_10"></i>
                              <span id="<?php echo $get_shortlist['id']; ?>" class="shortlist_pay"> Shortlisted</span>
                              </a>
                              <?php } ?>


                              <?php } else { ?>

                              <?php if($payment){ ?>
                              <a class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-orange padding-lr-zero" title="Add to Shortlist">
                              <i class="fa fa-filter ne_mrg_ri8_10"></i>
                              <span id="<?php echo $user['km_regcode']; ?>" class="add_shortlist"> Shortlist</span>
                              </a>
                              <?php } else { ?>
                              <a class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-orange padding-lr-zero" title="Add to Shortlist">
                              <i class="fa fa-filter ne_mrg_ri8_10"></i>
                              <span id="<?php echo $user['km_regcode']; ?>" class="shortlist_pay"> Shortlist</span>
                              </a>
                              <?php } ?>


                              <?php } ?>
                           </div>


                           <div class="col-md-3 nopad">
                              <a class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-orange padding-lr-zero " style="width:120px;     background: #f02d59;" title="View Phone">
                              <i class="fa fa-phone ne_mrg_ri8_10"></i>
                              <span  class="number" id="<?php echo $user['km_regcode']; ?>"> View Phone</span>
                              </a>
                              </div>
                              <div class="col-md-3 nopad">
                              <?php if($view_only_horos){ ?>
                                 <a class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-orange padding-lr-zero " style="width:140px;     background: #d42911;" title="View Horoscope">
                                 <i class="fa fa-globe ne_mrg_ri8_10"></i>
                                 <span  class="horoscope" id="<?php echo $user['km_regcode']; ?>"> View Horoscope</span>
                                 </a>
                                 <?php } else { ?>
                                 <a class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-orange padding-lr-zero " style="width:140px;background: #d42911;" title="View Horoscope">
                                 <i class="fa fa-globe ne_mrg_ri8_10"></i>
                                 <span  class="no_horoscope" id="<?php echo $user['km_regcode']; ?>"> View Horoscope</span>
                                 </a>
                                 <?php } ?>
                              </div>
                           </div>
                        </div>
                     </div>
                     <?php }                                  
                        }else{
                             ?>
                     <div id="result-content">
                        <h4 style="margin: 1.5em 1em;text-align: center;color: #17800a;"> Profile not available. </h4>
                     </div>
                     <?php
                        }                                
                        ?>
               </form>
               </div>
               <?php
                  $url = "search_results.php";
                  echo pagination($statement,$limit,$page,$url);
                  ?>
         </section>
         
         <div style=" clear: both;"></div>
         <div class="space"></div>
         
      </section>

      </div>
      <?php include("includes/footertop.php");?>
      <?php include("includes/footerin.php");?>
      
      <script>
         $(document).on('click', '.horoscope', function() {                  
             var service_id =  $(this).attr('id');
             $('#submit_id').val(service_id);
             $('#submit_flag').val('profile');  
             $('#profile_type').val('horoscope');               
             $('#search_result').attr('method', 'post');
             $('#search_result').attr('target', 'blank');
             $('#search_result').attr('action', 'search_results.php');
             $('#search_result').submit();
         });
         $(document).on('click', '.number', function() {                  
             var service_id =  $(this).attr('id');
             $('#submit_id').val(service_id);
             $('#submit_flag').val('profile'); 
             $('#profile_type').val('contact'); 
             $('#search_result').attr('method', 'post');
             $('#search_result').attr('target', 'blank');
             $('#search_result').attr('action', 'search_results.php');
             $('#search_result').submit();
         });
         $(document).on('click', '.view_profile', function() {                  
             var service_id =  $(this).attr('id');
             $('#submit_id').val(service_id);
             $('#submit_flag').val('view'); 
             $('#search_result').attr('method', 'post');
             $('#search_result').attr('target', 'blank');
             $('#search_result').attr('action', 'search_results.php');
             $('#search_result').submit();
         });
         $(document).on('click', '.view_album', function() {                  
             var service_id =  $(this).attr('id');
             $('#submit_id').val(service_id);
             $('#submit_flag').val('album'); 
             $('#search_result').attr('method', 'post');
             $('#search_result').attr('target', 'blank');
             $('#search_result').attr('action', 'search_results.php');
             $('#search_result').submit();
         });
         $(document).on('click', '.add_shortlist', function() {
         var confirm_msg = confirm("Do you want to shortlist this profile?");
               if (confirm_msg == true) {                  
             var service_id =  $(this).attr('id');
             // alert(service_id);
             $('#submit_id').val(service_id);
             $('#submit_flag').val('add_shortlist'); 
             $('#page_return').val('shortlisted_history');
             $('#search_result').attr('method', 'post');
             $('#search_result').attr('action', 'search_results.php');
             $('#search_result').submit();
           }
         });
         $(document).on('click', '.remove_shortlist', function() {
         var confirm_msg = confirm("Do you want to remove the profile from shortlisted ?");
               if (confirm_msg == true) {                  
             var service_id =  $(this).attr('id');
             // alert(service_id);
             $('#submit_id').val(service_id);
             $('#submit_flag').val('remove_shortlist'); 
             $('#page_return').val('shortlisted_history');
             $('#search_result').attr('method', 'post');
             $('#search_result').attr('action', 'search_results.php');
             $('#search_result').submit();
           }
         });
         
         $(document).on('click', '.remove_interest', function() {
         var confirm_msg = confirm("Do you want to remove the profile from sent interest?");
               if (confirm_msg == true) {                  
             var service_id =  $(this).attr('id');
             // alert(service_id);
             $('#submit_id').val(service_id);
             $('#submit_flag').val('remove_interest'); 
             $('#page_return').val('exp_interest_history');
             $('#search_result').attr('method', 'post');
             $('#search_result').attr('action', 'search_results.php');
             $('#search_result').submit();
           }
         });
         $(document).on('click', '.interest_pay', function() {                  
         $('#search_result').attr('method', 'post');
         $('#search_result').attr('action', 'membership.php');
         $('#search_result').submit();
         });
         $(document).on('click', '.shortlist_pay', function() {                  
             $('#search_result').attr('method', 'post');
             $('#search_result').attr('action', 'membership.php');
             $('#search_result').submit();
         });
         $(document).on('click', '.no_horoscope', function() {  
         alert("Horoscope not available for this profile");
         return false;                
         });
         
      </script>      
   </body>
</html>