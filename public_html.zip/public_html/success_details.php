<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
ob_start();
session_start();
require_once 'KANyaMatrI_GST/includes/configure.php';
require_once 'init.php';
require_once 'includes/pagination.php';
require_once 'includes/db.php';
date_default_timezone_set('Asia/Kolkata');

$status=$_POST["status"];
$firstname=$_POST["firstname"];
$amount=$_POST["amount"];
$txnid=$_POST["txnid"];
$posted_hash=$_POST["hash"];
$key=$_POST["key"];
$productinfo=$_POST["productinfo"];
$email=$_POST["email"];
$mobile=$_POST["phone"];

$payment_mode = $_POST["mode"];
if($payment_mode == 'CC'){$payment_mode = 'Credit card';}
if($payment_mode == 'NB'){$payment_mode = 'Net Banking';}
if($payment_mode == 'CD'){$payment_mode = 'Cheque or DD';}
if($payment_mode == 'CO'){$payment_mode = 'Cash';}

$salt="4ZrexCBzX5";

If (isset($_POST["additionalCharges"])) {
       $additionalCharges=$_POST["additionalCharges"];
        $retHashSeq = $additionalCharges.'|'.$salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
        
                  }
    else {    

        $retHashSeq = $salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;

         }
         $hash = hash("sha512", $retHashSeq);
         
       if ($hash != $posted_hash) {
           $result = "<h4 style='margin:1em;font-size: 20px;'>Invalid Transaction. Please try again</h4>";
           }
       else {
               if($status == 'success'){

			        $to = "support@kanyadhaanam.com";
					$subject = "Payment Details from KANYADHAANAM MATRIMONY";

			        $msg= "<table>
			        <tr><td align='right'>Payment Amount&nbsp;:&nbsp;</td><td>$amount</td></tr>
			      	<tr><td align='right'>Transaction ID&nbsp;:&nbsp;</td><td>$txnid</td></tr>
			      	<tr><td align='right'>Status&nbsp;:&nbsp;</td><td>$status</td></tr>

			      	<tr><td align='right'>Customer Reg ID&nbsp;:&nbsp;</td><td>$productinfo</td></tr>

			      	<tr><td align='right'>Customer Name&nbsp;:&nbsp;</td><td>$firstname</td></tr>
			      	<tr><td align='right'>Customer Mobile No&nbsp;:&nbsp;</td><td>$mobile</td></tr>
			      	<tr><td align='right'>Customer Email ID&nbsp;:&nbsp;</td><td>$email</td></tr>
			      	</table><br>";

			      	// Always set content-type when sending HTML email
					$headers = "MIME-Version: 1.0" . "\r\n";
					$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

					// More headers
					$headers .= 'From: <support@kanyadhaanam.com>' . "\r\n";

					$send = mail($to,$subject,$msg,$headers);


                }              
                
          $result .= "<h4 style='margin:1em;font-size: 20px;'>Your Transaction ID for this transaction is ".$txnid.".</h4>";
          $result .= "<h4 style='margin:1em;font-size: 20px;'>We have received your payment of Rs. " . $amount . ".</h4>";
  
           } 
                   

?>
<!DOCTYPE html>
<html>
   <head>
      <title>Kanyadhaanam Matrimony </title>
     
      <?php include("includes/headertop.php");?>
      <style type="text/css">table {
         width: 90%;
         border: none;
         margin: 0px auto;
         }
      </style>
   </head>
   <body class="home color-green boxed shadow">
     <?php include("includes/headerin.php");?>
         <?php include("includes/bannerin.php");?>
      <div class="root">
        
         <script src="js/jquery-1.12.4.js"></script>
                    <section class="content reverse">
                     <?php include("includes/right.php");?>
                        <section class="col-md-9 col-xs-12" style=" margin-top: 1%;">
                        <form method="post">
                            <h3 style=" margin-top: 10px; color: #175905;">PAYMENT SUCCESS</h3>
                            <br>


                            <form method="post" id='search_result' action="">
                             <div id="result-content">
                                <?php echo $result; ?>
                             </div>
                          </form>

                        
                            <div style=" clear: both;"></div>

                            <div class="space"></div>
                            </form>
                        </section>

                      

                    </section>
                    <div style=" clear: both;"></div>

                    <?php include("includes/footer.php");?>
        </div>
    </body>

</html>