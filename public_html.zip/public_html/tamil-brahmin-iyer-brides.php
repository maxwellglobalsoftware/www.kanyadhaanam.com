<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   if($_SESSION['User_Kamma_Matri']){
       unset($_SESSION['User_Kamma_Matri']);
   }
   date_default_timezone_set('Asia/Kolkata');
   require_once 'init.php';
   require_once 'KANyaMatrI_GST/includes/configure.php';
   
   if(isset($_SESSION['registrationAdded'])) {     
   if($_SESSION['registrationAdded']) {
       $result = "Registration Added<BR>".$_SESSION['userinfo'];
   } else {
       $result = "Failed to add Registration";
   }
   unset($_SESSION['registrationAdded']);
   }
   
   if(isset($_POST['go'])) {
       $username = $_POST['username'];
       $password = $_POST['password'];
   
       $user = new Registration();
       $user = $user->login($username, $password);  
       if($user) {
           $data = array();
           $data[] = $_SESSION['User_Kamma_Matri']['id'];
           $data[] = date_format(new DateTime(), 'd-m-Y');
           $data[] = date_format(new DateTime(), 'h:i A');
   
           $login = new Login();
           $login = $login->setLogin($data);
   
           $_SESSION['logged_id'] = $login->lastInsertID();   
           
           $today = date('Y-m-d');
           
           $paymentIDs = new Payment();
           $paymentIDs = $paymentIDs->fetch("WHERE pl_userId = '{$_SESSION['User_Kamma_Matri']['km_regcode']}'  ORDER BY id DESC LIMIT 1")->resultSet(); 
           $paymentID = $paymentIDs[0];
        
        
       $payments = new Payment();
       $payments = $payments->fetch("WHERE pl_userId = '{$_SESSION['User_Kamma_Matri']['km_regcode']}' AND id = '{$paymentID['id']}' AND pl_status = 'activate' AND '{$today}' BETWEEN pl_startDate AND pl_expireDate ORDER BY id DESC")->resultSet(); 
       $payment = $payments[0];
   
       if($payment){
        header('Location: profiles.php');
       } else {
        header('Location: membership_pay.php');
       }
           
        //   header('Location: profiles.php');
       } else {
           echo '<script>window.alert("Please enter valid User ID and/or Password");</script>';
           echo '<script>window.location="login.php"</script>';
   //            header('Location: index.php');
       }
   }
   
   
   //*********************** Female Profile Details *******************************
   $female_profiles = new Registration();
   $female_profiles = $female_profiles->fetch("WHERE km_gender = 'female' AND km_status = 'live' ORDER BY id DESC")->resultSet(); 
   
   ?>
<!DOCTYPE html>
<html>
   <head>
       <title>Brahmin Iyer Iyengar Brides in Chennai, Tamilnadu - Kanyadhaanam.com</title>
      <meta name="description" content="Looking for Tamil Brahmin iyer Iyengar Brides in Chennai? Kanyadhaanam.com provides well educated & settled brides profiles in Chennai all over Tamil Nadu. Free Registraion!
         "/>
      <meta name="keywords" content="iyer brides in chennai, brahmin brides in chennai, brahmin iyer brides in chennai, tamil iyengar brides in chennai, brahmin brides in tamilnadu, iyengar brides in tamilnadu, tamil brahmin iyer brides, tamil iyer matrimony brides, tamil brahmin matrimony brides, tamil iyengar matrimony brides, tamil iyengar brides in chennai"/>

      <link rel="canonical" href="http://www.kanyadhaanam.com/tamil-nadu-brahmin-brides.php" />
      <?php include("includes/headertop.php");?>
      <style type="text/css">table {
         width: 90%;
         border: none;
         margin: 0px auto;
         }
      </style>
      <script type="text/javascript">
         function logfn(form)
         
         {
         
         
         if(form.username.value=="") { alert("Please Enter User ID"); form.username.focus(); return false; }
         
         if(form.password.value=="") { alert("Please Enter Password"); form.password.focus(); return false; }
         
         }
         
      </script>
   </head>
   <body class="home color-green boxed shadow">
      <?php include("includes/header.php");?>
     <section id="register-home">
         <div class="container">
            <div class="row">
               <div class="col-sm-6 col-xs-12">
                  <h4 style="font-size: 45px;">
                     New Brides
                  </h4>
               </div>
            </div>
         </div>
      </section>
      <script src="js/jquery-1.12.4.js"></script>
      <div class="root">
         <section class="content reverse">
            <section class="main">
               <section class="columns" style=" margin-top: 10px;">
                  <h3 style=" color: #b5181a;">Kanyadhaanam Brides : </h3>
                  <div class="container-lg " style="margin-left: 0px; margin-top: 0px; padding-top: 0px; padding-left: 0px;">
                     <div class="home-higlight">
                        <div class="profile-slider swiper-container swiper-container-horizontal swiper-container-multirow">
                           <div class="swiper-wrapper">
                              <?php 
                                 if($female_profiles){
                                 $sno = 0;
                                 foreach($female_profiles as $female_profile){ 
                                 
                                  $users = new Registration();
                                  $users = $users->fetch("WHERE km_regcode = '{$female_profile['km_regcode']}'")->resultSet();
                                  $user = $users[0];
                                 
                                  $photos = new Profile();
                                  $photos = $photos->fetchPhotos("WHERE pho_userId = '{$user['km_regcode']}' AND pho_imgPath LIKE '%_profile_%' ORDER BY id DESC LIMIT 1")->resultSet();
                                  $photo = $photos[0];
                                  
                                  //// Districts /////
                                  $districts = new Registration();
                                  $districts = $districts->fetchDistricts("WHERE id = '{$user['km_district']}' ORDER BY name ASC")->resultSet();
                                  $district = $districts[0];
                                  
                                  if($photo['pho_imgPath']){
                                  if($sno < 18){
                                 
                                      $imgPath =  $photo['pho_imgPath'];
                                 
                                      $image_file = fopen($imgPath, 'r');
                                      $imgPath = fread($image_file, filesize($imgPath));
                                 
                                  $from = new DateTime($user['km_dateofbirth']);
                                  $to   = new DateTime('today');
                                  $age = $from->diff($to)->y; 
                                  $cur_Year = date("Y");
                                 
                                  ?>
                              <div class="swiper-slide profile-contain  newbride" data-wow-delay="0.1s" data-swiper-column="0" data-swiper-row="0">
                                 <div>
                                    <div class="img-contain"><img src="data:image/jpeg;base64,<?php echo base64_encode($imgPath); ?>" height="172"  alt="iyer brides in chennai" title="iyer brides in chennai"> </div>
                                    <div class="detail-contain">
                                       <h3><?php echo $user['km_name'];?> (<?php echo $user['km_regcode'];?>)</h3>
                                       <h3><?php echo $user['km_caste'];?> </h3>

                                       <p>
                                          <?php if($age && $user['km_height']){ ?>
                                          <?php echo $age; ?> / <?php echo $user['km_height']; ?>   
                                          <?php } else if($age){ ?>
                                          <?php if($age == $cur_Year){ echo 'N / A'; } else { echo $age; } ?>
                                          <?php } else if($user['km_height']){?>
                                          <?php echo $user['km_height']; ?> 
                                          <?php } else { echo ''; } ?>
                                       </p>
                                       <p > 
                                          <?php  if($user['km_education']){ echo $edu_array[$user['km_education']]; } else { echo ''; } ?>
                                       </p>
                                       <p class="place">
                                          <?php 
                                             if($user['km_district']){ 
                                             if($district){ 
                                              echo $district['name']; } 
                                              else { echo $user['km_district']; }
                                              } else { echo ''; } 
                                             ?>
                                          <!--<?php if($user['km_district']){ echo $user['km_district']; } else { echo ''; } ?>-->
                                       </p>
                                       <a href="login.php"><label>View Profile <i class="fa fa-angle-right"></i></label></a>
                                    </div>
                                 </div>
                              </div>
                              <?php $sno++; } } } } ?>
                           </div>
                           <br>
                           <a href="login.php" style=" text-align: right;
                              float: right;
                              margin-top: 30px;
                              padding-right: 20px; font-weight: bold; font-family: 'Catamaran', sans-serif;">மேலும் பார்க்க >> </a>
                        </div>
                     </div>
                  </div>
               </section>
            </section>
         </section>
         <?php
            if(isset($result)) {
            ?>
         <script>
            $('#message_container').fadeIn(10);
            $('#message').text("<?php echo $result; ?>");
            setTimeout(function() {
                    $('#message_container').fadeOut(50000, function() {
                            $('#message').text("");
                            $('#username').focus();
                    });
            }, 50000);
         </script>
         <?php
            }
            ?>
      </div>
      <div style=" clear: both;"></div>
      <?php include("includes/footer.php");?>
   </body>
</html>