<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   require_once 'KANyaMatrI_GST/includes/configure.php';
   require_once 'init.php';
   require_once 'includes/pagination.php';
   require_once 'includes/common_functions.php';
   require_once 'includes/db.php';
   
   $profileId = $_SESSION['pv_viewedId'];
   
   
   if(empty($profileId)){
       header('Location: profiles.php');
   }
   
   
   $profiles = new Registration();
   $profiles = $profiles->fetch("WHERE km_regcode = '{$profileId}'")->resultSet();    
   $profile = $profiles[0];
   
   
   //*********************** Photo Details *******************************
   $user_photos = new Profile();
   $user_photos = $user_photos->fetchPhotos("WHERE pho_userId = '{$profile['km_regcode']}' AND pho_imgPath LIKE '%_profile_%'")->resultSet();
   $user_profile_photos = $user_photos[0];
   
   
   $photos = new Profile();
   $photos = $photos->fetchPhotos("WHERE pho_userId = '{$profile['km_regcode']}' AND pho_imgPath NOT LIKE '%_profile_%'")->resultSet();

   $view_only_horos = new Profile();
   $view_only_horos = $view_only_horos->fetchHoroscope("WHERE hs_userId = '{$profile['km_regcode']}'")->resultSet();
   $view_only_horos = $view_only_horos[0];
   
   //// Occupation /////
$occupations = new Registration();
$occupations = $occupations->fetchOccupation("WHERE id = '{$profile['km_occupation']}' ORDER BY occupation ASC")->resultSet();
$occupation = $occupations[0];

//// Districts /////
$districts = new Registration();
$districts = $districts->fetchDistricts("WHERE id = '{$profile['km_district']}' ORDER BY name ASC")->resultSet();
$district = $districts[0];
   
   $km_regcode = $_SESSION['User_Kamma_Matri']['km_regcode'];
   
   if(isset($_POST['submit_id'])){
          profile_details($_POST['submit_id'],$km_regcode);
      }
   
   if($user_profile_photos['pho_imgPath']){
       $userimgPath =  $user_profile_photos['pho_imgPath'];
   
       $image_file = fopen($userimgPath, 'r');
       $userimgPath = fread($image_file, filesize($userimgPath));
   }else{
       if($profile['km_gender'] == 'male'){
           $userimgPath = 'images/male.png';
   
           $image_file = fopen($userimgPath, 'r');
           $userimgPath = fread($image_file, filesize($userimgPath));
       }else{
           $userimgPath = 'images/female.png';
   
           $image_file = fopen($userimgPath, 'r');
           $userimgPath = fread($image_file, filesize($userimgPath));
       }
        
   }
   
   
   ?>
<!DOCTYPE html>
<html>
   <head>
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <?php include("includes/headertop.php");?>
   </head>
   <body class="home color-green boxed shadow">
      
         <?php include("includes/headerin.php");?>
         
            
            <?php include("includes/bannerin.php");?>
       
         <?php //include("includes/quicksearch.php");?>

         <div class="root">
         <section class="content reverse">
          <?php include("includes/right.php");?>
            <section class="col-md-9 col-xs-12" style=" margin-top: 1%;">
               <table>
                  <tr class="tabletitle">
                     <td colspan="2" style="  border-top-left-radius: 0.5em; border-top-right-radius: 0.5em;">View Album</td>
                  </tr>
               </table>
               <div id="pagin" style=" margin-top: -20px;">
                  <form method="post" id='search_result' action="">
                     <input type="hidden" id="submit_id" name="submit_id" value="" />
                     <input type="hidden" id="submit_flag" name="submit_flag" value="" />
                     <input type="hidden" id="profile_type" name="profile_type" value="" />
                     <input type="hidden" id="page_return" name="page_return" value="" />
                     <input type="hidden" id="interest_value" name="interest_value" value="" />
                     <div id="r-content" class="style50" style="    margin-bottom: 40px;">
                        <div class="r-content-left">
                           <span class="profile">Profie ID : <?php echo $profile['km_regcode'];?> </span>
                           <div class="r-content-photo">
                              <a href=""> <img width="150" height="170" border="0" src="data:image/jpeg;base64,<?php echo base64_encode($userimgPath); ?>"></a>
                           </div>
                           <div class="r-content-top-2">
                              <div class="r-content-top-btn">
                                 <input type="button" id="<?php echo $profile['km_regcode']; ?>" class="button1 red view_profile" style="width: 160px;" value="View full profile" />
                              </div>
                              <!--  <div class="r-content-top-btn" style="margin-top:10px;"><a href="" class="button1 red"> View Photo Album</a>
                                 </div> -->
                              <div class="r-content-top-btn"> </div>
                           </div>
                        </div>
                        <div class="r-content-right-top">
                           <div class="r-content-top-1">
                              <table width="426" cellspacing="0" cellpadding="0" border="0">
                                 <tbody>
                                    <?php 
                                       $from = new DateTime($profile['km_dateofbirth']);
                                       $to   = new DateTime('today');
                                       $age = $from->diff($to)->y;                                                     
                                       ?>
                                    <tr>
                                       <td height="22" style=" color:#0f50e2;font-weight:bold; text-transform: uppercase;" colspan="3"><?php echo $profile['km_name'];?> K&nbsp;


                                       <div class="box-match-data-actions">
                                       <?php if($view_only_horos){ ?>
                                             <a  href="#" data-toggle="modal" data-target="#sendHOROModal"><span id="<?php echo $profile['km_regcode']; ?>" class="sp icon-mplanet2 horoscope tooltip" data-toggle="tooltip" title="" data-original-title="View Horoscope "><span class="tooltiptext">View Horoscope</span></span></a>
                                             <?php } else { ?>
                                             <a  href="#" data-toggle="modal" data-target="#sendHOROModal"><span id="<?php echo $profile['km_regcode']; ?>" class="sp icon-mplanet2 no_horoscope tooltip" data-toggle="tooltip" title="" data-original-title="View Horoscope "><span class="tooltiptext">View Horoscope</span></span></a>
                                             <?php } ?>
                                             <a  href="#" data-toggle="modal" data-target="#contactnowModal"><span id="<?php echo $profile['km_regcode']; ?>" class="sp icon-viewcontact tooltip number" data-toggle="tooltip" title="" data-original-title="View Contact "><span class="tooltiptext">View Contact</span></span></a>
                                          </div>
                                       </td>
                                       
                                          
                                       
                                    </tr>
                                    <tr>
                                       <td width="124" height="20" style="color:#000">Age / Height</td>
                                       <td width="20">:</td>
                                       <td width="182" style="color:#333"> <?php echo $age.' Yrs';?> / <?php echo $profile['km_height'];?>
                                    <tr>
                                       <td height="20" style="color:#000" valign="top">
                                          Star
                                       </td>
                                       <td valign="top">
                                          :
                                       </td>
                                       <td style="color:#333">
                                          <?php echo $profile['km_star'];?>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td height="20" style="color:#000" valign="top">
                                          District
                                       </td>
                                       <td valign="top">
                                          :
                                       </td>
                                       <td style="color:#333">
                                          <?php 
                                      if($profile['km_district']){ 
                                      if($district){ 
                                      	echo $district['name']; } 
                                      	else { echo $profile['km_district']; }
                                      	} else { echo 'N / A'; } 
                                      ?>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td height="19" style="color:#000">Qualification</td>
                                       <td height="19">:</td>
                                       <td height="19" style="color:#333"><?php echo $edu_array[$profile['km_education']];?></td>
                                    </tr>
                                    <tr>
                                       <td height="20" style="color:#000">Profession</td>
                                       <td>:</td>
                                       <td style="color:#333">
                                            <?php
                                         if($profile['km_employee_in'] == 'notworking'){
                                             echo 'Not Working';
                                         } else {
                                          if($profile['km_occupation']){ 
                                          if($occupation){ 
                                          	echo $occupation['occupation']; } 
                                          	else { echo $profile['km_occupation']; }
                                          	} else { echo 'N / A'; } 
                                         }
                                          ?>
                                           </td>
                                    </tr>
                                         <tr>
                                       <td height="20" style="color:#000" valign="top">
                                          SubCaste
                                       </td>
                                       <td valign="top">
                                          :
                                       </td>
                                       <td style="color:#333">
                                          <?php if($profile['km_subcaste']){ echo $profile['km_subcaste']; } else { echo 'N / A'; } ?>
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>


                              <div class="col-md-3 nopad first">
                                       <?php
                                          $get_interests = new Partner();
                                          $get_interests = $get_interests->fetchInterest("WHERE pl_userId ='{$km_regcode}' AND pv_viewedId = '{$profile['km_regcode']}'")->resultSet();
                                          $get_interest = $get_interests[0];
                                          
                                          if($get_interest){
                                           ?>

                                      <?php if($payment){ ?>
                                       <a class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-green padding-lr-zero"  title="Send Interest">
                                       <i class="fa fa-paper-plane"></i>&nbsp;<span id="<?php echo $get_interest['id']; ?>" class="remove_interest">Interest Sent</span>
                                       </a>
                                       <?php } else { ?>
                                       <a class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-green padding-lr-zero"  title="Send Interest">
                                       <i class="fa fa-paper-plane"></i>&nbsp;<span id="<?php echo $get_interest['id']; ?>" class="interest_pay">Interest Sent</span>
                                       </a>
                                       <?php }  ?>


                                       <?php } else { ?>

                                       <?php if($payment){ ?>
                                       <a href="#" style="border-color: #de0f7e!important;background: #de0f7e!important;color: white; width:125px;" class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-green padding-lr-zero" data-toggle="modal" data-target="#myModal_<?php echo $profile['km_regcode']; ?>" title="Send Interest">
                                       <i class="fa fa-paper-plane"></i>&nbsp;<span> Send Interest</span>
                                       </a>
                                       <?php } else { ?>
                                        <a href="#" style="border-color: #de0f7e!important;background: #de0f7e!important;color: white; width:125px;" class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-green padding-lr-zero"  title="Send Interest">
                                       <i class="fa fa-paper-plane"></i>&nbsp;<span class="interest_pay"> Send Interest</span>
                                       </a>
                                       <?php }  ?>


                                       <?php } ?>
                                       <!-- Modal -->
                                       <div class="modal fade" id="myModal_<?php echo $profile['km_regcode']; ?>" role="dialog">
                                          <div class="modal-dialog">
                                             <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title">Express Interest</h4>
                                             </div>
                                             <!-- Modal content-->
                                             <div class="modal-content">
                                                <div class="modal-body">
                                                   <div class="modal-body xxl-16 xl-16 m-16 l-16 s-16 xs-16">
                                                      <div class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 margin-top-10px-320px margin-top-10px-480px ne-mrg-top-10-768 margin-top-10px-999">
                                                         <ul class="list-unstyled">
                                                            <li>
                                                               <input  name="exp_interest_<?php echo $profile['km_regcode']; ?>" id="exp_interest_<?php echo $profile['km_regcode']; ?>"  type="radio" value="I am interested in your profile. Please Accept if you are interested."> I am interested in your profile. Please Accept if you are interested.
                                                            </li>
                                                            <li><input name="exp_interest_<?php echo $profile['km_regcode']; ?>" id="exp_interest2_<?php echo $profile['km_regcode']; ?>"  type="radio" value="You are the kind of person we have been looking for. Please respond to proceed further."> You are the kind of person we have been looking for. Please respond to proceed further.</li>
                                                            <li><input name="exp_interest_<?php echo $profile['km_regcode']; ?>" id="exp_interest3_<?php echo $profile['km_regcode']; ?>" class="radio-inline" type="radio" value=" We liked your profile and interested to take it forward. Please reply at the earliest."> We liked your profile and interested to take it forward. Please reply at the earliest.</li>
                                                            <li><input name="exp_interest_<?php echo $profile['km_regcode']; ?>" id="exp_interest4_<?php echo $profile['km_regcode']; ?>" class="radio-inline" type="radio" value="You seem to be the kind of person who suits our family. We would like to contact your parents to proceed further."> You seem to be the kind of person who suits our family. We would like to contact your parents to proceed further.</li>
                                                            <li><input name="exp_interest_<?php echo $profile['km_regcode']; ?>" id="exp_interest5_<?php echo $profile['km_regcode']; ?>" class="radio-inline" type="radio" value="You profile matches my sister's/brother's profile. Please 'Accept' if you are interested."> Your profile is matching to my profile. Please 'Accept' if you are interested.</li>
                                                            <li><input name="exp_interest_<?php echo $profile['km_regcode']; ?>"  id="exp_interest6_<?php echo $profile['km_regcode']; ?>" class="radio-inline" type="radio" value="Our children's profile seems to match. Please reply to proceed further."> My profile seems to match. Please reply to proceed further.</li>
                                                            <li><input name="exp_interest_<?php echo $profile['km_regcode']; ?>" id="exp_interest7_<?php echo $profile['km_regcode']; ?>" class="radio-inline" type="radio" value="We find a good life partner in you for our friend. Please reply to proceed further."> We find a good life partner in you for our friend. Please reply to proceed further.</li>
                                                         </ul>
                                                      </div>
                                                   </div>
                                                   <div class="clearfix"></div>
                                                </div>
                                                <div class="modal-footer">
                                                   <?php
                                                      $cur_date = date("d-m-Y"); 
                                                      $day =  date("D",strtotime($cur_date));
                                                      ?>
                                                   <p class="pull-left text-danger" style=" margin-top: 15px;
                                                      padding-left: 10px;"><?php echo $day; ?>  <?php echo date("d M, Y h:i A"); ?> </p>
                                                   <button type="submit" name="send-interest" value="submit" class="button-green button add_interest_<?php echo $profile['km_regcode']; ?>" id="<?php echo $profile['km_regcode']; ?>">Send Interest</button>
                                                   <button type="button" class="button-green button" data-dismiss="modal">Close</button>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <script type="text/javascript">
                                          $(document).on('click', '.add_interest_<?php echo $profile['km_regcode']; ?>', function() {                  
                                          var service_id =  $(this).attr('id');
                                          // alert(service_id);
                                          $('#submit_id').val(service_id);
                                          $('#submit_flag').val('add_interest');
                                          if (document.getElementById("exp_interest_<?php echo $profile['km_regcode']; ?>").checked == false && document.getElementById("exp_interest2_<?php echo $profile['km_regcode']; ?>").checked == false && document.getElementById("exp_interest3_<?php echo $profile['km_regcode']; ?>").checked == false && document.getElementById("exp_interest4_<?php echo $profile['km_regcode']; ?>").checked == false && document.getElementById("exp_interest5_<?php echo $profile['km_regcode']; ?>").checked == false && document.getElementById("exp_interest6_<?php echo $profile['km_regcode']; ?>").checked == false && document.getElementById("exp_interest7_<?php echo $profile['km_regcode']; ?>").checked == false) {
                                          alert("Please select any one express interest");
                                          return false;
                                          }
                                          if(document.getElementById("exp_interest_<?php echo $profile['km_regcode']; ?>").checked == true){
                                          var exp_interest = document.getElementById("exp_interest_<?php echo $profile['km_regcode']; ?>").value;
                                          $('#interest_value').val(exp_interest);
                                          } else if(document.getElementById("exp_interest2_<?php echo $profile['km_regcode']; ?>").checked == true){
                                          var exp_interest2 = document.getElementById("exp_interest2_<?php echo $profile['km_regcode']; ?>").value;
                                          $('#interest_value').val(exp_interest2);
                                          } else if(document.getElementById("exp_interest3_<?php echo $profile['km_regcode']; ?>").checked == true){
                                          var exp_interest3 = document.getElementById("exp_interest3_<?php echo $profile['km_regcode']; ?>").value;
                                          $('#interest_value').val(exp_interest3);
                                          } else if(document.getElementById("exp_interest4_<?php echo $profile['km_regcode']; ?>").checked == true){
                                          var exp_interest4 = document.getElementById("exp_interest4_<?php echo $profile['km_regcode']; ?>").value;
                                          $('#interest_value').val(exp_interest4);
                                          } else if(document.getElementById("exp_interest5_<?php echo $profile['km_regcode']; ?>").checked == true){
                                          var exp_interest5 = document.getElementById("exp_interest5_<?php echo $profile['km_regcode']; ?>").value;
                                          $('#interest_value').val(exp_interest5);
                                          } else if(document.getElementById("exp_interest6_<?php echo $profile['km_regcode']; ?>").checked == true){
                                          var exp_interest6 = document.getElementById("exp_interest6_<?php echo $profile['km_regcode']; ?>").value;
                                          $('#interest_value').val(exp_interest6);
                                          } else if(document.getElementById("exp_interest7_<?php echo $profile['km_regcode']; ?>").checked == true){
                                          var exp_interest7 = document.getElementById("exp_interest7_<?php echo $profile['km_regcode']; ?>").value;
                                          $('#interest_value').val(exp_interest7);
                                          } 
                                          $('#page_return').val('viewalbum'); 
                                          $('#search_result').attr('method', 'post');
                                          $('#search_result').attr('action', 'viewalbum.php');
                                          $('#search_result').submit();
                                          });
                                       </script>
                                   </div>
                                   <div class="col-md-3 nopad first"> 
                                       <?php
                                          $get_shortlists = new Partner();
                                          $get_shortlists = $get_shortlists->fetchShortList("WHERE pl_userId ='{$km_regcode}' AND pv_viewedId = '{$profile['km_regcode']}' ")->resultSet();
                                          $get_shortlist = $get_shortlists[0];
                                          if($get_shortlist){
                                           ?>

                                      <?php if($payment){ ?>
                                       <a style="border-color: #f3840a;background-color: #f35101;" class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-orange padding-lr-zero" title="Add to Shortlist">
                                       <i class="fa fa-filter ne_mrg_ri8_10"></i>
                                       <span id="<?php echo $get_shortlist['id']; ?>" class="remove_shortlist"> Shortlisted</span>
                                       </a>
                                       <?php } else { ?>
                                       <a style="border-color: #f3840a;background-color: #f35101;" class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-orange padding-lr-zero" title="Add to Shortlist">
                                       <i class="fa fa-filter ne_mrg_ri8_10"></i>
                                       <span id="<?php echo $get_shortlist['id']; ?>" class="shortlist_pay"> Shortlisted</span>
                                       </a>
                                       <?php } ?>


                                       <?php } else { ?>

                                       <?php if($payment){ ?>
                                       <a class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-orange padding-lr-zero" title="Add to Shortlist">
                                       <i class="fa fa-filter ne_mrg_ri8_10"></i>
                                       <span id="<?php echo $profile['km_regcode']; ?>" class="add_shortlist"> Shortlist</span>
                                       </a>
                                       <?php } else { ?>
                                       <a class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-orange padding-lr-zero" title="Add to Shortlist">
                                       <i class="fa fa-filter ne_mrg_ri8_10"></i>
                                       <span id="<?php echo $profile['km_regcode']; ?>" class="shortlist_pay"> Shortlist</span>
                                       </a>
                                       <?php }  ?>


                                       <?php } ?>
                                    </div>

                                   <div class="col-md-3 nopad">
                                     
                                       <a class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-orange padding-lr-zero " style="width:125px;     background: #f02d59;" title="View Phone">
                                       <i class="fa fa-phone ne_mrg_ri8_10"></i>
                                       <span  class="number" id="<?php echo $profile['km_regcode']; ?>"> View Phone</span>
                                       </a>
                                    </div>

                                    <div class="col-md-3 nopad">
                                    <?php if($view_only_horos){ ?>
                                       <a class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-orange padding-lr-zero " style="width:140px;     background: #d42911;" title="View Horoscope">
                                       <i class="fa fa-globe ne_mrg_ri8_10"></i>
                                       <span  class="horoscope" id="<?php echo $profile['km_regcode']; ?>"> View Horoscope</span>
                                       </a>
                                       <?php } else { ?>
                                       <a class="xxl-16 xl-16 l-16 s-16 m-16 xs-16 btn-orange padding-lr-zero " style="width:140px;     background: #d42911;" title="View Horoscope">
                                       <i class="fa fa-globe ne_mrg_ri8_10"></i>
                                       <span  class="no_horoscope" id="<?php echo $profile['km_regcode']; ?>"> View Horoscope</span>
                                       </a>
                                       <?php } ?>
                                    </div>


                           </div>
                        </div>
                     </div>
                  </form>
                  <h2 style=" color: #045f04;">Album</h2>
                  <div>
                     <script src="js/jquery-1.11.3.min.js" type="text/javascript"></script>
                     <script src="js/jssor.slider-22.1.9.mini.js" type="text/javascript"></script>
                     <script type="text/javascript">
                        jQuery(document).ready(function($) {
                        
                            var jssor_1_options = {
                                $AutoPlay: false,
                                $AutoPlaySteps: 1,
                                $SlideDuration: 160,
                                $SlideWidth: 540,
                                $SlideSpacing: 1,
                                $Cols: 1,
                                $ArrowNavigatorOptions: {
                                    $Class: $JssorArrowNavigator$,
                                    $Steps: 1
                                },
                                $BulletNavigatorOptions: {
                                    $Class: $JssorBulletNavigator$,
                                    $SpacingX: 1,
                                    $SpacingY: 1
                                }
                            };
                        
                            var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);
                        
                            function ScaleSlider() {
                                var refSize = jssor_1_slider.$Elmt.parentNode.clientWidth;
                                if (refSize) {
                                    refSize = Math.min(refSize, 540);
                                    jssor_1_slider.$ScaleWidth(refSize);
                                } else {
                                    window.setTimeout(ScaleSlider, 30);
                                }
                            }
                            ScaleSlider();
                            $(window).bind("load", ScaleSlider);
                            $(window).bind("resize", ScaleSlider);
                            $(window).bind("orientationchange", ScaleSlider);
                            /*responsive code end*/
                        });
                     </script>
                     <style>
                        .jssorb03 {
                        position: absolute;
                        }
                        .jssorb03 div,
                        .jssorb03 div:hover,
                        .jssorb03 .av {
                        position: absolute;
                        /* size of bullet elment */
                        width: 21px;
                        height: 21px;
                        text-align: center;
                        line-height: 21px;
                        color: white;
                        font-size: 12px;
                        background: url('images/b03.png') no-repeat;
                        overflow: hidden;
                        cursor: pointer;
                        }
                        .jssorb03 div {
                        background-position: -5px -4px;
                        }
                        .jssorb03 div:hover,
                        .jssorb03 .av:hover {
                        background-position: -35px -4px;
                        }
                        .jssorb03 .av {
                        background-position: -65px -4px;
                        }
                        .jssorb03 .dn,
                        .jssorb03 .dn:hover {
                        background-position: -95px -4px;
                        }
                        .jssora03l,
                        .jssora03r {
                        display: block;
                        position: absolute;
                        /* size of arrow element */
                        width: 55px;
                        height: 55px;
                        cursor: pointer;
                        background: url('images/a13.png') no-repeat;
                        overflow: hidden;
                        }
                        .jssora03l {
                        background-position: -3px -33px;
                        }
                        .jssora03r {
                        background-position: -63px -33px;
                        }
                        .jssora03l:hover {
                        background-position: -123px -33px;
                        }
                        .jssora03r:hover {
                        background-position: -183px -33px;
                        }
                        .jssora03l.jssora03ldn {
                        background-position: -243px -33px;
                        }
                        .jssora03r.jssora03rdn {
                        background-position: -303px -33px;
                        }
                        .jssora03l.jssora03lds {
                        background-position: -3px -33px;
                        opacity: .3;
                        pointer-events: none;
                        }
                        .jssora03r.jssora03rds {
                        background-position: -63px -33px;
                        opacity: .3;
                        pointer-events: none;
                        }
                     </style>
                     <?php 
                        if($photos){
                        
                        ?>
                     <div id="jssor_1" style="position:relative;left:0px;width:540px;height:600px;overflow:hidden;visibility:hidden;">
                        <!-- Loading Screen -->
                        <div data-u="loading" style="position:absolute;top:0px;left:0px;background-color:rgba(0,0,0,0.7);">
                           <div style="filter: alpha(opacity=70); opacity: 0.7; position: absolute; display: block; top: 0px; left: 0px; width: 100%; height: 100%;"></div>
                           <div style="position:absolute;display:block;background:url('images/loading.gif') no-repeat center center;top:0px;left:0px;width:100%;height:100%;"></div>
                        </div>
                        <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:540px;height:600px;overflow:hidden;">
                           <?php foreach($photos as $photo){  ?>
                           <div>
                              <img data-u="image" style="width:540px;" src="<?php echo $photo['pho_imgPath'];?>" />
                           </div>
                           <?php } ?>
                           <!--                                            <div>
                              <img data-u="image" src="images/photo1.jpg" />
                              </div>
                              <div>
                              <img data-u="image" src="images/photo1.jpg" />
                              </div>
                              <div>
                              <img data-u="image" src="images/photo1.jpg" />
                              </div>
                              <div>
                              <img data-u="image" src="images/photo1.jpg" />
                              </div>-->
                        </div>
                        <span data-u="arrowleft" class="jssora03l" style="top:0px;left:8px;width:55px;height:55px;" data-autocenter="2"></span>
                        <span data-u="arrowright" class="jssora03r" style="top:0px;right:8px;width:55px;height:55px;" data-autocenter="2"></span>
                     </div>
                     <?php 
                        }else{
                            ?>
                     <div id="result-content">
                        <h4 style="margin: 1.5em 1em;text-align: center;color: #17800a;"> Photos not available. </h4>
                     </div>
                     <?php
                        }                                
                        ?>
                  </div>
                  <br> <br> <br> <br>
               </div>
            </section>
           
         </section>
         <div style=" clear: both;"></div>
         </div>
         <?php include("includes/footertop.php");?>
         <?php include("includes/footer.php");?>
      
      <script>
            $(document).on('click', '.horoscope', function() {                  
                var service_id =  $(this).attr('id');
                $('#submit_id').val(service_id);
                $('#submit_flag').val('profile');  
                $('#profile_type').val('horoscope');               
                $('#search_result').attr('method', 'post');
                $('#search_result').attr('action', 'viewalbum.php');
                $('#search_result').submit();
            });
            $(document).on('click', '.number', function() {                  
                var service_id =  $(this).attr('id');
                $('#submit_id').val(service_id);
                $('#submit_flag').val('profile'); 
                $('#profile_type').val('contact');
                $('#search_result').attr('method', 'post');
                $('#search_result').attr('action', 'viewalbum.php');
                $('#search_result').submit();
            });
            $(document).on('click', '.view_profile', function() {                  
                var service_id =  $(this).attr('id');
                $('#submit_id').val(service_id);
                $('#submit_flag').val('view'); 
                $('#search_result').attr('method', 'post');
                $('#search_result').attr('action', 'viewalbum.php');
                $('#search_result').submit();
            });
            $(document).on('click', '.view_album', function() {                  
                var service_id =  $(this).attr('id');
                $('#submit_id').val(service_id);
                $('#submit_flag').val('album'); 
                $('#search_result').attr('method', 'post');
                $('#search_result').attr('action', 'viewalbum.php');
                $('#search_result').submit();
            });
            $(document).on('click', '.add_shortlist', function() {
            var confirm_msg = confirm("Do you want to shortlist this profile?");
                  if (confirm_msg == true) {                  
                var service_id =  $(this).attr('id');
                // alert(service_id);
                $('#submit_id').val(service_id);
                $('#submit_flag').val('add_shortlist'); 
                $('#page_return').val('viewalbum');
                $('#search_result').attr('method', 'post');
                $('#search_result').attr('action', 'viewalbum.php');
                $('#search_result').submit();
              }
            });
            $(document).on('click', '.remove_shortlist', function() {
            var confirm_msg = confirm("Do you want to remove the profile from shortlisted ?");
                  if (confirm_msg == true) {                  
                var service_id =  $(this).attr('id');
                // alert(service_id);
                $('#submit_id').val(service_id);
                $('#submit_flag').val('remove_shortlist'); 
                $('#page_return').val('viewalbum');
                $('#search_result').attr('method', 'post');
                $('#search_result').attr('action', 'viewalbum.php');
                $('#search_result').submit();
              }
            });
            
            $(document).on('click', '.remove_interest', function() {
            var confirm_msg = confirm("Do you want to remove the profile from sent interest?");
                  if (confirm_msg == true) {                  
                var service_id =  $(this).attr('id');
                // alert(service_id);
                $('#submit_id').val(service_id);
                $('#submit_flag').val('remove_interest'); 
                $('#page_return').val('viewalbum');
                $('#search_result').attr('method', 'post');
                $('#search_result').attr('action', 'viewalbum.php');
                $('#search_result').submit();
              }
            });
            $(document).on('click', '.interest_pay', function() {                  
             $('#search_result').attr('method', 'post');
             $('#search_result').attr('action', 'membership.php');
             $('#search_result').submit();
           });
           $(document).on('click', '.shortlist_pay', function() {                  
               $('#search_result').attr('method', 'post');
               $('#search_result').attr('action', 'membership.php');
               $('#search_result').submit();
           });
           $(document).on('click', '.no_horoscope', function() {  
           alert("Horoscope not available for this profile");
           return false;                
           });
            
         </script>
   </body>
</html>