<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   require_once 'KANyaMatrI_GST/includes/configure.php';
   require_once 'init.php';
   require_once 'includes/common_functions.php';
   require_once 'includes/session_handler.php';
   date_default_timezone_set('Asia/Kolkata');
   
   
   $pv_viewedId = $_SESSION['pv_viewedId'];
   
   $sms_alert = $_SESSION['sms_alert'];
   
   $km_regcode = $_SESSION['User_Kamma_Matri']['km_regcode'];
   $user_name = $_SESSION['User_Kamma_Matri']['km_name'];
   //*********************** Profile Details *******************************
   $profiles = new Registration();
   $profiles = $profiles->fetch("WHERE km_regcode = '{$pv_viewedId}'")->resultSet();    
   $profile = $profiles[0];
   
   //*********************** Horoscope Details *******************************
   $view_only_horos = new Profile();
   $view_only_horos = $view_only_horos->fetchHoroscope("WHERE hs_userId = '{$profile['km_regcode']}'")->resultSet();
   $view_only_horos = $view_only_horos[0];
   //*********************** Photo Details *******************************
   $view_only_photos = new Profile();
   $view_only_photos = $view_only_photos->fetchPhotos("WHERE pho_userId = '{$profile['km_regcode']}' AND pho_imgPath LIKE '%_profile_%'")->resultSet();
   $view_only_photo = $view_only_photos[0];

   //// Occupation /////
    $occupations = new Registration();
    $occupations = $occupations->fetchOccupation("WHERE id = '{$profile['km_occupation']}' ORDER BY occupation ASC")->resultSet();
    $occupation = $occupations[0];
   
   if($view_only_photo['pho_imgPath']){
       $view_only_imgPath =  $view_only_photo['pho_imgPath'];
   
       $image_file = fopen($view_only_imgPath, 'r');
       $view_only_imgPath = fread($image_file, filesize($view_only_imgPath));
   }else{
   
       if($profile['km_gender'] == 'male'){
           $view_only_imgPath = 'images/male.png';
   
           $image_file = fopen($view_only_imgPath, 'r');
           $view_only_imgPath = fread($image_file, filesize($view_only_imgPath));
       }else{
           $view_only_imgPath = 'images/female.png';
   
           $image_file = fopen($view_only_imgPath, 'r');
           $view_only_imgPath = fread($image_file, filesize($view_only_imgPath));
       }
        
   }
   
    if(isset($_POST['submit_id'])){
          profile_details($_POST['submit_id'],$km_regcode);
    } 
   
   if($sms_alert == 'yes'){
      
   $phone_no = $profile['km_mobile'];
   
   $profile_name = $profile['km_name'];
   $profile_email = $profile['km_email'];
   
   $msgdata = "Your Profile has been viewed by {$user_name} ({$km_regcode}). Regarding this, if u need any info contact us 95000 90825. Visit: www.kanyadhaanam.com";
   $url_data="http://alerts.maxwellsms.com/api/v3/index.php";
   $parameters_data = "method=sms&api_key=Afebb28266bdbd1300d76c268f10f65b8&to=$phone_no&sender=KDMMAT&message=$msgdata&format=xml&flash=0";
   
   $ch_data = curl_init($url_data);
   curl_setopt($ch_data, CURLOPT_POST, 1);
   curl_setopt($ch_data, CURLOPT_POSTFIELDS, $parameters_data);
   curl_setopt($ch_data, CURLOPT_FOLLOWLOCATION, 1);
   curl_setopt($ch_data, CURLOPT_HEADER, 0);
   curl_setopt($ch_data, CURLOPT_RETURNTRANSFER, 1);
   $response_data = curl_exec($ch_data);
   
    if($profile_email){
   
   $msg= "<table>
        
        <p style='font-size: 18px;'>Dear {$profile_name},</p>
        
        <tr><td align='left' style='font-size: 17px;line-height: 1.5em;'>Thank You very much for your interest with KANYADHAANAM MATRIMONY</td></tr>
        <tr><td align='left' style='font-size: 17px;line-height: 1.5em;'>Your Profile has been viewed by <b>{$user_name} ({$km_regcode})</b>. Kindly upgrade your membership to view contact details of your matching profiles.</td></tr>
        </table>
        <br>
        <table>
        <tr style='font-size: 15px;line-height: 1.5em;'><td>Regards, </tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;'><td>KANYADHAANAM MATRIMONY - TEAM</tr></td>
        <tr style='font-size: 15px;line-height: 1.5em;'><td><a href='www.kanyadhaanam.com' target='_blank'>www.kanyadhaanam.com</a></tr></td>
        </table>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/call_icon.png' style=''> &nbsp;95000 90825</p>
        
        <p style='font-size: 18px;margin: 5px;'><img src='http://www.kanyadhaanam.com/images/whatsapp_icon.png' style=''> &nbsp;95000 90825</p>
        
        
        <div id='accordion-container' style='font-size: 11px;background: #ffffff;padding: 5px 10px 10px 10px;border: 1px solid #cccccc;;border-radius: 5px;box-shadow: 0 5px 15px #cccccc; width:70%;'>
        
        <h2 class='accordion-header active-header' style=' margin-top: 0px;border-radius: 5px 5px 0 0;background: url(http://www.kanyadhaanam.com/images/active-header.gif) #cef98d;background-repeat: no-repeat;margin: 5px 0 0 0;padding: 5px 20px;cursor: pointer;color: #e23f0c;'><img src='http://www.kanyadhaanam.com/images/lightbulb.png' width='40' style='vertical-align: middle;'>  Qns : How do I pay for Subscriptions?
        </h2>
        
        <div class='accordion-content open-content' style='width: 766px; display: block;padding: 10px;background: #ffffff;border: 1px solid #cccccc;border-top: 0;border-radius: 0 0 5px 5px;text-align: justify;width: auto;font-size: 16px;font-weight: normal;'>
         <p style='margin: 5px;'>You can pay for your subscriptions online through Credit Card / Debit Card / Net Banking / Cash Payments are accepted. Your subscription will be activated within 5 minutes after your successfull payment.</p>
        
        </div>
   
        <h2 class='accordion-header active-header' style=' margin-top: 0px;border-radius: 5px 5px 0 0;background: url(http://www.kanyadhaanam.com/images/active-header.gif) #cef98d;background-repeat: no-repeat;margin: 5px 0 0 0;padding: 5px 20px;cursor: pointer;color: #e23f0c;'><img src='http://www.kanyadhaanam.com/images/lightbulb.png' width='40' style='vertical-align: middle;'>  Qns : How soon will my membership be processed when I make payment?
        </h2>
   
        <div class='accordion-content open-content' style='width: 766px; display: block;padding: 10px;background: #ffffff;border: 1px solid #cccccc;border-top: 0;border-radius: 0 0 5px 5px;text-align: justify;width: auto;font-size: 16px;font-weight: normal;'>
         <p style='margin: 5px;'>Your subscription will be activated within 5 minutes after your successfull payment.</p>
        
        </div>
        
        ";
   
   $to = $profile_email;
   $subject = "Your Profile is viewed by {$user_name} ({$km_regcode})  in  KANYADHAANAM MATRIMONY";
   
   // Always set content-type when sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    
    // More headers
    $headers .= 'From: <support@kanyadhaanam.com>' . "\r\n";
    
    $send_mail = mail($to,$subject,$msg,$headers);
   
   }
   
   
   
   }
    
   
   ?>
<!DOCTYPE html>
<html>
   <head>
      <style type="text/css">
         #photo-area {
         float: none !important;
         text-align: center;
         }
      </style>
      <?php include("includes/headertop.php");?>
   </head>
   <body class="home color-green boxed shadow">
      
         <?php include("includes/headerin.php");?>
         <?php include("includes/bannerin.php");?>
         <?php //include("includes/quicksearch.php");?>
         <div class="root">
         <section class="content reverse">
         <?php include("includes/right.php");?>
            <section class="col-md-9 col-xs-12" style=" margin-top: 1%;">
               <table>
                  <tr class="tabletitle" >
                     <td colspan="2" style="  border-top-left-radius: 0.5em; border-top-right-radius: 0.5em;">Full Profile </td>
                  </tr>
               </table>
               <form method="post" id='search_result' action="">
                  <input type="hidden" id="submit_id" name="submit_id" value="" />
                  <input type="hidden" id="submit_flag" name="submit_flag" value="" />
                  <input type="hidden" id="profile_type" name="profile_type" value="" />
                  <input type="hidden" id="page_return" name="page_return" value="" />
                  <input type="hidden" id="interest_value" name="interest_value" value="" />
                  <div id="result-content">
                     <div id="result-box">
                        
                        <div id="result-box-top-middle">
                           <div class="profile-id-text-results"><?php echo $profile['km_name'];?>&nbsp;(<?php echo $profile['km_regcode'];?>)</div>
                           <div class="profile-id-text-results" style="width:100px;"> </div>
                        </div>
                        
                        <div class="spacer"></div>
                        <div id="result-box-content2">
                           <div id="photo-area">
                              <div class="photo-album">
                                 <div class="photo-content">
                                    <img src="data:image/jpeg;base64,<?php echo base64_encode($view_only_imgPath); ?>" width="auto" height="auto" alt="" style="border:0px; padding-top: 2px; max-width: 300px;">
                                 </div>
                              </div>
                              <div class="photo-text"  style="cursor:pointer;"></div>
                           </div>
                           <div class="spacer"></div>
                        </div>
                        
                        
                       
                        <div class="spacer"></div>
                     </div>
                     <div class="basic-info-title-box">
                        
                        <div id="info-3-title-middle">
                           <div class="full-profile-title-text-1">Basic Information</div>
                        </div>
                        <?php 
                           $from = new DateTime($profile['km_dateofbirth']);
                           $to   = new DateTime('today');
                           $age = $from->diff($to)->y;
                           $cur_Year = date("Y");
                           
                           ?>
                       
                        <div class="spacer"></div>
                        <div class="basic-information-box" style=" min-height:470px;">
                           <div class="profile-q">Name : </div>
                           <div class="profile-a"><span class="information-text">
                              <?php echo ucwords($profile['km_name']); ?> </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q-long">Caste :</div>
                           <div class="profile-a-small" style=""><span class="information-text">
                              <?php if($profile['km_caste']){ ?>
                              <?php echo ucwords($profile['km_caste']); ?> 
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q-long">Sub Caste :</div>
                           <div class="profile-a-small" style=""><span class="information-text">
                              <?php if($profile['km_subcaste']){ ?>
                              <?php echo ucwords($profile['km_subcaste']); ?> 
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q">Age : </div>
                           <div class="profile-a"><span class="information-text">
                              <?php if($age){ ?>
                              <?php if($age == $cur_Year){ echo 'N / A'; } else { echo $age.' Yrs'; } ?>
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q">D.O.B : </div>
                           <div class="profile-a">
                              <span class="information-text">
                              <?php if($profile['km_dateofbirth']){ ?>
                              <?php if($profile['km_dateofbirth'] == '0000-00-00'){ ?>
                              <?php echo 'N / A'; } else { ?>
                              <?php echo date_format(new DateTime($profile['km_dateofbirth']), 'd-m-Y'); ?> 
                              <?php } ?>
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q">Marital Status : </div>
                           <div class="profile-a"><span class="information-text">
                              <?php if($profile['km_marital_status']){ ?> 
                              <?php echo ucwords($profile['km_marital_status']); ?> 
                              <?php } else { echo 'N / A'; } ?> 
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q">Gender : </div>
                           <div class="profile-a"><span class="information-text">
                              <?php echo ucwords($profile['km_gender']); ?> </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q">Place of Birth : </div>
                           <div class="profile-a"><span class="information-text">
                              <?php if($profile['km_place_of_birth']){ ?>
                              <?php echo ucwords($profile['km_place_of_birth']); ?> 
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q">Order of Birth : </div>
                           <div class="profile-a"><span class="information-text">
                              <?php if($profile['km_order_of_birth']){ ?>
                              <?php echo ucwords($profile['km_order_of_birth']); ?> 
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q">Day of Birth : </div>
                           <div class="profile-a"><span class="information-text">
                              <?php if($profile['km_dayofbirth']){ ?>
                              <?php echo ucwords($profile['km_dayofbirth']); ?> 
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q">Time of Birth : </div>
                           <div class="profile-a"><span class="information-text">
                              <?php if($profile['km_birthtime']){ ?>
                              <?php echo ucwords($profile['km_birthtime']); ?> 
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q">
                              Height :
                           </div>
                           <div class="profile-a"><span class="information-text">
                              <?php if($profile['km_height']){ ?> 
                              <?php echo $profile['km_height']; ?> 
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q">
                              Weight :
                           </div>
                           <div class="profile-a"><span class="information-text">
                              <?php if($profile['km_weight']){ ?> 
                              <?php echo $profile['km_weight']; ?> 
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q">
                              Blood Group :
                           </div>
                           <div class="profile-a"><span class="information-text">
                              <?php if($profile['km_blood_group']){ ?> 
                              <?php if($profile['km_blood_group'] == 'donotknow'){ ?>
                              <?php echo "Don't Know"; ?> 
                              <?php } else { ?>
                              <?php echo $blood_array[$profile['km_blood_group']]; ?>
                              <?php } ?>
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q">
                              Physical status :
                           </div>
                           <div class="profile-a"><span class="information-text">
                              <?php if($profile['km_physical_status']){ ?> 
                              <?php echo $profile['km_physical_status']; ?> 
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q">
                              Languages Known :
                           </div>
                           <div class="profile-a"><span class="information-text">
                              <?php if($profile['km_languages']){ ?> 
                              <?php echo $profile['km_languages']; ?> 
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                        </div>
                     </div>
                     <div class="basic-info-title-box">
                        
                        <div id="info-3-title-middle">
                           <div class="full-profile-title-text">
                              Education &amp; Career
                           </div>
                        </div>
                       
                        <div class="spacer"></div>
                        <div class="basic-information-box" style=" height:220px;">
                           <BR />
                           <div class="profile-q">Education : </div>
                           <div class="profile-a"><span class="information-text">
                              <?php if($profile['km_education']){ ?> 
                              <?php echo $edu_array[$profile['km_education']]; ?> 
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q">Education Details: </div>
                           <div class="profile-a"><span class="information-text">
                              <?php if($profile['km_education_details']){ ?> 
                              <?php echo $profile['km_education_details']; ?> 
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q">Occupation : </div>
                           <div class="profile-a"><span class="information-text">
                              <?php 
                           if($profile['km_employee_in'] == 'notworking'){
                             echo 'Not Working';
                         } else {
                          if($profile['km_occupation']){ 
                          if($occupation){ 
                            echo $occupation['occupation']; } 
                            else { echo $profile['km_occupation']; }
                            } else { echo 'N / A'; } 
                         }
                            ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q">Occupation Details : </div>
                          <div class="profile-a"><span class="information-text">
                             <?php if($profile['km_company_name']){ ?> 
                             <?php echo $profile['km_company_name']; ?> 
                             <?php } else { echo 'N / A'; } ?>
                             </span>
                          </div>
                          <div class="spacer"></div>
                           <div class="profile-q">Employed in : </div>
                           <div class="profile-a"><span class="information-text">
                              <?php if($profile['km_employee_in']){ ?> 
                              <?php echo $profile['km_employee_in']; ?> 
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q">
                              Annual Income :
                           </div>
                           <div class="profile-a"><span class="information-text">
                              <?php if($profile['km_annual_income']){ ?> 
                              <?php echo $profile['km_annual_income']; ?> 
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                        </div>
                        <div class="basic-info-title-box">
                           
                           <div id="info-3-title-middle">
                              <div class="full-profile-title-text-1">Religious &amp; Social Background</div>
                           </div>
                          
                           <div class="spacer"></div>
                           <div class="basic-information-box" style=" min-height:250px;">
                              <div class="profile-q-long">House Name :</div>
                              <div class="profile-a-small"><span class="information-text">
                                 <?php if($profile['km_housename']){ ?>
                                 <?php echo ucwords($profile['km_housename']); ?>  
                                 <?php } else { echo 'N / A'; } ?>
                                 </span>
                              </div>
                              <div class="spacer"></div>
                              <div class="profile-q-long">Gothram :</div>
                              <div class="profile-a-small"><span class="information-text">
                                 <?php if($profile['km_gothram']){ ?>
                                 <?php echo ucwords($profile['km_gothram']); ?>
                                 <?php } else { echo 'N / A'; } ?>
                                 </span>
                              </div>
                              <div class="spacer"></div>
                              <div class="profile-q-long">Star :</div>
                              <div class="profile-a-small"><span class="information-text">
                                 <?php if($profile['km_star']){ ?>
                                 <?php echo ucwords($profile['km_star']); ?>
                                 <?php } else { echo 'N / A'; } ?>
                                 </span>
                              </div>
                              <div class="spacer"></div>
                              <div class="profile-q-long">Raasi :</div>
                              <div class="profile-a-small"><span class="information-text">
                                 <?php if($profile['km_rasi']){ ?>
                                 <?php echo ucwords($profile['km_rasi']); ?>
                                 <?php } else { echo 'N / A'; } ?>
                                 </span>
                              </div>
                              <div class="spacer"></div>
                              <div class="profile-q-long">Dosham :</div>
                              <div class="profile-a-small"><span class="information-text">
                                 <?php if($profile['km_dosham']){ 
                                    if($profile['km_dosham'] == 'yes'){
                                    if($profile['km_dosham_details'] == ''){
                                    ?>
                                 <?php echo ucwords($profile['km_dosham']); ?>
                                 <?php 
                                    } else { ?>
                                 <?php echo ucwords($profile['km_dosham_details']); ?>
                                 <?php
                                    }
                                    } else {
                                    ?>
                                 <?php echo ucwords($profile['km_dosham']); ?>
                                 <?php } }  else { echo 'N / A'; } ?>
                                 </span>
                              </div>
                              <div class="spacer"></div>
                              <div class="profile-q-long">Lagnam :</div>
                              <div class="profile-a-small"><span class="information-text">
                                 <?php if($profile['km_lagnam']){ ?>
                                 <?php echo ucwords($profile['km_lagnam']); ?>
                                 <?php } else { echo 'N / A'; } ?>
                                 </span>
                              </div>
                              <div class="spacer"></div>
                              <div class="profile-q-long">Thisai irrupu :</div>
                              <div class="profile-a-small"><span class="information-text">
                                 <?php if($profile['km_thisai_irrupu']){ ?>
                                 <?php echo ucwords($profile['km_thisai_irrupu']); ?> 
                                 <?php } else { echo 'N / A'; } ?>
                                 </span>
                              </div>
                              <div class="spacer"></div>
                           </div>
                        </div>
                     </div>
                     <div class="basic-info-title-box">
                        
                        <div id="info-3-title-middle">
                           <div class="full-profile-title-text-1">Family Information</div>
                        </div>
                       
                        <div class="spacer"></div>
                        <div class="basic-information-box" style=" min-height:200px;">
                           <div class="profile-q-long">Father's Name :</div>
                           <div class="profile-a-small" style=""><span class="information-text">
                              <?php if($profile['km_father_name']){ ?>
                              <?php echo ucwords($profile['km_father_name']); ?>
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q-long">Father's Professional :</div>
                           <div class="profile-a-small" style=""><span class="information-text">
                              <?php if($profile['km_father_occupation']){ ?>
                              <?php echo ucwords($profile['km_father_occupation']); ?>
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q-long">Mother's Name :</div>
                           <div class="profile-a-small" style=""><span class="information-text">
                              <?php if($profile['km_mother_name']){ ?>
                              <?php echo ucwords($profile['km_mother_name']); ?>
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           <div class="profile-q-long">Mother's Professional :</div>
                           <div class="profile-a-small" style=""><span class="information-text">
                              <?php if($profile['km_mother_ocupation']){ ?>
                              <?php echo ucwords($profile['km_mother_ocupation']); ?> 
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           <div class="spacer"></div>
                           
                              <div class="profile-q-long">Family Status :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                        <?php if($profile['km_family_status']){ ?>
                        <?php echo ucwords($profile['km_family_status']); ?> 
                        <?php } else { echo 'N / A'; } ?>
                        </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q-long">Family Type :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                        <?php if($profile['km_family_type']){ ?>
                        <?php echo ucwords($profile['km_family_type']); ?> 
                        <?php } else { echo 'N / A'; } ?>
                        </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q-long">Family Value :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                        <?php if($profile['km_family_value']){ ?>
                        <?php echo ucwords($profile['km_family_value']); ?> 
                        <?php } else { echo 'N / A'; } ?>
                        </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q-long" style="margin-top:2%">Unmarried Brother :</div>
                        <div class="profile-a-small" style="margin-top:2%;"><span class="information-text">
                        <?php if($profile['bcount'] == ''){ ?>
                        <?php echo 'N / A'; ?> 
                        <?php } else { echo $profile['bcount']; } ?>
                        </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q-long">Married Brother :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                        <?php if($profile['bmcount'] == ''){ ?>
                        <?php echo 'N / A'; ?> 
                        <?php } else { echo $profile['bmcount']; } ?>
                        </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q-long">Unmarried Sister :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                        <?php if($profile['scount'] == ''){ ?>
                        <?php echo 'N / A'; ?> 
                        <?php } else { echo $profile['scount']; } ?>
                        </span>
                        </div>
                        <div class="spacer"></div>
                        <div class="profile-q-long">Married Sister :</div>
                        <div class="profile-a-small" style=""><span class="information-text">
                        <?php if($profile['smcount'] == ''){ ?>
                        <?php echo 'N / A'; ?> 
                        <?php } else { echo $profile['smcount']; } ?>
                        </span>
                        </div>
                        <div class="spacer"></div>


                           <div class="profile-q-long">Native District :</div>
                           <div class="profile-a-small" style=""><span class="information-text">
                              <?php if($profile['km_native_district']){ ?>
                              <?php echo ucwords($profile['km_native_district']); ?> 
                              <?php } else { echo 'N / A'; } ?>
                              </span>
                           </div>
                           
                           <div class="spacer"></div>
                           <div class="spacer"></div>
                        </div>
                     </div>
                     <p>&nbsp;</p>
                  </div>
               </form>
            </section>
            
         </section>
         <div style=" clear: both;"></div>
          </div>
         <?php include("includes/footertop.php");?>
         <?php include("includes/footerin.php");?>
     
      <script>
         $(document).on('click', '.horoscope', function() {                  
             var service_id =  $(this).attr('id');
             $('#submit_id').val(service_id);
             $('#submit_flag').val('profile');  
             $('#profile_type').val('horoscope');               
             $('#search_result').attr('method', 'post');
             $('#search_result').attr('action', 'viewbasicprofile.php');
             $('#search_result').submit();
         });
         $(document).on('click', '.number', function() {                  
             var service_id =  $(this).attr('id');
             alert(service_id);
             $('#submit_id').val(service_id);
             $('#submit_flag').val('profile'); 
             $('#profile_type').val('contact'); 
             $('#search_result').attr('method', 'post');
             $('#search_result').attr('action', 'viewbasicprofile.php');
             $('#search_result').submit();
         });
      </script>
   </body>
</html>