<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
  $user_name = 'kalai';
   $user_code = '190313';
   $sms_phone = '95000 90825';
   
    $msgsend = "Your Profile has been viewed by {$user_name} ({$user_code}). Regarding this, if u need any info contact us 95000 90825. Visit: www.kanyadhaanam.com";
                  $url="http://alerts.maxwellsms.com/api/v3/index.php";
                  $parameters = "method=sms&api_key=Afebb28266bdbd1300d76c268f10f65b8&to=$sms_phone&sender=KDMMAT&message=$msgsend&format=xml&flash=0";
   
                  $ch = curl_init($url);
                  curl_setopt($ch, CURLOPT_POST, 1);
                  curl_setopt($ch, CURLOPT_POSTFIELDS, $parameters);
                  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                  curl_setopt($ch, CURLOPT_HEADER, 0);
                  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                  $response = curl_exec($ch);
   
   ?>
