<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   require_once 'KANyaMatrI_GST/includes/configure.php';
   require_once 'init.php';
   require_once 'includes/common_functions.php';
   require_once 'includes/pagination.php';
   require_once 'includes/db.php';
   require_once 'includes/session_handler.php';
   date_default_timezone_set('Asia/Kolkata');
   
   
$pv_viewedId = $_SESSION['pv_viewedId'];
//*********************** Profile Details *******************************
$profiles = new Registration();
$profiles = $profiles->fetch("WHERE km_regcode = '{$pv_viewedId}'")->resultSet();    
$profile = $profiles[0];
//*********************** Horoscope Details *******************************
$profileviewhoros = new Profile();
$profileviewhoros = $profileviewhoros->fetchHoroscope("WHERE hs_userId = '{$profile['km_regcode']}'")->resultSet();
$profileviewhoros = $profileviewhoros[0];
//*********************** Photo Details *******************************
$profile_viewphotos = new Profile();
$profile_viewphotos = $profile_viewphotos->fetchPhotos("WHERE pho_userId = '{$profile['km_regcode']}' AND pho_imgPath LIKE '%_profile_%'")->resultSet();
$profile_viewphoto = $profile_viewphotos[0];

if($profile_viewphoto['pho_imgPath']){
    $viewimgPath =  $profile_viewphoto['pho_imgPath'];

    $image_file = fopen($viewimgPath, 'r');
    $viewimgPath = fread($image_file, filesize($viewimgPath));
}else{
    if($profile['km_gender'] == 'male'){
        $viewimgPath = 'images/male.png';

        $image_file = fopen($viewimgPath, 'r');
        $viewimgPath = fread($image_file, filesize($viewimgPath));
    }else{
        $viewimgPath = 'images/female.png';

        $image_file = fopen($viewimgPath, 'r');
        $viewimgPath = fread($image_file, filesize($viewimgPath));
    }
     
}
   
   ?>
<!DOCTYPE html>
<html>
    <head>
        
        <style type="text/css">
     
     #result-box-content2{

      border: none !important;
     }
     
     #result-box-bottom-middle{

      background-image: none !important;
     }
     
     #result-box-bottom-left{
background-image: none !important;

     }
     
     #result-box-bottom-right{
       background-image: none !important;  
         
     }
     
     #result-content{

      height: 400px !important;
     }
     
     @media only screen and (max-width: 479px)
     
     {
     #result-content {
height: 700px !important;

     }
     
.maketop{

margin-top: 90px !important;

     }
}


   </style>

<?php include("includes/headertop.php");?>
</head>
    <body class="home color-green boxed shadow">
       
            <?php include("includes/headerin.php");?>
                

                   

                    <?php include("includes/bannerin.php");?>
                
                <?php //include("includes/quicksearch.php");?>

                 <div class="root">
                    <section class="content reverse">
                    <?php include("includes/right.php");?>
                        <section class="col-md-9 col-xs-12" style=" margin-top: 1%;">

                            <table>
                                <tr class="tabletitle" >
                                    <td colspan="2" style="  border-top-left-radius: 0.5em; border-top-right-radius: 0.5em;">Contact Details </td>
                                </tr>
                            </table>

                            <div id="result-content">
                                <div id="result-box">
                                    
                                    <div id="result-box-top-middle">
                                        <div class="profile-id-text"> Profile ID :</div>
                                        <div class="profile-id-text-results"><?php echo $profile['km_regcode'];?></div>
                                        <div class="profile-id-text-results" style="width:100px;"> </div>
                                    </div>
                                    
                                    <div class="spacer"></div>
                                    <div id="result-box-content2">
                                        <div id="photo-area">
                                            <div class="photo-album">
                                                <div class="photo-content">
                                                    <img src="data:image/jpeg;base64,<?php echo base64_encode($viewimgPath); ?>" width="130" height="130" alt="" style="border:0px;">
                                                </div>
                                            </div>

                                            <div class="photo-text"  style="cursor:pointer;"></div>
                                        </div>
                                        <div id="right-information" style="height: auto !important;">
                                            <div id="information-area-1q">
                                                <div class="information-text-title">Name : </div>
                                                <div class="information-text-title"> Age : </div>
                                                <div class="information-text-title"> D.O.B : </div>
                                                <div class="information-text-title"> Email ID : </div>  
                                   <div class="information-text-title"> Marital Status : </div> 
                                   <div class="information-text-title"> Native Place : </div> 
                                   <div class="information-text-title"> Address : </div> 
                                               
                                                
                                            </div>
                                            <div id="information-area-1a" style=" width:350px;">
                                                <div class="information-text" style="width:210px;">
                                                    <?php echo ucwords($profile['km_name']); ?></div>
                                                <?php 
                                                    $from = new DateTime($profile['km_dateofbirth']);
                                                    $to   = new DateTime('today');
                                                    $age = $from->diff($to)->y;
                                                    $cur_Year = date("Y");
                                                ?>
                                                <div class="information-text">
                                                <?php if($age){ ?>
                                            <?php if($age == $cur_Year){ echo 'N / A'; } else { echo $age.' Yrs'; } ?>
                                            <?php } else { echo 'N / A'; } ?>
                                                </div>

                                                <div class="information-text">
                                                <?php if($profile['km_dateofbirth']){ ?>
                                                <?php if($profile['km_dateofbirth'] == '0000-00-00'){ ?>
                                                <?php echo 'N / A'; } else { ?>
                                                <?php echo date_format(new DateTime($profile['km_dateofbirth']), 'd-m-Y'); ?> 
                                                <?php } ?>
                                                <?php } else { echo 'N / A'; } ?>
                                                </div>
                                        <div class="information-text" style="width:210px;">
                                            <?php if($profile['km_email']){ ?> 
                                            <?php echo $profile['km_email']; ?>
                                            <?php } else { echo 'N / A'; } ?> 
                                         </div>
                                          <div class="information-text" style="width:210px;">
                                    <?php if($profile['km_marital_status']){ ?> 
                              <?php echo ucwords($profile['km_marital_status']); ?> 
                              <?php } else { echo 'N / A'; } ?> 
                                 </div>
                                 
                                         <div class="information-text" style="width:210px;">
                                    <?php if($profile['km_native_place']){ ?> 
                              <?php echo ucwords($profile['km_native_place']); ?> 
                              <?php } else { echo 'N / A'; } ?> 
                                 </div>
                                 
                                 
                                    <div class="information-text" style="width:210px;">
                                    <?php if($profile['km_doorno']){ ?> 
                              <?php echo $profile['km_doorno']; ?>,  
                              <?php } ?> 
                              <?php if($profile['km_street']){ ?> 
                              <?php echo $profile['km_street']; ?>,  
                              <?php } ?> 
                              <?php if($profile['km_city']){ ?> 
                              <?php echo $profile['km_city']; ?>,  
                              <?php } ?> 
                              <?php if($profile['km_district']){ ?> 
                              <?php echo $profile['km_district']; ?>,  
                              <?php } ?> 
                              <?php if($profile['km_pincode']){ ?> 
                              <?php echo $profile['km_pincode']; ?>. 
                              <?php } ?> 
                                 </div>
                                 
                                 
                                 
                                               
                                            </div>
                                            <div id="information-area-2anew" class="maketop">
                                                <div style="padding-left:0px; font-size: 20px;">
                                                    <div style="padding-top:0px; width:280px; cursor:pointer; float: left;  color:#b10000; font-weight: bold;     line-height: 63px;">


                                                   <img src="images/man-user.png" width="32"> Contact Details<br>
                                                   <div style=" margin-left: 0%; line-height: 45px;">

                                                   <?php if($profile['km_mobile'] == '' && $profile['km_second_mobile'] == ''){ ?>
                                                   <span> Contact not available</span><br>
                                                   <?php } ?>
                                                   <?php if($profile['km_mobile']){ ?>
                                                   <span><img src="images/mobile.png" width="28" style="vertical-align: sub;">  <?php echo $profile['km_mobile']; ?></span><br>
                                                   <?php } ?>
                                                   <?php if($profile['km_second_mobile']){ ?>
                                                   <span><img src="images/mobile.png" width="28" style="vertical-align: sub;">  <?php echo $profile['km_second_mobile']; ?></span><br>
                                                   <?php } else if($profile['km_landline']){ ?>
                                                   <span ><img src="images/call.png" width="25" style="vertical-align: sub;" ><?php echo $profile['km_landline']; ?></span>
                                                   <?php } ?>

                                                   </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="spacer"></div>
                                        </div>
                                        <div class="spacer"></div>
                                    </div>
                                    
                                    <div class="spacer"></div>
                                </div>
                                <br>
  <div style=" border: solid 2px #fff;
    width: 95%;    background-color: #d90022;
    margin: 0px auto;
    margin-top: 20px;
    margin-bottom: 20px; padding-left:20px;">
<p style=" font-size: 18px; padding-top: 5px;color:#fff; padding-bottom: 10px;"> <img src="images/lightbulb.png" style="vertical-align: bottom;  width: 30px;"> Strictly Don't Share these details to any other persons by anymodes.
</p>

</div>
                               
                                <p>&nbsp;</p>
                            </div>

                        </section>

                        

                    </section>
                    <div style=" clear: both;"></div>
                     </div>

                    <?php include("includes/footertop.php");?>



                    <?php include("includes/footerin.php");?>
       
    </body>

</html>