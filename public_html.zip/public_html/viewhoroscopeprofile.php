<?php error_reporting(E_ALL &~(E_NOTICE | E_STRICT));?>
<?php 
   ob_start();
   session_start();
   require_once 'KANyaMatrI_GST/includes/configure.php';
   require_once 'init.php';
   require_once 'includes/common_functions.php';
   require_once 'includes/pagination.php';
   require_once 'includes/db.php';
   require_once 'includes/session_handler.php';
   date_default_timezone_set('Asia/Kolkata');
   
   
$pv_viewedId = $_SESSION['pv_viewedId'];
//*********************** Profile Details *******************************
$profiles = new Registration();
$profiles = $profiles->fetch("WHERE km_regcode = '{$pv_viewedId}'")->resultSet();    
$profile = $profiles[0];
//*********************** Horoscope Details *******************************
$profileviewhoros = new Profile();
$profileviewhoros = $profileviewhoros->fetchHoroscope("WHERE hs_userId = '{$profile['km_regcode']}'")->resultSet();
$profileviewhoros = $profileviewhoros[0];
//*********************** Photo Details *******************************
$profile_viewphotos = new Profile();
$profile_viewphotos = $profile_viewphotos->fetchPhotos("WHERE pho_userId = '{$profile['km_regcode']}' AND pho_imgPath LIKE '%_profile_%'")->resultSet();
$profile_viewphoto = $profile_viewphotos[0];

if($profile_viewphoto['pho_imgPath']){
    $viewimgPath =  $profile_viewphoto['pho_imgPath'];

    $image_file = fopen($viewimgPath, 'r');
    $viewimgPath = fread($image_file, filesize($viewimgPath));
}else{
    if($profile['km_gender'] == 'male'){
        $viewimgPath = 'images/male.png';

        $image_file = fopen($viewimgPath, 'r');
        $viewimgPath = fread($image_file, filesize($viewimgPath));
    }else{
        $viewimgPath = 'images/female.png';

        $image_file = fopen($viewimgPath, 'r');
        $viewimgPath = fread($image_file, filesize($viewimgPath));
    }
     
}
   
   ?>
<!DOCTYPE html>
<html>
    <head>
<?php include("includes/headertop.php");?>
</head>
    <body class="home color-green boxed shadow">
        
            <?php include("includes/headerin.php");?>
                

                    

                    <?php include("includes/bannerin.php");?>
                
                <?php //include("includes/quicksearch.php");?>

                <div class="root">
                    <section class="content reverse">
                     <?php include("includes/right.php");?>
                        <section class="col-md-9 col-xs-12" style=" margin-top: 1%;">

                            <table>
                                <tr class="tabletitle" >
                                    <td colspan="2" style="  border-top-left-radius: 0.5em; border-top-right-radius: 0.5em;">Horoscope </td>
                                </tr>
                            </table>

                            <div id="result-content">
                                <div class="basic-info-title-box">
                                  
                                    <div style="  border-style: solid;border-width: 1px;border-color: #99f381;">                                        
                                    <div>
                                        <?php 
                                        if($profileviewhoros['hs_imgPath']){

                                            $horosImgPath =  $profileviewhoros['hs_imgPath'];
                                            $image_file = fopen($horosImgPath, 'r');
                                            $horosImgPath = fread($image_file, filesize($horosImgPath));

                                        ?>
                                        <img style='width:100%' src="data:image/jpeg;base64,<?php echo base64_encode($horosImgPath); ?>"></div>
                                        <?php }else{ ?>
                                        <p style="text-align: center;color:red;">Horoscope not available</p>
                                        <?php } ?>
                                    </div>
                                </div>
                                
                                <p>&nbsp;</p>
                            </div>

                        </section>

                       

                    </section>
                    <div style=" clear: both;"></div>

                    </div>

                    <?php include("includes/footertop.php");?>



                    <?php include("includes/footerin.php");?>
        
    </body>

</html>